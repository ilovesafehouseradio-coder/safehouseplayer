plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.radioplayer"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.radioplayer"
        minSdk = 26
        targetSdk = 34
        versionCode = 86
        versionName = "1.85"
    }

    // A fixed signing key, kept in the project, so every build is signed the same way.
    // That is what lets a new APK install over the top of the old one (no uninstalling).
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("safehouse-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")

    implementation(platform("androidx.compose:compose-bom:2024.09.02"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")

    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")

    // Chromecast: lets the radio play on speakers / TVs with Google Cast
    implementation("androidx.media3:media3-cast:1.4.1")
    implementation("androidx.mediarouter:mediarouter:1.7.0")
    implementation("androidx.appcompat:appcompat:1.7.0")

    // Loads the DJ artwork from the web
    implementation("io.coil-kt:coil-compose:2.7.0")

    // Show reminders: re-reads the calendar in the background every few hours
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // Background loading of the DJ list
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
