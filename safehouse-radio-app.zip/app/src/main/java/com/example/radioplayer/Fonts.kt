package com.example.radioplayer

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/**
 * Poppins, the same font family as the station's web player.
 * The font files live in app/src/main/res/font (licence: FONT-LICENSE.txt).
 */
val Poppins = FontFamily(
    Font(R.font.poppins_light, FontWeight.Light),
    Font(R.font.poppins_regular, FontWeight.Normal),
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_bold, FontWeight.Bold)
)

private val defaults = Typography()

/** The app's standard text styles, all switched over to Poppins. */
val RadioTypography = Typography(
    displayLarge = defaults.displayLarge.copy(fontFamily = Poppins),
    displayMedium = defaults.displayMedium.copy(fontFamily = Poppins),
    displaySmall = defaults.displaySmall.copy(fontFamily = Poppins),
    headlineLarge = defaults.headlineLarge.copy(fontFamily = Poppins),
    headlineMedium = defaults.headlineMedium.copy(fontFamily = Poppins),
    headlineSmall = defaults.headlineSmall.copy(fontFamily = Poppins),
    titleLarge = defaults.titleLarge.copy(fontFamily = Poppins),
    titleMedium = defaults.titleMedium.copy(fontFamily = Poppins),
    titleSmall = defaults.titleSmall.copy(fontFamily = Poppins),
    bodyLarge = defaults.bodyLarge.copy(fontFamily = Poppins),
    bodyMedium = defaults.bodyMedium.copy(fontFamily = Poppins),
    bodySmall = defaults.bodySmall.copy(fontFamily = Poppins),
    labelLarge = defaults.labelLarge.copy(fontFamily = Poppins),
    labelMedium = defaults.labelMedium.copy(fontFamily = Poppins),
    labelSmall = defaults.labelSmall.copy(fontFamily = Poppins)
)
