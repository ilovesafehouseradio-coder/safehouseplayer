package com.example.radioplayer

import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/*
 * THE CARD: part of the theme kit (with Theme.kt for colours, ScreenLayout for sizes, AppType for text and Lift.kt
 * for edges). Every card in the app is made with Modifier.kitCard(), so a card looks and lines up the same wherever
 * it is put:
 *  - the same rounded corners ([CardShape]), card colour, thin edge, and the glow only when it can be tapped;
 *  - the same padding inside (ScreenLayout.cardPad(), scaled from the flagship), so the writing starts in one line
 *    all the way down a page;
 *  - extras (the coloured strip down the left, a highlight outline, a warning edge) sit inside that padding or on
 *    the card's edge: they never push the picture or the writing out of line;
 *  - a picture on the left uses Modifier.cardPicture() (round) or Modifier.featuredPicture() (the On Air card's
 *    square), then CardPictureGap() before the writing;
 *  - whatever sits on the left (a picture, or a step number made with StepBadge) is laid out with CardWithLeading:
 *    the title, the writing and any button all start on one line beside it, never back under it;
 *  - a step number sits level with the first line of the title (StepTitle), however many lines the title takes;
 *  - the writing uses AppType: CardTime for the time, CardName for the DJ, ShowName for the show, Sub for notes.
 *
 * Not cards (they have their own rules): pills and buttons, the pop-up panels ("Safehouse says…" and dialogs), the
 * DJ photo tiles on the DJs tab, the mini player, the slim "Next:" strip on the Radio tab and the game's score tiles.
 */

/** The corners of every card. */
val CardShape = RoundedCornerShape(16.dp)

/** The coloured strip down the left of a featured card (Up Next, Next show). It sits inside the padding. */
val CardStripWidth = 4.dp

/**
 * Makes this the app's card. Put it after any size or outer spacing (fillMaxWidth, the gap below) and before nothing
 * else: it adds the edge, the colour, the tap, and the padding inside, in the right order.
 *
 * @param fill the card colour (the standard see-through card unless a card is special, like the On Air card).
 * @param tappable true when the card does something on a tap (it then gets the faint glow).
 * @param onClick what a tap does (null = nothing).
 * @param strip the colour of the strip down the left, or null for none.
 * @param highlight a 2 dp outline in the main colour (the show on air now, or reminders on).
 * @param glow the soft glow round a card with reminders on.
 * @param warning a special edge colour instead of the standard one (the amber "reminders are blocked" card).
 * @param rows true for a card made of full-width tappable rows (settings): the rows carry the side padding
 *             themselves (ScreenLayout.cardPad()), so a tap lights up the whole row; the card keeps a little above and below.
 * @param endPad the padding on the right when icon buttons sit in a strip down the right edge.
 * @param tuckTop for content with its own space above the first line (switch rows): taken off the top padding so the
 *                first line still starts one card padding in.
 */
@Composable
fun Modifier.kitCard(
    fill: Color = CardSurface,
    tappable: Boolean = false,
    onClick: (() -> Unit)? = null,
    onClickLabel: String? = null,
    strip: Color? = null,
    highlight: Boolean = false,
    glow: Boolean = false,
    warning: Color? = null,
    rows: Boolean = false,
    endPad: Dp? = null,
    tuckTop: Dp = 0.dp
): Modifier {
    val pad = ScreenLayout.cardPad()
    var m = this.followedGlow(CardShape, glow)
    m = if (warning == null) m.lift(CardShape, tappable = tappable, fill = fill) else m
    m = m.clip(CardShape).background(fill)
    if (strip != null) m = m.drawBehind { drawRect(strip, size = Size(CardStripWidth.toPx(), size.height)) }
    if (highlight) m = m.border(2.dp, FollowedEdge, CardShape)
    if (warning != null) m = m.border(EdgeWidth, warning, CardShape)
    if (onClick != null) m = m.clickable(onClickLabel = onClickLabel, role = Role.Button, onClick = onClick)
    return if (rows) {
        m.padding(vertical = 6.dp)
    } else {
        m.padding(start = pad, top = (pad - tuckTop).coerceAtLeast(0.dp), end = endPad ?: pad, bottom = pad)
    }
}

/** The round picture on the left of a card: the kit size, a circle, the soft picture edge. */
@Composable
fun Modifier.cardPicture(onLight: Boolean = false): Modifier =
    this.size(ScreenLayout.cardPicture()).clip(CircleShape).border(EdgeWidth, pictureEdge(onLight), CircleShape)

/** The bigger square picture on a featured card (On Air): the kit size, rounded corners, the soft picture edge. */
@Composable
fun Modifier.featuredPicture(onLight: Boolean = false): Modifier =
    this.size(ScreenLayout.featuredPicture()).clip(FeaturedPictureShape).border(EdgeWidth, pictureEdge(onLight), FeaturedPictureShape)

private val FeaturedPictureShape = RoundedCornerShape(12.dp)

/** The gap between a card's picture and its writing. */
@Composable
fun CardPictureGap() {
    Spacer(Modifier.width(ScreenLayout.pictureGap()))
}

/**
 * A card's contents with something on the left (a picture or a step number) and everything else in one column beside
 * it, so the title, the writing and any button all start on the same line. [centred] = true puts the left-hand thing
 * level with the middle of the column (show cards); false puts it level with the first line (step cards).
 */
@Composable
fun CardWithLeading(
    leading: @Composable () -> Unit,
    centred: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    Row(verticalAlignment = if (centred) Alignment.CenterVertically else Alignment.Top) {
        leading()
        CardPictureGap()
        Column(Modifier.weight(1f), content = content)
    }
}

// A step's number and its title share one line height, so the number sits level with the title's first line at any
// text size the phone uses.
private val StepLine = 26.sp

/** The round number on a step card (a gold tick once the step is done). */
@Composable
fun StepBadge(number: Int, done: Boolean) {
    val pal = ThemeState.current
    val size = with(LocalDensity.current) { StepLine.toDp() }
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(if (done) pal.live else pal.primary),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (done) "✓" else number.toString(),
            color = pal.background,
            fontSize = AppType.Pill,
            fontWeight = FontWeight.Bold,
            style = tightStyle(StepLine)
        )
    }
}

/** A step card's title: its first line is exactly as tall as the StepBadge beside it. */
@Composable
fun StepTitle(text: String) {
    Text(
        text = text,
        color = ThemeState.current.text,
        fontSize = AppType.RowLabel,
        fontWeight = FontWeight.Bold,
        style = tightStyle(StepLine)
    )
}

/**
 * A big line of writing that always stays on one line (the game's banners, "Big up <DJ>!"): it starts at [maxSize]
 * and shrinks, a step at a time, until it fits the space it has, never below [minSize] (anything still too long then
 * ends in "…"). Two lines of big bold writing can sit on top of each other, so these never wrap.
 */
@Composable
fun FitOneLine(
    text: String,
    color: Color,
    maxSize: androidx.compose.ui.unit.TextUnit,
    minSize: androidx.compose.ui.unit.TextUnit = 16.sp,
    fontWeight: FontWeight = FontWeight.Bold,
    modifier: Modifier = Modifier
) {
    val measurer = androidx.compose.ui.text.rememberTextMeasurer()
    androidx.compose.foundation.layout.BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val room = constraints.maxWidth
        val base = androidx.compose.material3.LocalTextStyle.current.copy(fontWeight = fontWeight)
        var size = maxSize.value
        while (size > minSize.value) {
            val w = measurer.measure(text, base.copy(fontSize = size.sp), maxLines = 1, softWrap = false).size.width
            if (w <= room) break
            size -= 1f
        }
        Text(
            text = text,
            color = color,
            fontSize = size.coerceAtLeast(minSize.value).sp,
            fontWeight = fontWeight,
            maxLines = 1,
            softWrap = false,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}
