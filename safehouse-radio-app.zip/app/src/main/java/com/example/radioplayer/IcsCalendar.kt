package com.example.radioplayer

import java.time.DayOfWeek
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

/** One entry in the calendar, with repeating shows already worked out into single dated entries. */
data class CalendarEvent(
    val start: Instant,
    val end: Instant,
    val summary: String,
    val description: String,
    val allDay: Boolean
)

/**
 * Reads a Google Calendar "iCal" (.ics) file and turns it into a plain list of dated events.
 * Handles weekly / monthly / daily / yearly repeats, skipped dates, and one-off changes to a
 * single night of a repeating show. Uses only java.time, so it has no Android parts.
 */
object IcsCalendar {

    private val LOCAL_FMT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss")
    private val DATE_FMT: DateTimeFormatter = DateTimeFormatter.BASIC_ISO_DATE
    private val LONDON: ZoneId = ZoneId.of("Europe/London")
    private val TZID_REGEX = Regex("TZID=([^;:]+)")
    private val BYDAY_REGEX = Regex("^([+-]?\\d+)?(MO|TU|WE|TH|FR|SA|SU)$")

    private val NEEDED = setOf(
        "DTSTART", "DTEND", "RRULE", "EXDATE", "UID", "RECURRENCE-ID", "SUMMARY", "DESCRIPTION", "STATUS"
    )

    private class Prop(val params: String, val value: String)

    private class Raw {
        val props = HashMap<String, MutableList<Prop>>()
        fun first(name: String): Prop? = props[name]?.firstOrNull()
        fun all(name: String): List<Prop> = props[name] ?: emptyList()
    }

    private class Moment(val local: LocalDateTime, val zone: ZoneId, val allDay: Boolean) {
        val instant: Instant get() = local.atZone(zone).toInstant()
    }

    private class Rule(
        val freq: String,
        val interval: Int,
        val count: Int?,
        val until: LocalDateTime?,
        val byDay: List<Pair<Int, DayOfWeek>>,
        val byMonthDay: List<Int>,
        val weekStart: DayOfWeek
    )

    /** All events that overlap the period [from, to), in time order. */
    fun parse(text: String, from: Instant, to: Instant): List<CalendarEvent> {
        val raws = readEvents(unfold(keepRelevant(text, from, to)))

        // Nights of a repeating show that were changed or cancelled individually.
        val replaced = HashSet<String>()
        for (r in raws) {
            val rid = r.first("RECURRENCE-ID") ?: continue
            val uid = r.first("UID")?.value ?: continue
            val m = moment(rid) ?: continue
            replaced.add(uid + "|" + m.instant.toEpochMilli())
        }

        val result = ArrayList<CalendarEvent>()
        for (r in raws) {
            val s = moment(r.first("DTSTART") ?: continue) ?: continue
            val e = r.first("DTEND")?.let { moment(it) }
            val startInstant = s.instant
            var endInstant = e?.instant
                ?: if (s.allDay) s.local.plusDays(1).atZone(s.zone).toInstant() else startInstant
            // Length on the clock face (a 00:00-12:00 show stays 12 hours long on the night the clocks change).
            var wallLength = if (e != null) Duration.between(s.local, e.local) else Duration.between(startInstant, endInstant)
            // A slot typed in with no end time (or an end that isn't after its start) is given an hour,
            // so it still counts as on air and shows up in the schedule.
            if (!s.allDay && !endInstant.isAfter(startInstant)) {
                endInstant = startInstant.plus(Duration.ofHours(1))
                wallLength = Duration.ofHours(1)
            }

            val status = r.first("STATUS")?.value?.trim()?.uppercase()
            if (status == "CANCELLED") continue

            val summary = unescape(r.first("SUMMARY")?.value ?: "")
            val description = unescape(r.first("DESCRIPTION")?.value ?: "")
            val ruleProp = r.first("RRULE")
            val isChange = r.first("RECURRENCE-ID") != null

            val rule = if (ruleProp != null && !isChange) parseRule(ruleProp.value, s.zone) else null
            if (rule == null) {
                if (endInstant.isAfter(from) && startInstant.isBefore(to)) {
                    result.add(CalendarEvent(startInstant, endInstant, summary, description, s.allDay))
                }
                continue
            }

            val uid = r.first("UID")?.value ?: ""
            val skipped = HashSet<Long>()
            for (p in r.all("EXDATE")) {
                for (v in p.value.split(',')) {
                    moment(Prop(p.params, v))?.let { skipped.add(it.instant.toEpochMilli()) }
                }
            }
            val windowEnd = to.atZone(s.zone).toLocalDateTime()
            for (local in occurrences(s.local, rule, windowEnd)) {
                val st = local.atZone(s.zone).toInstant()
                val en = local.plus(wallLength).atZone(s.zone).toInstant()
                if (!en.isAfter(from) || !st.isBefore(to)) continue
                val ms = st.toEpochMilli()
                if (ms in skipped) continue
                if (replaced.contains(uid + "|" + ms)) continue
                result.add(CalendarEvent(st, en, summary, description, s.allDay))
            }
        }
        result.sortWith(compareBy({ it.start }, { it.summary }))
        return result
    }

    // -- reading the file ----------------------------------------------------

    private const val EVENT_BEGIN = "BEGIN:VEVENT"
    private const val EVENT_END = "END:VEVENT"

    /**
     * The calendar file holds every show ever entered, so most of it is long finished. This cuts
     * the text down to the entries that could matter for [from, to) before the slow part starts.
     * An entry is dropped only when its dates are clearly (more than a day, to allow for time
     * zones) outside the period, a repeating one has finished repeating before the period, or a
     * one-night change belongs to a night outside the period. Anything it can't read with
     * certainty is kept, so it never loses a show.
     */
    internal fun keepRelevant(text: String, from: Instant, to: Instant): String {
        val lo = DATE_FMT.format(from.atZone(ZoneOffset.UTC).toLocalDate().minusDays(2))
        val hi = DATE_FMT.format(to.atZone(ZoneOffset.UTC).toLocalDate().plusDays(2))
        val out = StringBuilder(minOf(text.length, 1 shl 20))
        var pos = 0
        while (true) {
            var b = text.indexOf(EVENT_BEGIN, pos)
            // Only a real line start counts, not those words inside some show's description.
            while (b > 0 && text[b - 1] != '\n') b = text.indexOf(EVENT_BEGIN, b + 1)
            if (b < 0) break
            val e = text.indexOf(EVENT_END, b)
            if (e < 0) {
                out.append(text, b, text.length)
                break
            }
            val end = e + EVENT_END.length
            if (isRelevant(text.substring(b, e), lo, hi)) out.append(text, b, end).append('\n')
            pos = end
        }
        return out.toString()
    }

    private fun isRelevant(block: String, lo: String, hi: String): Boolean {
        val start = dateOf(block, "\nDTSTART") ?: return true
        val end = dateOf(block, "\nDTEND") ?: start
        // Falls (even partly) inside the period: needed.
        if (!(end < lo || start > hi)) return true
        if (block.contains("\nRDATE") || block.contains("RANGE=")) return true

        // A change to one night of a repeating show: needed only if that night, or the night it
        // was moved to (checked above), is in the period.
        if (block.contains("\nRECURRENCE-ID")) {
            val night = dateOf(block, "\nRECURRENCE-ID") ?: return true
            return night >= lo && night <= hi
        }

        // A repeating show: needed unless it hasn't started yet or has finished repeating.
        val rule = block.indexOf("\nRRULE")
        if (rule >= 0) {
            if (start > hi) return false
            val lineEnd = block.indexOf('\n', rule + 1).let { if (it < 0) block.length else it }
            val u = block.indexOf("UNTIL=", rule)
            if (u in 0 until lineEnd && u + 14 <= lineEnd) {
                val until = block.substring(u + 6, u + 14)
                if (until.all { it in '0'..'9' } && until < lo) return false
            }
            return true
        }

        // A single, ordinary entry outside the period.
        return false
    }

    /** The yyyyMMdd of a DTSTART / DTEND / RECURRENCE-ID line, or null if it isn't in the usual shape. */
    private fun dateOf(block: String, name: String): String? {
        val i = block.indexOf(name)
        if (i < 0) return null
        val lineEnd = block.indexOf('\n', i + 1).let { if (it < 0) block.length else it }
        val colon = block.indexOf(':', i)
        if (colon < 0 || colon + 9 > lineEnd) return null
        val d = block.substring(colon + 1, colon + 9)
        return if (d.all { it in '0'..'9' }) d else null
    }

    /** Long lines in .ics files are split over several lines; join them back together. */
    private fun unfold(text: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var has = false
        for (raw in text.lineSequence()) {
            if (raw.isNotEmpty() && (raw[0] == ' ' || raw[0] == '\t')) {
                sb.append(raw, 1, raw.length)
            } else {
                if (has) out.add(sb.toString())
                sb.setLength(0)
                sb.append(raw)
                has = true
            }
        }
        if (has) out.add(sb.toString())
        return out
    }

    private fun readEvents(lines: List<String>): List<Raw> {
        val events = ArrayList<Raw>()
        var cur: Raw? = null
        for (line in lines) {
            if (line == "BEGIN:VEVENT") {
                cur = Raw()
            } else if (line == "END:VEVENT") {
                cur?.let { events.add(it) }
                cur = null
            } else if (cur != null) {
                val colon = line.indexOf(':')
                if (colon <= 0) continue
                val head = line.substring(0, colon)
                val semi = head.indexOf(';')
                val name = (if (semi >= 0) head.substring(0, semi) else head).uppercase()
                if (name !in NEEDED) continue
                val params = if (semi >= 0) head.substring(semi + 1) else ""
                cur.props.getOrPut(name) { ArrayList() }.add(Prop(params, line.substring(colon + 1)))
            }
        }
        return events
    }

    private fun unescape(s: String): String {
        if (!s.contains('\\')) return s
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (val n = s[i + 1]) {
                    'n', 'N' -> sb.append('\n')
                    else -> sb.append(n)
                }
                i += 2
            } else {
                sb.append(c)
                i++
            }
        }
        return sb.toString()
    }

    // -- dates and times -----------------------------------------------------

    private fun zoneOf(id: String?): ZoneId =
        try {
            if (id == null) LONDON else ZoneId.of(id.trim('"'))
        } catch (e: Exception) {
            LONDON
        }

    private fun moment(p: Prop): Moment? =
        try {
            val v = p.value.trim()
            val tzid = TZID_REGEX.find(p.params)?.groupValues?.get(1)
            when {
                !v.contains('T') ->
                    Moment(LocalDate.parse(v.substring(0, 8), DATE_FMT).atStartOfDay(), zoneOf(tzid), true)

                v.endsWith("Z") -> {
                    // Written in UTC: work in London time, which is how the shows are planned.
                    val utc = LocalDateTime.parse(v.dropLast(1), LOCAL_FMT).atZone(ZoneOffset.UTC)
                    Moment(utc.withZoneSameInstant(LONDON).toLocalDateTime(), LONDON, false)
                }

                else -> Moment(LocalDateTime.parse(v, LOCAL_FMT), zoneOf(tzid), false)
            }
        } catch (e: Exception) {
            null
        }

    // -- repeating shows -----------------------------------------------------

    private fun parseRule(value: String, zone: ZoneId): Rule? {
        val parts = HashMap<String, String>()
        for (part in value.split(';')) {
            val i = part.indexOf('=')
            if (i > 0) parts[part.substring(0, i).uppercase()] = part.substring(i + 1)
        }
        val freq = parts["FREQ"]?.uppercase() ?: return null
        if (freq != "DAILY" && freq != "WEEKLY" && freq != "MONTHLY" && freq != "YEARLY") return null

        val until: LocalDateTime? = parts["UNTIL"]?.let { u ->
            try {
                when {
                    u.endsWith("Z") ->
                        LocalDateTime.parse(u.dropLast(1), LOCAL_FMT).atZone(ZoneOffset.UTC)
                            .withZoneSameInstant(zone).toLocalDateTime()

                    u.contains('T') -> LocalDateTime.parse(u, LOCAL_FMT)
                    else -> LocalDate.parse(u, DATE_FMT).atTime(23, 59, 59)
                }
            } catch (e: Exception) {
                null
            }
        }

        val byDay = ArrayList<Pair<Int, DayOfWeek>>()
        parts["BYDAY"]?.split(',')?.forEach { token ->
            val m = BYDAY_REGEX.find(token.trim().uppercase()) ?: return@forEach
            val n = m.groupValues[1].replace("+", "").ifEmpty { "0" }.toInt()
            byDay.add(n to dayOf(m.groupValues[2]))
        }
        val byMonthDay = parts["BYMONTHDAY"]?.split(',')?.mapNotNull { it.trim().toIntOrNull() } ?: emptyList()

        return Rule(
            freq = freq,
            interval = (parts["INTERVAL"]?.toIntOrNull() ?: 1).coerceAtLeast(1),
            count = parts["COUNT"]?.toIntOrNull(),
            until = until,
            byDay = byDay,
            byMonthDay = byMonthDay,
            weekStart = parts["WKST"]?.let { dayOf(it.uppercase()) } ?: DayOfWeek.MONDAY
        )
    }

    private fun dayOf(code: String): DayOfWeek = when (code) {
        "MO" -> DayOfWeek.MONDAY
        "TU" -> DayOfWeek.TUESDAY
        "WE" -> DayOfWeek.WEDNESDAY
        "TH" -> DayOfWeek.THURSDAY
        "FR" -> DayOfWeek.FRIDAY
        "SA" -> DayOfWeek.SATURDAY
        else -> DayOfWeek.SUNDAY
    }

    /** The nth (or, if n is negative, nth-from-last) given weekday of a month, or null if there isn't one. */
    private fun nthWeekday(ym: YearMonth, n: Int, dow: DayOfWeek): LocalDate? {
        val d = if (n > 0) {
            ym.atDay(1).with(TemporalAdjusters.nextOrSame(dow)).plusWeeks((n - 1).toLong())
        } else {
            ym.atEndOfMonth().with(TemporalAdjusters.previousOrSame(dow)).minusWeeks((-n - 1).toLong())
        }
        return if (YearMonth.from(d) == ym) d else null
    }

    /** Every start time of a repeating show, from its first night up to [windowEnd]. */
    private fun occurrences(start: LocalDateTime, rule: Rule, windowEnd: LocalDateTime): List<LocalDateTime> {
        val time = start.toLocalTime()
        val startDate = start.toLocalDate()
        val limit: LocalDateTime = rule.until?.let { if (it.isBefore(windowEnd)) it else windowEnd } ?: windowEnd
        val limitDate = limit.toLocalDate()
        val dates = ArrayList<LocalDate>()
        var guard = 0

        when (rule.freq) {
            "DAILY" -> {
                var d = startDate
                while (!d.isAfter(limitDate) && guard++ < 20000) {
                    dates.add(d)
                    d = d.plusDays(rule.interval.toLong())
                }
            }

            "WEEKLY" -> {
                fun offset(dw: DayOfWeek) = (dw.value - rule.weekStart.value + 7) % 7
                val days = (if (rule.byDay.isEmpty()) listOf(startDate.dayOfWeek) else rule.byDay.map { it.second })
                    .distinct().sortedBy { offset(it) }
                var weekStart = startDate.minusDays(offset(startDate.dayOfWeek).toLong())
                while (!weekStart.isAfter(limitDate) && guard++ < 5000) {
                    for (dw in days) {
                        val d = weekStart.plusDays(offset(dw).toLong())
                        if (!d.isBefore(startDate) && !d.isAfter(limitDate)) dates.add(d)
                    }
                    weekStart = weekStart.plusWeeks(rule.interval.toLong())
                }
            }

            "MONTHLY" -> {
                var ym = YearMonth.from(startDate)
                while (!ym.atDay(1).isAfter(limitDate) && guard++ < 2000) {
                    val inMonth = java.util.TreeSet<LocalDate>()
                    if (rule.byDay.isNotEmpty()) {
                        for ((n, dow) in rule.byDay) {
                            if (n == 0) {
                                var d = ym.atDay(1).with(TemporalAdjusters.nextOrSame(dow))
                                while (YearMonth.from(d) == ym) {
                                    inMonth.add(d)
                                    d = d.plusWeeks(1)
                                }
                            } else {
                                nthWeekday(ym, n, dow)?.let { inMonth.add(it) }
                            }
                        }
                    } else if (rule.byMonthDay.isNotEmpty()) {
                        for (md in rule.byMonthDay) {
                            val dom = if (md > 0) md else ym.lengthOfMonth() + md + 1
                            if (dom in 1..ym.lengthOfMonth()) inMonth.add(ym.atDay(dom))
                        }
                    } else if (startDate.dayOfMonth <= ym.lengthOfMonth()) {
                        inMonth.add(ym.atDay(startDate.dayOfMonth))
                    }
                    for (d in inMonth) {
                        if (!d.isBefore(startDate) && !d.isAfter(limitDate)) dates.add(d)
                    }
                    ym = ym.plusMonths(rule.interval.toLong())
                }
            }

            else -> { // YEARLY
                var year = startDate.year
                while (year <= limitDate.year && guard++ < 500) {
                    try {
                        val d = LocalDate.of(year, startDate.month, startDate.dayOfMonth)
                        if (!d.isBefore(startDate) && !d.isAfter(limitDate)) dates.add(d)
                    } catch (e: Exception) {
                        // 29 February in a year without one: skip
                    }
                    year += rule.interval
                }
            }
        }

        var result = dates.map { it.atTime(time) }.filter { !it.isAfter(limit) }
        val count = rule.count
        if (count != null && result.size > count) result = result.take(count)
        return result
    }
}
