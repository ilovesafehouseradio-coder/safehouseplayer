package com.example.radioplayer

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.LocalContext

/** The warm amber of the "live" glow, like an on-air lamp. */
private val PulseColor = Color(0xFFFFB048)

/**
 * A slow, steady glow behind a card or picture that fades up and down, like the rings round the play button
 * (one full breath is about 2.6 seconds). It comes from behind: only the glow outside the edge shows, the card
 * or picture itself is never tinted.
 *
 * Does nothing when [on] is false, and does nothing when "Reduce animations" is on (the switch on the More tab,
 * or the phone's own setting). It is plain Compose drawing, so it works on every Android version, and it only
 * runs while the thing it is on is on screen and the app is open.
 *
 * Put it after the shadow or .lift() and before .clip() / .background(), with the same [shape]:
 *     Modifier.lift(shape).pulseGlow(shape, on = true).clip(shape).background(...)
 */
fun Modifier.pulseGlow(shape: Shape, on: Boolean): Modifier = composed {
    val calm = AppSettings.reduceMotion(LocalContext.current)
    if (!on || calm) {
        Modifier
    } else {
        val transition = rememberInfiniteTransition(label = "pulseGlow")
        val breath by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1300, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "breath"
        )
        Modifier.drawWithContent {
            if (size.width > 0f && size.height > 0f) {
                val path = shape.createOutline(size, layoutDirection, this).toPath()
                val steps = 8
                val reach = 16f * density
                // Faint at the dimmest moment, clearly visible at the brightest.
                val layerAlpha = 0.04f + 0.12f * breath
                clipPath(path, ClipOp.Difference) {
                    for (i in steps downTo 1) {
                        val t = i / steps.toFloat()
                        drawPath(
                            path = path,
                            color = PulseColor.copy(alpha = layerAlpha),
                            style = Stroke(width = reach * 2f * t)
                        )
                    }
                }
            }
            drawContent()
        }
    }
}
