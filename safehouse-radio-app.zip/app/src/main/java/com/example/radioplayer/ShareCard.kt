package com.example.radioplayer

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextUtils
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * The picture that goes with a share: the DJ's picture (or the station's own card), the name, the time or show,
 * and "Listen live on Safehouse Radio" along the bottom. It is made on the phone for a moment when someone taps
 * Share, sent with the text, and not kept. If anything goes wrong the share is just the text, as before.
 */
object ShareCard {

    /**
     * [name] big, [line] under it, [pill] the small label at the top left (null for none). The picture is
     * [photo] (bytes already in hand) or [photoUrl] (fetched when sharing); with neither, the station's logo is used.
     * [station] makes the station's own card (round logo, no picture).
     */
    class Spec(
        val name: String,
        val line: String,
        val pill: String?,
        val photo: ByteArray? = null,
        val photoUrl: String? = null,
        val station: Boolean = false
    )

    private const val SIZE = 1080
    // The card's colours follow the theme in use when Share is tapped.
    private val LAVENDER: Int get() = ThemeState.current.primary.toArgb()
    private val EDGE: Int get() = ThemeState.current.edge.toArgb()
    private val INK: Int get() = ThemeState.current.background.toArgb()
    private val FOOTER: Int get() = ThemeState.current.background.copy(alpha = 0.88f).toArgb()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Makes the card and opens the share sheet with it and [text]; with no card possible, shares just the text. */
    fun share(ctx: Context, text: String, spec: Spec) {
        val app = ctx.applicationContext
        scope.launch {
            val uri = try {
                make(app, spec)?.let { FileProvider.getUriForFile(app, app.packageName + ".fileprovider", it) }
            } catch (e: Exception) {
                null
            } catch (e: OutOfMemoryError) {
                null
            }
            withContext(Dispatchers.Main) {
                if (uri == null) {
                    ShowActions.share(app, text)
                    return@withContext
                }
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "image/jpeg"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, text)
                    clipData = ClipData.newRawUri("", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try {
                    app.startActivity(
                        Intent.createChooser(send, "Share")
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    )
                } catch (e: Exception) {
                    // Nothing to share with: nothing to do.
                }
            }
        }
    }

    private fun make(ctx: Context, s: Spec): File? {
        val photo: Bitmap? = when {
            s.station -> null
            s.photo != null -> decode(s.photo)
            s.photoUrl != null -> download(s.photoUrl)?.let { decode(it) }
            else -> null
        }
        val bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val bold = font(ctx, R.font.poppins_bold, Typeface.DEFAULT_BOLD)
        val medium = font(ctx, R.font.poppins_medium, Typeface.DEFAULT)
        val tile = LogoTiles.bitmap(ctx, ThemeState.current)
            ?: Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)

        drawBackground(ctx, c)

        if (s.station) {
            // The station's own card: the round logo, big.
            val d = 470f
            val cx = SIZE / 2f
            val cy = 380f
            drawCircleImage(c, tile, cx, cy, d / 2f)
            drawText(c, s.name, cx, cy + d / 2f + 95f, bold, 92f, Color.WHITE, SIZE - 120f)
            drawText(c, s.line, cx, cy + d / 2f + 185f, medium, 48f, EDGE, SIZE - 120f)
        } else {
            s.pill?.let { drawPill(c, it, bold) }
            val ps = 500f
            val px = (SIZE - ps) / 2f
            val py = 160f
            drawRoundedImage(c, photo ?: tile, RectF(px, py, px + ps, py + ps), 48f)
            drawText(c, s.name, SIZE / 2f, py + ps + 75f, bold, 88f, Color.WHITE, SIZE - 120f)
            drawText(c, s.line, SIZE / 2f, py + ps + 160f, medium, 42f, EDGE, SIZE - 120f)
        }

        drawFooter(c, tile, bold, medium)

        val dir = File(ctx.cacheDir, "share")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val file = File(dir, "safehouse-radio-${System.currentTimeMillis()}.jpg")
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        bmp.recycle()
        return file
    }

    private fun font(ctx: Context, id: Int, fallback: Typeface): Typeface =
        try {
            ResourcesCompat.getFont(ctx, id) ?: fallback
        } catch (e: Exception) {
            fallback
        }

    private fun drawBackground(ctx: Context, c: Canvas) {
        val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
        val wall = BitmapFactory.decodeResource(ctx.resources, R.drawable.wallpaper, opts)
        if (wall != null) {
            val side = minOf(wall.width, wall.height)
            val src = Rect((wall.width - side) / 2, (wall.height - side) / 2, (wall.width + side) / 2, (wall.height + side) / 2)
            c.drawBitmap(wall, src, Rect(0, 0, SIZE, SIZE), Paint(Paint.FILTER_BITMAP_FLAG))
            wall.recycle()
        } else {
            c.drawColor(INK)
        }
        c.drawColor(Color.argb(150, 0, 0, 0))
    }

    private fun drawPill(c: Canvas, text: String, face: Typeface) {
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = face
            textSize = 34f
            color = INK
        }
        val w = tp.measureText(text) + 64f
        val box = RectF(60f, 60f, 60f + w, 132f)
        c.drawRoundRect(box, 36f, 36f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LAVENDER })
        c.drawText(text, box.left + 32f, box.centerY() + 12f, tp)
    }

    private fun drawRoundedImage(c: Canvas, img: Bitmap, box: RectF, radius: Float) {
        val side = minOf(img.width, img.height)
        val src = Rect((img.width - side) / 2, (img.height - side) / 2, (img.width + side) / 2, (img.height + side) / 2)
        val save = c.save()
        val clip = Path().apply { addRoundRect(box, radius, radius, Path.Direction.CW) }
        c.clipPath(clip)
        c.drawBitmap(img, src, box, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        c.restoreToCount(save)
        c.drawRoundRect(
            box, radius, radius,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 5f
                color = EDGE
            }
        )
    }

    private fun drawCircleImage(c: Canvas, img: Bitmap, cx: Float, cy: Float, r: Float) {
        val side = minOf(img.width, img.height)
        val src = Rect((img.width - side) / 2, (img.height - side) / 2, (img.width + side) / 2, (img.height + side) / 2)
        val save = c.save()
        val clip = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        c.clipPath(clip)
        c.drawBitmap(img, src, RectF(cx - r, cy - r, cx + r, cy + r), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        c.restoreToCount(save)
        c.drawCircle(
            cx, cy, r,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 5f
                color = EDGE
            }
        )
    }

    /** Centred text on the baseline [y]; made smaller (then shortened with "…") if it would not fit in [maxWidth]. */
    private fun drawText(c: Canvas, text: String, cx: Float, y: Float, face: Typeface, size: Float, color: Int, maxWidth: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = face
            this.color = color
            textAlign = Paint.Align.CENTER
            textSize = size
        }
        while (p.measureText(text) > maxWidth && p.textSize > size * 0.55f) p.textSize -= 2f
        val shown = TextUtils.ellipsize(text, android.text.TextPaint(p), maxWidth, TextUtils.TruncateAt.END).toString()
        c.drawText(shown, cx, y + p.textSize * 0.35f, p)
    }

    private fun drawFooter(c: Canvas, tile: Bitmap, bold: Typeface, medium: Typeface) {
        c.drawRect(0f, SIZE - 190f, SIZE.toFloat(), SIZE.toFloat(), Paint().apply { color = FOOTER })
        drawCircleImage(c, tile, 110f, SIZE - 95f, 56f)
        val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = bold
            color = Color.WHITE
            textSize = if (Config.PLAY_LIVE) 44f else 40f
        }
        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = medium
            color = EDGE
            textSize = 34f
        }
        val first = if (Config.PLAY_LIVE) "Get the app" else "Listen live on ${Config.STATION_NAME}"
        val second = if (Config.PLAY_LIVE) "Free on Android" else "safehouseradio.co.uk"
        c.drawText(first, 190f, SIZE - 95f - 8f, big)
        c.drawText(second, 190f, SIZE - 95f + 40f, small)
    }

    private fun decode(bytes: ByteArray): Bitmap? =
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1400) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        }

    /** The picture at [url] (https only, at most 4 MB), or null if it cannot be had quickly. */
    private fun download(url: String): ByteArray? {
        if (!url.startsWith("https://")) return null
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 6_000
                conn.readTimeout = 8_000
                conn.setRequestProperty("User-Agent", Config.userAgent)
                if (conn.responseCode !in 200..299) return null
                val out = ByteArrayOutputStream()
                val buf = ByteArray(16 * 1024)
                conn.inputStream.use { input ->
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        if (out.size() > 4 * 1024 * 1024) return null
                    }
                }
                out.toByteArray()
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }
}
