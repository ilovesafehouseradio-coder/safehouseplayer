package com.example.radioplayer

import kotlin.math.abs

/**
 * Spots the station's default picture (the plain purple Safehouse logo that the stream server
 * sends when a show has no artwork of its own), so the app can show its own nicer logo instead.
 *
 * It compares a tiny 8 x 8 colour "fingerprint" of the middle of the picture with the fingerprint
 * of the default one. That still matches if the picture is resized or recompressed, and costs nothing.
 * If the station ever changes its default picture this simply stops matching (the picture then
 * shows as it is), and the fingerprint below can be updated.
 */
object GenericArt {
    private const val GRID = 8
    private const val INSET = 0.06      // ignore the very edge of the picture
    private const val MAX_DIFFERENCE = 16.0   // average difference per colour value (0 to 255)

    // 8 x 8 cells, left to right then top to bottom, each as red, green, blue.
    private val DEFAULT_PRINT = intArrayOf(
        0, 0, 0, 33, 34, 34, 41, 44, 47, 28, 32, 36, 28, 32, 36, 41, 44, 47, 32, 33, 34, 0, 0, 0,
        34, 35, 36, 38, 41, 44, 33, 36, 40, 53, 56, 59, 82, 84, 86, 33, 37, 41, 30, 33, 37, 33, 34, 34,
        66, 68, 71, 148, 149, 150, 127, 128, 129, 174, 174, 174, 183, 174, 197, 148, 130, 176, 28, 32, 36, 40, 42, 45,
        72, 45, 119, 105, 93, 128, 125, 107, 154, 122, 114, 136, 109, 102, 124, 100, 83, 130, 40, 30, 67, 35, 30, 54,
        54, 26, 104, 68, 24, 142, 37, 29, 59, 75, 23, 160, 63, 25, 127, 58, 24, 115, 68, 22, 142, 53, 26, 102,
        46, 39, 65, 37, 29, 61, 48, 27, 87, 50, 33, 84, 56, 36, 94, 60, 39, 99, 55, 38, 90, 52, 42, 75,
        36, 37, 37, 29, 32, 36, 28, 32, 36, 31, 34, 38, 35, 39, 43, 36, 39, 43, 36, 40, 44, 37, 38, 38,
        1, 1, 1, 35, 37, 37, 38, 41, 44, 28, 31, 36, 28, 31, 36, 39, 42, 45, 35, 36, 36, 1, 1, 1
    )

    /** [pixels] are ARGB values, [width] x [height]. */
    fun isGeneric(pixels: IntArray, width: Int, height: Int): Boolean {
        if (width < GRID * 4 || height < GRID * 4 || pixels.size < width * height) return false
        val side = minOf(width, height)
        val x0 = (width - side) / 2
        val y0 = (height - side) / 2
        val edge = (side * INSET).toInt()
        val start = edge
        val span = side - 2 * edge
        if (span < GRID) return false

        val sums = DoubleArray(GRID * GRID * 3)
        val counts = IntArray(GRID * GRID)
        for (y in 0 until span) {
            val cy = y * GRID / span
            val row = (y0 + start + y) * width + x0 + start
            for (x in 0 until span) {
                val cx = x * GRID / span
                val p = pixels[row + x]
                val cell = cy * GRID + cx
                sums[cell * 3] += ((p shr 16) and 0xFF).toDouble()
                sums[cell * 3 + 1] += ((p shr 8) and 0xFF).toDouble()
                sums[cell * 3 + 2] += (p and 0xFF).toDouble()
                counts[cell]++
            }
        }
        var total = 0.0
        for (cell in 0 until GRID * GRID) {
            val n = counts[cell].coerceAtLeast(1)
            for (c in 0 until 3) {
                total += abs(sums[cell * 3 + c] / n - DEFAULT_PRINT[cell * 3 + c])
            }
        }
        return total / (GRID * GRID * 3) <= MAX_DIFFERENCE
    }
}
