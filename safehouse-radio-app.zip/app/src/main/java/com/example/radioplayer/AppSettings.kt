package com.example.radioplayer

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.exoplayer.DefaultLoadControl

/** The choices for the sound a show reminder makes. */
enum class ReminderSound(val label: String) {
    SAFEHOUSE("Safehouse"),
    PHONE("Phone"),
    SILENT("Silent")
}

/**
 * The switches on the More tab. They live on the phone only (nothing is sent anywhere), and are read
 * straight from there each time, so the playback service and the reminders always see the latest choice.
 */
object AppSettings {
    private const val PREFS = "app_settings"
    const val K_REMINDERS = "reminders_on"
    const val K_SOUND = "reminder_sound"
    const val K_UNPLUG = "pause_on_unplug"
    const val K_DATA = "warn_mobile_data"
    const val K_BUFFER = "buffer_choice"
    const val K_MOTION = "reduce_motion"
    const val K_WELCOME = "skip_welcome"
    const val K_WELCOME_SOUND = "welcome_sound"

    /** What the buffer choices are called, in order. The first (Short) is the normal one. */
    val BUFFER_LABELS = listOf("Short", "15 s", "30 s", "60 s")

    fun prefs(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun remindersOn(ctx: Context): Boolean = prefs(ctx).getBoolean(K_REMINDERS, true)
    fun setRemindersOn(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(K_REMINDERS, on).apply()

    fun reminderSound(ctx: Context): ReminderSound {
        val i = prefs(ctx).getInt(K_SOUND, 0)
        return ReminderSound.values().getOrNull(i) ?: ReminderSound.SAFEHOUSE
    }
    fun setReminderSound(ctx: Context, sound: ReminderSound) = prefs(ctx).edit().putInt(K_SOUND, sound.ordinal).apply()

    fun pauseOnUnplug(ctx: Context): Boolean = prefs(ctx).getBoolean(K_UNPLUG, true)
    fun setPauseOnUnplug(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(K_UNPLUG, on).apply()

    fun warnMobileData(ctx: Context): Boolean = prefs(ctx).getBoolean(K_DATA, false)
    fun setWarnMobileData(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(K_DATA, on).apply()

    fun bufferChoice(ctx: Context): Int = prefs(ctx).getInt(K_BUFFER, 0).coerceIn(0, BUFFER_LABELS.size - 1)
    fun setBufferChoice(ctx: Context, choice: Int) = prefs(ctx).edit().putInt(K_BUFFER, choice).apply()

    /** The switch on the More tab. */
    fun reduceMotionChoice(ctx: Context): Boolean = prefs(ctx).getBoolean(K_MOTION, false)

    /** True if animations should be calm: the switch is on, or the phone itself has animations turned off. */
    fun reduceMotion(ctx: Context): Boolean =
        reduceMotionChoice(ctx) || try {
            android.provider.Settings.Global.getFloat(ctx.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
        } catch (e: Exception) {
            false
        }

    fun setReduceMotion(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(K_MOTION, on).apply()

    fun skipWelcome(ctx: Context): Boolean = prefs(ctx).getBoolean(K_WELCOME, false)
    fun setSkipWelcome(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(K_WELCOME, on).apply()

    fun welcomeSound(ctx: Context): Boolean = prefs(ctx).getBoolean(K_WELCOME_SOUND, true)
    fun setWelcomeSound(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(K_WELCOME_SOUND, on).apply()

    /**
     * How much audio the radio collects before it starts playing, and again after a break. Live radio
     * arrives in real time, so a bigger cushion means a longer wait before you hear anything and hearing
     * the DJ that much later, in return for riding out short drops in signal. Short is about 5 seconds
     * more than the player's own default (2.5 s to start, 5 s after a break).
     */
    fun loadControl(ctx: Context): DefaultLoadControl {
        val startMs = when (bufferChoice(ctx)) {
            0 -> 7_500
            1 -> 15_000
            2 -> 30_000
            else -> 60_000
        }
        val afterBreakMs = if (bufferChoice(ctx) == 0) 10_000 else startMs
        val keepMs = maxOf(50_000, startMs + 5_000)
        return DefaultLoadControl.Builder()
            .setBufferDurationsMs(keepMs, keepMs, startMs, afterBreakMs)
            .build()
    }
}

/**
 * "Warn before using mobile data": when it is switched on, pressing play on mobile data (not Wi-Fi)
 * asks once per visit to the app. It never blocks the radio: Play carries on as normal. The play
 * buttons in the notification, the car and Bluetooth are not asked (they cannot show a question).
 */
object DataWarning {
    /** What to do if the listener chooses Play; non-null while the question is on screen. */
    var pending by mutableStateOf<(() -> Unit)?>(null)
    private var askedThisVisit = false

    /** Set once when the app opens, so the play buttons do not each need to pass a context. */
    var appContext: Context? = null

    private fun onMobileData(ctx: Context): Boolean =
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
                !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        } catch (e: Exception) {
            false
        }

    /** Runs [start] now, or after the listener says Play if a warning is due. */
    fun guard(start: () -> Unit) {
        val ctx = appContext
        if (ctx != null && !askedThisVisit && AppSettings.warnMobileData(ctx) && onMobileData(ctx)) {
            askedThisVisit = true
            pending = start
        } else {
            start()
        }
    }
}
