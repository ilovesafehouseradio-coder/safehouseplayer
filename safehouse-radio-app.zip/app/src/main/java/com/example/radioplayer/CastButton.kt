package com.example.radioplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.mediarouter.app.MediaRouteButton
import android.content.Context
import kotlin.math.roundToInt
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastOptions
import com.google.android.gms.cast.framework.OptionsProvider
import com.google.android.gms.cast.framework.SessionProvider
import com.google.android.gms.cast.framework.media.CastMediaOptions
import com.google.android.gms.cast.CastMediaControlIntent
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastState
import com.google.android.gms.cast.framework.CastStateListener

/**
 * Tells Google Cast which TV app to use. This is Google's own "Default Media Receiver": it has a
 * proper music screen that shows the DJ / show picture, title and artist. (The phone's own
 * notification and the Cast library's extra controls are switched off: the app has its own.)
 */
class SafehouseCastOptions : OptionsProvider {
    override fun getCastOptions(context: Context): CastOptions =
        CastOptions.Builder()
            .setReceiverApplicationId(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID)
            .setCastMediaOptions(
                CastMediaOptions.Builder()
                    .setMediaSessionEnabled(false)
                    .setNotificationOptions(null)
                    .build()
            )
            .build()

    override fun getAdditionalSessionProviders(context: Context): List<SessionProvider>? = null
}

// The standard "cast" symbol (24 x 24 grid).
private const val CAST_ICON_PATH =
    "M21,3L3,3c-1.1,0 -2,0.9 -2,2v3h2L3,5h18v14h-7v2h7c1.1,0 2,-0.9 2,-2L23,5c0,-1.1 -0.9,-2 -2,-2z" +
        "M1,18v3h3c0,-1.66 -1.34,-3 -3,-3z" +
        "M1,14v2c2.76,0 5,2.24 5,5h2c0,-3.87 -3.13,-7 -7,-7z" +
        "M1,10v2c4.97,0 9,4.03 9,9h2c0,-6.08 -4.93,-11 -11,-11z"

/**
 * The Chromecast button: always on show (in the header of every page but Chat), so it is always there to
 * tap. It turns lavender while connected. The icon is drawn here so it matches the app; a see-through
 * Google Cast button sits on top of it and opens the "choose a device" list when tapped (with nobody
 * nearby that list says it is searching, and finds devices as they appear).
 */
@Composable
fun CastButton(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var state by remember { mutableStateOf(CastState.NO_DEVICES_AVAILABLE) }

    DisposableEffect(context) {
        val castContext = try {
            CastContext.getSharedInstance(context)
        } catch (e: Exception) {
            null   // no Google Play services on this phone: no casting
        }
        if (castContext == null) {
            onDispose { }
        } else {
            state = castContext.castState
            val listener = CastStateListener { newState -> state = newState }
            castContext.addCastStateListener(listener)
            onDispose { castContext.removeCastStateListener(listener) }
        }
    }

    val iconPath = remember { PathParser().parsePathString(CAST_ICON_PATH).toPath() }
    val tint = if (state == CastState.CONNECTED) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground

    Box(
        modifier
            .size(48.dp)
            .semantics { contentDescription = "Cast to a speaker or TV" }
    ) {
        Canvas(Modifier.size(26.dp).align(Alignment.Center)) {
            scale(scale = size.width / 24f, pivot = Offset.Zero) {
                drawPath(path = iconPath, color = tint)
            }
        }
        AndroidView(
            factory = { ctx ->
                MediaRouteButton(ctx).also { button ->
                    CastButtonFactory.setUpMediaRouteButton(ctx, button)
                    // Stay tappable even when no device is nearby yet (the button normally hides itself then).
                    try {
                        MediaRouteButton::class.java
                            .getMethod("setAlwaysVisible", Boolean::class.javaPrimitiveType)
                            .invoke(button, true)
                    } catch (e: Throwable) {
                        // An older library without it: the button just behaves as it did before.
                    }
                }
            },
            modifier = Modifier.matchParentSize().alpha(0.02f)
        )
    }
}

/**
 * The phone's volume buttons while casting. Android only moves the phone's own volume, so while a Chromecast is
 * connected the app takes the buttons itself and turns the Chromecast's (TV or speaker) volume up or down.
 */
object CastVolume {
    private const val STEP = 0.05

    /** Moves the cast device's volume by one step ([direction] +1 or -1). False when nothing is being cast to. */
    fun adjust(context: Context, direction: Int): Boolean =
        try {
            val session = CastContext.getSharedInstance(context).sessionManager.currentCastSession
            if (session == null || !session.isConnected) {
                false
            } else {
                val volume = (session.volume + direction * STEP).coerceIn(0.0, 1.0)
                session.setVolume(volume)
                android.widget.Toast.makeText(
                    context.applicationContext,
                    "TV volume " + (volume * 100).roundToInt() + "%",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
                true
            }
        } catch (e: Exception) {
            false
        }
}
