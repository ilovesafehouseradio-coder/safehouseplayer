package com.example.radioplayer

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * The DJ list and the DJ pages already read, saved on the phone so the DJs tab opens at once and the
 * website is only asked again when the saved copy is old.
 */
object DjCache {

    private const val VERSION = 1
    private const val FILE = "dj_cache.json"

    class Saved(
        val listAt: Long,
        val djs: List<Dj>,
        val profiles: Map<String, DjProfile>,
        val profileAt: Map<String, Long>
    )

    @Synchronized
    fun save(dir: File, listAt: Long, djs: List<Dj>, profiles: Map<String, DjProfile>, profileAt: Map<String, Long>) {
        try {
            val root = JSONObject().put("v", VERSION).put("listAt", listAt)
            val list = JSONArray()
            for (d in djs) {
                list.put(JSONObject().put("n", d.name).put("l", d.link).put("i", d.imageUrl ?: JSONObject.NULL))
            }
            root.put("djs", list)
            val ps = JSONObject()
            for ((link, p) in profiles) {
                ps.put(
                    link,
                    JSONObject()
                        .put("at", profileAt[link] ?: 0L)
                        .put("g", JSONArray(p.genres))
                        .put("r", p.regular ?: JSONObject.NULL)
                        .put("p", JSONArray(p.paragraphs))
                        .put("li", JSONArray(p.links.map { JSONObject().put("l", it.label).put("u", it.url) }))
                        .put("ph", p.photoUrl ?: JSONObject.NULL)
                )
            }
            root.put("profiles", ps)
            val tmp = File(dir, "$FILE.tmp")
            tmp.writeText(root.toString())
            tmp.renameTo(File(dir, FILE))
        } catch (e: Exception) {
            // The cache is a convenience only.
        }
    }

    @Synchronized
    fun load(dir: File): Saved? =
        try {
            val f = File(dir, FILE)
            if (!f.exists()) null
            else {
                val root = JSONObject(f.readText())
                if (root.optInt("v") != VERSION) null
                else {
                    val arr = root.getJSONArray("djs")
                    val djs = (0 until arr.length()).map {
                        val o = arr.getJSONObject(it)
                        Dj(o.getString("n"), o.getString("l"), if (o.isNull("i")) null else o.getString("i"))
                    }
                    val profiles = HashMap<String, DjProfile>()
                    val at = HashMap<String, Long>()
                    val ps = root.optJSONObject("profiles")
                    if (ps != null) {
                        for (link in ps.keys()) {
                            val o = ps.getJSONObject(link)
                            fun strings(a: JSONArray) = (0 until a.length()).map { a.getString(it) }
                            profiles[link] = DjProfile(
                                genres = strings(o.getJSONArray("g")),
                                regular = if (o.isNull("r")) null else o.getString("r"),
                                paragraphs = strings(o.getJSONArray("p")),
                                links = o.getJSONArray("li").let { a ->
                                    (0 until a.length()).map { DjLink(a.getJSONObject(it).getString("l"), a.getJSONObject(it).getString("u")) }
                                },
                                photoUrl = if (o.isNull("ph")) null else o.getString("ph")
                            )
                            at[link] = o.optLong("at")
                        }
                    }
                    Saved(root.optLong("listAt"), djs, profiles, at)
                }
            }
        } catch (e: Exception) {
            null
        }
}
