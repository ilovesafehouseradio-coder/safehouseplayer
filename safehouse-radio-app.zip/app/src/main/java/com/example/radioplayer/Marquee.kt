package com.example.radioplayer

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.MarqueeSpacing
import androidx.compose.foundation.basicMarquee
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

/**
 * For a one-line text that may be too long: it waits a couple of seconds so the start can be read, then slides
 * left until the end has shown, waits again and repeats. Text that fits never moves. With "Reduce animations"
 * on, nothing moves (the caller's "…" shows instead).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.scrollWhenLong(): Modifier {
    if (AppSettings.reduceMotion(LocalContext.current)) return this
    return this.basicMarquee(
        iterations = Int.MAX_VALUE,
        delayMillis = 2000,
        initialDelayMillis = 2000,
        spacing = MarqueeSpacing(48.dp),
        velocity = 30.dp
    )
}
