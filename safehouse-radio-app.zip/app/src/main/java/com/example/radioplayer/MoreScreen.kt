package com.example.radioplayer

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

private val Edge = Color(0xFFC9C4DA)
private val Muted = Color(0xFFC8C8C8)

/**
 * The More tab: the app's own settings and the About section. Nothing here is a web page. Every
 * switch is kept on the phone only.
 */
@Composable
fun MoreScreen(
    onOpenReminderSetup: () -> Unit,
    onRemindersChanged: () -> Unit,
    onClearSaved: () -> Unit
) {
    var showPrivacy by remember { mutableStateOf(false) }
    if (showPrivacy) {
        PrivacyPage(onBack = { showPrivacy = false })
    } else {
        MoreMain(onOpenReminderSetup, onRemindersChanged, onClearSaved, onOpenPrivacy = { showPrivacy = true })
    }
}

@Composable
private fun MoreMain(
    onOpenReminderSetup: () -> Unit,
    onRemindersChanged: () -> Unit,
    onClearSaved: () -> Unit,
    onOpenPrivacy: () -> Unit
) {
    val ctx = LocalContext.current
    val bubble = remember { BubbleState() }

    var remindersOn by remember { mutableStateOf(AppSettings.remindersOn(ctx)) }
    var sound by remember { mutableStateOf(AppSettings.reminderSound(ctx)) }
    var unplug by remember { mutableStateOf(AppSettings.pauseOnUnplug(ctx)) }
    var dataWarn by remember { mutableStateOf(AppSettings.warnMobileData(ctx)) }
    var buffer by remember { mutableStateOf(AppSettings.bufferChoice(ctx)) }
    var motion by remember { mutableStateOf(AppSettings.reduceMotionChoice(ctx)) }
    var skipWelcome by remember { mutableStateOf(AppSettings.skipWelcome(ctx)) }
    var welcomeSound by remember { mutableStateOf(AppSettings.welcomeSound(ctx)) }
    var cleared by remember { mutableStateOf(false) }
    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName.orEmpty()
        } catch (e: Exception) {
            ""
        }
    }

    BubbleHost(bubble) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 24.dp)
        ) {
            PageHeader("More")

            SettingsCard("Reminders") {
                ToggleRow(
                    label = "Show reminders",
                    sub = if (remindersOn) "Switch off to pause every reminder" else "Paused. The DJs you follow are kept.",
                    checked = remindersOn,
                    onChange = {
                        remindersOn = it
                        AppSettings.setRemindersOn(ctx, it)
                        onRemindersChanged()
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("Switches every show reminder on or off in one go.")
                        BubbleText("The DJs and shows you follow are kept, so switching back on brings all your reminders back.")
                    }
                )
                RowDivider()
                ChoiceRow(
                    label = "Reminder sound",
                    sub = "Plays when a reminder arrives",
                    options = ReminderSound.values().map { it.label },
                    selected = sound.ordinal,
                    onSelect = {
                        sound = ReminderSound.values()[it]
                        AppSettings.setReminderSound(ctx, sound)
                        Reminders.ensureChannel(ctx)
                    },
                    bubble = bubble,
                    trailing = { TryButton { Reminders.playPreview(ctx) } },
                    info = {
                        BubbleText("Safehouse plays a short, quiet Safehouse sound with each reminder. Phone uses your phone's own notification sound. Silent shows the reminder without any sound.")
                        BubbleText("You can also change it in your phone's notification settings for Safehouse Radio.")
                    }
                )
                RowDivider()
                NavRow(
                    label = "Reminder setup guide",
                    sub = "Battery tips, if reminders arrive late",
                    external = false,
                    onClick = onOpenReminderSetup
                )
            }

            SettingsCard("Listening") {
                ToggleRow(
                    label = "Pause when headphones unplug",
                    sub = "Stops the radio if the cable or Bluetooth drops",
                    checked = unplug,
                    onChange = {
                        unplug = it
                        AppSettings.setPauseOnUnplug(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("Stops the radio when headphones or a Bluetooth speaker disconnect, so it never suddenly plays out loud.")
                        BubbleText("Switch this off if you would rather it carried on through the phone's speaker.")
                    }
                )
                RowDivider()
                ToggleRow(
                    label = "Warn before using mobile data",
                    sub = "Asks once if you are not on Wi-Fi",
                    checked = dataWarn,
                    onChange = {
                        dataWarn = it
                        AppSettings.setWarnMobileData(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("When this is on and you press play on mobile data, the app asks once before it starts. You can always carry on: the radio is never blocked.")
                        BubbleText("It does not apply to the play buttons in notifications, cars or Bluetooth.")
                    }
                )
                RowDivider()
                ChoiceRow(
                    label = "Buffer",
                    sub = "Smoother in weak signal, a little behind live",
                    options = AppSettings.BUFFER_LABELS,
                    selected = buffer,
                    onSelect = {
                        buffer = it
                        AppSettings.setBufferChoice(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("The buffer is a cushion of audio the radio collects before it starts playing. A bigger cushion rides out short drops in signal (tunnels, Wi-Fi changes), but there is a pause before you hear anything and you hear the DJ that much later.")
                        BubbleText("Short is about 8 seconds and suits most phones. Try 30 s or 60 s if the radio keeps cutting out. It does not use extra data. A change starts the radio again if it is playing.")
                    }
                )
            }

            SettingsCard("Display") {
                ToggleRow(
                    label = "Reduce animations",
                    sub = "Calmer play button and welcome screen",
                    checked = motion,
                    onChange = {
                        motion = it
                        AppSettings.setReduceMotion(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("Turns off the pulsing rings, the blinking LIVE dot and the bouncing logo on the welcome screen. Good if movement bothers you, and it saves a little battery.")
                        BubbleText("The app also does this by itself if your phone has animations turned off.")
                    }
                )
                RowDivider()
                ToggleRow(
                    label = "Skip the welcome screen",
                    sub = "Go straight to the radio",
                    checked = skipWelcome,
                    onChange = {
                        skipWelcome = it
                        AppSettings.setSkipWelcome(ctx, it)
                    },
                    bubble = bubble,
                    info = null
                )
                RowDivider()
                ToggleRow(
                    label = "Welcome sound",
                    sub = "A short Safehouse jingle when the app opens",
                    checked = welcomeSound,
                    onChange = {
                        welcomeSound = it
                        AppSettings.setWelcomeSound(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("A short Safehouse station ID that plays with the welcome screen, at your phone's media volume.")
                        BubbleText("It never plays if the radio or any other audio is already playing, or if your phone is on silent or vibrate.")
                    }
                )
                Text(
                    text = "Text size and colours follow your phone's settings.",
                    color = Muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 8.dp)
                )
            }

            SettingsCard("Storage") {
                NavRow(
                    label = "Clear saved pictures and schedule",
                    sub = if (cleared) "Cleared. They download again when needed." else "Frees space; they download again when needed",
                    external = false,
                    showChevron = false,
                    onClick = {
                        onClearSaved()
                        cleared = true
                    }
                )
            }

            SettingsCard("About Safehouse Radio") {
                NavRow("Visit our website", "Opens in your browser", external = true) { openUrl(ctx, Config.WEBSITE_URL) }
                RowDivider()
                NavRow("Privacy policy", "What the app does, and does not do, with data", external = false) { onOpenPrivacy() }
                RowDivider()
                NavRow("Terms of use", null, external = true) { openUrl(ctx, Config.TERMS_URL) }
                RowDivider()
                NavRow("Contact and help", null, external = true) { contact(ctx) }
            }

            Column(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "A non-profit internet radio station",
                    color = Edge,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
                Text(
                    Config.SLOGAN.trimEnd('.'),
                    color = Muted,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
                if (version.isNotEmpty()) {
                    Text(
                        "Version $version",
                        color = Muted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 14.dp)
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Privacy page (a short, plain statement; the full policy is on the website)
// ---------------------------------------------------------------------------

@Composable
private fun PrivacyPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        PageHeader(title = "Privacy", leading = { BackArrowButton(onBack) })
        Text(
            "Safehouse Radio is a non-profit internet radio station. This page says, in plain words, what this app does with information.",
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 14.sp,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
        )
        PrivacyCard(
            "What stays on your phone",
            "The DJs and shows you follow, your reminder choices, your settings, and saved copies of the schedule, DJ list and pictures so the app opens quickly. None of this is sent to us."
        )
        PrivacyCard(
            "What the app asks the internet for",
            "The radio stream and what is on air, our public show calendar, and DJ names, pictures and pages from our website. As with any request on the internet, those servers can see your device's network address."
        )
        PrivacyCard(
            "What the app does not do",
            "There are no accounts, no adverts and no tracking or analytics in the app, and nothing about you is sold or shared."
        )
        PrivacyCard(
            "Chat and casting",
            "The Chat tab shows our website's chat page, which has its own sign-in and cookies, and is covered by the website's policy. Casting to a speaker or TV uses Google's Cast service on your phone."
        )
        PrivacyCard(
            "Reminders",
            "Reminders are planned on your phone from the public schedule. Nothing is sent to a server to make them."
        )
        Box(Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp)) {
            SetupButton("Read the full privacy policy", onClick = { openUrl(ctx, Config.PRIVACY_URL) }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun PrivacyCard(title: String, text: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
            .lift(RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .padding(14.dp)
    ) {
        Text(title, color = MaterialTheme.colorScheme.onBackground, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(text, color = Color(0xFFD8D3E2), fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

/** The arrow at the left of a page title: the same as the phone's back button. */
@Composable
fun BoxScope.BackArrowButton(onBack: () -> Unit) {
    Box(
        modifier = Modifier
            .align(Alignment.CenterStart)
            .padding(start = 4.dp)
            .size(48.dp)
            .clip(CircleShape)
            .clickable(onClickLabel = "Go back", role = Role.Button, onClick = onBack),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_arrow_back),
            contentDescription = "Go back",
            tint = LavenderInk,
            modifier = Modifier.size(24.dp)
        )
    }
}

// ---------------------------------------------------------------------------
// The rows
// ---------------------------------------------------------------------------

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
            .lift(RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .padding(vertical = 6.dp)
    ) {
        Text(
            text = title,
            color = Edge,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp)
        )
        content()
    }
}

@Composable
private fun RowDivider() {
    Box(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .height(1.dp)
            .background(Color(0x28FFFFFF))
    )
}

/** The name of a setting, with its (i) beside it when there is something to explain. */
@Composable
private fun LabelWithInfo(
    label: String,
    bubble: BubbleState,
    info: (@Composable ColumnScope.() -> Unit)?,
    onClick: (() -> Unit)? = null
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .weight(1f, fill = false)
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        )
        if (info != null) InfoButton(label, bubble, info)
    }
}

@Composable
private fun ToggleRow(
    label: String,
    sub: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    bubble: BubbleState,
    info: (@Composable ColumnScope.() -> Unit)?
) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .padding(start = 16.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            LabelWithInfo(label, bubble, info, onClick = { onChange(!checked) })
            Text(
                text = sub,
                color = Muted,
                fontSize = 13.sp,
                modifier = Modifier.clickable { onChange(!checked) }
            )
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            modifier = Modifier.semantics { contentDescription = label },
            colors = SwitchDefaults.colors(
                checkedThumbColor = LavenderInk,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                checkedBorderColor = MaterialTheme.colorScheme.primary,
                uncheckedThumbColor = Edge,
                uncheckedTrackColor = Color(0x99000000),
                uncheckedBorderColor = Edge
            )
        )
    }
}

@Composable
private fun ChoiceRow(
    label: String,
    sub: String,
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    bubble: BubbleState,
    info: (@Composable ColumnScope.() -> Unit)?,
    trailing: (@Composable () -> Unit)? = null
) {
    Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 4.dp, bottom = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                LabelWithInfo(label, bubble, info)
                Text(text = sub, color = Muted, fontSize = 13.sp)
            }
            if (trailing != null) {
                Spacer(Modifier.width(8.dp))
                trailing()
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((i, option) in options.withIndex()) {
                Chip(option, selected = i == selected, modifier = Modifier.weight(1f)) { onSelect(i) }
            }
        }
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .lift(RoundedCornerShape(50), tappable = true)
            .clip(RoundedCornerShape(50))
            .background(if (selected) MaterialTheme.colorScheme.primary else Color(0x66000000))
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) LavenderInk else MaterialTheme.colorScheme.onBackground,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

@Composable
private fun TryButton(onClick: () -> Unit) {
    Row(
        Modifier
            .heightIn(min = 48.dp)
            .lift(RoundedCornerShape(50), tappable = true)
            .clip(RoundedCornerShape(50))
            .background(Color(0xEB3F3A58))
            .clickable(onClickLabel = "Play the reminder sound", role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Canvas(Modifier.size(14.dp)) {
            val p = Path().apply {
                moveTo(0f, 0f)
                lineTo(size.width, size.height / 2f)
                lineTo(0f, size.height)
                close()
            }
            drawPath(p, Color.White)
        }
        Spacer(Modifier.width(8.dp))
        Text("Try", color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NavRow(
    label: String,
    sub: String?,
    external: Boolean,
    showChevron: Boolean = true,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = label,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
            if (sub != null) Text(text = sub, color = Muted, fontSize = 13.sp)
        }
        if (showChevron) {
            Spacer(Modifier.width(8.dp))
            Canvas(Modifier.size(20.dp)) {
                val w = 2.dp.toPx()
                if (external) {
                    // A small arrow leaving a box: "opens elsewhere".
                    drawLine(Edge, Offset(size.width * 0.3f, size.height * 0.7f), Offset(size.width * 0.8f, size.height * 0.2f), strokeWidth = w, cap = StrokeCap.Round)
                    drawLine(Edge, Offset(size.width * 0.4f, size.height * 0.2f), Offset(size.width * 0.8f, size.height * 0.2f), strokeWidth = w, cap = StrokeCap.Round)
                    drawLine(Edge, Offset(size.width * 0.8f, size.height * 0.2f), Offset(size.width * 0.8f, size.height * 0.6f), strokeWidth = w, cap = StrokeCap.Round)
                } else {
                    val p = Path().apply {
                        moveTo(size.width * 0.35f, size.height * 0.15f)
                        lineTo(size.width * 0.75f, size.height * 0.5f)
                        lineTo(size.width * 0.35f, size.height * 0.85f)
                    }
                    drawPath(p, Edge, style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
    }
}

private fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: Exception) {
        // No browser to open it: nothing more to do.
    }
}

/** "Contact and help": an email to the station if its address is set, otherwise the contact page. */
private fun contact(ctx: Context) {
    if (Config.CONTACT_EMAIL.isBlank()) {
        openUrl(ctx, Config.CONTACT_URL)
        return
    }
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Config.CONTACT_EMAIL))
                .putExtra(Intent.EXTRA_SUBJECT, "${Config.STATION_NAME} app")
        )
    } catch (e: Exception) {
        openUrl(ctx, Config.CONTACT_URL)
    }
}

/**
 * The question shown by "Warn before using mobile data". Play carries on as normal; Not now just does
 * nothing. Shown at most once per visit to the app.
 */
@Composable
fun DataWarningDialog() {
    val start = DataWarning.pending
    if (start != null) {
        val shape = RoundedCornerShape(24.dp)
        Dialog(onDismissRequest = { DataWarning.pending = null }) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(Color(0xFF3F3A58))
                    .border(2.dp, Edge, shape)
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(R.drawable.station_logo_tile),
                        contentDescription = null,
                        modifier = Modifier.size(30.dp).clip(CircleShape)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Safehouse says…", color = Edge, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    "You are on mobile data.",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 14.dp)
                )
                Text(
                    "Live radio uses data while it plays. Carry on?",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
                Row(
                    Modifier.fillMaxWidth().padding(top = 18.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .heightIn(min = 48.dp)
                            .clip(RoundedCornerShape(50))
                            .clickable(role = Role.Button) { DataWarning.pending = null }
                            .padding(horizontal = 18.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Not now", color = Edge, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(8.dp))
                    SetupButton("Play", onClick = {
                        DataWarning.pending = null
                        start()
                    })
                }
            }
        }
    }
}
