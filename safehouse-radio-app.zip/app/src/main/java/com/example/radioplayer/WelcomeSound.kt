package com.example.radioplayer

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer

/**
 * The short Safehouse jingle that goes with the welcome screen. It plays at the phone's media volume
 * and only when it is welcome: never while anything is already playing (the radio, music, a podcast),
 * never when the phone is on silent or vibrate or the media volume is right down, and never when the
 * listener has switched "Welcome sound" off in More. It stops as soon as the radio starts or the
 * welcome screen is tapped away.
 */
object WelcomeSound {
    private var player: MediaPlayer? = null

    fun play(ctx: Context) {
        val app = ctx.applicationContext
        if (!AppSettings.welcomeSound(app)) return
        try {
            val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (audio.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
            if (audio.isMusicActive) return
            if (audio.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) return
            stop()
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val mp = MediaPlayer.create(app, R.raw.welcome_sound, attributes, audio.generateAudioSessionId()) ?: return
            mp.setOnCompletionListener { finished ->
                finished.release()
                if (player === finished) player = null
            }
            player = mp
            mp.start()
        } catch (e: Exception) {
            // A jingle that will not play is not worth a message: carry on silently.
            stop()
        }
    }

    fun stop() {
        val mp = player ?: return
        player = null
        try {
            mp.stop()
        } catch (e: Exception) {
            // Already finished.
        }
        mp.release()
    }
}
