package com.example.radioplayer

import android.webkit.WebView
import java.lang.ref.WeakReference

/**
 * A short note of what went wrong inside the chat window (pictures that would not load, errors the chat page reported,
 * and the size of the pictures and frames on the page). It only lives in memory while the app is open, and is only
 * ever sent anywhere if the person shares it (tap "Version" on the More tab seven times).
 */
object ChatDiag {
    private val lines = ArrayDeque<String>()

    /** The chat window, so its layout can be measured on request. */
    @Volatile
    var view: WeakReference<WebView>? = null

    private const val MEASURE_SCRIPT = """
        (function () {
          try {
            var out = [];
            document.querySelectorAll('iframe').forEach(function (f) {
              var r = f.getBoundingClientRect();
              var p = f.parentElement;
              var pr = p ? p.getBoundingClientRect() : null;
              out.push('iframe ' + f.src + ' size ' + Math.round(r.width) + 'x' + Math.round(r.height) +
                ' attrs ' + (f.getAttribute('width') || '') + 'x' + (f.getAttribute('height') || '') +
                ' style [' + (f.getAttribute('style') || '') + '] class [' + f.className + ']' +
                ' parent [' + (p ? p.tagName + ' ' + p.className : '') + ' ' + (pr ? Math.round(pr.width) + 'x' + Math.round(pr.height) : '') + ']');
            });
            document.querySelectorAll('video,img').forEach(function (m) {
              var r = m.getBoundingClientRect();
              if (m.tagName === 'VIDEO' || r.width > 150) {
                out.push(m.tagName + ' ' + (m.currentSrc || m.src) + ' size ' + Math.round(r.width) + 'x' + Math.round(r.height));
              }
            });
            out.push('window ' + innerWidth + 'x' + innerHeight + ' dpr ' + devicePixelRatio);
            return out.join('\n');
          } catch (e) {
            return 'measure error ' + e;
          }
        })();
    """

    @Synchronized
    fun add(line: String) {
        if (lines.size >= 150) lines.removeFirst()
        lines.addLast(line.take(400))
    }

    @Synchronized
    private fun text(): String = lines.joinToString("\n")

    /** Measures the chat page, then hands over everything noted. Call on the main thread. */
    fun snapshot(done: (String) -> Unit) {
        val web = view?.get()
        if (web == null) {
            done(text())
            return
        }
        try {
            web.evaluateJavascript(MEASURE_SCRIPT) { result ->
                val page = (result ?: "").removeSurrounding("\"")
                    .replace("\\n", "\n").replace("\\\"", "\"").replace("\\u003C", "<")
                add("page layout:\n$page")
                done(text())
            }
        } catch (e: Exception) {
            done(text())
        }
    }
}
