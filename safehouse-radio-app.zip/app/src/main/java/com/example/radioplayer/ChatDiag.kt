package com.example.radioplayer

/**
 * A short note of what went wrong inside the chat window (pictures that would not load, errors the chat page reported).
 * It only lives in memory while the app is open, and is only ever sent anywhere if the person shares it
 * (tap "Version" on the More tab seven times).
 */
object ChatDiag {
    private val lines = ArrayDeque<String>()

    @Synchronized
    fun add(line: String) {
        if (lines.size >= 150) lines.removeFirst()
        lines.addLast(line.take(300))
    }

    @Synchronized
    fun text(): String = lines.joinToString("\n")
}
