package com.example.radioplayer

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.text.format.DateFormat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.work.CoroutineWorker
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import org.json.JSONArray
import org.json.JSONObject

// ---------------------------------------------------------------------------
// Show reminders: "follow" a DJ and get a notification 15 minutes before their shows.
//
// How it works, in plain words:
//  - The DJs you follow are kept on the phone (SharedPreferences).
//  - Each time the schedule is read, the next few reminders are worked out and saved as a short list.
//  - ONE alarm is always set for the earliest reminder on that list. When it goes off, the receiver
//    posts the notification(s) that are due, then sets the alarm for the next one.
//  - A background check every ~6 hours re-reads the calendar, so changed or cancelled shows are
//    picked up even if the app hasn't been opened.
//  - After a restart the saved list is used to set the alarm again.
// ---------------------------------------------------------------------------

object Reminders {
    const val LEAD_MINUTES = 15L
    const val CHANNEL_ID = "show_reminders"

    const val ACTION_ALARM = "com.example.radioplayer.REMINDER_ALARM"
    const val ACTION_TEST = "com.example.radioplayer.REMINDER_TEST"
    const val ACTION_UNFOLLOW = "com.example.radioplayer.REMINDER_UNFOLLOW"
    const val EXTRA_KEY = "key"
    const val EXTRA_NOTIFICATION_ID = "notification_id"

    private const val PREFS = "reminders"
    private const val K_FOLLOWED = "followed"      // set of "key<sep>Display Name"
    private const val K_PENDING = "pending"        // JSON list of the next reminders
    private const val K_DELIVERED = "delivered"    // set of "id<sep>time" so nothing is sent twice
    private const val K_SETUP_SEEN = "setup_seen"
    private const val K_ASKED = "asked_permission"
    private const val SEP = "\u0001"
    private const val WORK_NAME = "reminder-refresh"
    private const val TEST_ID = 7777

    private class Pending(
        val id: String,
        val at: Long,       // when the reminder should go off
        val key: String,
        val dj: String,
        val title: String,
        val start: Long,
        val end: Long
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** "Cody Chase" and "cody chase!" count as the same DJ. */
    fun key(dj: String): String = dj.lowercase().filter { it.isLetterOrDigit() }

    // ---- who is followed ----

    private fun followedMap(ctx: Context): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (entry in prefs(ctx).getStringSet(K_FOLLOWED, emptySet()).orEmpty()) {
            val i = entry.indexOf(SEP)
            if (i > 0) out[entry.substring(0, i)] = entry.substring(i + 1)
        }
        return out
    }

    fun followedKeys(ctx: Context): Set<String> = followedMap(ctx).keys

    /** Follows or unfollows a DJ. Returns the new set of followed keys. */
    @Synchronized
    fun setFollowed(ctx: Context, key: String, display: String, on: Boolean): Set<String> {
        val map = followedMap(ctx).toMutableMap()
        if (on) map[key] = display else map.remove(key)
        prefs(ctx).edit()
            .putStringSet(K_FOLLOWED, map.entries.map { it.key + SEP + it.value }.toSet())
            .apply()
        if (map.isEmpty()) cancelWorker(ctx) else enqueueWorker(ctx)
        return map.keys
    }

    fun setupSeen(ctx: Context): Boolean = prefs(ctx).getBoolean(K_SETUP_SEEN, false)
    fun markSetupSeen(ctx: Context) = prefs(ctx).edit().putBoolean(K_SETUP_SEEN, true).apply()

    // ---- the saved list of upcoming reminders ----

    private fun loadPending(ctx: Context): List<Pending> =
        try {
            val arr = JSONArray(prefs(ctx).getString(K_PENDING, "[]"))
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Pending(
                    o.getString("id"), o.getLong("at"), o.getString("k"), o.getString("dj"),
                    o.getString("t"), o.getLong("s"), o.getLong("e")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }

    private fun savePending(ctx: Context, list: List<Pending>) {
        val arr = JSONArray()
        for (p in list) {
            arr.put(
                JSONObject().put("id", p.id).put("at", p.at).put("k", p.key).put("dj", p.dj)
                    .put("t", p.title).put("s", p.start).put("e", p.end)
            )
        }
        prefs(ctx).edit().putString(K_PENDING, arr.toString()).apply()
    }

    private fun delivered(ctx: Context): MutableSet<String> {
        val cutoff = System.currentTimeMillis() - 3 * 24 * 60 * 60_000L
        return prefs(ctx).getStringSet(K_DELIVERED, emptySet()).orEmpty()
            .filter { (it.substringAfterLast(SEP).toLongOrNull() ?: 0L) > cutoff }
            .toMutableSet()
    }

    /**
     * Works out the next reminders for the followed DJs from the schedule, saves them and sets the
     * alarm. Call it whenever the schedule is read or the followed DJs change.
     */
    @Synchronized
    fun rebuild(ctx: Context, shows: List<Show>) {
        val followed = followedMap(ctx)
        if (followed.isEmpty()) {
            savePending(ctx, emptyList())
            armNext(ctx)
            return
        }
        val now = System.currentTimeMillis()
        val done = delivered(ctx).map { it.substringBefore(SEP) }.toSet()
        DjGroups.ensureLoaded(ctx)
        // Back-to-back slots of one event count once: one reminder, before the whole event starts.
        val list = Events.group(shows).mapNotNull { s ->
            // Live shows only: repeat slots never get a reminder.
            if (s.isFiller) return@mapNotNull null
            val k = DjMatch.followedKey(s, followed.keys) ?: return@mapNotNull null
            val dj = followed[k] ?: s.dj ?: return@mapNotNull null
            val id = s.start.toEpochMilli().toString() + "|" + k
            val at = s.start.toEpochMilli() - LEAD_MINUTES * 60_000L
            // Skip reminders already sent, and shows that are too close to start for a 15-minute warning.
            if (id in done || at < now - 30_000L || s.end.toEpochMilli() <= now) return@mapNotNull null
            Pending(id, at, k, dj, s.title, s.start.toEpochMilli(), s.end.toEpochMilli())
        }.distinctBy { it.id }.sortedBy { it.at }.take(30)
        savePending(ctx, list)
        armNext(ctx)
    }

    // ---- the alarm ----

    private fun alarmIntent(ctx: Context, action: String, requestCode: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx,
            requestCode,
            Intent(ctx, ReminderReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** Sets (or clears) the one alarm, for the earliest saved reminder. */
    @Synchronized
    fun armNext(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = alarmIntent(ctx, ACTION_ALARM, 1)
        val next = loadPending(ctx).minByOrNull { it.at }
        if (next == null) {
            am.cancel(pi)
            return
        }
        val at = maxOf(next.at, System.currentTimeMillis() + 2_000L)
        try {
            // "Inexact" on purpose: no special permission needed, and a reminder a few minutes either
            // way is fine. (The exact-alarm permission is only allowed for alarm clocks on Google Play.)
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            // Not allowed to set alarms right now: nothing more we can do.
        }
    }

    /** The alarm went off: send what is due, then set the alarm for the next one. */
    @Synchronized
    fun onAlarm(ctx: Context) {
        val now = System.currentTimeMillis()
        val all = loadPending(ctx)
        val due = all.filter { it.at <= now + 60_000L }
        val rest = all.filter { it.at > now + 60_000L }
        val sent = delivered(ctx)
        for (p in due) {
            if (p.end > now) {
                val minutes = ((p.start - now + 59_999L) / 60_000L).toInt()
                val title = if (minutes >= 2) "${p.dj} is on in $minutes minutes" else "${p.dj} is on now"
                val zone = ZoneId.systemDefault()
                val fmt = DateTimeFormatter.ofPattern(if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm a")
                val range = fmt.format(Instant.ofEpochMilli(p.start).atZone(zone)) + " – " +
                    fmt.format(Instant.ofEpochMilli(p.end).atZone(zone))
                post(ctx, p.id.hashCode(), title, p.title + "  ·  " + range, p.key)
            }
            sent.add(p.id + SEP + now)
        }
        prefs(ctx).edit().putStringSet(K_DELIVERED, sent).apply()
        savePending(ctx, rest)
        armNext(ctx)
    }

    /** "Stop following" pressed on a reminder. */
    @Synchronized
    fun unfollowFromNotification(ctx: Context, key: String, notificationId: Int) {
        val map = followedMap(ctx).toMutableMap()
        map.remove(key)
        prefs(ctx).edit()
            .putStringSet(K_FOLLOWED, map.entries.map { it.key + SEP + it.value }.toSet())
            .apply()
        savePending(ctx, loadPending(ctx).filter { it.key != key })
        armNext(ctx)
        if (map.isEmpty()) cancelWorker(ctx)
        NotificationManagerCompat.from(ctx).cancel(notificationId)
    }

    // ---- the notification ----

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val channel = NotificationChannel(CHANNEL_ID, "Show reminders", NotificationManager.IMPORTANCE_DEFAULT)
            channel.description = "A heads-up 15 minutes before the DJs you follow go on air"
            nm.createNotificationChannel(channel)
        }
    }

    private fun post(ctx: Context, id: Int, title: String, text: String, key: String?) {
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx,
            0,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_OPEN_RADIO, true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bell_filled)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        if (key != null) {
            val stop = PendingIntent.getBroadcast(
                ctx,
                id,
                Intent(ctx, ReminderReceiver::class.java)
                    .setAction(ACTION_UNFOLLOW)
                    .putExtra(EXTRA_KEY, key)
                    .putExtra(EXTRA_NOTIFICATION_ID, id),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(0, "Stop following", stop)
        }
        try {
            NotificationManagerCompat.from(ctx).notify(id, builder.build())
        } catch (e: SecurityException) {
            // Notifications are switched off: the setup screen explains how to turn them back on.
        }
    }

    fun postTest(ctx: Context) {
        post(ctx, TEST_ID, "Test reminder", "Reminders are working. A real one will look like this.", null)
    }

    /** Sends a test reminder in about 10 seconds, through the same alarm route as the real ones. */
    fun scheduleTest(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            am.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 10_000L,
                alarmIntent(ctx, ACTION_TEST, 2)
            )
        } catch (e: SecurityException) {
        }
    }

    // ---- what the phone allows (used by the setup screen and the warning banner) ----

    /** True if notifications are on for the app and the "Show reminders" category isn't blocked. */
    fun notificationsOk(ctx: Context): Boolean {
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return false
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = nm.getNotificationChannel(CHANNEL_ID)
        return channel == null || channel.importance != NotificationManager.IMPORTANCE_NONE
    }

    fun batteryOk(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }

    // ---- the background check ----

    private fun enqueueWorker(ctx: Context) {
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(6, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
    }

    private fun cancelWorker(ctx: Context) {
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK_NAME)
    }

    fun onBoot(ctx: Context) {
        armNext(ctx)
        if (followedMap(ctx).isNotEmpty()) enqueueWorker(ctx)
    }

    // ---- asking for the notification permission ----

    internal fun askedForPermission(ctx: Context): Boolean = prefs(ctx).getBoolean(K_ASKED, false)
    internal fun markAskedForPermission(ctx: Context) = prefs(ctx).edit().putBoolean(K_ASKED, true).apply()
}

/** Gets the alarm, the test alarm and the "Stop following" button. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        when (intent.action) {
            Reminders.ACTION_ALARM -> Reminders.onAlarm(app)
            Reminders.ACTION_TEST -> Reminders.postTest(app)
            Reminders.ACTION_UNFOLLOW -> Reminders.unfollowFromNotification(
                app,
                intent.getStringExtra(Reminders.EXTRA_KEY).orEmpty(),
                intent.getIntExtra(Reminders.EXTRA_NOTIFICATION_ID, 0)
            )
        }
    }
}

/** After the phone restarts (or the app is updated) the alarm has to be set again. */
class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminders.onBoot(context.applicationContext)
    }
}

/** Every ~6 hours: read the calendar again so changed or cancelled shows are picked up. */
class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext
        if (Reminders.followedKeys(app).isEmpty()) return Result.success()
        val state = ScheduleState()
        state.useCache(app.cacheDir)
        state.loadFromCache()
        state.load()
        if (state.shows.isNotEmpty()) Reminders.rebuild(app, state.shows)
        return Result.success()
    }
}

// ---------------------------------------------------------------------------
// The setup screen
// ---------------------------------------------------------------------------

private val Green = Color(0xFF6FCF97)

@Composable
fun ReminderSetupScreen(onDone: () -> Unit) {
    val context = LocalContext.current
    var refresh by remember { mutableStateOf(0) }
    var testSent by remember { mutableStateOf(false) }

    // Re-check the phone's settings every time the person comes back from the settings screens.
    DisposableEffect(context) {
        val owner = context as? LifecycleOwner
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refresh++
        }
        owner?.lifecycle?.addObserver(observer)
        onDispose { owner?.lifecycle?.removeObserver(observer) }
    }
    // The "Show reminders" category has to exist before it can appear in the phone's settings.
    LaunchedEffect(Unit) { Reminders.ensureChannel(context) }

    val notificationsOk = remember(refresh) { Reminders.notificationsOk(context) }
    val batteryOk = remember(refresh) { Reminders.batteryOk(context) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        refresh++
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        PageHeader("Reminder setup")

        Text(
            text = "Get a heads-up ${Reminders.LEAD_MINUTES} minutes before the DJs you follow go on air. " +
                "These steps make sure your phone lets the reminders through.",
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 14.sp,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
        )

        // 1. Notifications
        SetupCard(
            number = 1,
            done = notificationsOk,
            title = "Allow notifications",
            lines = if (notificationsOk) {
                listOf("Notifications are on for reminders.")
            } else {
                listOf("Reminders are notifications, so they need to be switched on for Safehouse Radio.")
            },
            buttonLabel = if (notificationsOk) null else "Allow notifications",
            onButton = {
                val needsAsk = Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED &&
                    !Reminders.askedForPermission(context)
                if (needsAsk) {
                    Reminders.markAskedForPermission(context)
                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    openSettings(
                        context,
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName),
                        appDetails(context)
                    )
                }
            }
        )

        // 2. Battery
        SetupCard(
            number = 2,
            done = batteryOk,
            title = "Allow background running",
            lines = if (batteryOk) {
                listOf("Safehouse Radio is allowed to run in the background.")
            } else {
                listOf(
                    "Without this, your phone may stop the app to save battery, and reminders can arrive late or not at all.",
                    "Find Safehouse Radio in the list and choose \"Don't optimise\" (or \"Unrestricted\")."
                )
            },
            buttonLabel = if (batteryOk) null else "Open battery settings",
            onButton = {
                openSettings(
                    context,
                    Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                    appDetails(context)
                )
            }
        )

        // 3. Tips for this make of phone
        val phone = phoneTips()
        SetupCard(
            number = 3,
            done = false,
            title = phone.first,
            lines = phone.second,
            buttonLabel = "Open app settings",
            onButton = { openSettings(context, appDetails(context), null) }
        )

        // 4. Test
        SetupCard(
            number = 4,
            done = false,
            title = "Send a test reminder",
            lines = listOf(
                if (testSent) {
                    "Sent! Lock your screen and wait a minute or so. If nothing arrives, go back over steps 1 to 3."
                } else {
                    "Arrives in about 10 seconds, the same way real reminders do. Lock your screen and wait."
                }
            ),
            buttonLabel = if (testSent) "Send another test" else "Send me a test reminder",
            onButton = {
                Reminders.scheduleTest(context)
                testSent = true
            }
        )

        Box(Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp)) {
            SetupButton("Done", onClick = {
                Reminders.markSetupSeen(context)
                onDone()
            }, modifier = Modifier.fillMaxWidth())
        }
    }
}

/** A title and a few tips that match the phone's make (the battery menus have different names). */
private fun phoneTips(): Pair<String, List<String>> {
    val maker = Build.MANUFACTURER.lowercase()
    return when {
        maker.contains("xiaomi") || maker.contains("redmi") || maker.contains("poco") -> Pair(
            "Your phone: Xiaomi",
            listOf(
                "•  In app settings, turn on \"Autostart\" for Safehouse Radio.",
                "•  Set the app's Battery saver to \"No restrictions\".",
                "•  Open your recent apps, then lock Safehouse Radio (long-press its card and tap the padlock). Otherwise clearing your recent apps can cancel reminders."
            )
        )
        maker.contains("samsung") -> Pair(
            "Your phone: Samsung",
            listOf(
                "•  Settings > Battery > Background usage limits.",
                "•  Add Safehouse Radio to \"Never sleeping apps\", and make sure it isn't in \"Sleeping apps\"."
            )
        )
        maker.contains("huawei") || maker.contains("honor") -> Pair(
            "Your phone: ${Build.MANUFACTURER}",
            listOf(
                "•  In app settings, open Battery > App launch.",
                "•  Switch off \"Manage automatically\", then allow auto-launch, secondary launch and run in background."
            )
        )
        maker.contains("oneplus") || maker.contains("oppo") || maker.contains("realme") || maker.contains("vivo") -> Pair(
            "Your phone: ${Build.MANUFACTURER}",
            listOf(
                "•  In app settings, set Battery usage to \"Allow background activity\" (or \"Unrestricted\").",
                "•  If there is an \"Auto-launch\" option, turn it on for Safehouse Radio."
            )
        )
        else -> Pair(
            "Your phone's battery settings",
            listOf(
                "•  In app settings, set Safehouse Radio's battery use to \"Unrestricted\" (or similar).",
                "•  If your phone has an \"Auto-start\" or \"Sleeping apps\" list, make sure Safehouse Radio is allowed."
            )
        )
    }
}

private fun appDetails(context: Context): Intent =
    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))

/** Opens a settings screen; if the phone doesn't have that one, tries [fallback]. */
private fun openSettings(context: Context, intent: Intent, fallback: Intent?) {
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        try {
            if (fallback != null) context.startActivity(fallback)
        } catch (e2: Exception) {
        }
    }
}

@Composable
private fun SetupCard(
    number: Int,
    done: Boolean,
    title: String,
    lines: List<String>,
    buttonLabel: String?,
    onButton: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(if (done) Green else MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (done) "✓" else number.toString(),
                    color = LavenderInk,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.width(10.dp))
            Text(
                text = title,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
        }
        for (line in lines) {
            Text(
                text = line,
                color = Color(0xFFD8D3E2),
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        if (buttonLabel != null) {
            SetupButton(buttonLabel, onClick = onButton, modifier = Modifier.padding(top = 12.dp))
        }
    }
}

@Composable
internal fun SetupButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.primary)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = LavenderInk, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}
