package com.example.radioplayer

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * One slot on the schedule. [isFiller] marks the "repeat shows" / "get in touch" / playlist slots,
 * which are shown quietly and never appear under Up Next or Recently Aired.
 */
data class Show(
    val start: Instant,
    val end: Instant,
    val dj: String?,
    val title: String,
    val genres: String?,
    val description: String,
    val isFiller: Boolean,
    // Set only on an "event": several back-to-back slots under one title, joined into one block
    // (see Events). [eventDjs] are the DJs / names found in those slots.
    val eventDjs: List<String> = emptyList(),
    val isEvent: Boolean = false
)

/**
 * What the On Air card shows. It is built from the live feed (what is really playing) and, when
 * the feed agrees with the calendar, the calendar's extra details (times, genres, description).
 * [start] / [end] are null when only the feed is known: there is no time or progress bar then.
 */
class OnAirDisplay(
    val dj: String?,
    val title: String?,
    val genres: String?,
    val description: String,
    val start: Instant?,
    val end: Instant?,
    val tag: String,            // "LIVE" (a live DJ is connected) or "ON AIR"
    val scheduledNote: String?, // "Scheduled: ..." when the feed and the calendar disagree
    val feedKey: String,        // changes when the show changes: used to refresh the picture
    val page: Dj? = null        // the DJ's page, if we have one (the card opens it)
)

class ScheduleSnapshot(
    val onAir: Show?,
    val upNext: List<Show>,
    val recent: List<Show>
)

/** Turns calendar entries into shows, and works out what's on air, up next and recently aired. */
object ScheduleLogic {

    private val SPACES = Regex("\\s+")
    // Phones and word processors turn " - " into a longer dash, or a bullet / full-width bar: all mean the same thing.
    private val LONG_DASH = Regex("\\s[\\u2012\\u2013\\u2014\\u2015\\u2212]\\s")
    private val BULLET = Regex("\\s[\\u2022\\u00B7\\u2219]\\s")
    private val GENRES = Regex("^(.*?)\\s*\\(([^()]*)\\)\\s*$")
    private val DJ_SLASH_SHOW = Regex("^([^/(|]+?)\\s+/\\s+(.+)$")
    private val OWNER_REPEAT = Regex("^(.+?)\\s+repeat\\s+shows?\\W*$", RegexOption.IGNORE_CASE)

    /**
     * The calendar is typed in by hand, so it comes in a few styles:
     *   "DJ Name | Show Name (Genre, Genre)"   the usual one
     *   "DJ Name - Show Name"                   also seen
     *   "DJ Name / Show Name"                   also seen
     *   "Repeat shows", "Get in touch…"         empty slots, treated as filler
     */
    fun toShow(e: CalendarEvent): Show {
        val text = e.summary.trim().replace(SPACES, " ")
            .replace(LONG_DASH, " - ").replace(BULLET, " | ")
            .replace('\uFF5C', '|').replace('\u00A6', '|')
        val lower = text.lowercase()

        // A placeholder like "Syndicast" is not a DJ: it is dropped here so it never reaches the app.
        fun make(dj: String?, title: String, genres: String?, filler: Boolean) =
            Show(
                e.start, e.end,
                dj?.takeUnless { DjMatch.isPlaceholder(it) }?.ifEmpty { null },
                DjMatch.scrub(title).orEmpty(), genres, DjMatch.scrub(e.description).orEmpty(), filler
            )

        fun split(rest: String): Pair<String, String?> {
            val g = GENRES.find(rest)
            val name = g?.groupValues?.get(1)?.trim().orEmpty()
            return if (g != null && name.isNotEmpty()) {
                name to g.groupValues[2].trim().ifEmpty { null }
            } else {
                rest to null
            }
        }

        val bar = text.indexOf('|')
        if (bar > 0) {
            val dj = text.substring(0, bar).trim()
            val (title, genres) = split(text.substring(bar + 1).trim())
            val shown = if (title.equals("live", ignoreCase = true)) "Live show" else title
            return make(dj, shown.ifEmpty { text }, genres, false)
        }

        val owner = OWNER_REPEAT.find(text)
        if (owner != null) return make(owner.groupValues[1].trim(), "Repeat show", null, true)

        if (lower.isEmpty() || lower.startsWith("repeat") || lower.contains("get in touch") ||
            lower.contains("want this set")
        ) {
            val title = if (lower.startsWith("your show here")) "Your show here?" else "Repeat shows"
            return make(null, title, null, true)
        }
        if (lower.startsWith("your show here")) return make(null, "Your show here?", null, true)
        if (lower == "general playlist") return make(null, "General playlist", null, true)

        val dash = text.indexOf(" - ")
        if (dash > 0) {
            val (title, genres) = split(text.substring(dash + 3).trim().trimStart('-', '|', ' '))
            return make(text.substring(0, dash).trim(), title.ifEmpty { text }, genres, false)
        }

        // "DJ Name / Show Name": the slash only counts before any brackets, so "(Trance / Hard Trance)" is left alone.
        val slash = DJ_SLASH_SHOW.find(text)
        if (slash != null) {
            val (title, genres) = split(slash.groupValues[2].trim())
            return make(slash.groupValues[1].trim(), title.ifEmpty { text }, genres, false)
        }

        val (title, genres) = split(text)
        return make(null, title, genres, false)
    }

    /** Calendar entries -> shows in time order (all-day notes like "Half term" are left out). */
    fun toShows(events: List<CalendarEvent>): List<Show> =
        events.filter { !it.allDay }
            .distinctBy { Triple(it.start, it.end, it.summary) }
            .map { toShow(it) }
            .sortedBy { it.start }

    fun snapshot(shows: List<Show>, now: Instant): ScheduleSnapshot {
        val current = shows.filter { !it.start.isAfter(now) && it.end.isAfter(now) }
        val onAir = current.filter { !it.isFiller }.maxByOrNull { it.start }
            ?: current.maxByOrNull { it.start }
        val upNext = shows.filter { !it.isFiller && it.start.isAfter(now) }.take(2)
        val recent = shows.filter { !it.isFiller && !it.end.isAfter(now) }
            .sortedByDescending { it.end }
            .take(3)
        return ScheduleSnapshot(onAir, upNext, recent)
    }

    /** Everything starting on [day] (in [zone]); neighbouring "repeat" slots are joined into one. */
    fun forDay(shows: List<Show>, day: LocalDate, zone: ZoneId): List<Show> {
        val out = ArrayList<Show>()
        for (s in shows) {
            if (s.start.atZone(zone).toLocalDate() != day) continue
            val last = out.lastOrNull()
            if (last != null && s.isFiller && last.isFiller && s.title == last.title && s.dj == last.dj &&
                !s.start.isAfter(last.end)) {
                if (s.end.isAfter(last.end)) out[out.size - 1] = last.copy(end = s.end)
            } else {
                out.add(s)
            }
        }
        return out
    }

    /** For the search box: does the DJ, show name or genres contain what was typed? */
    fun matchesQuery(s: Show, query: String): Boolean =
        listOfNotNull(s.dj, s.title, s.genres).any { it.contains(query, ignoreCase = true) }

    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    /** Does the calendar's show look like the same show the feed is reporting? */
    fun matches(scheduled: Show, feedTitle: String, feedDj: String?): Boolean {
        val f = norm(feedTitle)
        if (f.isEmpty()) return false
        val sd = scheduled.dj?.let { norm(it) }.orEmpty()
        val st = norm(scheduled.title)
        val fd = feedDj?.takeUnless { DjMatch.isPlaceholder(it) }?.let { norm(it) }.orEmpty()
        if (sd.length >= 3 && (f.contains(sd) || (fd.length >= 3 && sd.contains(fd)))) return true
        // Generic names like "Live show" say nothing about who is on.
        if (st.length >= 4 && st != "liveshow" && f.contains(st)) return true
        return false
    }

    /**
     * Decides what the On Air card shows. The live feed is the truth about what is playing; the
     * calendar is the plan. If they agree the calendar's details are used; if they don't, the feed
     * wins and the planned show is mentioned underneath. With no feed, the calendar is used.
     */
    fun onAirDisplay(scheduled: Show?, feed: LiveStatus?, djs: List<Dj> = emptyList()): OnAirDisplay? {
        val feedTitle = feed?.title?.trim().orEmpty()
        if (feed == null || feedTitle.isEmpty()) {
            val s = scheduled ?: return null
            return fromShow(s, "ON AIR", null, s.title + s.start.toEpochMilli(), djs)
        }
        val tag = if (feed.liveDj) "LIVE" else "ON AIR"
        // A show known by its file name (ABGT697): the card says what the Radio tab says; the calendar,
        // if it has the same DJ on now, adds the times and details.
        KnownShows.match(feedTitle)?.let { k ->
            val shown = StreamNames.resolve(feedTitle, djs, listOfNotNull(scheduled))
            val plan = scheduled?.takeIf { !it.isFiller && it.dj != null && DjMatch.djMatches(it.dj, DjMatch.key(k.dj)) }
            return OnAirDisplay(
                shown.dj, shown.show, plan?.genres, plan?.description.orEmpty(), plan?.start, plan?.end,
                tag, null, feedTitle, shown.match
            )
        }
        // A title too poor to show: the calendar's show if there is one on now, else the station itself.
        if (StreamQuality.isBad(feedTitle)) {
            if (scheduled != null && !scheduled.isFiller) return fromShow(scheduled, tag, null, feedTitle, djs)
            return OnAirDisplay(Config.STATION_NAME, Config.FALLBACK_SHOW, null, "", null, null, tag, null, feedTitle, null)
        }
        // A DJ part that is only a stray word ("the") says nothing about who is on.
        val fDj = splitNowPlaying(feedTitle).first?.takeIf { StreamQuality.djPart(it) != PartVerdict.BAD }
        if (scheduled != null && matches(scheduled, feedTitle, fDj)) {
            return fromShow(scheduled, tag, null, feedTitle, djs)
        }
        val note = scheduled?.takeIf { !it.isFiller }?.let {
            "Scheduled: " + (if (it.dj != null) it.dj + " – " + it.title else it.title)
        }
        val shown = StreamNames.resolve(feedTitle, djs, listOfNotNull(scheduled))
        return OnAirDisplay(
            dj = shown.dj ?: DjMatch.scrub(fDj ?: feedTitle),
            title = shown.show,
            genres = null,
            description = "",
            start = null,
            end = null,
            tag = tag,
            scheduledNote = note,
            feedKey = feedTitle,
            page = shown.match
        )
    }

    private fun fromShow(s: Show, tag: String, note: String?, key: String, djs: List<Dj>) =
        UpNext.djForShow(s, djs).let { page ->
            OnAirDisplay(s.dj ?: page?.name, s.title, s.genres, s.description, s.start, s.end, tag, note, key, page)
        }
}
