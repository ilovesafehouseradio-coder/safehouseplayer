package com.example.radioplayer

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * One slot on the schedule. [isFiller] marks the "repeat shows" / "get in touch" / playlist slots,
 * which are shown quietly and never appear under Up Next or Recently Aired.
 */
data class Show(
    val start: Instant,
    val end: Instant,
    val dj: String?,
    val title: String,
    val genres: String?,
    val description: String,
    val isFiller: Boolean
)

class ScheduleSnapshot(
    val onAir: Show?,
    val upNext: List<Show>,
    val recent: List<Show>
)

/** Turns calendar entries into shows, and works out what's on air, up next and recently aired. */
object ScheduleLogic {

    private val SPACES = Regex("\\s+")
    private val GENRES = Regex("^(.*?)\\s*\\(([^()]*)\\)\\s*$")
    private val OWNER_REPEAT = Regex("^(.+?)\\s+repeat\\s+shows?\\W*$", RegexOption.IGNORE_CASE)

    /**
     * The calendar is typed in by hand, so it comes in a few styles:
     *   "DJ Name | Show Name (Genre, Genre)"   the usual one
     *   "DJ Name - Show Name"                   also seen
     *   "Repeat shows", "Get in touch…"         empty slots, treated as filler
     */
    fun toShow(e: CalendarEvent): Show {
        val text = e.summary.trim().replace(SPACES, " ")
        val lower = text.lowercase()

        fun make(dj: String?, title: String, genres: String?, filler: Boolean) =
            Show(e.start, e.end, dj?.ifEmpty { null }, title, genres, e.description, filler)

        fun split(rest: String): Pair<String, String?> {
            val g = GENRES.find(rest)
            val name = g?.groupValues?.get(1)?.trim().orEmpty()
            return if (g != null && name.isNotEmpty()) {
                name to g.groupValues[2].trim().ifEmpty { null }
            } else {
                rest to null
            }
        }

        val bar = text.indexOf('|')
        if (bar > 0) {
            val dj = text.substring(0, bar).trim()
            val (title, genres) = split(text.substring(bar + 1).trim())
            val shown = if (title.equals("live", ignoreCase = true)) "Live show" else title
            return make(dj, shown.ifEmpty { text }, genres, false)
        }

        val owner = OWNER_REPEAT.find(text)
        if (owner != null) return make(owner.groupValues[1].trim(), "Repeat show", null, true)

        if (lower.isEmpty() || lower.startsWith("repeat") || lower.contains("get in touch") ||
            lower.contains("want this set")
        ) {
            val title = if (lower.startsWith("your show here")) "Your show here?" else "Repeat shows"
            return make(null, title, null, true)
        }
        if (lower.startsWith("your show here")) return make(null, "Your show here?", null, true)
        if (lower == "general playlist") return make(null, "General playlist", null, true)

        val dash = text.indexOf(" - ")
        if (dash > 0) {
            val (title, genres) = split(text.substring(dash + 3).trim())
            return make(text.substring(0, dash).trim(), title.ifEmpty { text }, genres, false)
        }

        val (title, genres) = split(text)
        return make(null, title, genres, false)
    }

    /** Calendar entries -> shows in time order (all-day notes like "Half term" are left out). */
    fun toShows(events: List<CalendarEvent>): List<Show> =
        events.filter { !it.allDay }
            .distinctBy { Triple(it.start, it.end, it.summary) }
            .map { toShow(it) }
            .sortedBy { it.start }

    fun snapshot(shows: List<Show>, now: Instant): ScheduleSnapshot {
        val current = shows.filter { !it.start.isAfter(now) && it.end.isAfter(now) }
        val onAir = current.filter { !it.isFiller }.maxByOrNull { it.start }
            ?: current.maxByOrNull { it.start }
        val upNext = shows.filter { !it.isFiller && it.start.isAfter(now) }.take(2)
        val recent = shows.filter { !it.isFiller && !it.end.isAfter(now) }
            .sortedByDescending { it.end }
            .take(3)
        return ScheduleSnapshot(onAir, upNext, recent)
    }

    /** Everything starting on [day] (in [zone]); neighbouring "repeat" slots are joined into one. */
    fun forDay(shows: List<Show>, day: LocalDate, zone: ZoneId): List<Show> {
        val out = ArrayList<Show>()
        for (s in shows) {
            if (s.start.atZone(zone).toLocalDate() != day) continue
            val last = out.lastOrNull()
            if (last != null && s.isFiller && last.isFiller && s.title == last.title && s.dj == last.dj &&
                !s.start.isAfter(last.end)) {
                if (s.end.isAfter(last.end)) out[out.size - 1] = last.copy(end = s.end)
            } else {
                out.add(s)
            }
        }
        return out
    }
}
