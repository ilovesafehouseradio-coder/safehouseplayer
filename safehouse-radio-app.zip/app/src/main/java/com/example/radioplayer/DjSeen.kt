package com.example.radioplayer

import android.content.Context

/**
 * Notices DJs that have been added to the website's list since the app last looked, so the DJs page
 * can give them a "NEW" pill for two weeks. It is all kept on the phone (the DJ's page address and the
 * day the app first saw it): nothing is sent anywhere. The very first time the app runs, every DJ
 * already on the list counts as known, so nobody is marked "new" just because the app is new.
 */
object DjSeen {
    private const val PREFS = "djs_seen"
    private const val KEY = "seen"
    private const val SEP = "\u0001"
    private const val NEW_MS = 14L * 24 * 3600 * 1000
    private const val MIN_LIST = 10     // a list shorter than this is probably a failed read: don't learn from it
    private const val MAX_NEW_AT_ONCE = 15  // many "new" at once means the site changed its links, not that people joined

    @Synchronized
    fun newLinks(ctx: Context, djs: List<Dj>, now: Long = System.currentTimeMillis()): Set<String> {
        if (djs.size < MIN_LIST) return emptySet()
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val first = !p.contains(KEY)
        val known = HashMap<String, Long>()
        for (e in p.getStringSet(KEY, emptySet()).orEmpty()) {
            val i = e.indexOf(SEP)
            if (i > 0) e.substring(i + 1).toLongOrNull()?.let { known[e.substring(0, i)] = it }
        }
        val unseen = djs.filter { it.link !in known }
        if (unseen.isNotEmpty() || first) {
            val stamp = if (first || unseen.size > MAX_NEW_AT_ONCE) 0L else now
            for (d in unseen) known[d.link] = stamp
            p.edit().putStringSet(KEY, known.map { it.key + SEP + it.value }.toSet()).apply()
        }
        return djs.filter {
            val t = known[it.link] ?: 0L
            t > 0L && now - t < NEW_MS
        }.map { it.link }.toSet()
    }
}
