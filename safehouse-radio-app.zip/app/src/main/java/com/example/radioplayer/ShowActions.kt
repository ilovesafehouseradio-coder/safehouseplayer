package com.example.radioplayer

import android.content.Context
import android.content.Intent
import android.provider.CalendarContract
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * "Add to calendar" and "Share" for a coming show on a DJ's page. The calendar button opens the phone's own
 * calendar app with the show filled in (so the app needs no calendar permission); the share button opens the
 * usual share sheet with a short message.
 */
object ShowActions {

    /** The link in a share message. When the app is on Google Play this is where its Play Store address goes. */
    private const val LINK = Config.WEBSITE_URL

    /** "Mon 2 Nov · 19:00 – 21:00 GMT" (with the time zone, because it goes to other people). */
    fun whenLine(show: Show, zone: ZoneId, is24: Boolean): String {
        val time = DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a", Locale.getDefault())
        val day = DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault())
        val tz = DateTimeFormatter.ofPattern("z", Locale.getDefault())
        val start = show.start.atZone(zone)
        val end = show.end.atZone(zone)
        return "${day.format(start)} · ${time.format(start)} – ${time.format(end)} ${tz.format(start)}"
    }

    /** The message that goes with a share: a coming show, or one that is on right now. */
    fun shareText(dj: String, show: Show, live: Boolean, zone: ZoneId, is24: Boolean): String {
        val title = DjMatch.scrub(show.title).orEmpty().trim()
        val showLine = if (title.isEmpty() || title.equals(dj, ignoreCase = true)) "" else title
        return if (live) {
            liveText(dj, showLine)
        } else {
            val lines = ArrayList<String>()
            lines.add("🎧 Catch $dj on ${Config.STATION_NAME}")
            lines.add(whenLine(show, zone, is24))
            if (showLine.isNotEmpty()) lines.add(showLine)
            lines.joinToString("\n") + "\n\nListen live: $LINK\n#SafehouseRadio"
        }
    }

    /** "Live now" message for the DJ and show on air ([showLine] may be empty). */
    fun liveText(dj: String, showLine: String): String {
        val line = if (showLine.isEmpty() || showLine.equals(dj, ignoreCase = true)) dj else "$dj – $showLine"
        return "🎧 Live now on ${Config.STATION_NAME}\n$line\n\nListen live: $LINK\n#SafehouseRadio"
    }

    fun share(ctx: Context, text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        try {
            ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            // Nothing to share with: nothing to do.
        }
    }

    /** Opens the phone's calendar with this show filled in; the listener presses Save there. */
    fun addToCalendar(ctx: Context, dj: String, show: Show) {
        val title = DjMatch.scrub(show.title).orEmpty().trim()
        val description = buildString {
            if (title.isNotEmpty()) append(title).append("\n")
            append("Listen live: ").append(LINK)
        }
        val insert = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, show.start.toEpochMilli())
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, show.end.toEpochMilli())
            .putExtra(CalendarContract.Events.TITLE, "$dj on ${Config.STATION_NAME}")
            .putExtra(CalendarContract.Events.DESCRIPTION, description)
            .putExtra(CalendarContract.Events.EVENT_LOCATION, "${Config.STATION_NAME} (online)")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(insert)
        } catch (e: Exception) {
            Toast.makeText(ctx, "No calendar app found on this phone", Toast.LENGTH_SHORT).show()
        }
    }
}

enum class ActionGlyph { CALENDAR, SHARE }

private val GlyphColor = Color(0xFFF8F8F8)

@Composable
private fun Glyph(glyph: ActionGlyph, size: androidx.compose.ui.unit.Dp) {
    if (glyph == ActionGlyph.SHARE) {
        ActionIconView(ActionIcon.SHARE, GlyphColor)
        return
    }
    // A small calendar with a plus.
    Canvas(Modifier.size(size)) {
        val u = this.size.width / 24f
        val w = 1.8f * u
        drawRoundRect(
            color = GlyphColor,
            topLeft = Offset(3.5f * u, 5f * u),
            size = Size(17f * u, 15.5f * u),
            cornerRadius = CornerRadius(2.5f * u),
            style = Stroke(width = w, cap = StrokeCap.Round)
        )
        drawLine(GlyphColor, Offset(4.2f * u, 10f * u), Offset(19.8f * u, 10f * u), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(GlyphColor, Offset(8f * u, 3f * u), Offset(8f * u, 6.5f * u), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(GlyphColor, Offset(16f * u, 3f * u), Offset(16f * u, 6.5f * u), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(GlyphColor, Offset(12f * u, 12.5f * u), Offset(12f * u, 18f * u), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(GlyphColor, Offset(9.2f * u, 15.2f * u), Offset(14.8f * u, 15.2f * u), strokeWidth = w, cap = StrokeCap.Round)
    }
}

/**
 * A labelled button for the Next show card: 48dp tall, outlined in lavender. Given a width (weight) it
 * fills it and centres its words; the words never wrap, and are cut short with "…" rather than spill out.
 */
@Composable
fun ActionPill(label: String, glyph: ActionGlyph, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(
        modifier
            .heightIn(min = 48.dp)
            .lift(RoundedCornerShape(50), tappable = true)
            .clip(RoundedCornerShape(50))
            .background(CardSurface)
            .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(50))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Glyph(glyph, 22.dp)
        Spacer(Modifier.width(8.dp))
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
    }
}

/** The same outlined look as [ActionPill] but a round, icon-only 48dp button (screen readers say [description]). */
@Composable
fun ActionRoundButton(description: String, glyph: ActionGlyph, onClick: () -> Unit) {
    Box(
        Modifier
            .size(48.dp)
            .lift(CircleShape, tappable = true)
            .clip(CircleShape)
            .background(CardSurface)
            .border(1.dp, MaterialTheme.colorScheme.primary, CircleShape)
            .clickable(onClickLabel = description, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        Glyph(glyph, 22.dp)
    }
}

/**
 * The plain Share icon for the corner of a Schedule card: no circle, a 48dp touch area, the same size as the bell
 * under it. [tint] suits the card it sits on.
 */
@Composable
fun CardShareButton(description: String, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .size(48.dp)
            .clip(CircleShape)
            .clickable(onClickLabel = description, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        ActionIconView(ActionIcon.SHARE, tint)
    }
}

/** A compact, icon-only 48dp button for the cards under "Later"; screen readers say what it does. */
@Composable
fun ActionIconButton(description: String, glyph: ActionGlyph, onClick: () -> Unit) {
    Box(
        Modifier
            .size(48.dp)
            .clip(CircleShape)
            .clickable(onClickLabel = description, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        Glyph(glyph, 24.dp)
    }
}

/**
 * The two actions for one coming show of [dj]. [compact] is the icon-only form for the later cards. A show that
 * is on right now can only be shared (worded "Live now"); a repeat slot has no actions at all.
 */
@Composable
fun ShowActionRow(dj: String, show: Show, now: Instant, zone: ZoneId, is24: Boolean, compact: Boolean) {
    if (show.isFiller) return
    val ctx = LocalContext.current
    val live = !show.start.isAfter(now)
    val label = if (show.title.isBlank()) dj else "${show.title} with $dj"
    val doShare = { ShowActions.share(ctx, ShowActions.shareText(dj, show, live, zone, is24)) }
    val doCalendar = { ShowActions.addToCalendar(ctx, dj, show) }
    if (compact) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!live) ActionIconButton("Add $label to calendar", ActionGlyph.CALENDAR, doCalendar)
            ActionIconButton("Share $label", ActionGlyph.SHARE, doShare)
        }
    } else {
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!live) {
                // Calendar takes the width that is left; Share is a round icon beside it, so neither is ever cut off.
                ActionPill("Add to calendar", ActionGlyph.CALENDAR, Modifier.weight(1f), doCalendar)
                Spacer(Modifier.width(8.dp))
                ActionRoundButton("Share $label", ActionGlyph.SHARE, doShare)
            } else {
                ActionPill("Share", ActionGlyph.SHARE, onClick = doShare)
            }
        }
    }
}
