package com.example.radioplayer

/**
 * Joins back-to-back slots that belong to one event into a single block.
 *
 * On special days (Christmas, New Year's Eve, "Sunday Sesh" and so on) the calendar often lists one
 * slot per DJ, every one carrying the same event title. For the DJ profiles and reminders those are
 * one event: it runs from the first slot's start to the last slot's end, and every DJ in it is part
 * of it. The Schedule tab itself keeps showing the separate slots.
 */
object Events {

    private const val MAX_GAP_MS = 10 * 60_000L   // slots may be this far apart and still count as back to back
    private const val MIN_SHARED = 12              // a title must be at least this long for the "ends with" rule

    fun group(shows: List<Show>): List<Show> {
        val sorted = shows.sortedBy { it.start }
        val out = ArrayList<Show>(sorted.size)
        var run = ArrayList<Show>()

        fun flush() {
            if (run.size >= 2) {
                val hosts = run.map { it.dj ?: it.title }.distinctBy { DjMatch.key(it) }
                if (hosts.size >= 2) {
                    val title = run.map { it.title.trim() }.maxByOrNull { it.length } ?: run[0].title
                    out.add(
                        Show(
                            start = run.first().start,
                            end = run.maxOf { it.end },
                            dj = null,
                            title = title,
                            genres = run.firstNotNullOfOrNull { it.genres },
                            description = run.firstOrNull { it.description.isNotBlank() }?.description.orEmpty(),
                            isFiller = false,
                            eventDjs = hosts,
                            isEvent = true
                        )
                    )
                    run = ArrayList()
                    return
                }
            }
            out.addAll(run)
            run = ArrayList()
        }

        for (s in sorted) {
            if (s.isFiller) {
                flush()
                out.add(s)
                continue
            }
            val last = run.lastOrNull()
            if (last != null && sameEvent(last, s) && s.start.toEpochMilli() - last.end.toEpochMilli() <= MAX_GAP_MS) {
                run.add(s)
            } else {
                flush()
                run.add(s)
            }
        }
        flush()
        return out.sortedBy { it.start }
    }

    private fun sameEvent(a: Show, b: Show): Boolean {
        if (a.dj == null && b.dj == null) return false          // loose titles: nothing says they belong together
        val x = DjMatch.key(a.title)
        val y = DjMatch.key(b.title)
        if (x.isEmpty() || y.isEmpty()) return false
        if (x == y) return true
        val (short, long) = if (x.length <= y.length) x to y else y to x
        return short.length >= MIN_SHARED && long.endsWith(short)
    }
}
