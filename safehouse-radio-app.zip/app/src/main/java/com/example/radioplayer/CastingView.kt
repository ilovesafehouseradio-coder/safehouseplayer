package com.example.radioplayer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.session.MediaController
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/** Whether the radio is being cast right now, and to what (the TV's own name). */
class CastInfo(val connected: Boolean, val deviceName: String?)

/** Follows the Chromecast connection, so the Radio tab can switch to its casting view and back. */
@Composable
fun rememberCastInfo(): CastInfo {
    val appContext = LocalContext.current.applicationContext
    var info by remember { mutableStateOf(CastInfo(false, null)) }
    DisposableEffect(Unit) {
        val read: () -> Unit = {
            val session = try {
                CastContext.getSharedInstance(appContext).sessionManager.currentCastSession
            } catch (e: Exception) {
                null
            }
            info = CastInfo(session != null && session.isConnected, session?.castDevice?.friendlyName)
        }
        val listener = object : SessionManagerListener<CastSession> {
            override fun onSessionStarting(session: CastSession) {}
            override fun onSessionStarted(session: CastSession, sessionId: String) = read()
            override fun onSessionStartFailed(session: CastSession, error: Int) = read()
            override fun onSessionEnding(session: CastSession) {}
            override fun onSessionEnded(session: CastSession, error: Int) = read()
            override fun onSessionResuming(session: CastSession, sessionId: String) {}
            override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) = read()
            override fun onSessionResumeFailed(session: CastSession, error: Int) = read()
            override fun onSessionSuspended(session: CastSession, reason: Int) = read()
        }
        var added = false
        try {
            CastContext.getSharedInstance(appContext).sessionManager
                .addSessionManagerListener(listener, CastSession::class.java)
            added = true
            read()
        } catch (e: Exception) {
            // No Google Play services: casting is simply never on.
        }
        onDispose {
            if (added) {
                try {
                    CastContext.getSharedInstance(appContext).sessionManager
                        .removeSessionManagerListener(listener, CastSession::class.java)
                } catch (e: Exception) {
                }
            }
        }
    }
    return info
}

/**
 * The Radio tab while a Chromecast is playing: only the controls that really work there. Where it is playing,
 * what is on, play / pause, the TV's volume, and a way back to the phone. All in the current theme's colours.
 */
@Composable
fun CastingView(
    deviceName: String?,
    djName: String?,
    showName: String?,
    isPlaying: Boolean,
    isBuffering: Boolean,
    hasError: Boolean,
    controller: MediaController?
) {
    val ctx = LocalContext.current
    val pal = ThemeState.current
    var volume by remember { mutableStateOf(CastVolume.level(ctx)) }
    var lastTouch by remember { mutableStateOf(0L) }
    // Follows changes made elsewhere (the phone's buttons, the TV's own remote).
    LaunchedEffect(Unit) {
        while (true) {
            if (System.currentTimeMillis() - lastTouch > 1500) volume = CastVolume.level(ctx)
            delay(500)
        }
    }
    val cardShape = RoundedCornerShape(20.dp)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 28.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Where it is playing.
        Column(
            Modifier
                .fillMaxWidth()
                .clip(cardShape)
                .background(pal.cardSurface)
                .border(1.dp, pal.primary, cardShape)
                .padding(16.dp)
        ) {
            Text("PLAYING ON YOUR TV", color = pal.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = rememberLogoTile(),
                    contentDescription = null,
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(16.dp))
                )
                Spacer(Modifier.size(16.dp))
                Column {
                    Text(
                        deviceName ?: "Your TV or speaker", color = pal.text, fontSize = 22.sp,
                        fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Text("${Config.STATION_NAME} is playing there", color = pal.textDim, fontSize = 14.sp)
                }
            }
        }

        // What is on.
        Column(
            Modifier
                .fillMaxWidth()
                .clip(cardShape)
                .background(pal.cardSurface)
                .border(1.dp, pal.primary, cardShape)
                .padding(16.dp)
        ) {
            val note = when {
                hasError -> "Connection lost. Reconnecting…"
                isBuffering && !isPlaying -> "Connecting…"
                !isPlaying -> "Paused"
                else -> null
            }
            if (isPlaying) {
                StatusPill("LIVE", pal.live, pal.background)
                Spacer(Modifier.height(8.dp))
            }
            Text(
                djName ?: Config.STATION_NAME, color = pal.text, fontSize = 26.sp,
                fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            if (showName != null) {
                Text(showName, color = pal.textDim, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (note != null) {
                Spacer(Modifier.height(4.dp))
                Text(note, color = pal.textDim, fontSize = 14.sp)
            }
        }

        // Play / pause.
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .size(88.dp)
                    .clip(CircleShape)
                    .background(pal.primary)
                    .semantics { contentDescription = if (isPlaying || isBuffering) "Pause" else "Play" }
                    .clickable(enabled = controller != null, role = Role.Button) {
                        controller?.let { togglePlayback(it) }
                    },
                contentAlignment = Alignment.Center
            ) {
                PlayPauseIcon(isPlaying, pal.onPrimary)
            }
            Spacer(Modifier.height(6.dp))
            Text(if (isPlaying || isBuffering) "Pause" else "Play", color = pal.textDim, fontSize = 16.sp)
        }

        // The TV's volume.
        Column(
            Modifier
                .fillMaxWidth()
                .clip(cardShape)
                .background(pal.cardSurface)
                .border(1.dp, pal.primary, cardShape)
                .padding(16.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "TV VOLUME", color = pal.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp, modifier = Modifier.weight(1f)
                )
                Text(
                    "${(volume * 100).roundToInt()}%", color = pal.text, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.End
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                VolumeButton("−", "Lower the TV volume") {
                    lastTouch = System.currentTimeMillis()
                    volume = (volume - 0.05f).coerceIn(0f, 1f)
                    CastVolume.set(ctx, volume)
                }
                Slider(
                    value = volume,
                    onValueChange = {
                        lastTouch = System.currentTimeMillis()
                        volume = it
                        CastVolume.set(ctx, it)
                    },
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = pal.primary,
                        activeTrackColor = pal.primary,
                        inactiveTrackColor = pal.background
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                        .semantics { contentDescription = "TV volume" }
                )
                VolumeButton("+", "Raise the TV volume") {
                    lastTouch = System.currentTimeMillis()
                    volume = (volume + 0.05f).coerceIn(0f, 1f)
                    CastVolume.set(ctx, volume)
                }
            }
            Text(
                "Or use your phone’s volume buttons", color = pal.textDim, fontSize = 14.sp,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }

        // The way back.
        val pill = RoundedCornerShape(50)
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 56.dp)
                .clip(pill)
                .border(2.dp, pal.primary, pill)
                .clickable(role = Role.Button) { CastVolume.stopCasting(ctx) }
                .padding(horizontal = 24.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "Stop casting – play on this phone", color = pal.text, fontSize = 16.sp,
                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun VolumeButton(symbol: String, description: String, onClick: () -> Unit) {
    val pal = ThemeState.current
    Box(
        Modifier
            .size(56.dp)
            .clip(CircleShape)
            .border(2.dp, pal.primary, CircleShape)
            .semantics { contentDescription = description }
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(symbol, color = pal.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
    }
}
