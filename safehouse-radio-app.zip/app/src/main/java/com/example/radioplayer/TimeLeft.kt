package com.example.radioplayer

import java.time.Duration
import java.time.Instant

/**
 * What the listener is actually hearing. When they have gone back (rewind), the show is that many seconds
 * "younger" for them: the Radio tab and the On Air card both use this, so their label and bar always agree.
 */
object Heard {
    fun at(now: Instant): Instant =
        if (TimeShift.rewound) now.minusSeconds(TimeShift.behindSeconds.toLong().coerceAtLeast(0L)) else now

    /** "40 s behind" / "1:05 behind" while rewound, otherwise null. */
    fun behindText(): String? {
        if (!TimeShift.rewound) return null
        val s = TimeShift.behindSeconds.coerceAtLeast(0)
        return if (s < 60) "$s s behind" else "${s / 60}:${(s % 60).toString().padStart(2, '0')} behind"
    }
}

/** "34 min left" for the show on air, worked out from the schedule's end time (null when there isn't one). */
object TimeLeft {
    fun text(end: Instant?, now: Instant): String? {
        if (end == null) return null
        val seconds = Duration.between(now, end).seconds
        if (seconds <= 0) return null
        val minutes = (seconds + 59) / 60
        return when {
            minutes <= 3 -> "Ending soon"
            minutes < 60 -> "$minutes min left"
            minutes % 60 == 0L -> "${minutes / 60} hr left"
            else -> "${minutes / 60} hr ${minutes % 60} min left"
        }
    }
}
