package com.example.radioplayer

import java.time.Duration
import java.time.Instant

/** "34 min left" for the show on air, worked out from the schedule's end time (null when there isn't one). */
object TimeLeft {
    fun text(end: Instant?, now: Instant): String? {
        if (end == null) return null
        val seconds = Duration.between(now, end).seconds
        if (seconds <= 0) return null
        val minutes = (seconds + 59) / 60
        return when {
            minutes <= 3 -> "Ending soon"
            minutes < 60 -> "$minutes min left"
            minutes % 60 == 0L -> "${minutes / 60} hr left"
            else -> "${minutes / 60} hr ${minutes % 60} min left"
        }
    }
}
