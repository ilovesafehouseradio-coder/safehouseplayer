package com.example.radioplayer

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.roundToInt

/**
 * The station's round logo on a square of the theme's card colour: the picture shown wherever a DJ or show has
 * no artwork of its own. It is drawn (not a fixed picture), so its background follows the chosen theme.
 */
private class LogoTilePainter(private val logo: ImageBitmap, private val background: Color) : Painter() {
    override val intrinsicSize: Size = Size(768f, 768f)

    override fun DrawScope.onDraw() {
        drawRect(background)
        // The round logo fills about 88% of the square, centred.
        val side = minOf(size.width, size.height) * 0.881f
        val x = ((size.width - side) / 2f).roundToInt()
        val y = ((size.height - side) / 2f).roundToInt()
        drawImage(
            image = logo,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(logo.width, logo.height),
            dstOffset = IntOffset(x, y),
            dstSize = IntSize(side.roundToInt(), side.roundToInt()),
            filterQuality = FilterQuality.High
        )
    }
}

/** The station logo tile in the current theme's card colour (changes the moment the theme does). */
@Composable
fun rememberLogoTile(): Painter {
    val logo = ImageBitmap.imageResource(R.drawable.station_logo)
    val background = ThemeState.current.card
    return remember(logo, background) { LogoTilePainter(logo, background) }
}
