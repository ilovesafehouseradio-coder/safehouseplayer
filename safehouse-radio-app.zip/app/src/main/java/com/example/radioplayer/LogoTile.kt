package com.example.radioplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.toArgb
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.roundToInt

/**
 * The station's round logo on a square of the theme's card colour: the picture shown wherever a DJ or show has
 * no artwork of its own. It is drawn (not a fixed picture), so its background follows the chosen theme.
 */
private class LogoTilePainter(private val logo: ImageBitmap, private val background: Color) : Painter() {
    override val intrinsicSize: Size = Size(768f, 768f)

    override fun DrawScope.onDraw() {
        drawRect(background)
        // The round logo fills about 88% of the square, centred.
        val side = minOf(size.width, size.height) * 0.881f
        val x = ((size.width - side) / 2f).roundToInt()
        val y = ((size.height - side) / 2f).roundToInt()
        drawImage(
            image = logo,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(logo.width, logo.height),
            dstOffset = IntOffset(x, y),
            dstSize = IntSize(side.roundToInt(), side.roundToInt()),
            filterQuality = FilterQuality.High
        )
    }
}

/** The station logo tile in the current theme's card colour (changes the moment the theme does). */
@Composable
fun rememberLogoTile(): Painter {
    val logo = ImageBitmap.imageResource(ThemeState.current.logo)
    val background = ThemeState.current.card
    return remember(logo, background) { LogoTilePainter(logo, background) }
}

/** The same tile as a plain picture (for the notification, lock screen and share cards), in a theme's colours. */
object LogoTiles {
    fun bitmap(ctx: Context, palette: Palette): Bitmap? {
        return try {
            val logo = BitmapFactory.decodeResource(ctx.resources, palette.logo) ?: return null
            val out = Bitmap.createBitmap(768, 768, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            c.drawColor(palette.card.toArgb())
            val side = 768f * 0.881f
            val off = (768f - side) / 2f
            c.drawBitmap(logo, null, RectF(off, off, off + side, off + side), Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
            logo.recycle()
            out
        } catch (e: Exception) {
            null
        }
    }
}
