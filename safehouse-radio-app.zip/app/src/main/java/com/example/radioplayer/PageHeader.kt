package com.example.radioplayer

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The dark, see-through background of the cards on top of the wallpaper (shows, DJs, search box).
 * Raise the CC (80% black) towards FF for more solid cards, lower it to let more wallpaper through.
 */
val CardSurface = Color(0xCC000000)

/**
 * The title at the top of every page ("Safehouse Radio", "Schedule", "Our DJs").
 * One place, so all the pages look the same: change it here and they all change.
 */
@Composable
fun PageHeader(title: String, horizontalPadding: Dp = 16.dp) {
    Text(
        text = title,
        color = MaterialTheme.colorScheme.onBackground,
        fontSize = 28.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.85f), Offset(0f, 3f), 14f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = horizontalPadding, end = horizontalPadding, top = 16.dp)
    )
}
