package com.example.radioplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The dark, see-through background of the cards on top of the wallpaper (shows, DJs, search box).
 * Raise the CC (80% black) towards FF for more solid cards, lower it to let more wallpaper through.
 */
val CardSurface = Color(0xCC000000)

/** Dark text used on top of lavender (the same near-black as the On Air card). */
val LavenderInk = Color(0xFF14121A)

/** Height of the lavender bar at the top of the Radio, Schedule and DJs pages: the same on all three. */
val BarHeight = 52.dp

/** Size of the writing in that bar. Shared with the On Air / Schedule tabs so they always match. */
val BarTextSize = 18.sp

/**
 * The title at the top of the Radio and DJs pages: a lavender bar with dark bold text. The
 * Schedule page uses a bar with exactly the same height, width, corners and text size for its
 * On Air / Schedule tabs (see ScheduleTabs), so all three pages start the same way.
 * [trailing] is for something that sits inside the bar at the right-hand end (the cast button);
 * it floats over the bar and never changes its size.
 */
@Composable
fun PageHeader(
    title: String,
    horizontalPadding: Dp = 16.dp,
    trailing: @Composable BoxScope.() -> Unit = {}
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = horizontalPadding, end = horizontalPadding, top = 16.dp, bottom = 10.dp)
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.primary)
            .heightIn(min = BarHeight),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = LavenderInk,
            fontSize = BarTextSize,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            // Screen readers announce this as a page heading.
            modifier = Modifier
                .padding(horizontal = 56.dp, vertical = 8.dp)
                .semantics { heading() }
        )
        Box(Modifier.matchParentSize()) { trailing() }
    }
}
