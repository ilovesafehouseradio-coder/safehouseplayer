package com.example.radioplayer

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Lavender = Color(0xFF9994AC)

/**
 * The opening screen: the wallpaper, the logo bouncing in over a pulsing glow, the slogan
 * fading up, and dancing equaliser bars. It plays for about two and a half seconds, then fades
 * away to reveal the app. Tap anywhere to skip it.
 */
@Composable
fun WelcomeOverlay(onFinished: () -> Unit) {
    // "Reduce animations": the logo and slogan are simply there, still, and the screen fades out sooner.
    val context = LocalContext.current
    val calm = AppSettings.reduceMotion(context)
    val logoScale = remember { Animatable(if (calm) 1f else 0.5f) }
    val logoAlpha = remember { Animatable(if (calm) 1f else 0f) }
    val sloganAlpha = remember { Animatable(if (calm) 1f else 0f) }
    val overlayAlpha = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        // The jingle (only if it is welcome: see WelcomeSound).
        WelcomeSound.play(context)
        if (calm) {
            delay(900)
            overlayAlpha.animateTo(0f, tween(300))
            onFinished()
            return@LaunchedEffect
        }
        launch { logoAlpha.animateTo(1f, tween(500)) }
        launch {
            logoScale.animateTo(
                1f,
                spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)
            )
        }
        delay(550)
        sloganAlpha.animateTo(1f, tween(600))
        delay(1100)
        overlayAlpha.animateTo(0f, tween(450))
        onFinished()
    }

    val pulse = rememberInfiniteTransition(label = "glow")
    val animatedGlow by pulse.animateFloat(
        initialValue = 0.30f,
        targetValue = 0.80f,
        animationSpec = infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Reverse),
        label = "glowAlpha"
    )
    val glow = if (calm) 0.55f else animatedGlow

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = overlayAlpha.value }
            .background(Color(0xFF050505))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                WelcomeSound.stop()
                onFinished()
            }
    ) {
        Image(
            painter = painterResource(R.drawable.wallpaper),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alignment = BiasAlignment(0.2f, 0f),
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Color(0x99000000)))

        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(300.dp)
                        .background(
                            Brush.radialGradient(listOf(Lavender.copy(alpha = glow), Color.Transparent))
                        )
                )
                Image(
                    painter = painterResource(R.drawable.station_logo),
                    contentDescription = Config.STATION_NAME,
                    modifier = Modifier
                        .size(200.dp)
                        .graphicsLayer {
                            scaleX = logoScale.value
                            scaleY = logoScale.value
                            alpha = logoAlpha.value
                        }
                        .clip(CircleShape)
                )
            }

            Spacer(Modifier.height(24.dp))

            Text(
                text = Config.SLOGAN,
                color = Color(0xFFF8F8F8),
                fontSize = 17.sp,
                fontWeight = FontWeight.Light,
                textAlign = TextAlign.Center,
                style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.85f), Offset(0f, 3f), 14f)),
                modifier = Modifier.graphicsLayer { alpha = sloganAlpha.value }
            )

            Spacer(Modifier.height(28.dp))

            Box(Modifier.graphicsLayer { alpha = sloganAlpha.value }) {
                if (!calm) EqualizerBars()
            }
        }
    }
}

/** Five bars that bounce up and down at different speeds, like a sound-level meter. */
@Composable
private fun EqualizerBars() {
    val transition = rememberInfiniteTransition(label = "bars")
    val speeds = listOf(520, 740, 610, 880, 560)
    Row(
        modifier = Modifier.height(36.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        for ((i, millis) in speeds.withIndex()) {
            val level by transition.animateFloat(
                initialValue = 0.2f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(millis, easing = LinearEasing), RepeatMode.Reverse),
                label = "bar$i"
            )
            Box(
                Modifier
                    .width(6.dp)
                    .fillMaxHeight(level)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Lavender)
            )
        }
    }
}
