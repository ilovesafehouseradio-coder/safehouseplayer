package com.example.radioplayer

/**
 * Proper English capitals for names and show titles that were sent all in small letters or ALL IN CAPITALS
 * ("john smith" / "JOHN SMITH" -> "John Smith", "on-air-536" -> "On Air 536"). A DJ with a card on our list
 * always gets the card's spelling instead (see StreamNames). Anything sent in proper mixed case is left
 * exactly as it was sent: clean metadata is never changed.
 */
object NameCase {
    // Short words that are always written in capitals.
    private val KEEP_UPPER = setOf(
        "DJ", "MC", "B2B", "B3B", "UK", "USA", "US", "EU", "EP", "LP", "VIP", "FM", "EDM", "BPM", "TV",
        "ABGT", "ASOT", "BBC", "NYC", "LA", "II", "III", "IV", "XL"
    )
    // Small joining words: written small, unless they start the title.
    private val SMALL = setOf(
        "a", "an", "and", "as", "at", "but", "by", "for", "from", "in", "into", "nor", "of", "on", "or",
        "the", "to", "vs", "with", "feat", "ft"
    )

    /** True when every letter is small, or every letter is a capital (and there are letters at all). */
    private fun uniform(t: String): Boolean {
        val letters = t.filter { it.isLetter() }
        if (letters.length < 2) return false
        return letters.all { it.isLowerCase() } || letters.all { it.isUpperCase() }
    }

    fun tidy(text: String?): String? {
        if (text == null || !uniform(text)) return text
        var t = text.trim()
        // One word joined by dashes or underscores ("on-air-536"): a file name, so the joins become spaces.
        if (t.none { it.isWhitespace() } && (t.contains('-') || t.contains('_'))) {
            t = t.replace('-', ' ').replace('_', ' ')
        }
        var first = true
        return t.split(Regex("\\s+")).filter { it.isNotEmpty() }.joinToString(" ") { w ->
            val out = word(w, first)
            first = false
            out
        }
    }

    private fun word(w: String, first: Boolean): String {
        val core = w.trim { !it.isLetterOrDigit() }
        if (core.isEmpty()) return w
        val up = core.uppercase()
        val low = core.lowercase()
        val fixed = when {
            up in KEEP_UPPER -> up
            !first && low in SMALL -> low
            else -> low.replaceFirstChar { it.titlecase() }
        }
        val at = w.indexOf(core)
        return w.substring(0, at) + fixed + w.substring(at + core.length)
    }
}
