package com.example.radioplayer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate

/** The lavender of the app (the same as the title bars). The glow and the light edge use it. */
private val LiftColor = Color(0xFF9994AC)

/**
 * Makes a card, button or pill stand out from the wallpaper with a thin lavender line around it.
 *  - [tappable] = true: a slightly brighter line plus a very small, faint glow just outside it, to
 *    say "touch me" (buttons, pills, cards that open).
 *  - [tappable] = false: the thin line only, no glow.
 *
 * Put it first in the chain, before .clip() and .background(), and give it the same [shape]:
 *     Modifier.lift(RoundedCornerShape(16.dp), tappable = true).clip(RoundedCornerShape(16.dp)).background(...)
 *
 * The glow is a few soft outlines drawn outside the card (plain Compose drawing, so it works on every
 * Android version and never tints the card itself). To change the look, adjust the numbers below.
 */
fun Modifier.lift(shape: Shape, tappable: Boolean = false): Modifier =
    this.drawWithContent {
        if (size.width > 0f && size.height > 0f) {
            val outline = shape.createOutline(size, layoutDirection, this)
            val path = outline.toPath()

            // 1) a very small, faint glow outside the card: tappable things only
            if (tappable) {
                val steps = 4
                val reach = 5f * density
                clipPath(path, ClipOp.Difference) {
                    translate(top = 1f * density) {
                        for (i in steps downTo 1) {
                            val t = i / steps.toFloat()
                            drawPath(
                                path = path,
                                color = LiftColor.copy(alpha = 0.06f),
                                style = Stroke(width = reach * 2f * t)
                            )
                        }
                    }
                }
            }

            drawContent()

            // 2) the thin line all the way round
            drawPath(
                path = path,
                color = LiftColor.copy(alpha = if (tappable) 0.55f else 0.30f),
                style = Stroke(width = 1f * density)
            )
        } else {
            drawContent()
        }
    }

internal fun Outline.toPath(): Path = when (this) {
    is Outline.Rectangle -> Path().apply { addRect(rect) }
    is Outline.Rounded -> Path().apply { addRoundRect(roundRect) }
    is Outline.Generic -> path
}

/** The outline of a card whose reminders are on (the lavender of the title bars). */
val FollowedEdge = Color(0xFF9994AC)

/**
 * A soft lavender glow just outside a card that has reminders on. Plain Compose drawing, like [lift].
 * Does nothing when [on] is false. Put it before .lift() and .clip().
 */
fun Modifier.followedGlow(shape: Shape, on: Boolean): Modifier =
    if (!on) this else this.drawWithContent {
        if (size.width > 0f && size.height > 0f) {
            val path = shape.createOutline(size, layoutDirection, this).toPath()
            val steps = 6
            val reach = 9f * density
            clipPath(path, ClipOp.Difference) {
                for (i in steps downTo 1) {
                    val t = i / steps.toFloat()
                    drawPath(
                        path = path,
                        color = FollowedEdge.copy(alpha = 0.07f),
                        style = Stroke(width = reach * 2f * t)
                    )
                }
            }
        }
        drawContent()
    }

/** The small "Following" label at the bottom right of a card with reminders on. */
@Composable
fun FollowTag(text: String) {
    Text(
        text = text,
        color = Color(0xFF14121A),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(FollowedEdge)
            .padding(horizontal = 10.dp, vertical = 3.dp)
    )
}
