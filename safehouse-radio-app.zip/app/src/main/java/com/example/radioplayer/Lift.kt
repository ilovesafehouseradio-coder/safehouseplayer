package com.example.radioplayer

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate

/** The lavender of the app (the same as the title bars). The glow and the light edge use it. */
private val LiftColor = Color(0xFF9994AC)

/**
 * Makes a card, button or pill look slightly raised off the wallpaper: a soft lavender glow under it
 * and a thin light edge along its top.
 *  - [tappable] = true: a stronger glow and a brighter edge, to say "touch me" (buttons, pills, cards that open).
 *  - [tappable] = false: just a faint lift, so everything still feels part of the same family.
 *
 * Put it first in the chain, before .clip() and .background(), and give it the same [shape]:
 *     Modifier.lift(RoundedCornerShape(16.dp), tappable = true).clip(RoundedCornerShape(16.dp)).background(...)
 *
 * The glow is a stack of soft outlines drawn outside the card (plain Compose drawing, so it works on
 * every Android version and never tints the card itself).
 */
fun Modifier.lift(shape: Shape, tappable: Boolean = false): Modifier =
    this.drawWithContent {
        if (size.width > 0f && size.height > 0f) {
            val outline = shape.createOutline(size, layoutDirection, this)
            val path = outline.toPath()

            // 1) the glow, only outside the card
            val steps = if (tappable) 8 else 5
            val reach = (if (tappable) 14f else 8f) * density
            val drop = (if (tappable) 3f else 2f) * density
            val each = (if (tappable) 0.47f else 0.18f) / steps * 1.6f
            clipPath(path, ClipOp.Difference) {
                translate(top = drop) {
                    for (i in steps downTo 1) {
                        val t = i / steps.toFloat()
                        drawPath(
                            path = path,
                            color = LiftColor.copy(alpha = each),
                            style = Stroke(width = reach * 2f * t)
                        )
                    }
                }
            }

            drawContent()

            // 2) the light edge along the top, fading away down the sides
            val edge = LiftColor.copy(alpha = if (tappable) 0.9f else 0.35f)
            drawPath(
                path = path,
                brush = Brush.verticalGradient(
                    0f to edge,
                    0.55f to Color.Transparent,
                    startY = 0f,
                    endY = size.height
                ),
                style = Stroke(width = 1f * density)
            )
        } else {
            drawContent()
        }
    }

private fun Outline.toPath(): Path = when (this) {
    is Outline.Rectangle -> Path().apply { addRect(rect) }
    is Outline.Rounded -> Path().apply { addRoundRect(roundRect) }
    is Outline.Generic -> path
}
