package com.example.radioplayer

import android.os.Build
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.asFrameworkPaint

/** The lavender of the app (the same as the title bars). The glow and the light edge use it. */
private val LiftColor = Color(0xFF9994AC)

/**
 * Makes a card, button or pill look slightly raised off the wallpaper: a soft lavender glow under it
 * and a thin light edge along its top.
 *  - [tappable] = true: a stronger glow and a brighter edge, to say "touch me" (buttons, pills, cards that open).
 *  - [tappable] = false: just a faint lift, so everything still feels part of the same family.
 *
 * Put it first in the chain, before .clip() and .background(), and give it the same [shape]:
 *     Modifier.lift(RoundedCornerShape(16.dp), tappable = true).clip(RoundedCornerShape(16.dp)).background(...)
 * On Android 8 the glow isn't drawn (the system can't), the light edge still is.
 */
fun Modifier.lift(shape: Shape, tappable: Boolean = false): Modifier =
    this.drawWithContent {
        if (size.width > 0f && size.height > 0f) {
            val outline = shape.createOutline(size, layoutDirection, this)

            // 1) the glow, drawn only outside the card so it never tints the card itself
            if (Build.VERSION.SDK_INT >= 28) {
                val blur = (if (tappable) 14f else 8f) * density
                val drop = (if (tappable) 3f else 2f) * density
                val glow = LiftColor.copy(alpha = if (tappable) 0.47f else 0.18f)
                val path = outline.toPath()
                clipPath(path, ClipOp.Difference) {
                    drawIntoCanvas { canvas ->
                        val paint = Paint()
                        val fw = paint.asFrameworkPaint()
                        fw.isAntiAlias = true
                        fw.color = android.graphics.Color.TRANSPARENT
                        fw.setShadowLayer(blur, 0f, drop, glow.toArgb())
                        canvas.drawPath(path, paint)
                    }
                }
            }

            drawContent()

            // 2) the light edge along the top, fading away down the sides
            val edge = LiftColor.copy(alpha = if (tappable) 0.9f else 0.35f)
            drawOutline(
                outline = outline,
                brush = Brush.verticalGradient(
                    0f to edge,
                    0.55f to Color.Transparent,
                    startY = 0f,
                    endY = size.height
                ),
                style = Stroke(width = 1f * density)
            )
        } else {
            drawContent()
        }
    }

private fun Outline.toPath(): Path = when (this) {
    is Outline.Rectangle -> Path().apply { addRect(rect) }
    is Outline.Rounded -> Path().apply { addRoundRect(roundRect) }
    is Outline.Generic -> path
}
