package com.example.radioplayer

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// The "Safehouse says…" speech bubbles: a small explanation that pops out beside an (i) button, in the
// app's own lilac, with a tail pointing at the button. They only ever open when someone taps an (i).

private val BubbleFill: Color get() = ThemeState.current.card
private val BubbleEdge: Color get() = ThemeState.current.primary

/** What the bubble on screen is pointing at, and what it says. At most one bubble is open at a time. */
@Stable
class BubbleState {
    var anchor by mutableStateOf<Rect?>(null)
    var body by mutableStateOf<(@Composable ColumnScope.() -> Unit)?>(null)

    fun show(from: Rect, content: @Composable ColumnScope.() -> Unit) {
        anchor = from
        body = content
    }

    fun hide() {
        anchor = null
        body = null
    }
}

/**
 * Wraps a whole page. While a bubble is open it dims the page, draws the bubble under the (i) that was
 * tapped (it scrolls inside itself if the words are long) and closes on a tap outside, the cross,
 * "Got it" or the phone's back button.
 */
@Composable
fun BubbleHost(state: BubbleState, content: @Composable () -> Unit) {
    var origin by remember { mutableStateOf(Offset.Zero) }
    var hostSize by remember { mutableStateOf(IntSize.Zero) }
    Box(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned {
                origin = it.positionInWindow()
                hostSize = it.size
            }
    ) {
        content()
        val anchor = state.anchor
        val body = state.body
        if (anchor != null && body != null && hostSize.width > 0) {
            BackHandler { state.hide() }
            BubbleLayer(anchor, origin, hostSize, body, onClose = { state.hide() })
        }
    }
}

@Composable
private fun BubbleLayer(
    anchor: Rect,
    origin: Offset,
    hostSize: IntSize,
    body: @Composable ColumnScope.() -> Unit,
    onClose: () -> Unit
) {
    val density = LocalDensity.current
    val margin = with(density) { 16.dp.roundToPx() }
    val tail = with(density) { 14.dp.roundToPx() }
    val top = (anchor.bottom - origin.y).toInt() - with(density) { 8.dp.roundToPx() } + tail
    val widthPx = hostSize.width - 2 * margin
    val maxHeightPx = (hostSize.height - top - margin).coerceAtLeast(with(density) { 180.dp.roundToPx() })
    val tailX = ((anchor.center.x - origin.x) - margin)
        .coerceIn(with(density) { 36.dp.toPx() }, widthPx - with(density) { 36.dp.toPx() })
    val shape = RoundedCornerShape(24.dp)
    val noRipple = remember { MutableInteractionSource() }

    // The dim layer: a tap anywhere outside the bubble closes it.
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0x99000000))
            .clickable(interactionSource = noRipple, indication = null, onClickLabel = "Close", onClick = onClose)
    )
    Column(
        Modifier
            .offset { IntOffset(margin, top) }
            .width(with(density) { widthPx.toDp() })
            .heightIn(max = with(density) { maxHeightPx.toDp() })
            .drawWithContent {
                drawContent()
                // The tail: a small triangle pointing up at the (i), drawn over the bubble's top edge.
                val half = 12.dp.toPx()
                val lift = tail.toFloat()
                val seam = 3.dp.toPx()
                val path = Path().apply {
                    moveTo(tailX - half, seam)
                    lineTo(tailX, -lift)
                    lineTo(tailX + half, seam)
                    close()
                }
                drawPath(path, BubbleFill)
                drawLine(BubbleEdge, Offset(tailX - half, 0f), Offset(tailX, -lift), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
                drawLine(BubbleEdge, Offset(tailX + half, 0f), Offset(tailX, -lift), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
            }
            .clip(shape)
            .background(BubbleFill)
            .border(2.dp, BubbleEdge, shape)
            // A tap on the bubble itself does nothing (it must not fall through to the dim layer).
            .clickable(interactionSource = noRipple, indication = null) { }
            .padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = rememberLogoTile(),
                contentDescription = null,
                modifier = Modifier.size(30.dp).clip(CircleShape)
            )
            Spacer(Modifier.width(10.dp))
            Text(
                text = "Safehouse says…",
                color = BubbleEdge,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Box(
                Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .clickable(onClickLabel = "Close", role = Role.Button, onClick = onClose),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.size(18.dp).semantics { contentDescription = "Close" }) {
                    val w = 2.5.dp.toPx()
                    drawLine(BubbleEdge, Offset(2f, 2f), Offset(size.width - 2f, size.height - 2f), strokeWidth = w, cap = StrokeCap.Round)
                    drawLine(BubbleEdge, Offset(size.width - 2f, 2f), Offset(2f, size.height - 2f), strokeWidth = w, cap = StrokeCap.Round)
                }
            }
        }
        // The words (scroll inside the bubble only when they do not fit).
        Column(
            Modifier
                .weight(1f, fill = false)
                .padding(end = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            body()
        }
        Box(Modifier.fillMaxWidth().padding(top = 10.dp, end = 8.dp), contentAlignment = Alignment.Center) {
            BubbleButton("Got it", onClick = onClose)
        }
    }
}

/** A paragraph inside a bubble (same size and colour everywhere). */
@Composable
fun BubbleText(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onBackground,
        fontSize = 15.sp,
        modifier = modifier.padding(top = 6.dp)
    )
}

/**
 * The small round (i). A full 48dp to touch; the picture is smaller. Tapping it opens a bubble with
 * [body] under it. [what] is read out by screen readers ("More information about Buffer").
 */
@Composable
fun InfoButton(what: String, state: BubbleState, body: @Composable ColumnScope.() -> Unit) {
    var bounds by remember { mutableStateOf<Rect?>(null) }
    Box(
        Modifier
            .size(48.dp)
            .onGloballyPositioned { bounds = it.boundsInWindow() }
            .clip(CircleShape)
            .clickable(onClickLabel = "Open explanation", role = Role.Button) {
                bounds?.let { state.show(it, body) }
            }
            .semantics { contentDescription = "More information about $what" },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_info),
            contentDescription = null,
            tint = BubbleEdge,
            modifier = Modifier.size(22.dp)
        )
    }
}

/**
 * The (i) as part of a line of writing: it sits straight after the last word with a small, even gap, its bottom
 * on the text line like a letter, wherever the title ends (one line or two). The picture is small, but the
 * touch area is still a full 48 dp, spilling over the space around it without pushing the rows apart.
 */
@Composable
fun InfoInline(what: String, state: BubbleState, body: @Composable ColumnScope.() -> Unit) {
    var bounds by remember { mutableStateOf<Rect?>(null) }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterEnd) {
        val glyph = with(LocalDensity.current) { 18.sp.toDp() }
        Box(
            Modifier
                .size(glyph)
                .wrapContentSize(unbounded = true)
                .requiredSize(48.dp)
                .onGloballyPositioned { bounds = it.boundsInWindow() }
                .clip(CircleShape)
                .clickable(onClickLabel = "Open explanation", role = Role.Button) {
                    bounds?.let { state.show(it, body) }
                }
                .semantics { contentDescription = "More information about $what" },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_info),
                contentDescription = null,
                tint = BubbleEdge,
                modifier = Modifier.size(glyph)
            )
        }
    }
}

/**
 * The button on a "Safehouse says…" card: a lilac outline with white writing (the same on every card).
 * 48dp tall at least. The filled lilac button is kept for main actions on the pages themselves.
 */
@Composable
internal fun BubbleButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .heightIn(min = 48.dp)
            .clip(shape)
            .border(2.dp, ThemeState.current.primary, shape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = ThemeState.current.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}
