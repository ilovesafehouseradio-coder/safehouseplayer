package com.example.radioplayer

import android.content.Intent
import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebChromeClient

/** Hands the chat's "choose a file" request to the phone's file picker and passes the answer back. */
object ChatFiles {
    /** Set by the main screen while it is open. */
    @Volatile
    var launcher: ((Intent) -> Unit)? = null

    private var pending: ValueCallback<Array<Uri>>? = null

    @Synchronized
    fun start(callback: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams): Boolean {
        val launch = launcher
        if (launch == null) {
            callback.onReceiveValue(null)
            return true
        }
        // A new request replaces any old one that was never answered.
        pending?.onReceiveValue(null)
        pending = callback
        return try {
            launch(params.createIntent())
            true
        } catch (e: Exception) {
            ChatDiag.add("file picker failed: ${e.message}")
            pending = null
            callback.onReceiveValue(null)
            true
        }
    }

    @Synchronized
    fun finish(resultCode: Int, data: Intent?) {
        val callback = pending ?: return
        pending = null
        callback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
    }
}
