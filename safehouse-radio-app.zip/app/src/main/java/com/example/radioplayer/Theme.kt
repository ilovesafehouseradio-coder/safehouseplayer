package com.example.radioplayer

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

/**
 * A theme is just four colours (plus white for writing). Everything else the app needs is worked out from
 * them here, so a new theme is four colours added to [Themes] and nothing on any screen needs to change:
 *  - [background]: Midnight black: main background and player surfaces
 *  - [card]: Deep plum: cards, panels and secondary surfaces
 *  - [primary]: Soft lavender: primary controls and selected states
 *  - [live]: Muted gold: small highlights and live indicators
 */
class Palette(
    val id: String,
    val name: String,
    val background: Color,
    val card: Color,
    val primary: Color,
    val live: Color,
    /** How much black is laid over the wallpaper everywhere (0 = none, 1 = black). The middle of the page is about 85% clear. */
    val wallpaperDim: Float = 0.15f
) {
    /** Main writing on dark cards: white (near-white). */
    val text: Color get() = White

    /** Dark writing and icons that sit on the main colour: the background colour. */
    val onPrimary: Color get() = background

    /** Secondary writing: the main colour lightened towards white. */
    val textDim: Color get() = lerp(primary, White, 0.5f)

    /** The light line colour for thin outlines and small icons. */
    val edge: Color get() = lerp(primary, White, 0.3f)

    /** The see-through card colour over the wallpaper. */
    val cardSurface: Color get() = card.copy(alpha = 0.92f)

    /** A lighter solid panel (info cards, pop-ups, the station's own cards): the card colour mixed with the main colour. */
    val panel: Color get() = lerp(card, primary, 0.2f)

    /** The slightly lighter see-through card used for the station's own cards. */
    val lilacSurface: Color get() = panel.copy(alpha = 0.94f)

    /** The thin line between rows inside a card. */
    val divider: Color get() = edge.copy(alpha = 0.16f)

    /** A dark layer for a label or switch track sitting on a picture or the wallpaper. */
    val scrim: Color get() = background.copy(alpha = 0.6f)

    /** The same, stronger, for a bar that must stay readable. */
    val scrimStrong: Color get() = background.copy(alpha = 0.8f)

    private companion object {
        val White = Color(0xFFF8F8F8)
    }
}

object Themes {
    val MIDNIGHT = Palette(
        id = "midnight", name = "Midnight",
        background = Color(0xFF0B0A10), card = Color(0xFF292535),
        primary = Color(0xFFA59DBB), live = Color(0xFFD6AD69)
    )

    // Placeholders until the real second and third themes arrive: change their four colours here, nothing else.
    val THEME_2 = Palette(
        id = "theme2", name = "Theme 2",
        background = Color(0xFF0A1018), card = Color(0xFF1C2A3C),
        primary = Color(0xFF7FB5D6), live = Color(0xFFD6AD69)
    )

    val THEME_3 = Palette(
        id = "theme3", name = "Theme 3",
        background = Color(0xFF120B0D), card = Color(0xFF3A2226),
        primary = Color(0xFFD68F7F), live = Color(0xFFD6AD69)
    )

    val all = listOf(MIDNIGHT, THEME_2, THEME_3)

    fun byId(id: String?): Palette = all.firstOrNull { it.id == id } ?: MIDNIGHT
}

/** The theme in use. Changing it redraws the whole app straight away, and the phone remembers the choice. */
object ThemeState {
    private const val K_THEME = "theme"

    var current by mutableStateOf(Themes.MIDNIGHT)
        private set

    fun load(ctx: Context) {
        current = Themes.byId(AppSettings.prefs(ctx).getString(K_THEME, null))
    }

    fun choose(ctx: Context, palette: Palette) {
        current = palette
        AppSettings.prefs(ctx).edit().putString(K_THEME, palette.id).apply()
    }
}
