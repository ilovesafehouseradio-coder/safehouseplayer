package com.example.radioplayer

import java.time.Duration
import java.time.Instant

/** How a DJ's card is shown on the DJs page. */
enum class DjTier {
    LIVE,      // on air right now: glow and a "LIVE" pill
    UP_NEXT,   // nobody is live and this show starts within 24 hours: glow and an "UP NEXT" pill
    SOON,      // a live show in the next five days: just a faint thin line, listed soonest first
    NONE       // everyone else, in the usual A to Z order
}

/**
 * Orders the DJs page. Only one show is ever featured (LIVE, or if nobody is live, UP_NEXT),
 * so no DJ is promoted over another; then the DJs with a show in the next few days, soonest
 * first; then everyone else in their usual order. Live shows only (never the "repeat" slots).
 */
object DjOrder {
    const val WINDOW_DAYS = 5L
    const val UP_NEXT_HOURS = 24L

    /**
     * [onAir] is the stream server's title right now ("DJ, Show": live or a recorded show), if any. The
     * DJ it names comes first: that DJ gets LIVE even if the calendar knows nothing about the show. A
     * placeholder name like "Syndicast" is ignored and the show name is used instead. If it names
     * nobody on our list, the calendar decides, as before.
     */
    fun order(djs: List<Dj>, shows: List<Show>, now: Instant, onAir: String? = null): List<Pair<Dj, DjTier>> {
        val streamLive: Set<Dj> =
            if (onAir.isNullOrBlank()) emptySet()
            else djs.filter { DjMatch.streamMatches(onAir, DjMatch.key(it.name)) }.toSet()

        // The stream answered but names nobody usable: the calendar can't be sure who is on, so no one is
        // called LIVE from it (a show that has started simply counts as one of the DJs on soon).
        val unidentified = StreamNames.unidentified(onAir)
        val windowEnd = now.plus(Duration.ofDays(WINDOW_DAYS))
        // Back-to-back slots of one event count as one block, as on the DJ pages.
        val window = Events.group(
            shows.filter { !it.isFiller && it.end.isAfter(now) && it.start.isBefore(windowEnd) }
        ).filter { !it.isFiller }.sortedBy { it.start }
        if (window.isEmpty() && streamLive.isEmpty()) return djs.map { it to DjTier.NONE }

        // Each DJ's soonest show in the window.
        val next = HashMap<Dj, Show>()
        for (dj in djs) {
            val k = DjMatch.key(dj.name)
            val s = window.firstOrNull { DjMatch.showMatches(it, k) }
            if (s != null) next[dj] = s
        }

        // The featured show: the one on air, else the soonest one starting within 24 hours.
        // (When the stream already names a DJ, that is the featured one and the calendar's pick is not used.)
        val live = if (streamLive.isNotEmpty() || unidentified) null else window.firstOrNull { !it.start.isAfter(now) }
        val upNext = if (live != null || streamLive.isNotEmpty()) null else
            window.firstOrNull {
                (!unidentified || it.start.isAfter(now)) && it.start.isBefore(now.plus(Duration.ofHours(UP_NEXT_HOURS)))
            }
        val featured = live ?: upNext
        val featuredTier = if (live != null) DjTier.LIVE else DjTier.UP_NEXT

        fun tierOf(dj: Dj): DjTier {
            if (dj in streamLive) return DjTier.LIVE
            val s = next[dj] ?: return DjTier.NONE
            return if (featured != null && s.start == featured.start && s.end == featured.end) featuredTier else DjTier.SOON
        }

        val tiered = djs.map { it to tierOf(it) }
        val first = tiered.filter { it.second == DjTier.LIVE || it.second == DjTier.UP_NEXT }
        val soon = tiered.filter { it.second == DjTier.SOON }.sortedBy { next[it.first]!!.start }
        val rest = tiered.filter { it.second == DjTier.NONE }
        return first + soon + rest
    }
}
