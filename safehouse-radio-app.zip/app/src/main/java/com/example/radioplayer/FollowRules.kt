package com.example.radioplayer

/**
 * The one rule that says whether a show gets a reminder. The schedule cards, the Following filter,
 * the DJ page and the reminders themselves all use it, so they can never disagree.
 *
 *  - Following a DJ turns on every show of theirs (new shows start on).
 *  - Switching one show off (while following) skips just that show: an "off" entry.
 *  - Without following the DJ, switching a show on gives reminders for that show only: an "on" entry.
 *  - Following or unfollowing a DJ clears that DJ's on/off entries.
 *
 * "on" and "off" are sets of [pair]s: the DJ's key, a separator, then the show's key.
 */
object FollowRules {
    const val SEP = "\u0001"

    /** "Cliffie's Music Lab!" and "cliffies music lab" are the same show. */
    fun showKey(title: String): String = title.lowercase().filter { it.isLetterOrDigit() }

    fun pair(djKey: String, showKey: String): String = djKey + SEP + showKey

    fun djOf(pair: String): String = pair.substringBefore(SEP)
    fun showOf(pair: String): String = pair.substringAfter(SEP)

    /** True if [set] holds an entry for this DJ (any spelling) and show. */
    fun has(set: Collection<String>, djKey: String, showKey: String): Boolean =
        set.any { showOf(it) == showKey && DjMatch.sameKey(DjMatch.key(djOf(it)), DjMatch.key(djKey)) }

    /**
     * The DJ key this slot gets a reminder under, or null if it gets none. Live shows only: repeat
     * slots never get a reminder.
     */
    fun reminderKey(
        show: Show,
        followed: Collection<String>,
        on: Collection<String>,
        off: Collection<String>
    ): String? {
        if (show.isFiller) return null
        val sk = showKey(show.title)
        val fk = DjMatch.followedKey(show, followed)
        if (fk != null) return if (has(off, fk, sk)) null else fk
        for (p in on) {
            if (showOf(p) == sk && DjMatch.showMatches(show, djOf(p))) return djOf(p)
        }
        return null
    }

    /** Is the DJ itself followed (so every show is on unless skipped)? */
    fun isFollowing(show: Show, followed: Collection<String>): Boolean =
        !show.isFiller && DjMatch.followedKey(show, followed) != null
}
