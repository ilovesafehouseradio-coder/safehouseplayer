package com.example.radioplayer

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

/**
 * Long one-line texts that run round in a loop, one line at a time, like a ticker.
 *
 * The text waits a couple of seconds so the start can be read, then slides left. As its end leaves on the left, its
 * start comes back in on the right (after a small gap), and it keeps going until that start is exactly where the
 * text began: one full lap, never backwards. Then it rests and the next line takes its turn. A line that fits never
 * moves, and with "Reduce animations" on nothing moves (the line shows "…" instead).
 */
/** Space between the end of the text and its start coming round again. */
const val LOOP_GAP_DP = 40

class TurnLine {
    /** How far the text is pushed to the left right now (pixels). */
    var offset by mutableFloatStateOf(0f)

    /** How much longer the text is than the space it has (pixels); 0 when it fits. Set while measuring. */
    @Volatile
    var overflowPx = 0

    /** One lap: the text's own length plus the gap before it comes round again (pixels). Set while measuring. */
    @Volatile
    var cyclePx = 0f

    /** Changes when the text changes, so a slide in progress stops and the text starts from the beginning again. */
    @Volatile
    var epoch = 0

    fun reset() {
        epoch++
        offset = 0f
    }
}

class TurnLines(count: Int) {
    val lines = List(count) { TurnLine() }

    private suspend fun slide(line: TurnLine, to: Float, millis: Int, linear: Boolean) {
        val from = line.offset
        val epoch = line.epoch
        var start = -1L
        while (true) {
            val now = withFrameNanos { it }
            if (start < 0) start = now
            if (line.epoch != epoch) return
            val f = (((now - start) / 1_000_000f) / millis.coerceAtLeast(1)).coerceIn(0f, 1f)
            val eased = if (linear) f else f * f * (3f - 2f * f)
            line.offset = from + (to - from) * eased
            if (f >= 1f) return
        }
    }

    /** Goes round the lines for ever, one at a time. [pxPerDp] is the screen density. */
    suspend fun run(pxPerDp: Float) {
        val speed = 40f * pxPerDp            // pixels per second
        while (true) {
            var moved = false
            for (line in lines) {
                if (line.overflowPx <= 0) continue
                moved = true
                val epoch = line.epoch
                delay(2000)                   // the start can be read
                if (line.epoch != epoch || line.overflowPx <= 0) continue
                val lap = line.cyclePx
                if (lap <= 0f) continue
                slide(line, lap, (lap / speed * 1000f).toInt(), linear = true)
                // The start has come all the way round and sits where it began: look identical, so just reset.
                if (line.epoch == epoch) line.offset = 0f
            }
            delay(if (moved) 600L else 1500L)   // a short rest, then look again (the text may have changed)
        }
    }
}

/** One set of lines that take turns. Put it where the lines are shown; it stops by itself when they leave the screen. */
@Composable
fun rememberTurns(count: Int): TurnLines {
    val turns = remember(count) { TurnLines(count) }
    val reduce = AppSettings.reduceMotion(LocalContext.current)
    val pxPerDp = LocalDensity.current.density
    LaunchedEffect(turns, reduce) {
        if (!reduce) turns.run(pxPerDp)
    }
    return turns
}

/**
 * Makes a one-line Text slide (when too long) in its turn. [key] is the text: when it changes the line starts again
 * from the beginning.
 */
@Composable
fun Modifier.turnScroll(turns: TurnLines, index: Int, key: Any?): Modifier {
    if (AppSettings.reduceMotion(LocalContext.current)) return this
    val line = turns.lines[index]
    LaunchedEffect(key) { line.reset() }
    return this
        .clipToBounds()
        .layout { measurable, constraints ->
            // Measure the text at its full length, show only the part that fits, and push it along by the offset.
            val placeable = measurable.measure(constraints.copy(minWidth = 0, maxWidth = Constraints.Infinity))
            val width = if (constraints.maxWidth == Constraints.Infinity) placeable.width else constraints.maxWidth
            line.overflowPx = (placeable.width - width).coerceAtLeast(0)
            line.cyclePx = (placeable.width + LOOP_GAP_DP.dp.roundToPx()).toFloat()
            layout(width, placeable.height) {
                placeable.place(-line.offset.roundToInt(), 0)
            }
        }
        .drawWithContent {
            drawContent()
            // The start of the text again, one lap further along, so it comes in on the right as the end leaves.
            if (line.offset > 0f && line.overflowPx > 0) {
                translate(left = line.cyclePx) { this@drawWithContent.drawContent() }
            }
        }
}
