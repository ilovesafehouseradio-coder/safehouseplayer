package com.example.radioplayer

import java.time.Instant

/** A coming live show with a named DJ (for the "Next:" line on the Radio tab). */
class NextUp(val dj: String, val title: String, val start: Instant, val photoUrl: String?)

object UpNext {

    /** The station's DJ page for a name typed in the calendar or sent by the stream (null if none matches). */
    fun djFor(name: String?, djs: List<Dj>): Dj? {
        if (name.isNullOrBlank()) return null
        return djs.firstOrNull { DjMatch.djMatches(name, DjMatch.key(it.name)) }
    }

    /**
     * The DJ page for a slot. With a DJ named it is that DJ; with none (or only a placeholder like
     * "Syndicast") the show's title decides ("WARM Global Dance Radio Chart" is the WARM page).
     */
    fun djForShow(show: Show, djs: List<Dj>): Dj? {
        if (show.dj != null) return djFor(show.dj, djs)
        if (show.isFiller) return null
        return djs.firstOrNull { DjMatch.showMatches(show, DjMatch.key(it.name)) }
    }

    /** The next [n] live shows that have a DJ (named, or found from the title), soonest first. Repeats and empty slots never count. */
    fun list(shows: List<Show>, djs: List<Dj>, now: Instant, n: Int = 3): List<NextUp> =
        shows.asSequence()
            .filter { !it.isFiller && it.start.isAfter(now) }
            .sortedBy { it.start }
            .map { it to djForShow(it, djs) }
            .filter { (s, dj) -> s.dj != null || dj != null }
            .take(n)
            .map { (s, dj) -> NextUp(s.dj ?: dj?.name.orEmpty(), s.title, s.start, dj?.imageUrl) }
            .toList()
}
