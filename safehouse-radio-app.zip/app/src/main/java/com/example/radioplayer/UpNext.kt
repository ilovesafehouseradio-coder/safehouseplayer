package com.example.radioplayer

import java.time.Instant

/** A coming live show with a named DJ (for the "Next:" line on the Radio tab). */
class NextUp(val dj: String, val title: String, val start: Instant, val photoUrl: String?)

object UpNext {

    /** The station's DJ page for a name typed in the calendar or sent by the stream (null if none matches). */
    fun djFor(name: String?, djs: List<Dj>): Dj? {
        if (name.isNullOrBlank()) return null
        return djs.firstOrNull { DjMatch.djMatches(name, DjMatch.key(it.name)) }
    }

    /** The next [n] live shows that have a DJ named, soonest first. Repeats and empty slots never count. */
    fun list(shows: List<Show>, djs: List<Dj>, now: Instant, n: Int = 3): List<NextUp> =
        shows.asSequence()
            .filter { !it.isFiller && it.dj != null && it.start.isAfter(now) }
            .sortedBy { it.start }
            .take(n)
            .map { NextUp(it.dj.orEmpty(), it.title, it.start, djFor(it.dj, djs)?.imageUrl) }
            .toList()
}
