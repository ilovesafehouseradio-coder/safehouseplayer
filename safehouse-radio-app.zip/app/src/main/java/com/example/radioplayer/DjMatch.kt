package com.example.radioplayer

import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap

/**
 * Decides which calendar entries belong to which DJ. The calendar is typed in by hand, so a DJ's
 * name can be written with or without spaces, dashes, capitals, accents or a leading "DJ"; a show
 * can be shared ("Cherish b2b MarkyMark"); a duo can be listed under its brand name; and an event
 * can be named after its host. This one place is used by the DJ profile, the schedule bells and the
 * reminders, so they always agree.
 */
object DjMatch {

    private val TEAM_SPLIT = Regex("(?i)\\s+b2b\\s+|\\s+&\\s+|\\s+and\\s+|\\s+\\+\\s+")
    private val SPACES = Regex("\\s+")

    // Extra words that may follow a DJ's name in the DJ field: "Cliffie 2Hrs", "Cliffie Live".
    private val EXTRA_WORDS = Regex("(?i)^(?:\\d+\\s*(?:hrs?|hours?|h|mins?)|xl|live|extended|special|set|mix|show|guest\\s*mix)$")

    // Names shorter than this are never looked for inside a show title (too easy to match by accident).
    private const val MIN_TITLE_KEY = 6

    // Different spellings of the same DJ. Add the odd ones here.
    private val SAME = listOf(
        setOf("cliffie", "cliffy"),
        setOf("missbehaviour", "missbehavior")
    )

    // A brand and the DJs in it. Anything under the brand counts for each member, and a member's
    // own shows count for the brand. More are learned from the DJ bios (see DjGroups).
    private val HAND_GROUPS = mapOf(
        "contagiousbehaviour" to setOf("catch22", "missbehaviour")
    )

    @Volatile private var learned: Map<String, Set<String>> = emptyMap()
    private val expandCache = ConcurrentHashMap<String, Set<String>>()
    private val keyCache = ConcurrentHashMap<String, String>()

    /** "Marky Mark", "MarkyMark", "marky-mark" and "DJ Marky Mark" all become "markymark". */
    fun key(name: String): String {
        keyCache[name]?.let { return it }
        val plain = Normalizer.normalize(name, Normalizer.Form.NFD)
            .filter { Character.getType(it) != Character.NON_SPACING_MARK.toInt() }
        val k = plain.lowercase().filter { it.isLetterOrDigit() }.removePrefix("dj")
        if (keyCache.size > 4000) keyCache.clear()
        keyCache[name] = k
        return k
    }

    /** Replaces the groups learned from the bios. */
    fun setLearned(groups: Map<String, Set<String>>) {
        learned = groups
        expandCache.clear()
    }

    fun learnedGroups(): Map<String, Set<String>> = learned

    private fun spellings(k: String): Set<String> = SAME.firstOrNull { k in it } ?: setOf(k)

    private fun allGroups(): Map<String, Set<String>> {
        val out = HashMap<String, MutableSet<String>>()
        for ((g, m) in HAND_GROUPS) out.getOrPut(g) { HashSet() }.addAll(m)
        for ((g, m) in learned) out.getOrPut(g) { HashSet() }.addAll(m)
        return out
    }

    /**
     * Every key a calendar entry may carry for it to count as this DJ's: the DJ, other spellings,
     * the brand they belong to, and (for a brand) the DJs in it.
     */
    fun expand(k: String): Set<String> = expandCache.getOrPut(k) {
        val out = HashSet<String>()
        val mine = spellings(k)
        out.addAll(mine)
        val groups = allGroups()
        for (name in mine) {
            groups[name]?.let { members -> for (m in members) out.addAll(spellings(m)) }
            for ((g, members) in groups) if (name in members) out.addAll(spellings(g))
        }
        out
    }

    /** True if the DJ written in the calendar is this DJ [k] (a [key]), alone, in a team, or with extra words. */
    fun djMatches(shownDj: String?, k: String): Boolean {
        if (shownDj == null || k.isEmpty()) return false
        val ex = expand(k)
        if (key(shownDj) in ex) return true
        val parts = shownDj.split(TEAM_SPLIT)
        if (parts.size > 1 && parts.any { key(it) in ex }) return true
        // "Cliffie 2Hrs": the name, then only words that describe the slot.
        val words = shownDj.trim().split(SPACES)
        for (n in 1 until words.size) {
            if (key(words.take(n).joinToString("")) in ex &&
                EXTRA_WORDS.matches(words.drop(n).joinToString(" "))
            ) return true
        }
        return false
    }

    /** True if [text] (a show title) contains the name of this DJ, long names only. */
    private fun titleHas(text: String, k: String): Boolean {
        val t = key(text)
        for (e in expand(k)) if (e.length >= MIN_TITLE_KEY && t.contains(e)) return true
        return false
    }

    /**
     * True if this slot is for the DJ [k]: the DJ is named in the usual place, or the DJ's name is in
     * the show title ("Dropkick with Marky Mark", "Cliffie's New Year's Eve Party"), or (for an event
     * made of several slots) any of the DJs in it.
     */
    fun showMatches(show: Show, k: String): Boolean {
        if (k.isEmpty()) return false
        if (show.eventDjs.isNotEmpty()) {
            return show.eventDjs.any { djMatches(it, k) || titleHas(it, k) } || titleHas(show.title, k)
        }
        if (show.dj != null) return djMatches(show.dj, k) || (!show.isFiller && titleHas(show.title, k))
        if (show.isFiller) return false
        return titleHas(show.title, k)
    }

    /** The followed key (if any) that this slot belongs to, by any of the rules above. */
    fun followedKey(show: Show, followed: Collection<String>): String? =
        followed.firstOrNull { showMatches(show, key(it)) }

    /** For the bell on a schedule card: is the DJ named on this very slot followed? (Title matches don't count.) */
    fun followedByDj(show: Show, followed: Collection<String>): Boolean {
        val dj = show.dj ?: return false
        return followed.any { djMatches(dj, key(it)) }
    }
}
