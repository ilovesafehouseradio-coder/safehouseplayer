package com.example.radioplayer

import java.text.Normalizer

/**
 * Decides which calendar entries belong to which DJ. The calendar is typed in by hand, so a DJ's
 * name can be written with or without spaces, dashes, capitals, accents or a leading "DJ", and a
 * show can be shared ("Cherish b2b MarkyMark"). This one place is used by the DJ profile, the bells
 * on the schedule and the reminders, so they always agree.
 */
object DjMatch {

    private val TEAM_SPLIT = Regex("(?i)\\s+b2b\\s+|\\s+&\\s+|\\s+and\\s+|\\s+\\+\\s+")

    // Names shorter than this are never looked for inside a show title (too easy to match by accident).
    private const val MIN_TITLE_KEY = 6

    /** "Marky Mark", "MarkyMark", "marky-mark" and "DJ Marky Mark" all become "markymark". */
    fun key(name: String): String {
        val plain = Normalizer.normalize(name, Normalizer.Form.NFD).filter { Character.getType(it) != Character.NON_SPACING_MARK.toInt() }
        return plain.lowercase().filter { it.isLetterOrDigit() }.removePrefix("dj")
    }

    /** True if the DJ written in the calendar is this DJ [k] (a [key]), alone or as part of a team. */
    fun djMatches(shownDj: String?, k: String): Boolean {
        if (shownDj == null || k.isEmpty()) return false
        if (key(shownDj) == k) return true
        val parts = shownDj.split(TEAM_SPLIT)
        return parts.size > 1 && parts.any { key(it) == k }
    }

    /**
     * True if this calendar slot is for the DJ [k]: the DJ is named in the usual place, or (when the
     * entry has no recognised DJ) the name appears in the show title, e.g. "Show with Marky Mark".
     */
    fun showMatches(show: Show, k: String): Boolean {
        if (show.dj != null) return djMatches(show.dj, k)
        if (show.isFiller) return false
        return k.length >= MIN_TITLE_KEY && key(show.title).contains(k)
    }

    /** The followed key (if any) that this slot belongs to. */
    fun followedKey(show: Show, followed: Collection<String>): String? =
        followed.firstOrNull { showMatches(show, key(it)) }
}
