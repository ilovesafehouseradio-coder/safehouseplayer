package com.example.radioplayer

import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.TextUnit

/**
 * Poppins carries a lot of built-in space above and below each line (its lines are about 1.76 times the
 * text size tall). For short labels and card text this gives a line a fixed, tighter height, with the text
 * centred in it. [lineHeight] is about 1.3 times the font size. Not for paragraphs (bios, Terms, Privacy),
 * which keep the roomier default.
 */
@Composable
fun tightStyle(lineHeight: TextUnit): TextStyle =
    LocalTextStyle.current.copy(
        lineHeight = lineHeight,
        lineHeightStyle = LineHeightStyle(
            alignment = LineHeightStyle.Alignment.Center,
            trim = LineHeightStyle.Trim.None
        )
    )
