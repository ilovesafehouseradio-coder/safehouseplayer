package com.example.radioplayer

import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import androidx.core.content.IntentCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.CommandButton
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import java.io.ByteArrayOutputStream
import com.google.android.gms.cast.framework.CastContext
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Runs the audio in a foreground service so the stream keeps playing with the
 * screen locked or the app in the background. Media3 shows the notification
 * (with play/pause) and the lock screen controls automatically.
 *
 * It is a "library" service so Android Auto (and other car / Bluetooth screens) can browse it:
 * they see one item, the live station.
 *
 * The service also checks what's on air every 15 seconds while playing and puts the
 * DJ name, show name and DJ picture into that notification.
 */
class PlaybackService : MediaLibraryService() {

    private var mediaSession: MediaLibrarySession? = null
    private var exoPlayer: ExoPlayer? = null   // plays on this phone
    private var castPlayer: CastPlayer? = null // plays on a Chromecast, while one is connected
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var reconnectJob: Job? = null
    private var pausedJob: Job? = null
    private var reconnectAttempts = 0
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var netFirstSeen = false
    private var lastNetKick = 0L
    private var itemSetAt = 0L   // when the station was last handed to the player (SystemClock.elapsedRealtime)

    private val libraryCallback = object : MediaLibrarySession.Callback {

        // Adds a "Stop" button to the notification (one tap silences everything).
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_AND_LIBRARY_COMMANDS
                .buildUpon()
                .add(STOP_ALL)
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .setCustomLayout(ImmutableList.of(stopButton()))
                .build()
        }

        // A headset, car or Bluetooth "play" when the radio has fully stopped (paused and swiped away, say):
        // bring the station back, joining live, instead of doing nothing.
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> =
            Futures.immediateFuture(
                MediaSession.MediaItemsWithStartPosition(listOf(forPhone(liveItem())), 0, C.TIME_UNSET)
            )

        // Headphone and Bluetooth buttons beyond play / pause: next and fast-forward go forward 10 seconds,
        // previous and rewind go back 10 seconds (a live radio has no next or previous track).
        override fun onMediaButtonEvent(
            session: MediaSession,
            controllerInfo: MediaSession.ControllerInfo,
            intent: Intent
        ): Boolean {
            val event = IntentCompat.getParcelableExtra(intent, Intent.EXTRA_KEY_EVENT, KeyEvent::class.java)
                ?: return false
            val step = when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> TimeShift.STEP_SECONDS
                KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_MEDIA_REWIND -> -TimeShift.STEP_SECONDS
                else -> return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && session.player === exoPlayer) {
                TimeShift.skip(step)
            }
            return true
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            if (customCommand.customAction == ACTION_STOP_ALL) {
                stopEverything()
                return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_ERROR_NOT_SUPPORTED))
        }

        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(rootItem(), params))

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> =
            Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.of(liveItem()), params))

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String
        ): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(liveItem(), null))

        // A car screen asks to play an item by its id only: fill in the stream address.
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: List<MediaItem>
        ): ListenableFuture<List<MediaItem>> {
            val resolved: List<MediaItem> = mediaItems.map { item ->
                val full = if (item.localConfiguration == null) liveItem() else item
                // The phone listens through the rolling recording (so rewind works); a Chromecast gets the plain address.
                if (castPlayer != null && mediaSession?.player === castPlayer) forCast(full) else forPhone(full)
            }
            return Futures.immediateFuture(resolved)
        }
    }

    // Hears the switches on the More tab that change the player (the buffer, pausing when headphones unplug).
    private var settingsListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null

    /** The player that plays on this phone, with the listener's buffer choice and headphone choice applied. */
    private fun createPhonePlayer(): ExoPlayer {
        val player = ExoPlayer.Builder(this)
            // Plays the stream through the rolling recording (see TimeShift); web addresses still work as before.
            .setMediaSourceFactory(DefaultMediaSourceFactory(TimeShift.dataSourceFactory(this)))
            .setLoadControl(AppSettings.loadControl(this))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(AppSettings.pauseOnUnplug(this))
            // Keeps the phone's Wi-Fi/CPU awake while streaming with the screen off.
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        // As soon as playback starts, fetch what's on air so the notification is right straight away.
        player.addListener(object : Player.Listener {
            // The signal dropped (tunnel, weak data, wifi change): keep trying to get back on air.
            override fun onPlayerError(error: PlaybackException) {
                // If the recording never got a single byte from the station, our own way of reading it does not
                // work on this phone or network: after two tries, play the stream directly, as before.
                if (player.currentMediaItem?.localConfiguration?.uri?.scheme == TimeShift.SCHEME && !TimeShift.everReceived) {
                    TimeShift.failuresWithoutData++
                    if (TimeShift.failuresWithoutData >= 2) {
                        TimeShift.disabled = true
                        TimeShift.stop(false)
                    }
                }
                scheduleReconnect(player)
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                pausedJob?.cancel()
                if (!playWhenReady) {
                    // The recording is kept while paused (so playing again can carry on), but not for ever.
                    pausedJob = scope.launch {
                        delay(TimeShift.KEEP_SECONDS * 1000L)
                        if (!player.playWhenReady) TimeShift.stop(true)
                    }
                } else if (player.currentMediaItem?.localConfiguration?.uri?.scheme == TimeShift.SCHEME &&
                    (TimeShift.idleStopped || SystemClock.elapsedRealtime() - itemSetAt > 1_500L)
                ) {
                    // Playing was asked for after a pause by something other than the app's own Play button (a
                    // headset, the car, the notification, a call ending), or the recording was dropped during a long
                    // pause: join live at your cushion again, exactly as the app's own Play button does. (The app's
                    // own button has just set the station, so it is left alone.)
                    player.currentMediaItem?.let { item ->
                        player.setMediaItem(forPhone(item))
                        player.prepare()
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!isPlaying) DataWarning.stoppedAt = SystemClock.elapsedRealtime()
                if (isPlaying) {
                    reconnectAttempts = 0
                    TimeShift.failuresWithoutData = 0
                    reconnectJob?.cancel()
                    // Whoever started us (app, notification, car), the web players must be quiet.
                    WebAudio.pauseAll()
                    scope.launch { refreshNowPlaying() }
                }
            }
        })
        return player
    }

    /**
     * The buffer choice changed: the buffer is built into the player, so a new phone player takes over
     * (it carries on with the station, and keeps playing if the radio was playing).
     */
    private fun applyBufferChoice() {
        val old = exoPlayer ?: return
        val session = mediaSession ?: return
        val fresh = createPhonePlayer()
        exoPlayer = fresh
        TimeShift.player = fresh
        if (session.player === old) {
            val item = old.currentMediaItem
            val playing = old.playWhenReady
            reconnectJob?.cancel()
            old.stop()
            old.clearMediaItems()
            session.player = fresh
            SleepTimer.player = fresh
            if (item != null) {
                // Starts again from the copy at the new cushion (no waiting for it to fill), if the copy has it.
                fresh.setMediaItem(forPhone(item))
                if (playing) {
                    fresh.prepare()
                    fresh.playWhenReady = true
                }
            }
        }
        old.release()
    }

    override fun onCreate() {
        super.onCreate()
        Config.initUserAgent(applicationContext)
        TimeShift.appContext = applicationContext
        val player = createPhonePlayer()
        exoPlayer = player
        TimeShift.player = player

        // The sleep timer pauses this player when it runs out.
        SleepTimer.player = player

        // Tapping the notification (or lock screen player) opens the app on the Radio tab.
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_OPEN_RADIO, true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        mediaSession = MediaLibrarySession.Builder(this, player, libraryCallback)
            .setSessionActivity(openApp)
            .build()

        setUpChromecast()
        watchNetwork(player)

        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            when (key) {
                AppSettings.K_BUFFER -> applyBufferChoice()
                AppSettings.K_UNPLUG -> exoPlayer?.setHandleAudioBecomingNoisy(AppSettings.pauseOnUnplug(this))
            }
        }
        settingsListener = listener
        AppSettings.prefs(this).registerOnSharedPreferenceChangeListener(listener)

        // ...and keep it up to date while listening.
        scope.launch {
            while (true) {
                delay(15_000)
                val current = mediaSession?.player
                if (current != null && current.playWhenReady) refreshNowPlaying()
            }
        }
    }

    /**
     * Chromecast: when you connect to a Cast device the stream moves over to it (the phone goes
     * quiet and just acts as the remote); disconnect and it comes back to the phone.
     * If this phone has no Google Play services, casting is simply left out.
     */
    private fun setUpChromecast() {
        var cast: CastPlayer? = null
        try {
            val created = CastPlayer(CastContext.getSharedInstance(this))
            cast = created
            created.setSessionAvailabilityListener(object : SessionAvailabilityListener {
                override fun onCastSessionAvailable() {
                    switchPlayer(created)
                }

                override fun onCastSessionUnavailable() {
                    exoPlayer?.let { switchPlayer(it) }
                }
            })
            castPlayer = created
            if (created.isCastSessionAvailable) switchPlayer(created)
        } catch (e: Exception) {
            // Casting isn't available here: tidy up and carry on with phone-only playback.
            castPlayer = null
            try {
                cast?.setSessionAvailabilityListener(null)
                cast?.release()
            } catch (ignored: Exception) {
            }
        }
    }

    /**
     * When the phone gets a network back (out of a tunnel, Wi-Fi to mobile data and back), and the radio is
     * trying to play but has dropped or stalled, join live again straight away instead of waiting out the
     * retry timer. A radio that is playing is left alone.
     */
    private fun watchNetwork(player: ExoPlayer) {
        val cm = getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                // The first call only reports the network that is already there.
                if (!netFirstSeen) {
                    netFirstSeen = true
                    return
                }
                networkBack(player)
            }
        }
        try {
            cm.registerDefaultNetworkCallback(callback, Handler(Looper.getMainLooper()))
            netCallback = callback
        } catch (e: Exception) {
            // Without it the timer-based retries still work.
        }
    }

    private fun networkBack(player: ExoPlayer) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastNetKick < 3_000L) return
        if (!player.playWhenReady || player.isPlaying || mediaSession?.player !== player) return
        val stuck = reconnectAttempts > 0 || player.playerError != null || player.playbackState == Player.STATE_BUFFERING
        if (!stuck) return
        lastNetKick = now
        reconnectAttempts = 0
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(500)   // let the new connection settle
            if (!player.playWhenReady || mediaSession?.player !== player || player.isPlaying) return@launch
            player.setMediaItem(forPhone(player.currentMediaItem ?: liveItem()))
            player.prepare()
            player.play()
        }
    }

    /**
     * After the stream drops, try again: after 2 seconds, then 4, 8, 16 and then every 30, for
     * about ten minutes. Stops as soon as the radio plays again, or if the listener pauses it.
     * (A radio that just dies in a tunnel and needs a tap to come back isn't much of a radio.)
     */
    private fun scheduleReconnect(player: ExoPlayer) {
        if (!player.playWhenReady) return
        if (reconnectAttempts >= MAX_RECONNECTS) {
            player.pause()   // give up quietly: the play button is there to try again
            return
        }
        val wait = minOf(2_000L shl minOf(reconnectAttempts, 4), 30_000L)
        reconnectAttempts++
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(wait)
            // Only if the listener still wants it, and it is still this phone playing (not a TV).
            if (!player.playWhenReady || mediaSession?.player !== player) return@launch
            if (player.isPlaying) return@launch
            // Reload the station so we join the live stream, not stale audio.
            player.setMediaItem(forPhone(player.currentMediaItem ?: liveItem()))
            player.prepare()
            player.play()
        }
    }

    /** Hands the current station (and playing / paused state) from one player to the other. */
    private fun switchPlayer(to: Player) {
        val session = mediaSession ?: return
        val from = session.player
        if (from === to) return
        // When a Chromecast disconnects its queue may already be empty: fall back to the station.
        var item = from.currentMediaItem ?: liveItem()
        if (to === castPlayer) {
            // Fresh address each time, so the TV never shows an old cached picture.
            item = item.buildUpon()
                .setMediaMetadata(
                    item.mediaMetadata.buildUpon()
                        .setArtworkUri(Uri.parse("${Config.ARTWORK_URL}?t=${System.currentTimeMillis()}"))
                        .build()
                )
                .build()
        }
        // A Chromecast needs the plain web address; the phone listens through the recording.
        item = if (to === castPlayer) forCast(item) else forPhone(item)
        TimeShift.castActive = to === castPlayer
        if (to === castPlayer) TimeShift.stop(false)
        val wasPlaying = from.playWhenReady
        from.stop()
        from.clearMediaItems()
        session.player = to
        SleepTimer.player = to
        to.setMediaItem(item)
        to.prepare()
        to.playWhenReady = wasPlaying
    }

    private fun stopButton(): CommandButton =
        CommandButton.Builder()
            .setDisplayName("Stop")
            .setIconResId(R.drawable.ic_stop)
            .setSessionCommand(STOP_ALL)
            .build()

    /** Silences everything: the radio, the sleep timer and any player on the web pages. */
    private fun stopEverything() {
        reconnectJob?.cancel()
        pausedJob?.cancel()
        TimeShift.stop(false)
        SleepTimer.cancel()
        WebAudio.pauseAll()
        val player = mediaSession?.player ?: return
        player.pause()
        player.stop()
        player.clearMediaItems()
    }

    private companion object {
        const val MAX_RECONNECTS = 25
        const val ACTION_STOP_ALL = "com.example.radioplayer.STOP_ALL"
        val STOP_ALL = SessionCommand(ACTION_STOP_ALL, Bundle.EMPTY)
    }

    private fun rootItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId("root")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(Config.STATION_NAME)
                    .setIsBrowsable(true)
                    .setIsPlayable(false)
                    .build()
            )
            .build()

    /** The same item, listening through the rolling recording (at your buffer distance behind live), unless it is switched off. */
    private fun forPhone(item: MediaItem): MediaItem {
        val uri = item.localConfiguration?.uri
        val isStation = uri?.toString() == Config.STREAM_URL || uri?.scheme == TimeShift.SCHEME
        if (!isStation) return item
        itemSetAt = SystemClock.elapsedRealtime()
        TimeShift.idleStopped = false
        val target = if (TimeShift.disabled) Uri.parse(Config.STREAM_URL) else TimeShift.joinUri()
        return item.buildUpon().setUri(target).build()
    }

    /** The same item with the plain web address, which is what a Chromecast plays. */
    private fun forCast(item: MediaItem): MediaItem {
        val uri = item.localConfiguration?.uri
        if (uri?.scheme != TimeShift.SCHEME) return item
        return item.buildUpon().setUri(Config.STREAM_URL).build()
    }

    private fun liveItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId("live")
            .setUri(Config.STREAM_URL)
            .setMimeType(MimeTypes.AUDIO_MPEG)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(Config.STATION_NAME)
                    .setArtist("Live on ${Config.STATION_NAME}")
                    .setArtworkUri(Uri.parse(Config.LOGO_URL))
                    .setIsBrowsable(false)
                    .setIsPlayable(true)
                    .build()
            )
            .build()

    private suspend fun refreshNowPlaying() {
        // null means the status page couldn't be read: leave the notification as it is.
        val title = withContext(Dispatchers.IO) { fetchNowPlayingTitle() } ?: return
        showInNotification(title)    // "" = the server answered but names nobody: the station's own details
    }

    /** The round station logo as a small PNG, for shows that have no picture of their own. */
    private fun logoBytes(): ByteArray? =
        try {
            val bitmap = BitmapFactory.decodeResource(resources, R.drawable.station_logo_tile)
            val out = ByteArrayOutputStream()
            bitmap?.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.toByteArray().takeIf { it.isNotEmpty() }
        } catch (e: Exception) {
            null
        }

    private suspend fun showInNotification(title: String?) {
        val session = mediaSession ?: return
        val player = session.player
        // While casting, changing the item would restart the stream on the Chromecast: leave it.
        if (player === castPlayer) return
        val currentItem = player.currentMediaItem ?: return

        // The same rule the screens use (StreamNames.resolve), so the notification, car display, Bluetooth
        // and Chromecast always show what the app shows: a placeholder like "Syndicast" or a junk title is
        // never sent out, and a DJ name written another way ("Cherish-DJ") is the DJ list's own spelling.
        val (djs, shows) = withContext(Dispatchers.IO) { StreamNames.savedLists(applicationContext.cacheDir) }
        // A title too poor to show (a DJ sending nonsense, or nothing) is replaced by
        // "Safehouse Radio / All Day Every Day".
        val shown = StreamNames.resolve(title, djs, shows)
        val newTitle = shown.dj ?: Config.STATION_NAME
        val newArtist = shown.show ?: "Live on ${Config.STATION_NAME}"

        // Nothing changed: don't touch the player.
        if (currentItem.mediaMetadata.title?.toString() == newTitle &&
            currentItem.mediaMetadata.artist?.toString() == newArtist
        ) return

        // The picture goes in as real image data (not just a web address): that is what car and
        // Bluetooth displays use.
        val djPicture = LiveArt.get(title)
        // No picture from the station: the one we carry for a known show (ABGT697), else the station logo.
        val showPicture = if (djPicture == null) withContext(Dispatchers.Default) { ShowArt.bytes(applicationContext, title) } else null
        val picture = djPicture ?: showPicture ?: logoBytes()

        // Things may have changed while the picture downloaded.
        val nowPlayer = mediaSession?.player ?: return
        if (nowPlayer !== player) return
        val item = nowPlayer.currentMediaItem ?: return

        val metadata = MediaMetadata.Builder()
            .setTitle(newTitle)
            .setArtist(newArtist)
            // (No album line: some phones glue it onto the end of the show name, and it only repeated the station name.)
        // The web address is what a Chromecast uses; the picture data above is for the phone and car.
        // (Not set when the station only sent its plain default picture, so nothing shows that.)
        if (djPicture != null) {
            metadata.setArtworkUri(Uri.parse("${Config.ARTWORK_URL}?t=${System.currentTimeMillis()}"))
        }
        if (picture != null) {
            metadata.setArtworkData(picture, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
        }

        // Same stream address with new details: playback carries on without a restart.
        nowPlayer.replaceMediaItem(
            nowPlayer.currentMediaItemIndex,
            item.buildUpon().setMediaMetadata(metadata.build()).build()
        )
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? =
        mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Keep playing if the user swiped the app away mid-stream; otherwise shut down.
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        settingsListener?.let { AppSettings.prefs(this).unregisterOnSharedPreferenceChangeListener(it) }
        settingsListener = null
        netCallback?.let { cb ->
            try {
                (getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as? ConnectivityManager)?.unregisterNetworkCallback(cb)
            } catch (e: Exception) {
            }
        }
        netCallback = null
        scope.cancel()
        TimeShift.stop(false)
        TimeShift.player = null
        SleepTimer.cancel()
        SleepTimer.player = null
        castPlayer?.setSessionAvailabilityListener(null)
        castPlayer?.release()
        castPlayer = null
        exoPlayer?.release()
        exoPlayer = null
        mediaSession?.release()
        mediaSession = null
        super.onDestroy()
    }
}
