package com.example.radioplayer

import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Runs the audio in a foreground service so the stream keeps playing with the
 * screen locked or the app in the background. Media3 shows the notification
 * (with play/pause) and the lock screen controls automatically.
 *
 * It is a "library" service so Android Auto (and other car / Bluetooth screens) can browse it:
 * they see one item, the live station.
 *
 * The service also checks what's on air every 15 seconds while playing and puts the
 * DJ name, show name and DJ picture into that notification.
 */
class PlaybackService : MediaLibraryService() {

    private var mediaSession: MediaLibrarySession? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val libraryCallback = object : MediaLibrarySession.Callback {

        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(rootItem(), params))

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> =
            Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.of(liveItem()), params))

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String
        ): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(liveItem(), null))

        // A car screen asks to play an item by its id only: fill in the stream address.
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: List<MediaItem>
        ): ListenableFuture<List<MediaItem>> {
            val resolved: List<MediaItem> = mediaItems.map { item ->
                if (item.localConfiguration == null) liveItem() else item
            }
            return Futures.immediateFuture(resolved)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            // Keeps the phone's Wi-Fi/CPU awake while streaming with the screen off.
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        // The sleep timer pauses this player when it runs out.
        SleepTimer.player = player

        // As soon as playback starts, fetch what's on air so the notification is right straight away.
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) scope.launch { refreshNowPlaying() }
            }
        })

        // Tapping the notification (or lock screen player) opens the app on the Radio tab.
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(MainActivity.EXTRA_OPEN_RADIO, true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        mediaSession = MediaLibrarySession.Builder(this, player, libraryCallback)
            .setSessionActivity(openApp)
            .build()

        // ...and keep it up to date while listening.
        scope.launch {
            while (true) {
                delay(15_000)
                val current = mediaSession?.player
                if (current != null && current.playWhenReady) refreshNowPlaying()
            }
        }
    }

    private fun rootItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId("root")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(Config.STATION_NAME)
                    .setIsBrowsable(true)
                    .setIsPlayable(false)
                    .build()
            )
            .build()

    private fun liveItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId("live")
            .setUri(Config.STREAM_URL)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(Config.STATION_NAME)
                    .setArtist("Live")
                    .setIsBrowsable(false)
                    .setIsPlayable(true)
                    .build()
            )
            .build()

    private suspend fun refreshNowPlaying() {
        // null means the status page couldn't be read: leave the notification as it is.
        val title = withContext(Dispatchers.IO) { fetchNowPlayingTitle() } ?: return
        showInNotification(title.ifEmpty { null })
    }

    private fun showInNotification(title: String?) {
        val player = mediaSession?.player ?: return
        val currentItem = player.currentMediaItem ?: return

        val (dj, show) = splitNowPlaying(title)
        val newTitle = dj ?: Config.STATION_NAME
        val newArtist = show ?: "Live"

        // Nothing changed: don't touch the player.
        if (currentItem.mediaMetadata.title?.toString() == newTitle &&
            currentItem.mediaMetadata.artist?.toString() == newArtist
        ) return

        val metadata = MediaMetadata.Builder()
            .setTitle(newTitle)
            .setArtist(newArtist)
            .setArtworkUri(Uri.parse("${Config.ARTWORK_URL}?t=${System.currentTimeMillis()}"))
            .build()

        // Same stream address with new details: playback carries on without a restart.
        player.replaceMediaItem(
            player.currentMediaItemIndex,
            currentItem.buildUpon().setMediaMetadata(metadata).build()
        )
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? =
        mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Keep playing if the user swiped the app away mid-stream; otherwise shut down.
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        scope.cancel()
        SleepTimer.cancel()
        SleepTimer.player = null
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }
}
