package com.example.radioplayer

import android.content.Intent
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Runs the audio in a foreground service so the stream keeps playing with the
 * screen locked or the app in the background. Media3 shows the notification
 * (with play/pause) and the lock screen controls automatically.
 *
 * The service also checks what's on air every 15 seconds while playing and puts the
 * DJ name, show name and DJ picture into that notification.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()

        // As soon as playback starts, fetch what's on air so the notification is right straight away.
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) scope.launch { refreshNowPlaying() }
            }
        })

        mediaSession = MediaSession.Builder(this, player).build()

        // ...and keep it up to date while listening.
        scope.launch {
            while (true) {
                delay(15_000)
                val current = mediaSession?.player
                if (current != null && current.playWhenReady) refreshNowPlaying()
            }
        }
    }

    private suspend fun refreshNowPlaying() {
        // null means the status page couldn't be read: leave the notification as it is.
        val title = withContext(Dispatchers.IO) { fetchNowPlayingTitle() } ?: return
        showInNotification(title.ifEmpty { null })
    }

    private fun showInNotification(title: String?) {
        val player = mediaSession?.player ?: return
        val currentItem = player.currentMediaItem ?: return

        val (dj, show) = splitNowPlaying(title)
        val newTitle = dj ?: Config.STATION_NAME
        val newArtist = show ?: "Live"

        // Nothing changed: don't touch the player.
        if (currentItem.mediaMetadata.title?.toString() == newTitle &&
            currentItem.mediaMetadata.artist?.toString() == newArtist
        ) return

        val metadata = MediaMetadata.Builder()
            .setTitle(newTitle)
            .setArtist(newArtist)
            .setArtworkUri(Uri.parse("${Config.ARTWORK_URL}?t=${System.currentTimeMillis()}"))
            .build()

        // Same stream address with new details: playback carries on without a restart.
        player.replaceMediaItem(
            player.currentMediaItemIndex,
            currentItem.buildUpon().setMediaMetadata(metadata).build()
        )
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? =
        mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Keep playing if the user swiped the app away mid-stream; otherwise shut down.
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        scope.cancel()
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }
}
