package com.example.radioplayer

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.LocalContext

/** The pale lilac of the light that runs round the edge. */
private val GlowColor = Color(0xFFD6C8FF)

/**
 * A soft light that runs clockwise round the edge of a card or picture, coming from behind it: only the glow
 * outside the edge shows, the card or picture itself is never tinted. One lap takes [lapMillis].
 *
 * Does nothing when [on] is false, and does nothing when "Reduce animations" is on (the switch on the More tab,
 * or the phone's own setting). It is plain Compose drawing, so it works on every Android version, and it only
 * runs while the thing it is on is on screen and the app is open.
 *
 * Put it after the shadow or .lift() and before .clip() / .background(), with the same [shape]:
 *     Modifier.lift(shape).travellingGlow(shape, on = true).clip(shape).background(...)
 */
fun Modifier.travellingGlow(shape: Shape, on: Boolean, lapMillis: Int = 6000): Modifier = composed {
    val calm = AppSettings.reduceMotion(LocalContext.current)
    if (!on || calm) {
        Modifier
    } else {
        val transition = rememberInfiniteTransition(label = "glow")
        val lap by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(lapMillis, easing = LinearEasing)),
            label = "lap"
        )
        Modifier.drawWithContent {
            if (size.width > 0f && size.height > 0f) {
                val path = shape.createOutline(size, layoutDirection, this).toPath()
                val measure = PathMeasure()
                measure.setPath(path, false)
                val length = measure.length
                if (length > 0f) {
                    val reach = 10f * density
                    val tail = length * 0.34f
                    val head = lap * length
                    val slices = 10
                    val widths = floatArrayOf(1f, 0.7f, 0.45f, 0.25f)
                    clipPath(path, ClipOp.Difference) {
                        for (s in 0 until slices) {
                            val from = head - tail * (s + 1) / slices
                            val to = head - tail * s / slices
                            val fade = 1f - (s + 0.5f) / slices
                            val piece = Path()
                            addArc(measure, from, to, length, piece)
                            for (w in widths) {
                                drawPath(
                                    path = piece,
                                    color = GlowColor.copy(alpha = 0.26f * fade * fade),
                                    style = Stroke(width = reach * 2f * w, cap = StrokeCap.Round)
                                )
                            }
                        }
                    }
                }
            }
            drawContent()
        }
    }
}

/** Adds the stretch of the outline from [from] to [to] (distances along it, which may run past either end). */
private fun addArc(measure: PathMeasure, from: Float, to: Float, length: Float, out: Path) {
    var a = from
    var b = to
    if (b <= 0f) {
        a += length
        b += length
    }
    if (a < 0f) {
        measure.getSegment(a + length, length, out, true)
        measure.getSegment(0f, b, out, true)
    } else {
        measure.getSegment(a, b, out, true)
    }
}
