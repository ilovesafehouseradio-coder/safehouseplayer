package com.example.radioplayer

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/** Chery Poppins: the hidden game (hold Cherish's photo on her DJ page for three seconds). */
object CheryGame {
    var open by mutableStateOf(false)

    private const val PREFS = "chery_game"
    fun best(ctx: Context): Int = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("best", 0)
    fun saveBest(ctx: Context, v: Int) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("best", v).apply()
}

private enum class Phase { READY, PLAYING, PAUSED, OVER }

/** Something falling: x as a share of the width, y in pixels. kind 0 = record, 1 = note, 2 = gold star. */
/** A catch sparkle: where it happened, and how long it has left (seconds). */
private class Burst(val x: Float, val y: Float) {
    var left = 0.35f
}

/** The size of a falling record, note or star: a little smaller each level, down to two thirds. */
private fun dropRadius(w: Float, level: Int): Float = w * 0.045f * 0.96f.pow(level).coerceAtLeast(0.66f)

private class Drop(val x: Float, var y: Float, val kind: Int, val speed: Float) {
    var caught = false
    var missed = false
}

// Where the umbrella is in Chery's picture (shares of the picture's width and height): its top and its rim.
private const val CANOPY_LEFT = 0.012f
private const val CANOPY_RIGHT = 0.988f
private const val CANOPY_TOP = 0.056f
private const val CANOPY_RIM = 0.243f
private const val MAX_LEVEL = 10

@Composable
fun CheryGameScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pal = ThemeState.current
    val reduce = AppSettings.reduceMotion(ctx)
    val stand = ImageBitmap.imageResource(R.drawable.chery_stand)
    val cheer = ImageBitmap.imageResource(R.drawable.chery_cheer)

    var phase by remember { mutableStateOf(Phase.READY) }
    var score by remember { mutableIntStateOf(0) }
    var best by remember { mutableIntStateOf(CheryGame.best(ctx)) }
    var lives by remember { mutableIntStateOf(3) }
    var newBest by remember { mutableStateOf(false) }
    var frame by remember { mutableIntStateOf(0) }       // goes up every frame, so the field is drawn again

    // The game's moving parts (plain fields: they change every frame).
    val drops = remember { ArrayList<Drop>() }
    val bursts = remember { ArrayList<Burst>() }
    val view = androidx.compose.ui.platform.LocalView.current
    var field by remember { mutableStateOf(IntSize.Zero) }
    val game = remember {
        object {
            var x = 0.5f; var target = 0.5f; var catches = 0; var combo = 0; var level = 0
            var sinceSpawn = 0f; var cheerFor = 0f; var banner = ""; var bannerFor = 0f
        }
    }

    // Leaving the app pauses the game.
    val visible by rememberAppVisible()
    LaunchedEffect(visible) { if (!visible && phase == Phase.PLAYING) phase = Phase.PAUSED }
    BackHandler {
        if (phase == Phase.PLAYING) phase = Phase.PAUSED else onClose()
    }

    fun start() {
        drops.clear(); bursts.clear(); score = 0; lives = 3; newBest = false; frame = 0
        game.x = 0.5f; game.target = 0.5f; game.catches = 0; game.combo = 0; game.level = 0
        game.sinceSpawn = 0f; game.cheerFor = 0f; game.bannerFor = 0f
        phase = Phase.PLAYING
    }

    fun end() {
        phase = Phase.OVER
        if (score > best) {
            best = score; newBest = true; CheryGame.saveBest(ctx, score)
        }
    }

    // The game loop: one step each frame while playing.
    LaunchedEffect(phase) {
        if (phase != Phase.PLAYING) return@LaunchedEffect
        var last = 0L
        while (phase == Phase.PLAYING) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0f else ((now - last) / 1e9f).coerceAtMost(0.05f)
                last = now
                val w = field.width.toFloat(); val h = field.height.toFloat()
                if (w <= 0f || h <= 0f) return@withFrameNanos

                // Chery glides towards the finger.
                game.x += (game.target - game.x) * min(1f, dt * 14f)
                // Sizes for this level: she shrinks, things fall faster.
                val lv = game.level
                val cherH = h * (0.46f * 0.9f.pow(lv)).coerceAtLeast(0.22f)
                val cherW = cherH * stand.width / stand.height
                val cherTop = h - cherH - 4f
                val cx = game.x * w
                val left = cx - cherW * (0.5f - CANOPY_LEFT)
                val right = cx + cherW * (CANOPY_RIGHT - 0.5f)
                val half = (right - left) / 2f
                val top = cherTop + cherH * CANOPY_TOP
                val rim = cherTop + cherH * CANOPY_RIM
                val fallTime = if (reduce) 3.2f - lv * 0.1f else (2.6f - lv * 0.13f).coerceAtLeast(1.2f)
                val radius = dropRadius(w, lv)

                // New drops on a steady rhythm that quickens with each level.
                game.sinceSpawn += dt
                val steadyGap = (1.15f - lv * 0.06f).coerceAtLeast(0.55f)
                val spawn = game.sinceSpawn >= steadyGap
                if (spawn) {
                    game.sinceSpawn = 0f
                    val kind = if (Random.nextInt(8) == 0) 2 else Random.nextInt(2)
                    drops.add(Drop(Random.nextFloat() * 0.84f + 0.08f, -radius, kind, h / fallTime))
                }

                // Move everything, and see what lands on the umbrella.
                val it = drops.iterator()
                while (it.hasNext()) {
                    val d = it.next()
                    d.y += d.speed * dt
                    val dx = d.x * w - cx
                    if (!d.caught && !d.missed && abs(dx) < half + radius * 0.4f) {
                        val k = (dx / half).coerceIn(-1f, 1f)
                        val surface = top + (rim - top) * k * k
                        if (d.y + radius >= surface && d.y - radius < rim) {
                            d.caught = true
                            view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                            bursts.add(Burst(d.x, d.y + radius * 0.5f))
                            game.catches++; game.combo++
                            val mult = when { game.combo >= 10 -> 3; game.combo >= 5 -> 2; else -> 1 }
                            score += (if (d.kind == 2) 5 else 1) * mult
                            game.level = (game.catches / 8).coerceAtMost(MAX_LEVEL)
                            if (d.kind == 2 || game.combo == 5 || game.combo == 10) {
                                game.cheerFor = 0.7f
                                game.banner = if (mult > 1) "x$mult" else "+5"
                                game.bannerFor = 1.0f
                            }
                        }
                    }
                    if (!d.caught && !d.missed && d.y - radius > rim) {
                        d.missed = true
                        game.combo = 0
                        if (d.kind != 2) {
                            view.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                            lives--
                            if (lives <= 0) end()
                        }
                    }
                    if (d.caught || d.y - radius > h) it.remove()
                }
                val bi = bursts.iterator()
                while (bi.hasNext()) { val b = bi.next(); b.left -= dt; if (b.left <= 0f) bi.remove() }
                game.cheerFor = (game.cheerFor - dt).coerceAtLeast(0f)
                game.bannerFor = (game.bannerFor - dt).coerceAtLeast(0f)
                frame++
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        PageHeader(
            title = "Chery Poppins",
            leading = { BackArrowInBar("Close the game", onClose) },
            trailing = {
                if (phase == Phase.PLAYING) {
                    Box(
                        Modifier.align(Alignment.CenterEnd).padding(end = 4.dp).size(48.dp).clip(CircleShape)
                            .clickable(onClickLabel = "Pause", role = Role.Button) { phase = Phase.PAUSED }
                            .semantics { contentDescription = "Pause the game" },
                        contentAlignment = Alignment.Center
                    ) { PauseBars(LavenderInk) }
                }
            }
        )
        // Score, best and lives: three cards on the page border, one gap apart.
        Row(
            Modifier.fillMaxWidth().padding(horizontal = ScreenLayout.side()),
            horizontalArrangement = Arrangement.spacedBy(ScreenLayout.gap())
        ) {
            StatCard("SCORE", score.toString(), Modifier.weight(1f))
            StatCard("BEST", best.toString(), Modifier.weight(1f))
            StatCard("LIVES", "♥".repeat(lives.coerceAtLeast(0)).ifEmpty { "–" }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(ScreenLayout.gap()))

        // The playing field.
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .onSizeChanged { field = it }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        if (size.width > 0) game.target = (down.position.x / size.width).coerceIn(0.08f, 0.92f)
                        while (true) {
                            val event = awaitPointerEvent()
                            val p = event.changes.firstOrNull() ?: break
                            if (!p.pressed) break
                            if (size.width > 0) game.target = (p.position.x / size.width).coerceIn(0.08f, 0.92f)
                            p.consume()
                        }
                    }
                }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val tick = frame   // read here so the field is drawn again every frame
                if (tick < 0) return@Canvas
                val w = size.width; val h = size.height
                val radius = dropRadius(w, game.level)
                for (d in drops) drawDrop(d, d.x * w, d.y, radius, pal.primary, pal.live, pal.card, reduce)
                // A quick gold sparkle where each catch landed.
                if (!reduce) {
                    for (b in bursts) {
                        val t = 1f - b.left / 0.35f
                        for (i in 0 until 8) {
                            val ang = i * Math.PI / 4
                            val r1 = radius * (0.6f + t * 1.2f); val r2 = radius * (1.0f + t * 1.8f)
                            drawLine(
                                pal.live.copy(alpha = 1f - t),
                                Offset(b.x * w + (r1 * cos(ang)).toFloat(), b.y + (r1 * sin(ang)).toFloat()),
                                Offset(b.x * w + (r2 * cos(ang)).toFloat(), b.y + (r2 * sin(ang)).toFloat()),
                                strokeWidth = radius * 0.18f, cap = StrokeCap.Round
                            )
                        }
                    }
                }
                // Chery.
                val lv = game.level
                val cherH = h * (0.46f * 0.9f.pow(lv)).coerceAtLeast(0.22f)
                val cherW = cherH * stand.width / stand.height
                val img = if (game.cheerFor > 0f) cheer else stand
                drawImage(
                    image = img,
                    srcOffset = IntOffset.Zero,
                    srcSize = IntSize(img.width, img.height),
                    dstOffset = IntOffset((game.x * w - cherW / 2f).roundToInt(), (h - cherH - 4f).roundToInt()),
                    dstSize = IntSize(cherW.roundToInt(), cherH.roundToInt())
                )
            }
            if (game.bannerFor > 0f && phase == Phase.PLAYING) {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(game.banner, color = pal.live, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                    Text("Nice catch!", color = pal.text, fontSize = AppType.Button, fontWeight = FontWeight.Bold)
                }
            }
            if (phase == Phase.PLAYING && frame < 120) {
                Text(
                    "Slide to move Chery",
                    color = pal.textDim, fontSize = AppType.Sub,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
                )
            }
            when (phase) {
                Phase.READY -> GamePanel {
                    Image(
                        painter = painterResource(R.drawable.chery_logo),
                        contentDescription = "Chery Poppins",
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(ScreenLayout.gap()))
                    Text(
                        "Catch the music before it hits the floor! Slide to move Chery. Gold stars are worth 5.",
                        color = pal.text, fontSize = AppType.ShowName, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(ScreenLayout.gap() * 2))
                    SetupButton("Play", onClick = { start() }, modifier = Modifier.fillMaxWidth())
                }
                Phase.PAUSED -> GamePanel {
                    Text("Paused", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(ScreenLayout.gap() * 2))
                    SetupButton("Carry on", onClick = { phase = Phase.PLAYING }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(ScreenLayout.gap()))
                    BubbleButton("Close the game", onClick = onClose, modifier = Modifier.fillMaxWidth())
                }
                Phase.OVER -> GamePanel {
                    Text("Game over", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(ScreenLayout.gap()))
                    Text("$score", color = pal.live, fontSize = 48.sp, fontWeight = FontWeight.Bold)
                    Text(if (newBest) "New best score!" else "Best: $best", color = pal.textDim, fontSize = AppType.ShowName)
                    Spacer(Modifier.height(ScreenLayout.gap() * 2))
                    SetupButton("Play again", onClick = { start() }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(ScreenLayout.gap()))
                    BubbleButton("Share my score", onClick = {
                        ShareCard.share(
                            ctx,
                            "I scored $score on Chery Poppins, the game hidden in the ${Config.STATION_NAME} app. Can you find it and beat me? ${Config.SHARE_URL}",
                            ShareCard.Spec(name = "Chery Poppins", line = "", pill = null, gameScore = score)
                        )
                    }, modifier = Modifier.fillMaxWidth())
                }
                Phase.PLAYING -> {}
            }
        }
    }
}

/** A card in the middle of the field for the start, pause and game-over messages. */
@Composable
private fun GamePanel(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(Modifier.fillMaxSize().background(ThemeState.current.scrim), contentAlignment = Alignment.Center) {
        Column(
            Modifier
                .padding(horizontal = ScreenLayout.side())
                .fillMaxWidth()
                .lift(shape)
                .clip(shape)
                .background(ThemeState.current.card)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            content = content
        )
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .lift(shape)
            .clip(shape)
            .background(CardSurface)
            .heightIn(min = 60.dp)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(label, color = ThemeState.current.primary, fontSize = AppType.CardTime, fontWeight = FontWeight.Bold)
        Text(value, color = ThemeState.current.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** The back arrow at the left of a page title pill. */
@Composable
private fun androidx.compose.foundation.layout.BoxScope.BackArrowInBar(label: String, onBack: () -> Unit) {
    Box(
        Modifier.align(Alignment.CenterStart).padding(start = 4.dp).size(48.dp).clip(CircleShape)
            .clickable(onClickLabel = label, role = Role.Button, onClick = onBack),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(R.drawable.ic_arrow_back), contentDescription = label, tint = LavenderInk, modifier = Modifier.size(24.dp))
    }
}

@Composable
private fun PauseBars(color: Color) {
    Canvas(Modifier.size(20.dp)) {
        val bw = size.width * 0.3f
        drawRoundRect(color, Offset(size.width * 0.1f, 0f), Size(bw, size.height), androidx.compose.ui.geometry.CornerRadius(3f, 3f))
        drawRoundRect(color, Offset(size.width * 0.6f, 0f), Size(bw, size.height), androidx.compose.ui.geometry.CornerRadius(3f, 3f))
    }
}

/** A record, a note or a gold star, with a soft trail above it. */
private fun DrawScope.drawDrop(d: Drop, x: Float, y: Float, r: Float, main: Color, gold: Color, dark: Color, reduce: Boolean) {
    val col = if (d.kind == 2) gold else main
    if (!reduce) {
        for (i in 1..6) {
            drawLine(col.copy(alpha = 0.22f * (1f - i / 7f)), Offset(x, y - r - (i - 1) * r * 0.5f), Offset(x, y - r - i * r * 0.5f), strokeWidth = r * 0.35f, cap = StrokeCap.Round)
        }
    }
    val a = if (d.missed) 0.35f else 1f
    when (d.kind) {
        0 -> {
            drawCircle(dark.copy(alpha = a), r, Offset(x, y))
            drawCircle(col.copy(alpha = a), r, Offset(x, y), style = Stroke(r * 0.16f))
            drawCircle(col.copy(alpha = 0.45f * a), r * 0.7f, Offset(x, y), style = Stroke(r * 0.05f))
            drawCircle(col.copy(alpha = a), r * 0.36f, Offset(x, y))
            drawCircle(dark.copy(alpha = a), r * 0.08f, Offset(x, y))
        }
        1 -> {
            val head = r * 0.42f
            drawCircle(col.copy(alpha = a), head, Offset(x - r * 0.25f, y + r * 0.45f))
            drawLine(col.copy(alpha = a), Offset(x - r * 0.25f + head * 0.85f, y + r * 0.45f), Offset(x - r * 0.25f + head * 0.85f, y - r * 0.85f), strokeWidth = r * 0.16f)
            val flag = Path().apply {
                moveTo(x - r * 0.25f + head * 0.85f, y - r * 0.85f)
                lineTo(x + r * 0.65f, y - r * 0.45f)
                lineTo(x + r * 0.6f, y - r * 0.1f)
                lineTo(x - r * 0.25f + head * 0.85f, y - r * 0.45f)
                close()
            }
            drawPath(flag, col.copy(alpha = a))
        }
        else -> {
            val star = Path()
            for (i in 0 until 10) {
                val ang = -Math.PI / 2 + i * Math.PI / 5
                val rr = if (i % 2 == 0) r * 1.1f else r * 0.48f
                val px = x + (rr * cos(ang)).toFloat(); val py = y + (rr * sin(ang)).toFloat()
                if (i == 0) star.moveTo(px, py) else star.lineTo(px, py)
            }
            star.close()
            drawPath(star, col.copy(alpha = a))
        }
    }
}
