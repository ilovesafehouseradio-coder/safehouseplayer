package com.example.radioplayer

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.appendInlineContent
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/** Chery Poppins: the hidden game (hold Cherish's photo on her DJ page for three seconds). */
object CheryGame {
    var open by mutableStateOf(false)

    private const val PREFS = "chery_game"
    fun best(ctx: Context): Int = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("best", 0)
    fun saveBest(ctx: Context, v: Int) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("best", v).apply()
}

private enum class Phase { READY, PLAYING, PAUSED, OVER }

/** A catch sparkle: where it happened, and how long it has left (seconds). */
private class Burst(val x: Float, val y: Float) {
    var left = 0.35f
}

/** The size of a falling record, note or star: a little smaller each level, down to two thirds. */
private fun dropRadius(w: Float, level: Int): Float = w * 0.045f * 0.96f.pow(level).coerceAtLeast(0.66f)

/**
 * Something falling: x as a share of the width, y in pixels.
 * kind 0 = record, 1 = note, 2 = gold star (5 points), 3 = cracked record and 4 = cheesy pop CD (catch them and you
 * lose a life: dodge them), 5 = gold rewind record (slow motion), 6 = gold headphones (magnet), 7 = purple heart (a life).
 */
private const val BAD_CRACKED = 3
private const val BAD_POP = 4
private const val REWIND = 5
private const val MAGNET = 6
private const val HEART = 7
private fun isBad(kind: Int) = kind == BAD_CRACKED || kind == BAD_POP

/** The warning red for bad things in the game (the game only, asked for specially). */
private val WarnRed = Color(0xFFFF3B3B)

/** A warning buzz: a double knock, different from the single tap of a good catch. */
private fun warnBuzz(view: android.view.View) {
    if (android.os.Build.VERSION.SDK_INT >= 30) {
        view.performHapticFeedback(android.view.HapticFeedbackConstants.REJECT)
    } else {
        view.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
    }
    view.postDelayed({ view.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) }, 140)
}

private val QUIPS = listOf(
    "Tune!", "Rewind!", "Selector!", "Bass face!", "Big tune!", "Lovely!",
    // Some of the real Chery's own sayings.
    "Word Machines", "NuggetsRNice", "Stay Happy", "Stay Healthy"
)

private class Drop(var x: Float, var y: Float, val kind: Int, val speed: Float) {
    var caught = false
    var missed = false
}

// Where the umbrella is in Chery's picture (shares of the picture's width and height): its top and its rim.
private const val CANOPY_LEFT = 0.012f
private const val CANOPY_RIGHT = 0.988f
private const val CANOPY_TOP = 0.056f
private const val CANOPY_RIM = 0.243f
private const val MAX_LEVEL = 10

@Composable
fun CheryGameScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pal = ThemeState.current
    val reduce = AppSettings.reduceMotion(ctx)
    val stand = ImageBitmap.imageResource(R.drawable.chery_stand)
    val cheer = ImageBitmap.imageResource(R.drawable.chery_cheer)

    var phase by remember { mutableStateOf(Phase.READY) }
    var score by remember { mutableIntStateOf(0) }
    var best by remember { mutableIntStateOf(CheryGame.best(ctx)) }
    var lives by remember { mutableIntStateOf(3) }
    var newBest by remember { mutableStateOf(false) }
    var frame by remember { mutableIntStateOf(0) }       // goes up every frame, so the field is drawn again

    // The game's moving parts (plain fields: they change every frame).
    val drops = remember { ArrayList<Drop>() }
    val bursts = remember { ArrayList<Burst>() }
    val view = androidx.compose.ui.platform.LocalView.current
    var field by remember { mutableStateOf(IntSize.Zero) }
    val game = remember {
        object {
            var x = 0.5f; var target = 0.5f; var catches = 0; var combo = 0; var level = 0
            var sinceSpawn = 0f; var cheerFor = 0f; var banner = ""; var sub = ""; var bannerFor = 0f
            var slowFor = 0f; var magnetFor = 0f; var quip = ""; var quipFor = 0f; var nextShout = 100
        }
    }
    // Whoever is on air now, for the shout-outs on a big combo (the station's name if nobody is named).
    var onAir by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {
        onAir = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val (djs, shows) = StreamNames.savedLists(ctx.cacheDir)
                val feed = LiveFeed.last ?: fetchLiveStatus()
                feed?.let { StreamNames.resolve(it.title, djs, shows) }?.takeIf { !it.generic }?.dj
            } catch (e: Exception) {
                null
            }
        }
    }
    fun say(text: String) { game.quip = text; game.quipFor = 1.0f }
    fun announce(big: String, small: String) { game.banner = big; game.sub = small; game.bannerFor = 1.2f }

    // Leaving the app pauses the game.
    val visible by rememberAppVisible()
    LaunchedEffect(visible) { if (!visible && phase == Phase.PLAYING) phase = Phase.PAUSED }
    BackHandler {
        if (phase == Phase.PLAYING) phase = Phase.PAUSED else onClose()
    }

    fun start() {
        drops.clear(); bursts.clear(); score = 0; lives = 3; newBest = false; frame = 0
        game.x = 0.5f; game.target = 0.5f; game.catches = 0; game.combo = 0; game.level = 0
        game.sinceSpawn = 0f; game.cheerFor = 0f; game.bannerFor = 0f
        game.slowFor = 0f; game.magnetFor = 0f; game.quipFor = 0f; game.nextShout = 100
        phase = Phase.PLAYING
    }

    fun end() {
        phase = Phase.OVER
        if (score > best) {
            best = score; newBest = true; CheryGame.saveBest(ctx, score)
        }
    }

    // The game loop: one step each frame while playing.
    LaunchedEffect(phase) {
        if (phase != Phase.PLAYING) return@LaunchedEffect
        var last = 0L
        while (phase == Phase.PLAYING) {
            withFrameNanos { now ->
                val dt = if (last == 0L) 0f else ((now - last) / 1e9f).coerceAtMost(0.05f)
                last = now
                val w = field.width.toFloat(); val h = field.height.toFloat()
                if (w <= 0f || h <= 0f) return@withFrameNanos

                // Chery glides towards the finger.
                game.x += (game.target - game.x) * min(1f, dt * 14f)
                // Sizes for this level: she shrinks, things fall faster.
                val lv = game.level
                val cherH = h * (0.46f * 0.9f.pow(lv)).coerceAtLeast(0.22f)
                val cherW = cherH * stand.width / stand.height
                val cherTop = h - cherH - 4f
                val cx = game.x * w
                val left = cx - cherW * (0.5f - CANOPY_LEFT)
                val right = cx + cherW * (CANOPY_RIGHT - 0.5f)
                val half = (right - left) / 2f
                val top = cherTop + cherH * CANOPY_TOP
                val rim = cherTop + cherH * CANOPY_RIM
                val fallTime = if (reduce) 3.2f - lv * 0.1f else (2.6f - lv * 0.13f).coerceAtLeast(1.2f)
                val radius = dropRadius(w, lv)

                // New drops on a steady rhythm that quickens with each level. Now and then something special falls.
                game.sinceSpawn += dt
                val steadyGap = (1.15f - lv * 0.06f).coerceAtLeast(0.55f)
                if (game.sinceSpawn >= steadyGap) {
                    game.sinceSpawn = 0f
                    val r = Random.nextInt(100)
                    val kind = when {
                        lv >= 1 && r < 12 -> if (Random.nextBoolean()) BAD_CRACKED else BAD_POP
                        r in 12..15 && game.slowFor <= 0f -> REWIND
                        r in 16..18 && game.magnetFor <= 0f -> MAGNET
                        r in 19..21 && lives < 3 -> HEART
                        r in 22..33 -> 2
                        else -> Random.nextInt(2)
                    }
                    drops.add(Drop(Random.nextFloat() * 0.84f + 0.08f, -radius, kind, h / fallTime))
                }

                // Move everything (half speed in slow motion; the magnet pulls the good things towards Chery),
                // and see what lands on the umbrella.
                val pace = if (game.slowFor > 0f) 0.5f else 1f
                val it = drops.iterator()
                while (it.hasNext()) {
                    val d = it.next()
                    d.y += d.speed * dt * pace
                    if (game.magnetFor > 0f && !isBad(d.kind) && !d.caught && !d.missed && d.y > h * 0.25f) {
                        d.x += (game.x - d.x) * min(1f, dt * 4f)
                    }
                    val dx = d.x * w - cx
                    if (!d.caught && !d.missed && abs(dx) < half + radius * 0.4f) {
                        val k = (dx / half).coerceIn(-1f, 1f)
                        val surface = top + (rim - top) * k * k
                        if (d.y + radius >= surface && d.y - radius < rim) {
                            d.caught = true
                            when {
                                isBad(d.kind) -> {
                                    // Caught the wrong thing: a life gone, and a warning buzz.
                                    warnBuzz(view)
                                    game.combo = 0
                                    say("Not on Safehouse!")
                                    lives--
                                    if (lives <= 0) end()
                                }
                                d.kind == REWIND -> {
                                    view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                                    game.slowFor = 5f; game.cheerFor = 0.7f
                                    announce("Rewind!", "Slow motion for 5 seconds"); say("Wheel it up!")
                                }
                                d.kind == MAGNET -> {
                                    view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                                    game.magnetFor = 5f; game.cheerFor = 0.7f
                                    announce("Magnet!", "The headphones pull it all in"); say("Pull up!")
                                }
                                d.kind == HEART -> {
                                    view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                                    lives = (lives + 1).coerceAtMost(3); game.cheerFor = 0.7f
                                    say("Extra life!")
                                }
                                else -> {
                                    view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
                                    bursts.add(Burst(d.x, d.y + radius * 0.5f))
                                    game.catches++; game.combo++
                                    val mult = when { game.combo >= 10 -> 3; game.combo >= 5 -> 2; else -> 1 }
                                    score += (if (d.kind == 2) 5 else 1) * mult
                                    game.level = (game.catches / 8).coerceAtMost(MAX_LEVEL)
                                    when {
                                        // At 100 points, then every 500: a shout-out to whoever is on air.
                                        score >= game.nextShout -> {
                                            val reached = game.nextShout
                                            game.nextShout = if (reached < 500) 500 else reached + 500
                                            game.cheerFor = 0.9f
                                            announce("Big up ${onAir ?: Config.STATION_NAME}!", "$reached points")
                                        }
                                        game.combo == 5 || game.combo == 10 -> {
                                            game.cheerFor = 0.7f; announce("x$mult", "Nice catch!")
                                        }
                                        d.kind == 2 -> { game.cheerFor = 0.7f; announce("+${5 * mult}", "Nice catch!") }
                                    }
                                    if (Random.nextInt(4) == 0) say(QUIPS.random())
                                }
                            }
                        }
                    }
                    if (!d.caught && !d.missed && d.y - radius > rim) {
                        d.missed = true
                        when {
                            d.kind == 0 || d.kind == 1 -> {
                                // A record or a note hit the floor: a life gone.
                                game.combo = 0
                                view.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                                say("Oops…")
                                lives--
                                if (lives <= 0) end()
                            }
                            d.kind == 2 -> game.combo = 0
                            isBad(d.kind) && Random.nextInt(3) == 0 -> say("Dodged!")
                        }
                    }
                    if (d.caught || d.y - radius > h) it.remove()
                }
                val bi = bursts.iterator()
                while (bi.hasNext()) { val b = bi.next(); b.left -= dt; if (b.left <= 0f) bi.remove() }
                game.cheerFor = (game.cheerFor - dt).coerceAtLeast(0f)
                game.bannerFor = (game.bannerFor - dt).coerceAtLeast(0f)
                game.quipFor = (game.quipFor - dt).coerceAtLeast(0f)
                game.slowFor = (game.slowFor - dt).coerceAtLeast(0f)
                game.magnetFor = (game.magnetFor - dt).coerceAtLeast(0f)
                frame++
            }
        }
    }

    // The (i) "How to play" bubble uses the same "Safehouse says…" bubbles as the rest of the app.
    val bubble = remember { BubbleState() }
    BubbleHost(bubble) {
        Column(Modifier.fillMaxSize()) {
            PageHeader(
                title = "Chery Poppins",
                leading = { BackArrowInBar("Close the game", onClose) },
                trailing = {
                    if (phase == Phase.PLAYING) {
                        Box(
                            Modifier.align(Alignment.CenterEnd).padding(end = 4.dp).size(48.dp).clip(CircleShape)
                                .clickable(onClickLabel = "Pause", role = Role.Button) { phase = Phase.PAUSED }
                                .semantics { contentDescription = "Pause the game" },
                            contentAlignment = Alignment.Center
                        ) { PauseBars(LavenderInk) }
                    }
                }
            )
            // Score, best and lives: three cards on the page border, one gap apart.
            Row(
                Modifier.fillMaxWidth().padding(horizontal = ScreenLayout.side()),
                horizontalArrangement = Arrangement.spacedBy(ScreenLayout.gap())
            ) {
                StatCard("SCORE", score.toString(), Modifier.weight(1f))
                StatCard("BEST", best.toString(), Modifier.weight(1f))
                StatCard("LIVES", "", Modifier.weight(1f)) { Hearts(lives) }
            }
            Spacer(Modifier.height(ScreenLayout.gap()))

            // The playing field.
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .onSizeChanged { field = it }
                    .pointerInput(Unit) {
                        awaitEachGesture {
                            val down = awaitFirstDown()
                            if (size.width > 0) game.target = (down.position.x / size.width).coerceIn(0.08f, 0.92f)
                            while (true) {
                                val event = awaitPointerEvent()
                                val p = event.changes.firstOrNull() ?: break
                                if (!p.pressed) break
                                if (size.width > 0) game.target = (p.position.x / size.width).coerceIn(0.08f, 0.92f)
                                p.consume()
                            }
                        }
                    }
            ) {
                // The wallpaper is dimmed behind the game (faded in at the top), so everything falling stands out.
                Canvas(Modifier.fillMaxSize()) {
                    val w = size.width; val h = size.height
                    val fade = 24.dp.toPx()
                    drawRect(
                        androidx.compose.ui.graphics.Brush.verticalGradient(
                            listOf(pal.background.copy(alpha = 0f), pal.background.copy(alpha = 0.55f)), startY = 0f, endY = fade
                        ),
                        size = Size(w, fade)
                    )
                    drawRect(pal.background.copy(alpha = 0.55f), topLeft = Offset(0f, fade), size = Size(w, h - fade))
                }
                // The big banners sit behind everything, in the top half (well clear of Chery), so they never hide
                // what's falling.
                if (game.bannerFor > 0f && phase == Phase.PLAYING) {
                    Column(
                        Modifier
                            .align(androidx.compose.ui.BiasAlignment(0f, -0.6f))
                            .padding(horizontal = ScreenLayout.side())
                            .clip(RoundedCornerShape(22.dp))
                            .background(pal.card.copy(alpha = 0.88f))
                            .border(EdgeWidth, pal.primary, RoundedCornerShape(22.dp))
                            .padding(horizontal = 20.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            game.banner, color = pal.live, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                            fontSize = if (game.banner.length > 8) 28.sp else 40.sp
                        )
                        Text(game.sub, color = pal.text, fontSize = AppType.Button, fontWeight = FontWeight.Bold)
                    }
                }
                Canvas(Modifier.fillMaxSize()) {
                    val tick = frame   // read here so the field is drawn again every frame
                    if (tick < 0) return@Canvas
                    val w = size.width; val h = size.height
                    val radius = dropRadius(w, game.level)
                    // Bad things pulse red (a steady red glow with Reduce animations).
                    val pulse = if (reduce) 0.6f else 0.5f + 0.5f * sin(tick * 0.25f)
                    for (d in drops) drawDrop(d, d.x * w, d.y, radius, pal.primary, pal.live, pal.card, pal.text, reduce, pulse)
                    // A quick gold sparkle where each catch landed.
                    if (!reduce) {
                        for (b in bursts) {
                            val t = 1f - b.left / 0.35f
                            for (i in 0 until 8) {
                                val ang = i * Math.PI / 4
                                val r1 = radius * (0.6f + t * 1.2f); val r2 = radius * (1.0f + t * 1.8f)
                                drawLine(
                                    pal.live.copy(alpha = 1f - t),
                                    Offset(b.x * w + (r1 * cos(ang)).toFloat(), b.y + (r1 * sin(ang)).toFloat()),
                                    Offset(b.x * w + (r2 * cos(ang)).toFloat(), b.y + (r2 * sin(ang)).toFloat()),
                                    strokeWidth = radius * 0.18f, cap = StrokeCap.Round
                                )
                            }
                        }
                    }
                    // Chery.
                    val lv = game.level
                    val cherH = h * (0.46f * 0.9f.pow(lv)).coerceAtLeast(0.22f)
                    val cherW = cherH * stand.width / stand.height
                    val img = if (game.cheerFor > 0f) cheer else stand
                    drawImage(
                        image = img,
                        srcOffset = IntOffset.Zero,
                        srcSize = IntSize(img.width, img.height),
                        dstOffset = IntOffset((game.x * w - cherW / 2f).roundToInt(), (h - cherH - 4f).roundToInt()),
                        dstSize = IntSize(cherW.roundToInt(), cherH.roundToInt())
                    )
                }
                // Chery's speech bubble, just above her umbrella.
                if (game.quipFor > 0f && phase == Phase.PLAYING && field.width > 0) {
                    val fw = field.width.toFloat(); val fh = field.height.toFloat()
                    val cherH = fh * (0.46f * 0.9f.pow(game.level)).coerceAtLeast(0.22f)
                    val bx = (game.x * fw).roundToInt(); val by = (fh - cherH - 4f).roundToInt()
                    Box(
                        Modifier.fillMaxSize().layout { m, c ->
                            val p = m.measure(androidx.compose.ui.unit.Constraints())
                            layout(c.maxWidth, c.maxHeight) {
                                p.place((bx - p.width / 2).coerceIn(0, (c.maxWidth - p.width).coerceAtLeast(0)), (by - p.height).coerceAtLeast(0))
                            }
                        }
                    ) {
                        Text(
                            game.quip, color = pal.text, fontSize = AppType.Pill, fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(pal.card)
                                .border(EdgeWidth, pal.primary, RoundedCornerShape(50))
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
                // A power-up running: a small pill with the seconds left.
                val power = when {
                    game.slowFor > 0f -> "Slow motion ${game.slowFor.toInt() + 1}s"
                    game.magnetFor > 0f -> "Magnet ${game.magnetFor.toInt() + 1}s"
                    else -> null
                }
                if (power != null && phase == Phase.PLAYING) {
                    Text(
                        power, color = pal.background, fontSize = AppType.Pill, fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(start = ScreenLayout.side())
                            .clip(RoundedCornerShape(50))
                            .background(pal.live)
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                if (phase == Phase.PLAYING && frame < 120) {
                    Text(
                        "Slide to move Chery",
                        color = pal.textDim, fontSize = AppType.Sub,
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp)
                    )
                }
                when (phase) {
                    Phase.READY -> GamePanel {
                        Image(
                            painter = painterResource(R.drawable.chery_logo),
                            contentDescription = "Chery Poppins",
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(ScreenLayout.gap()))
                        Text(
                            "Catch the music on Chery's umbrella before it hits the floor! Slide your finger to move her.",
                            color = pal.text, fontSize = AppType.ShowName, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(ScreenLayout.gap()))
                        HowToPlayLabel(bubble)
                        Spacer(Modifier.height(ScreenLayout.gap() * 2))
                        SetupButton("Play", onClick = { start() }, modifier = Modifier.fillMaxWidth())
                    }
                    Phase.PAUSED -> GamePanel {
                        Text("Paused", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(ScreenLayout.gap()))
                        HowToPlayLabel(bubble)
                        Spacer(Modifier.height(ScreenLayout.gap() * 2))
                        SetupButton("Carry on", onClick = { phase = Phase.PLAYING }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(ScreenLayout.gap()))
                        BubbleButton("Close the game", onClick = onClose, modifier = Modifier.fillMaxWidth())
                    }
                    Phase.OVER -> GamePanel {
                        Text("Game over", color = pal.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(ScreenLayout.gap()))
                        Text("$score", color = pal.live, fontSize = 48.sp, fontWeight = FontWeight.Bold)
                        Text(if (newBest) "New best score!" else "Best: $best", color = pal.textDim, fontSize = AppType.ShowName)
                        Spacer(Modifier.height(ScreenLayout.gap() * 2))
                        SetupButton("Play again", onClick = { start() }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(ScreenLayout.gap()))
                        BubbleButton("Share my score", onClick = {
                            ShareCard.share(
                                ctx,
                                "I scored $score on Chery Poppins, the game hidden in the ${Config.STATION_NAME} app. Can you find it and beat me? ${Config.SHARE_URL}",
                                ShareCard.Spec(name = "Chery Poppins", line = "", pill = null, gameScore = score)
                            )
                        }, modifier = Modifier.fillMaxWidth())
                    }
                    Phase.PLAYING -> {}
                }
            }
        }
    }
}

/**
 * "How to play" with its (i), on the start and pause cards. The (i) opens the game's guide in a "Safehouse says…"
 * bubble, the same as every other (i) in the app.
 */
@Composable
private fun HowToPlayLabel(bubble: BubbleState) {
    Text(
        text = androidx.compose.ui.text.buildAnnotatedString {
            append("How to play")
            appendInlineContent("info", "(i)")
        },
        inlineContent = mapOf(
            "info" to androidx.compose.foundation.text.InlineTextContent(
                androidx.compose.ui.text.Placeholder(
                    width = 26.sp, height = 18.sp,
                    placeholderVerticalAlign = androidx.compose.ui.text.PlaceholderVerticalAlign.AboveBaseline
                )
            ) { InfoInline("how to play Chery Poppins", bubble) { GameGuide() } }
        ),
        color = ThemeState.current.text, fontSize = AppType.RowLabel, fontWeight = FontWeight.Bold
    )
}

/**
 * Everything that falls in the game, in the order the guide lists it: the picture, its name and what it does.
 * KEEP THIS UP TO DATE: whenever the game changes (points, lives, power-ups, new things falling), change the
 * guide here and in GameGuide() in the same build.
 */
private val GUIDE_ITEMS = listOf(
    Triple(0, "Record", "1 point. Don't let it hit the floor, or you lose a heart."),
    Triple(1, "Music note", "1 point. Don't let it hit the floor, or you lose a heart."),
    Triple(2, "Gold star", "5 points. Missing one doesn't cost a heart."),
    Triple(REWIND, "Gold rewind record", "Slow motion for 5 seconds."),
    Triple(MAGNET, "Gold headphones", "A magnet for 5 seconds: the good things are pulled towards Chery."),
    Triple(HEART, "Purple heart", "An extra heart (up to 3). It only falls when you've lost one."),
    Triple(BAD_CRACKED, "Cracked record (glows red)", "Bad! Catch it and you lose a heart, so let it fall."),
    Triple(BAD_POP, "Cheesy pop CD (glows red)", "Bad! Catch it and you lose a heart, so let it fall.")
)

/** The guide inside the bubble, in plain English. Kept in step with the game (see GUIDE_ITEMS). */
@Composable
private fun androidx.compose.foundation.layout.ColumnScope.GameGuide() {
    val pal = ThemeState.current
    BubbleText("Slide your finger left and right to move Chery. Catch the music on her umbrella before it hits the floor.")
    BubbleText("You have 3 hearts. You lose one when a record or a note hits the floor, or when you catch something bad. No hearts left means game over.")
    BubbleText("Catch 5 in a row for double points, and 10 in a row for triple points. A miss or a bad catch starts the count again.")
    BubbleText("Every 8 catches it gets harder: things fall faster and get smaller, and so does Chery. The bad things start falling after your first 8 catches.")
    BubbleText("At 100 points, and then every 500, Chery gives a shout-out to whoever is on air.")
    Text(
        "What falls",
        color = pal.primary, fontSize = AppType.RowLabel, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 14.dp)
    )
    for ((kind, name, what) in GUIDE_ITEMS) {
        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Canvas(Modifier.size(36.dp)) {
                drawDrop(
                    Drop(0f, 0f, kind, 0f), center.x, center.y, size.minDimension * 0.3f,
                    pal.primary, pal.live, pal.card, pal.text, reduce = true, pulse = 0.6f
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, color = pal.text, fontSize = AppType.Pill, fontWeight = FontWeight.Bold)
                Text(what, color = pal.textDim, fontSize = AppType.Sub)
            }
        }
    }
    BubbleText("To pause, tap the two bars at the top. The game also pauses by itself if you leave the app.", Modifier.padding(top = 8.dp))
}

/** A card in the middle of the field for the start, pause and game-over messages. */
@Composable
private fun GamePanel(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(Modifier.fillMaxSize().background(ThemeState.current.scrim), contentAlignment = Alignment.Center) {
        Column(
            Modifier
                .padding(horizontal = ScreenLayout.side())
                .fillMaxWidth()
                .lift(shape)
                .clip(shape)
                .background(ThemeState.current.card)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            content = content
        )
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier, custom: (@Composable () -> Unit)? = null) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier
            .lift(shape)
            .clip(shape)
            .background(CardSurface)
            .heightIn(min = 60.dp)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(label, color = ThemeState.current.primary, fontSize = AppType.CardTime, fontWeight = FontWeight.Bold)
        if (custom != null) custom() else Text(value, color = ThemeState.current.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/**
 * The lives: three hearts, always the Purple theme's purple whatever theme is chosen (drawn, not the ♥ character,
 * which some phones turn into a red emoji). A lost life leaves an outline.
 */
@Composable
private fun Hearts(lives: Int) {
    val purple = Themes.PURPLE.primary
    Canvas(Modifier.padding(top = 4.dp).width(72.dp).height(20.dp)) {
        val s = size.height
        for (i in 0 until 3) {
            val left = i * (size.width / 3f) + (size.width / 3f - s) / 2f
            val heart = Path().apply {
                moveTo(left + s / 2f, s * 0.95f)
                cubicTo(left - s * 0.15f, s * 0.55f, left + s * 0.05f, s * 0.02f, left + s / 2f, s * 0.28f)
                cubicTo(left + s * 0.95f, s * 0.02f, left + s * 1.15f, s * 0.55f, left + s / 2f, s * 0.95f)
                close()
            }
            if (i < lives) drawPath(heart, purple) else drawPath(heart, purple.copy(alpha = 0.5f), style = Stroke(s * 0.09f))
        }
    }
}

/** The back arrow at the left of a page title pill. */
@Composable
private fun androidx.compose.foundation.layout.BoxScope.BackArrowInBar(label: String, onBack: () -> Unit) {
    Box(
        Modifier.align(Alignment.CenterStart).padding(start = 4.dp).size(48.dp).clip(CircleShape)
            .clickable(onClickLabel = label, role = Role.Button, onClick = onBack),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(R.drawable.ic_arrow_back), contentDescription = label, tint = LavenderInk, modifier = Modifier.size(24.dp))
    }
}

@Composable
private fun PauseBars(color: Color) {
    Canvas(Modifier.size(20.dp)) {
        val bw = size.width * 0.3f
        drawRoundRect(color, Offset(size.width * 0.1f, 0f), Size(bw, size.height), androidx.compose.ui.geometry.CornerRadius(3f, 3f))
        drawRoundRect(color, Offset(size.width * 0.6f, 0f), Size(bw, size.height), androidx.compose.ui.geometry.CornerRadius(3f, 3f))
    }
}

/** A record, a note or a gold star, with a soft trail above it. */
private fun DrawScope.drawDrop(d: Drop, x: Float, y: Float, r: Float, main: Color, gold: Color, dark: Color, light: Color, reduce: Boolean, pulse: Float) {
    val purple = Themes.PURPLE.primary
    val col = when (d.kind) {
        2, REWIND, MAGNET -> gold
        HEART -> purple
        BAD_CRACKED, BAD_POP -> WarnRed
        else -> main
    }
    if (!reduce) {
        for (i in 1..6) {
            drawLine(col.copy(alpha = 0.22f * (1f - i / 7f)), Offset(x, y - r - (i - 1) * r * 0.5f), Offset(x, y - r - i * r * 0.5f), strokeWidth = r * 0.35f, cap = StrokeCap.Round)
        }
    }
    val a = if (d.missed) 0.35f else 1f
    if (isBad(d.kind)) {
        // A red warning glow behind it, and a red ring round it.
        drawCircle(
            androidx.compose.ui.graphics.Brush.radialGradient(
                listOf(WarnRed.copy(alpha = (0.35f + 0.4f * pulse) * a), WarnRed.copy(alpha = 0f)),
                center = Offset(x, y), radius = r * (1.6f + 0.4f * pulse)
            ),
            r * (1.6f + 0.4f * pulse), Offset(x, y)
        )
    }
    when (d.kind) {
        0 -> {
            drawCircle(dark.copy(alpha = a), r, Offset(x, y))
            drawCircle(col.copy(alpha = a), r, Offset(x, y), style = Stroke(r * 0.16f))
            drawCircle(col.copy(alpha = 0.45f * a), r * 0.7f, Offset(x, y), style = Stroke(r * 0.05f))
            drawCircle(col.copy(alpha = a), r * 0.36f, Offset(x, y))
            drawCircle(dark.copy(alpha = a), r * 0.08f, Offset(x, y))
        }
        1 -> {
            val head = r * 0.42f
            drawCircle(col.copy(alpha = a), head, Offset(x - r * 0.25f, y + r * 0.45f))
            drawLine(col.copy(alpha = a), Offset(x - r * 0.25f + head * 0.85f, y + r * 0.45f), Offset(x - r * 0.25f + head * 0.85f, y - r * 0.85f), strokeWidth = r * 0.16f)
            val flag = Path().apply {
                moveTo(x - r * 0.25f + head * 0.85f, y - r * 0.85f)
                lineTo(x + r * 0.65f, y - r * 0.45f)
                lineTo(x + r * 0.6f, y - r * 0.1f)
                lineTo(x - r * 0.25f + head * 0.85f, y - r * 0.45f)
                close()
            }
            drawPath(flag, col.copy(alpha = a))
        }
        BAD_CRACKED -> {
            // A record with a crack right across it.
            drawCircle(dark.copy(alpha = a), r, Offset(x, y))
            drawCircle(light.copy(alpha = 0.6f * a), r, Offset(x, y), style = Stroke(r * 0.12f))
            drawCircle(light.copy(alpha = 0.6f * a), r * 0.3f, Offset(x, y))
            val crack = Path().apply {
                moveTo(x - r * 0.9f, y - r * 0.3f); lineTo(x - r * 0.35f, y + r * 0.1f); lineTo(x - r * 0.05f, y - r * 0.25f)
                lineTo(x + r * 0.35f, y + r * 0.2f); lineTo(x + r * 0.9f, y - r * 0.05f)
            }
            drawPath(crack, light.copy(alpha = a), style = Stroke(r * 0.14f, cap = StrokeCap.Round))
            drawCircle(WarnRed.copy(alpha = (0.6f + 0.4f * pulse) * a), r, Offset(x, y), style = Stroke(r * 0.14f))
        }
        BAD_POP -> {
            // A shiny pop CD with a cross on it.
            drawCircle(light.copy(alpha = 0.85f * a), r, Offset(x, y))
            drawCircle(main.copy(alpha = 0.35f * a), r * 0.75f, Offset(x, y), style = Stroke(r * 0.08f))
            drawCircle(dark.copy(alpha = a), r * 0.3f, Offset(x, y))
            drawCircle(light.copy(alpha = a), r * 0.12f, Offset(x, y))
            drawLine(dark.copy(alpha = a), Offset(x - r * 0.55f, y - r * 0.55f), Offset(x + r * 0.55f, y + r * 0.55f), strokeWidth = r * 0.16f, cap = StrokeCap.Round)
            drawLine(dark.copy(alpha = a), Offset(x + r * 0.55f, y - r * 0.55f), Offset(x - r * 0.55f, y + r * 0.55f), strokeWidth = r * 0.16f, cap = StrokeCap.Round)
            drawCircle(WarnRed.copy(alpha = (0.6f + 0.4f * pulse) * a), r, Offset(x, y), style = Stroke(r * 0.14f))
        }
        REWIND -> {
            // A gold record with a rewind arrow.
            drawCircle(col.copy(alpha = a), r * 1.1f, Offset(x, y))
            drawCircle(dark.copy(alpha = a), r * 0.45f, Offset(x, y))
            drawArc(col.copy(alpha = a), 200f, 250f, false, Offset(x - r * 0.3f, y - r * 0.3f), Size(r * 0.6f, r * 0.6f), style = Stroke(r * 0.1f))
            val head = Path().apply {
                moveTo(x - r * 0.38f, y - r * 0.18f); lineTo(x - r * 0.2f, y - r * 0.38f); lineTo(x - r * 0.12f, y - r * 0.1f); close()
            }
            drawPath(head, col.copy(alpha = a))
        }
        MAGNET -> {
            // Gold headphones.
            drawArc(col.copy(alpha = a), 180f, 180f, false, Offset(x - r * 0.9f, y - r * 0.9f), Size(r * 1.8f, r * 1.8f), style = Stroke(r * 0.22f))
            drawRoundRect(col.copy(alpha = a), Offset(x - r * 1.05f, y - r * 0.1f), Size(r * 0.55f, r * 0.85f), androidx.compose.ui.geometry.CornerRadius(r * 0.2f))
            drawRoundRect(col.copy(alpha = a), Offset(x + r * 0.5f, y - r * 0.1f), Size(r * 0.55f, r * 0.85f), androidx.compose.ui.geometry.CornerRadius(r * 0.2f))
        }
        HEART -> {
            val s = r * 2.1f; val left = x - s / 2f; val topY = y - s / 2f
            val heart = Path().apply {
                moveTo(left + s / 2f, topY + s * 0.95f)
                cubicTo(left - s * 0.15f, topY + s * 0.55f, left + s * 0.05f, topY + s * 0.02f, left + s / 2f, topY + s * 0.28f)
                cubicTo(left + s * 0.95f, topY + s * 0.02f, left + s * 1.15f, topY + s * 0.55f, left + s / 2f, topY + s * 0.95f)
                close()
            }
            drawPath(heart, col.copy(alpha = a))
        }
        else -> {
            val star = Path()
            for (i in 0 until 10) {
                val ang = -Math.PI / 2 + i * Math.PI / 5
                val rr = if (i % 2 == 0) r * 1.1f else r * 0.48f
                val px = x + (rr * cos(ang)).toFloat(); val py = y + (rr * sin(ang)).toFloat()
                if (i == 0) star.moveTo(px, py) else star.lineTo(px, py)
            }
            star.close()
            drawPath(star, col.copy(alpha = a))
        }
    }
}
