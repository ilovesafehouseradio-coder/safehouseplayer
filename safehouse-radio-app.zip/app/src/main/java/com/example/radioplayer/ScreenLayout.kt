package com.example.radioplayer

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * The app's layout rules, designed on a 2026 flagship (412 dp wide) and shrunk in proportion on smaller phones,
 * so borders and gaps always stay equal to each other, just smaller:
 *  - one side border for everything on a page (cards, pills, text, bars, button rows), the same left and right;
 *  - one gap between stacked elements, so each element sits centred between the one above and the one below;
 *  - elements centred across the page; the writing inside cards stays left-aligned.
 * Buttons keep their full 48 dp tap areas and text keeps the phone's text size whatever the screen.
 */
object ScreenLayout {
    private const val DESIGN_WIDTH = 412f

    /** The one side border: 28 dp on a flagship. */
    @Composable
    fun side(): Dp = (LocalConfiguration.current.screenWidthDp * 28f / DESIGN_WIDTH).coerceIn(20f, 32f).dp

    /** The one gap between stacked elements: 11 dp on a flagship. */
    @Composable
    fun gap(): Dp = (LocalConfiguration.current.screenWidthDp * 11f / DESIGN_WIDTH).coerceIn(8f, 13f).dp

    /** How far in from the visible edge a 48 dp icon button's picture sits (so the picture, not the tap area, lines up). */
    val iconInset: Dp = 11.dp
}
