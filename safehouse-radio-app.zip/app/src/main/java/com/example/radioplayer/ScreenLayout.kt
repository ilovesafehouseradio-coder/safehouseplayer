package com.example.radioplayer

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * The app's layout rules, designed on a 2026 flagship (412 dp wide) and shrunk in proportion on smaller phones,
 * so borders and gaps always stay equal to each other, just smaller:
 *  - one side border for everything on a page (cards, pills, text, bars, button rows), the same left and right;
 *  - one gap between stacked elements, so each element sits centred between the one above and the one below;
 *  - elements centred across the page; the writing inside cards stays left-aligned.
 *  - cards with a picture on the left all use the same inside padding, picture size and picture-to-writing gap
 *    (cardPad, cardPicture, pictureGap below), so the pictures and the writing sit in one straight line all the
 *    way down a page, whatever section a card is in. Anything extra on a card (a coloured strip, a border, a tag)
 *    goes inside that padding or on top of the card: it never pushes the picture or the writing out of line.
 *    Every new card with a picture follows this rule.
 * Buttons keep their full 48 dp tap areas and text keeps the phone's text size whatever the screen.
 */
object ScreenLayout {
    private const val DESIGN_WIDTH = 412f

    /** The one side border: 28 dp on a flagship. */
    @Composable
    fun side(): Dp = (LocalConfiguration.current.screenWidthDp * 28f / DESIGN_WIDTH).coerceIn(20f, 32f).dp

    /** The one gap between stacked elements: 11 dp on a flagship. */
    @Composable
    fun gap(): Dp = (LocalConfiguration.current.screenWidthDp * 11f / DESIGN_WIDTH).coerceIn(8f, 13f).dp

    /** The padding inside every card, all round: 16 dp on a flagship (14 dp on a 360 dp phone). */
    @Composable
    fun cardPad(): Dp = (LocalConfiguration.current.screenWidthDp * 16f / DESIGN_WIDTH).coerceIn(12f, 18f).dp

    /** The round picture on the left of a card (a DJ's photo, or the logo): 64 dp on a flagship (56 dp on a 360 dp phone). */
    @Composable
    fun cardPicture(): Dp = (LocalConfiguration.current.screenWidthDp * 64f / DESIGN_WIDTH).coerceIn(48f, 68f).dp

    /** The bigger square picture on a featured card (the On Air card): 82 dp on a flagship (72 dp on a 360 dp phone). */
    @Composable
    fun featuredPicture(): Dp = (LocalConfiguration.current.screenWidthDp * 82f / DESIGN_WIDTH).coerceIn(64f, 88f).dp

    /** The gap between a card's picture and its writing: 14 dp on a flagship (12 dp on a 360 dp phone). */
    @Composable
    fun pictureGap(): Dp = (LocalConfiguration.current.screenWidthDp * 14f / DESIGN_WIDTH).coerceIn(10f, 16f).dp

    /** How far in from the visible edge a 48 dp icon button's picture sits (so the picture, not the tap area, lines up). */
    val iconInset: Dp = 11.dp
}
