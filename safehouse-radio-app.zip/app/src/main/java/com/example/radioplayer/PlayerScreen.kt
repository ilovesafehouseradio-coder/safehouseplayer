package com.example.radioplayer

import android.content.Intent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import java.nio.ByteBuffer
import kotlin.math.sin
import kotlin.math.cos
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import android.text.format.DateFormat
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.width
import androidx.compose.ui.semantics.Role
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

// ---------------------------------------------------------------------------
// Radio tab
// ---------------------------------------------------------------------------

@Composable
fun PlayerScreen(
    controller: MediaController?,
    upcoming: List<NextUp> = emptyList(),
    djs: List<Dj> = emptyList(),
    shows: List<Show> = emptyList(),
    onOpenDj: (Dj) -> Unit = {},
    onOpenNext: (NextUp) -> Unit = {}
) {
    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(false) }
    var hasError by remember { mutableStateOf(false) }
    var icyTitle by remember { mutableStateOf<String?>(null) }   // title sent inside the audio stream
    var polledTitle by remember { mutableStateOf<String?>(null) } // title from the server status page
    var polledBlank by remember { mutableStateOf(false) }          // the status page answered, but names nobody
    var started by remember { mutableStateOf(false) }             // has playback been started yet?

    DisposableEffect(controller) {
        val player = controller
        if (player == null) {
            onDispose { }
        } else {
            isPlaying = player.isPlaying
            isBuffering = player.playbackState == Player.STATE_BUFFERING
            started = player.playbackState != Player.STATE_IDLE
            icyTitle = player.mediaMetadata.title?.toString()
                ?.takeIf { it != Config.STATION_NAME }

            val listener = object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying_: Boolean) {
                    isPlaying = isPlaying_
                    if (isPlaying_) hasError = false
                }

                override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                    // Paused (by the listener, or after giving up reconnecting): no error to show.
                    if (!playWhenReady) hasError = false
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    isBuffering = playbackState == Player.STATE_BUFFERING
                    started = playbackState != Player.STATE_IDLE
                }

                override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                    // Live streams usually send the current show as the title.
                    icyTitle = mediaMetadata.title?.toString()
                        ?.takeIf { it != Config.STATION_NAME }
                }

                override fun onPlayerError(error: PlaybackException) {
                    hasError = true
                }
            }
            player.addListener(listener)
            onDispose { player.removeListener(listener) }
        }
    }

    // Ask the server what's on air now, and again every 15 seconds while this screen is open.
    LaunchedEffect(Unit) {
        while (true) {
            val title = withContext(Dispatchers.IO) { fetchNowPlayingTitle() }
            if (title != null) {
                polledTitle = title.ifEmpty { null }
                polledBlank = title.isEmpty()
            }
            delay(15_000)
        }
    }
    // A live DJ who sends no title at all: "" (the station's own fallback is shown), not null (not known yet).
    val nowPlaying = polledTitle ?: icyTitle ?: if (polledBlank) "" else null

    // Fetch the artwork whenever the show changes (and each time this screen opens), even before
    // play is pressed, so the opening screen shows what's on air. It stays null (so the round logo
    // shows) while loading, if it can't be fetched, or if the station sent its plain default picture.
    var artBytes by remember { mutableStateOf<ByteArray?>(null) }
    val artContext = LocalContext.current.applicationContext
    LaunchedEffect(nowPlaying) {
        if (nowPlaying == null) return@LaunchedEffect
        // The station's own picture, else the one we carry for a known show, else null (the logo shows).
        artBytes = LiveArt.get(nowPlaying) ?: withContext(Dispatchers.Default) { ShowArt.bytes(artContext, nowPlaying) }
    }

    // The title holds the DJ name and the show name: show them on two lines. A placeholder name like
    // "Syndicast" is never shown: it becomes our DJ's name (found from the show), or the station's name.
    // A title too poor to show, or none at all, is replaced by the station's own name and "All Day Every Day":
    // the calendar is only a plan, so it never guesses who is on.
    val shown = remember(nowPlaying, djs, shows, upcoming) { StreamNames.resolve(nowPlaying, djs, shows) }
    val djName = shown.dj
    val showName = shown.show

    // A short, clean message that reads well on every app (WhatsApp, Facebook, X, Instagram DMs...):
    // what is playing, where to listen, and one hashtag.
    val shareText = if (djName != null) {
        val line = when {
            shown.generic -> showName ?: Config.SLOGAN
            showName != null -> "$djName – $showName"
            else -> djName
        }
        "🎧 Now playing on ${Config.STATION_NAME}\n$line\n\nListen live: ${Config.SHARE_URL}\n#SafehouseRadio"
    } else {
        "🎧 ${Config.STATION_NAME}\n${Config.SLOGAN}\n\nListen live: ${Config.SHARE_URL}\n#SafehouseRadio"
    }

    // The next live show with a DJ named (not the one already on air): tapping it opens that DJ's page.
    val liveKey = (shown.match?.name ?: djName)?.let { DjMatch.key(it) }
    val nextUp = upcoming.firstOrNull { liveKey == null || !DjMatch.djMatches(it.dj, liveKey) }

    // How long the show on air has left, from the calendar (the same answer as the On Air card). Nothing
    // shows when the calendar has no end time for it.
    var clock by remember { mutableStateOf(Instant.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            clock = Instant.now()
        }
    }
    val liveWindow = remember(nowPlaying, shows, djs, upcoming) {
        val feed = nowPlaying?.let { LiveStatus(it, false) }
        ScheduleLogic.onAirDisplay(ScheduleLogic.snapshot(shows, Instant.now()).onAir, feed, djs)
    }
    val timeLeft = TimeLeft.text(liveWindow?.end, Heard.at(clock))
    // How far through the show we are (0 to 1), for the thin bar; null when the calendar has no times for it.
    val showFraction: Float? = run {
        val start = liveWindow?.start
        val end = liveWindow?.end
        if (start == null || end == null || timeLeft == null) {
            null
        } else {
            val total = java.time.Duration.between(start, end).toMillis().coerceAtLeast(1L)
            (java.time.Duration.between(start, Heard.at(clock)).toMillis().toFloat() / total.toFloat()).coerceIn(0f, 1f)
        }
    }

    // Keeps the rewind / fast-forward buttons and "behind live" up to date while this screen is on show.
    val appVisible by rememberAppVisible()
    LaunchedEffect(appVisible) {
        while (appVisible) {
            TimeShift.refresh()
            delay(1000)
        }
    }

    // A status message replaces the "Now Playing" block when there's nothing to show yet.
    val status: String? = when {
        hasError -> "Connection lost. Reconnecting… (or tap play)"
        isBuffering && !isPlaying -> "Connecting…"
        isPlaying -> if (djName == null) "Live now" else null
        else -> "Tap to listen live"
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // The "Now Playing" text block grows with the phone's text-size setting, so big text isn't clipped.
        // 102 dp holds "Now Playing:", a big name and a one-line show title at normal text size.
        val textBlockHeight = (102 * LocalDensity.current.fontScale.coerceIn(1f, 1.6f)).dp
        // The artwork takes whatever height is left once everything else has its room (see below).
        val screenWidth = maxWidth

        Column(Modifier.fillMaxSize()) {
            // Top: the page title, in the same style as every other page.
            // The Chromecast button (only shows when a Cast device is nearby) sits inside it, at the right.
            PageHeader(Config.STATION_NAME) {
                CastButton(Modifier.align(Alignment.CenterEnd).padding(end = 6.dp), onLavender = true)
            }

            // The next live show, just under the title: a little narrower than the title bar, with
            // space around it, so the station stays the main thing on the page.
            if (nextUp != null) {
                Box(Modifier.fillMaxWidth().padding(start = 40.dp, end = 40.dp, top = 8.dp, bottom = 4.dp)) {
                    NextUpLine(nextUp) { onOpenNext(nextUp) }
                }
            }

        Column(
            modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.Start
        ) {
            // The full round logo is shown when the app first opens (before play is pressed),
            // and whenever there is no DJ artwork. Once playing, the current DJ's picture replaces it.
            // The "?t=" part makes sure we never get a stale picture.
            // This box takes all the height the other parts leave, and the picture is as big as fits in it
            // (never wider than most of the screen), so it is always the biggest it can be.
            BoxWithConstraints(
                Modifier.fillMaxWidth().weight(1f).padding(top = 8.dp, bottom = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                val artSize = minOf(screenWidth * 0.82f, maxHeight).coerceAtLeast(110.dp)
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(artBytes?.let { ByteBuffer.wrap(it) })
                        .crossfade(true)
                        .diskCachePolicy(CachePolicy.DISABLED)
                        .memoryCachePolicy(CachePolicy.DISABLED)
                        .build(),
                    contentDescription = Config.STATION_NAME,
                    placeholder = painterResource(R.drawable.station_logo_tile),
                    error = painterResource(R.drawable.station_logo_tile),
                    fallback = painterResource(R.drawable.station_logo_tile),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(artSize)
                        .shadow(20.dp, RoundedCornerShape(24.dp))
                        .clip(RoundedCornerShape(24.dp))
                )
            }

            Spacer(Modifier.height(10.dp))

            // Text sits on the left, like a proper music app.
            // Fixed height (long names are cut short with "…") so nothing jumps when the text changes.
            Column(
                modifier = Modifier.fillMaxWidth().height(textBlockHeight),
                horizontalAlignment = Alignment.Start
            ) {
                if (status != null) {
                    // The invitation to press play is big, bold and centred; other messages are centred too.
                    val invite = !isPlaying && !isBuffering && !hasError
                    ShadowText(
                        status,
                        fontSize = if (invite) 28 else 18,
                        weight = if (invite) FontWeight.Bold else FontWeight.Normal,
                        alpha = if (invite) 1f else 0.85f,
                        topPadding = if (invite) 8 else 0,
                        align = TextAlign.Center
                    )
                } else {
                    Box(Modifier.fillMaxWidth()) {
                        ShadowText("Now Playing:", fontSize = 16, weight = FontWeight.Light, alpha = 0.75f)
                        // "Behind live" when the listener has gone back; otherwise how long the show has left.
                        val rightLabel = Heard.behindText() ?: timeLeft
                        if (rightLabel != null) {
                            ShadowText(
                                rightLabel, fontSize = 14, weight = FontWeight.Medium, alpha = 0.85f,
                                topPadding = 2, maxLines = 1, align = TextAlign.End
                            )
                        }
                        // A thin bar of how far through the show we are, in the small gap under this line
                        // (it is drawn there, so nothing else moves).
                        if (showFraction != null) {
                            Box(
                                Modifier
                                    .align(Alignment.BottomStart)
                                    .offset(y = 4.dp)
                                    .fillMaxWidth()
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(MaterialTheme.colorScheme.onBackground.copy(alpha = 0.22f))
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(showFraction)
                                        .fillMaxHeight()
                                        .background(MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f))
                                )
                            }
                        }
                    }
                    if (djName != null) {
                        // A title with no separate show name (e.g. "Federico Scavo Radio Show 097")
                        // is shown slightly smaller on up to two lines, so it isn't cut short.
                        val single = showName == null
                        // If this DJ has a page, the name is a button (the little › says so).
                        val page = shown.match
                        val hasPage = page != null
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .then(
                                    if (hasPage) {
                                        Modifier.clickable(onClickLabel = "Open $djName's page", role = Role.Button) {
                                            if (page != null) onOpenDj(page)
                                        }
                                    } else {
                                        Modifier
                                    }
                                )
                        ) {
                            ShadowText(
                                if (hasPage) "$djName  ›" else djName,
                                fontSize = if (single) 22 else 28, weight = FontWeight.Bold,
                                alpha = 1f, topPadding = 8, maxLines = if (single) 2 else 1,
                                scrollIfLong = !single
                            )
                        }
                    }
                    if (showName != null) {
                        ShadowText(
                            showName, fontSize = 16, weight = FontWeight.Normal, alpha = 0.95f,
                            topPadding = 4, maxLines = 1, scrollIfLong = true
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Play / pause button, with the sleep timer on the left and share on the right
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                // Sleep and Share: each icon-and-word pair is centred on the play button's centre line, and they sit
                // a little further out so there is room between them and the rewind / fast-forward circles.
                SleepTimerButton(Modifier.align(Alignment.CenterStart).offset(x = (-17).dp))
                ShareButton(
                    text = shareText,
                    modifier = Modifier.align(Alignment.CenterEnd).offset(x = 17.dp)
                )
                // The rings ripple out from the button while the stream is playing: a quick
                // visual sign that it's live, whatever the volume is set to.
                // Waiting to be pressed: a lighter lilac with a soft glow to draw the eye.
                // Playing: the standard lilac with the rings. Connecting: standard lilac, no glow.
                val waiting = !isPlaying && !isBuffering
                // Room for the rings between play and the circles (a little less on a narrow phone).
                val ringRoom = if (LocalConfiguration.current.screenWidthDp >= 350) 28.dp else 20.dp
                Row(
                    horizontalArrangement = Arrangement.spacedBy(ringRoom),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                SkipButton(forward = false, enabled = TimeShift.canRewind) { TimeShift.skip(-TimeShift.STEP_SECONDS) }
                Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                    if (isPlaying) {
                        PulseRings(MaterialTheme.colorScheme.primary, Modifier.matchParentSize())
                    }
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .drawBehind {
                                if (waiting) {
                                    for (i in 1..4) {
                                        drawCircle(
                                            color = Color(0xFFC9C4DA).copy(alpha = 0.08f),
                                            radius = size.minDimension / 2f + (5 - i) * 2.5.dp.toPx()
                                        )
                                    }
                                }
                            }
                            .lift(CircleShape, tappable = true)
                            .clip(CircleShape)
                            .background(if (waiting) Color(0xFFC9C4DA) else MaterialTheme.colorScheme.primary)
                            .semantics {
                                contentDescription = if (isPlaying || isBuffering) "Pause" else "Play"
                            }
                            .clickable(enabled = controller != null) {
                                controller?.let { togglePlayback(it) }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isBuffering && !isPlaying) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(36.dp)
                            )
                        } else {
                            PlayPauseIcon(isPlaying, MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                }
                SkipButton(forward = true, enabled = TimeShift.canForward) { TimeShift.skip(TimeShift.STEP_SECONDS) }
                }
            }

            Spacer(Modifier.height(28.dp))
        }
        }
    }
}

/**
 * The small round rewind / fast-forward buttons either side of play: a round arrow with "10" in it (each tap goes 10
 * seconds). Greyed out and not pressable when there is nowhere to go (nothing kept yet, or already as near live as
 * the buffer allows).
 */
@Composable
private fun SkipButton(forward: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val tint = MaterialTheme.colorScheme.onBackground.copy(alpha = if (enabled) 0.95f else 0.35f)
    Box(
        modifier = Modifier
            .size(48.dp)
            .lift(CircleShape, tappable = enabled)
            .clip(CircleShape)
            .background(CardSurface)
            .semantics {
                contentDescription = if (forward) "Forward 10 seconds" else "Back 10 seconds"
            }
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(34.dp)) {
            // Back is drawn as the mirror image of forward.
            if (forward) {
                scale(scaleX = -1f, scaleY = 1f, pivot = center) { drawReplayArrow(tint) }
            } else {
                drawReplayArrow(tint)
            }
        }
        Text(
            text = "10",
            color = tint,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            style = tightStyle(11.sp)
        )
    }
}

/** A round arrow (anticlockwise, with the head at the top right), as in a "replay" button. */
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawReplayArrow(color: Color) {
    val radius = 11.dp.toPx()
    val stroke = 2.dp.toPx()
    drawArc(
        color = color,
        startAngle = 240f,
        sweepAngle = -300f,
        useCenter = false,
        topLeft = Offset(center.x - radius, center.y - radius),
        size = Size(radius * 2f, radius * 2f),
        style = Stroke(width = stroke, cap = StrokeCap.Round)
    )
    // The arrow head at the end of the arc (300 degrees), pointing the way the arc is going (anticlockwise).
    val end = Math.toRadians(300.0)
    val ex = center.x + radius * cos(end).toFloat()
    val ey = center.y + radius * sin(end).toFloat()
    val dx = sin(end).toFloat()
    val dy = -cos(end).toFloat()
    val nx = -dy
    val ny = dx
    val length = 5.dp.toPx()
    val half = 4.dp.toPx()
    val head = Path().apply {
        moveTo(ex + dx * length, ey + dy * length)
        lineTo(ex + nx * half, ey + ny * half)
        lineTo(ex - nx * half, ey - ny * half)
        close()
    }
    drawPath(head, color)
}

/** Sleep timer: tap, pick a time, and the radio pauses by itself when it runs out. */
/**
 * Two soft rings that spread out from the play button and fade away, over and over.
 * Only put this on screen while playing: it stops by itself when it leaves the screen.
 */
@Composable
private fun PulseRings(color: Color, modifier: Modifier = Modifier) {
    // "Reduce animations": no rings at all.
    if (AppSettings.reduceMotion(LocalContext.current)) return
    val transition = rememberInfiniteTransition(label = "pulseRings")
    val first by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing)),
        label = "ring1"
    )
    val second by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(2600, easing = LinearEasing),
            initialStartOffset = StartOffset(1300)
        ),
        label = "ring2"
    )
    Canvas(modifier) {
        val startRadius = size.minDimension / 2f
        val spread = 28.dp.toPx()
        for (progress in listOf(first, second)) {
            drawCircle(
                color = color.copy(alpha = (1f - progress) * 0.55f),
                radius = startRadius + spread * progress,
                style = Stroke(width = 3.dp.toPx())
            )
        }
    }
}

@Composable
private fun SleepTimerButton(modifier: Modifier = Modifier) {
    var menuOpen by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    val endsAt = SleepTimer.endsAt
    LaunchedEffect(endsAt) {
        while (endsAt != null) {
            now = System.currentTimeMillis()
            delay(15_000)
        }
    }
    val tint = if (endsAt != null) MaterialTheme.colorScheme.primary
    else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f)

    Box(modifier) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .clickable { menuOpen = true }
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ActionIconView(ActionIcon.SLEEP, tint)
            Text(
                text = if (endsAt != null) "${(endsAt - now).coerceAtLeast(0L) / 60_000L + 1} min" else "Sleep",
                color = tint,
                fontSize = 11.sp
            )
        }
        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
            for (minutes in listOf(15, 30, 45, 60, 90)) {
                DropdownMenuItem(
                    text = { Text("$minutes minutes") },
                    onClick = {
                        SleepTimer.start(minutes)
                        menuOpen = false
                    }
                )
            }
            if (endsAt != null) {
                DropdownMenuItem(
                    text = { Text("Turn off timer") },
                    onClick = {
                        SleepTimer.cancel()
                        menuOpen = false
                    }
                )
            }
        }
    }
}

/** "Next: Robin Schulz" with the day and time underneath, and their photo: opens the DJ's page. */
@Composable
private fun NextUpLine(next: NextUp, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val is24 = DateFormat.is24HourFormat(ctx)
    val zone = ZoneId.systemDefault()
    val whenText = remember(next, is24) {
        val at = next.start.atZone(zone)
        val time = DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a").format(at)
        val today = LocalDate.now(zone)
        when (at.toLocalDate()) {
            today -> time
            today.plusDays(1) -> "Tomorrow $time"
            else -> DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault()).format(at) + " " + time
        }
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 48.dp)
            .lift(RoundedCornerShape(50), tappable = true)
            .clip(RoundedCornerShape(50))
            .background(CardSurface)
            .clickable(onClickLabel = "Open ${next.dj}'s page", role = Role.Button, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = next.photoUrl,
            contentDescription = null,
            placeholder = painterResource(R.drawable.station_logo_tile),
            error = painterResource(R.drawable.station_logo_tile),
            fallback = painterResource(R.drawable.station_logo_tile),
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(38.dp).clip(CircleShape)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = "Next: ${next.dj}",
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = tightStyle(18.sp)
            )
            Text(
                text = whenText,
                color = Color(0xFFD0CAD8),
                fontSize = 13.sp,
                fontWeight = FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = tightStyle(15.sp)
            )
        }
        Text(text = "›", color = MaterialTheme.colorScheme.onBackground, fontSize = 22.sp, fontWeight = FontWeight.Bold, style = tightStyle(24.sp))
        Spacer(Modifier.width(8.dp))
    }
}

/** Opens the phone's share sheet with a ready-made message. */
@Composable
private fun ShareButton(text: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f)
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                context.startActivity(Intent.createChooser(send, "Share ${Config.STATION_NAME}"))
            }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ActionIconView(ActionIcon.SHARE, tint)
        Text(text = "Share", color = tint, fontSize = 11.sp)
    }
}

/** White text with a soft shadow so it stays readable over the wallpaper. */
@Composable
fun ShadowText(
    text: String,
    fontSize: Int,
    weight: FontWeight,
    alpha: Float,
    topPadding: Int = 0,
    maxLines: Int = Int.MAX_VALUE,
    align: TextAlign = TextAlign.Start,
    scrollIfLong: Boolean = false   // one line that slides along when too long (instead of "…")
) {
    Text(
        text = text,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = alpha),
        fontSize = fontSize.sp,
        fontWeight = weight,
        textAlign = align,
        style = TextStyle(
            fontFamily = Poppins,
            shadow = Shadow(
                color = Color.Black.copy(alpha = 0.85f),
                offset = Offset(0f, 2f),
                blurRadius = 12f
            )
        ),
        modifier = Modifier.fillMaxWidth().padding(top = topPadding.dp).let { if (scrollIfLong) it.scrollWhenLong() else it }
    )
}

@Composable
fun PlayPauseIcon(playing: Boolean, color: Color) {
    Canvas(Modifier.size(40.dp)) {
        if (playing) {
            val barWidth = size.width * 0.28f
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.12f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(6f, 6f)
            )
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.60f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(6f, 6f)
            )
        } else {
            val triangle = Path().apply {
                moveTo(size.width * 0.20f, size.height * 0.05f)
                lineTo(size.width * 0.95f, size.height * 0.50f)
                lineTo(size.width * 0.20f, size.height * 0.95f)
                close()
            }
            drawPath(triangle, color)
        }
    }
}
