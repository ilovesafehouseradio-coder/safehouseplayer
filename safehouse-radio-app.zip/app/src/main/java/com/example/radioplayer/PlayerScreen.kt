package com.example.radioplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Radio tab
// ---------------------------------------------------------------------------

@Composable
fun PlayerScreen(controller: MediaController?) {
    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(false) }
    var hasError by remember { mutableStateOf(false) }
    var icyTitle by remember { mutableStateOf<String?>(null) }   // title sent inside the audio stream
    var polledTitle by remember { mutableStateOf<String?>(null) } // title from the server status page
    var started by remember { mutableStateOf(false) }             // has playback been started yet?

    DisposableEffect(controller) {
        val player = controller
        if (player == null) {
            onDispose { }
        } else {
            isPlaying = player.isPlaying
            isBuffering = player.playbackState == Player.STATE_BUFFERING
            started = player.playbackState != Player.STATE_IDLE
            icyTitle = player.mediaMetadata.title?.toString()
                ?.takeIf { it != Config.STATION_NAME }

            val listener = object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying_: Boolean) {
                    isPlaying = isPlaying_
                    if (isPlaying_) hasError = false
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    isBuffering = playbackState == Player.STATE_BUFFERING
                    started = playbackState != Player.STATE_IDLE
                }

                override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                    // Live streams usually send the current show as the title.
                    icyTitle = mediaMetadata.title?.toString()
                        ?.takeIf { it != Config.STATION_NAME }
                }

                override fun onPlayerError(error: PlaybackException) {
                    hasError = true
                }
            }
            player.addListener(listener)
            onDispose { player.removeListener(listener) }
        }
    }

    // Ask the server what's on air now, and again every 15 seconds while this screen is open.
    LaunchedEffect(Unit) {
        while (true) {
            val title = withContext(Dispatchers.IO) { fetchNowPlayingTitle() }
            if (title != null) polledTitle = title.ifEmpty { null }
            delay(15_000)
        }
    }
    val nowPlaying = polledTitle ?: icyTitle

    // Reload the artwork whenever the show changes (and each time this screen opens).
    val artUrl = remember(nowPlaying) { "${Config.ARTWORK_URL}?t=${System.currentTimeMillis()}" }

    // The title holds the DJ name and the show name: show them on two lines.
    val (djName, showName) = splitNowPlaying(nowPlaying)

    // A status message replaces the "Now Playing" block when there's nothing to show yet.
    val status: String? = when {
        hasError -> "Can't reach the stream. Tap play to retry."
        isBuffering && !isPlaying -> "Connecting…"
        isPlaying -> if (djName == null) "Live now" else null
        else -> "Tap play to listen"
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // Artwork size: most of the width, but never so tall that the controls get squeezed.
        val artSize = minOf(maxWidth * 0.82f, maxHeight - 360.dp).coerceAtLeast(150.dp)

        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.Start
        ) {
            // Top: the station name in the logo lettering, always visible.
            Box(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.station_wordmark),
                    contentDescription = Config.STATION_NAME,
                    modifier = Modifier.height(76.dp)
                )
            }

            Spacer(Modifier.weight(1f))

            // The full round logo is shown when the app first opens (before play is pressed),
            // and whenever there is no DJ artwork. Once playing, the current DJ's picture replaces it.
            // The "?t=" part makes sure we never get a stale picture.
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(if (started) artUrl else null)
                        .crossfade(true)
                        .diskCachePolicy(CachePolicy.DISABLED)
                        .memoryCachePolicy(CachePolicy.DISABLED)
                        .build(),
                    contentDescription = Config.STATION_NAME,
                    placeholder = painterResource(R.drawable.station_logo),
                    error = painterResource(R.drawable.station_logo),
                    fallback = painterResource(R.drawable.station_logo),
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(artSize)
                        .shadow(20.dp, RoundedCornerShape(24.dp))
                        .clip(RoundedCornerShape(24.dp))
                )
            }

            Spacer(Modifier.height(28.dp))

            // Text sits on the left, like a proper music app.
            // Fixed minimum height so nothing jumps when the text changes.
            Column(
                modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp),
                horizontalAlignment = Alignment.Start
            ) {
                if (status != null) {
                    ShadowText(status, fontSize = 18, weight = FontWeight.Normal, alpha = 0.85f)
                } else {
                    ShadowText("Now Playing:", fontSize = 16, weight = FontWeight.Light, alpha = 0.75f)
                    if (djName != null) {
                        ShadowText(
                            djName, fontSize = 28, weight = FontWeight.Bold, alpha = 1f,
                            topPadding = 8
                        )
                    }
                    if (showName != null) {
                        ShadowText(
                            showName, fontSize = 20, weight = FontWeight.Normal, alpha = 0.95f,
                            topPadding = 4
                        )
                    }
                }
            }

            Spacer(Modifier.weight(1f))

            // Play / pause button
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .clickable(enabled = controller != null) {
                            controller?.let { togglePlayback(it) }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (isBuffering && !isPlaying) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(36.dp)
                        )
                    } else {
                        PlayPauseIcon(isPlaying, MaterialTheme.colorScheme.onPrimary)
                    }
                }
            }

            Spacer(Modifier.height(28.dp))
        }
    }
}

/** White text with a soft shadow so it stays readable over the wallpaper. */
@Composable
fun ShadowText(
    text: String,
    fontSize: Int,
    weight: FontWeight,
    alpha: Float,
    topPadding: Int = 0
) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = alpha),
        fontSize = fontSize.sp,
        fontWeight = weight,
        textAlign = TextAlign.Start,
        style = TextStyle(
            fontFamily = Poppins,
            shadow = Shadow(
                color = Color.Black.copy(alpha = 0.85f),
                offset = Offset(0f, 2f),
                blurRadius = 12f
            )
        ),
        modifier = Modifier.fillMaxWidth().padding(top = topPadding.dp)
    )
}

@Composable
fun PlayPauseIcon(playing: Boolean, color: Color) {
    Canvas(Modifier.size(40.dp)) {
        if (playing) {
            val barWidth = size.width * 0.28f
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.12f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(6f, 6f)
            )
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.60f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(6f, 6f)
            )
        } else {
            val triangle = Path().apply {
                moveTo(size.width * 0.20f, size.height * 0.05f)
                lineTo(size.width * 0.95f, size.height * 0.50f)
                lineTo(size.width * 0.20f, size.height * 0.95f)
                close()
            }
            drawPath(triangle, color)
        }
    }
}
