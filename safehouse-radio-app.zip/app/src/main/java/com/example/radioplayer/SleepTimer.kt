package com.example.radioplayer

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.Player
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Pauses the radio after a chosen number of minutes. It lives outside the screen on purpose,
 * so it keeps counting even if the app is closed while the music carries on.
 * The playback service hands it the player (see PlaybackService).
 */
object SleepTimer {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    /** When the timer will pause the radio (milliseconds since 1970), or null if no timer is set. */
    var endsAt by mutableStateOf<Long?>(null)
        private set

    var player: Player? = null

    fun start(minutes: Int) {
        cancel()
        val length = minutes * 60_000L
        endsAt = System.currentTimeMillis() + length
        job = scope.launch {
            delay(length)
            player?.pause()
            endsAt = null
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        endsAt = null
    }
}
