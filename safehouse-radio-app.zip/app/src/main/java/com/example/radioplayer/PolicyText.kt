package com.example.radioplayer

// The words of the Privacy and Terms pages (More tab). The same words are in privacy.html on the web, so
// the app and the web page never disagree. Change both together.
object PolicyText {
    const val UPDATED = "27 October 2026"
    val privacyIntro = "Safehouse Radio is a non-profit internet radio station. This page says, in plain words, what the Safehouse Radio app does with information."
    val privacy: List<Pair<String, String>> = listOf(
        "Who we are" to "Safehouse Radio is responsible for the information described on this page. You can contact us at ${Config.CONTACT_EMAIL}.",
        "What stays on your phone" to "The DJs and shows you follow, your reminder choices, your settings, and saved copies of the schedule, DJ list and pictures so the app opens quickly. None of this is sent to us.",
        "What the app asks the internet for" to "The radio stream and what is on air, our public show calendar, and DJ names, pictures and pages from our website. As with any request on the internet, those servers can see your device's network address.",
        "What the app does not do" to "The app has no sign-in of its own, no adverts and no tracking or analytics. It does not collect your location, contacts, photos, camera or microphone. Nothing about you is sold or shared.",
        "Permissions the app asks for" to "Notifications: to show what is playing and to send your show reminders. Internet and network state: to play the radio. Background playback and keeping the phone awake while playing: so the radio keeps playing with the screen off. Starting with the phone: so reminders are planned again after a restart.",
        "The chat" to "The Chat tab shows our website's chat inside the app. The chat is run for us by the provider that hosts our website, who handles chat information on our behalf and only to run the chat. If you use it, the chat collects a display name; an email address and password if you create an account (guests can join with just a display name, and email and picture are optional); a picture or audio file, if you choose to add one (the app only sees the file you pick, and passes it to the chat); and the messages you post, which others in the room can see. It also keeps a sign-in on your phone so you stay signed in.",
        "Your choices and your information" to "Sign out and clear chat data: in More, under Chat account, this removes your saved chat sign-in from your phone straight away. Delete your chat account: in More, under Chat account, \"Delete my chat account\" opens an email to us. We will arrange for your account and the details linked to it to be deleted within 30 days, and confirm by email. You can also email ${Config.CONTACT_EMAIL} at any time. Under UK data protection law you can ask what we hold about you, ask us to correct it, and ask us to delete it. If you are unhappy with how we have handled your information, you can complain to the Information Commissioner's Office at ico.org.uk.",
        "Casting" to "If you cast the radio to a speaker or TV, your phone uses Google's Cast service. We do not receive any information from it.",
        "Reminders" to "Reminders are planned on your phone from the public schedule. Nothing is sent to a server to make them.",
        "Contact and help" to "\"Contact and help\" in More opens an email to us. It fills in the app version and your phone model, so we can find the fault. You can change or delete anything in the email before you send it, and nothing is sent unless you press send. Testers can also send a tester report (tap the version number in More seven times): an email with the phone model and Android version, screen and text size, the app's settings, what the radio has been doing since the app was opened (when it played, paused or lost the signal) and what the station was playing. It contains no names, email addresses, accounts or locations, it is kept only in the phone's memory while the app is open, and it is only sent if you press send. \"Join the DJ team\" opens an email to us with a few questions about you and your music; you choose what to write and whether to send it. We read every message, though we can't always reply to each one (requests about your chat account or your information are always answered).",
        "Changes" to "If we change this page, the date above changes too.",
    )
    val termsIntro = "These terms are for using the Safehouse Radio app. By using the app you agree to them."
    val terms: List<Pair<String, String>> = listOf(
        "The app" to "The app is a free way to listen to Safehouse Radio, a non-profit internet radio station, and to see the schedule and DJs and set show reminders. We may change or stop parts of it at any time.",
        "Listening" to "The app is for your own personal listening. Please do not record, copy or rebroadcast the stream, or use it for anything commercial. Our broadcast licence covers listeners in the UK, so the stream may not play from other countries.",
        "Shows and DJs" to "Our shows are made by DJs, who are responsible for what they play and say. What is on air can change at short notice, and some shows are repeats or automated. The schedule is a guide.",
        "The chat" to "The chat is our website's chat, shown inside the app. Please be kind: no abuse, hate, threats, spam or anything illegal. We can remove messages and accounts that break these rules.",
        "Show reminders" to "Reminders are planned on your phone and sent as notifications. They depend on your phone's settings, such as battery saving, so we cannot promise they will always arrive on time.",
        "No guarantees" to "We do our best, but the app and the radio stream are provided as they are and may sometimes be interrupted or contain mistakes. To the extent the law allows, we are not responsible for loss or damage from using the app. Nothing here takes away your legal rights as a consumer.",
        "Your information" to "How we handle information is explained on the Privacy page.",
        "Contact" to "Questions about these terms: ${Config.CONTACT_EMAIL}.",
        "Changes" to "We may update these terms. The date above changes when we do, and carrying on using the app means you accept the new version.",
    )
}
