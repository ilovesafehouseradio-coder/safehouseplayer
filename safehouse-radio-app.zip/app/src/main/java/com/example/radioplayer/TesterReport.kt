package com.example.radioplayer

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The tester report (tap "Version" in More seven times). A short, plain description of the phone, the app's settings
 * and what the radio has been doing this session, written into an email to the station. Nothing is sent by the app:
 * the person sees every line and presses Send themselves (or deletes it). No names, emails, accounts or locations are
 * ever included, and the timeline only lives in memory while the app is open.
 */
object TesterLog {
    private const val KEEP = 40
    private val events = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.UK)

    @Volatile var dropouts = 0
    @Volatile var reconnects = 0
    @Volatile var lastError: String? = null
    @Volatile var radioState: String = "stopped"
    @Volatile private var lastShown: String? = null

    /** One line on the timeline ("21:04:12 play"). */
    fun add(event: String) {
        synchronized(events) {
            events.addLast(clock.format(Date()) + "  " + event)
            while (events.size > KEEP) events.removeFirst()
        }
    }

    fun error(what: String) {
        dropouts++
        lastError = clock.format(Date()) + "  " + what
        add("dropout: $what")
    }

    /** What the station sent and what the app showed for it (only noted when it changes). */
    fun nowPlaying(raw: String?, shownDj: String?, shownShow: String?) {
        val shown = "${shownDj.orEmpty()} / ${shownShow.orEmpty()}"
        if (shown == lastShown) return
        lastShown = shown
        add("now playing: \"${raw.orEmpty()}\" shown as \"$shown\"")
    }

    fun timeline(): String = synchronized(events) { events.joinToString("\n").ifEmpty { "(nothing yet)" } }
}

object TesterReport {

    private fun version(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName.orEmpty()
    } catch (e: Exception) {
        ""
    }

    private fun phone(): String = listOf(android.os.Build.MANUFACTURER, android.os.Build.MODEL)
        .filter { it.isNotBlank() }.joinToString(" ").replaceFirstChar { it.uppercase() }

    private fun network(ctx: Context): String = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        when {
            caps == null -> "none"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "cable"
            else -> "other"
        }
    } catch (e: Exception) {
        "unknown"
    }

    private fun onOff(b: Boolean) = if (b) "on" else "off"

    private fun age(file: java.io.File): String {
        if (!file.exists()) return "never"
        val mins = (System.currentTimeMillis() - file.lastModified()) / 60_000L
        return when {
            mins < 1 -> "just now"
            mins < 60 -> "$mins min ago"
            mins < 48 * 60 -> "${mins / 60} hr ago"
            else -> "${mins / (24 * 60)} days ago"
        }
    }

    /** The whole report, in the same order every time. Call off the main thread (it reads the saved lists). */
    fun text(ctx: Context, chatNotes: String): String {
        val c = ctx.applicationContext
        val cfg = c.resources.configuration
        val dm = c.resources.displayMetrics
        // The latest of everything, read now (not what was remembered earlier): the saved DJ list and schedule as
        // they are on the phone this moment, and a fresh look at what the station is playing.
        val (djs, shows) = StreamNames.savedLists(c.cacheDir, fresh = true)
        val checkedLive = fetchLiveStatus()
        val feed = checkedLive ?: LiveFeed.last
        val shown = feed?.let { StreamNames.resolve(it.title, djs, shows) }
        val cast = try {
            com.google.android.gms.cast.framework.CastContext.getSharedInstance(c).sessionManager.currentCastSession
                ?.takeIf { it.isConnected }?.castDevice?.friendlyName
        } catch (e: Exception) {
            null
        }
        val stamp = SimpleDateFormat("EEE d MMM yyyy, HH:mm", Locale.UK).format(Date())
        return buildString {
            appendLine("--- Tester report (made by the app, please keep) ---")
            appendLine("When: $stamp")
            appendLine("App: ${Config.STATION_NAME} ${version(c)}")
            appendLine("Phone: ${phone()}, Android ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})")
            appendLine("Screen: ${cfg.screenWidthDp} x ${cfg.screenHeightDp} dp, ${dm.densityDpi} dpi, text size x${"%.2f".format(cfg.fontScale)}")
            appendLine()
            appendLine("Theme: ${ThemeState.saved(c).name}")
            appendLine("Buffer: ${AppSettings.BUFFER_LABELS.getOrElse(AppSettings.bufferChoice(c)) { "?" }}")
            appendLine("Reminders: ${onOff(AppSettings.remindersOn(c))}, sound ${AppSettings.reminderSound(c).label}")
            appendLine("Notifications allowed: ${if (Reminders.notificationsOk(c)) "yes" else "no"}, battery unrestricted: ${if (Reminders.batteryOk(c)) "yes" else "no"}")
            appendLine("Pause when headphones unplug: ${onOff(AppSettings.pauseOnUnplug(c))}, warn on mobile data: ${onOff(AppSettings.warnMobileData(c))}")
            appendLine("Artwork from the radio: ${onOff(LiveArtSwitch.isOn(c))}, reduce animations: ${onOff(AppSettings.reduceMotion(c))}")
            appendLine()
            appendLine("Radio: ${TesterLog.radioState}, network: ${network(c)}")
            appendLine("This session: ${TesterLog.dropouts} dropouts, ${TesterLog.reconnects} reconnect tries")
            appendLine("Last error: ${TesterLog.lastError ?: "none"}")
            appendLine("Casting: ${cast ?: "no"}")
            appendLine()
            appendLine("Station sent: \"${feed?.title ?: "(could not reach the station)"}\"${if (feed?.liveDj == true) " (live DJ connected)" else ""}${if (checkedLive == null && feed != null) " (from earlier: the station did not answer just now)" else ""}")
            appendLine("App shows: \"${shown?.dj.orEmpty()}\" / \"${shown?.show.orEmpty()}\"${if (shown?.match != null) " (DJ page: ${shown.match.name})" else ""}")
            appendLine()
            appendLine("DJ list: ${djs.size} DJs, updated ${age(java.io.File(c.cacheDir, "dj_cache.json"))}")
            appendLine("Schedule: ${shows.size} shows, updated ${age(java.io.File(c.cacheDir, "schedule.json"))}")
            appendLine()
            appendLine("Timeline (this session):")
            appendLine(TesterLog.timeline())
            if (chatNotes.isNotBlank()) {
                appendLine()
                appendLine("Chat notes:")
                appendLine(chatNotes.take(2500))
            }
            appendLine("--- end of report ---")
        }
    }

    /**
     * Opens an email to the station with the report under a short form for the tester to fill in. The subject always
     * starts "Safehouse Radio bug report", so the station can file them all in one folder.
     */
    /** Gathers the report (with the chat notes) off the main thread, then opens the email. */
    fun open(ctx: Context) {
        ChatDiag.snapshot { notes ->
            Thread {
                val report = text(ctx, notes)
                android.os.Handler(android.os.Looper.getMainLooper()).post { send(ctx, report) }
            }.start()
        }
    }

    fun send(ctx: Context, report: String) {
        val subject = "${Config.STATION_NAME} bug report · ${version(ctx)} · ${phone()} · " +
            SimpleDateFormat("d MMM HH:mm", Locale.UK).format(Date())
        val body = "Thanks for helping test the app. We read every report, but we can't reply to them individually.\n\n" +
            "What happened?\n\n\nWhat did you expect to happen?\n\n\nWhen, roughly?\n\n\n" + report
        if (!Email.compose(ctx, subject, body)) {
            // No email app: the phone's share sheet instead (WhatsApp and the like).
            ShowActions.share(ctx, "$subject\n\n$body", null)
        }
    }
}
