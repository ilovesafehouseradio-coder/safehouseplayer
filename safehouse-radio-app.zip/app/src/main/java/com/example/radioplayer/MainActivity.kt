package com.example.radioplayer

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

// FragmentActivity (a ComponentActivity with extras) is needed for the Chromecast device picker.
class MainActivity : FragmentActivity() {

    companion object {
        /** Sent by the notification: "open the app on the Radio tab". */
        const val EXTRA_OPEN_RADIO = "open_radio"
    }

    // Goes up by one each time the notification is tapped while the app is already open.
    private var radioSignal by mutableStateOf(0)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_OPEN_RADIO, false)) radioSignal++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            RadioTheme {
                RadioApp(openRadioSignal = radioSignal)
            }
        }
    }

    override fun onStop() {
        // Save cookies to disk so the chat login survives the app being closed.
        CookieManager.getInstance().flush()
        super.onStop()
    }
}

// ---------------------------------------------------------------------------
// Theme
// ---------------------------------------------------------------------------

@Composable
fun RadioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        // Colours sampled from the Safehouse Radio logo:
        // lavender #9994AC, white #F8F8F8, silver ring #C8C8C8, black.
        colorScheme = darkColorScheme(
            primary = Color(0xFF9994AC),
            onPrimary = Color(0xFF050505),
            secondaryContainer = Color(0xFF2B2935),
            onSecondaryContainer = Color(0xFFF8F8F8),
            background = Color(0xFF050505),
            surface = Color(0xFF111113),
            onBackground = Color(0xFFF8F8F8),
            onSurface = Color(0xFFF8F8F8),
            onSurfaceVariant = Color(0xFFC8C8C8)
        ),
        typography = RadioTypography
    ) {
        // Plain Text(...) calls don't pick up the theme font on their own, so set it here.
        ProvideTextStyle(MaterialTheme.typography.bodyLarge) {
            content()
        }
    }
}

// ---------------------------------------------------------------------------
// App shell: bottom tabs
// ---------------------------------------------------------------------------

private enum class Tab(val label: String, val icon: TabIcon) {
    RADIO("Radio", TabIcon.RADIO),
    SCHEDULE("Schedule", TabIcon.SCHEDULE),
    CHAT("Chat", TabIcon.CHAT),
    DJS("DJs", TabIcon.DJS),
    WEBSITE("Website", TabIcon.WEBSITE)
}

// The tab bar uses the lavender from the word "house" in the logo, with dark icons and text.
private val BarColor = Color(0xFF9994AC)
private val BarDark = Color(0xFF2B2935)

@Composable
fun RadioApp(openRadioSignal: Int = 0) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.RADIO) }
    var showWelcome by rememberSaveable { mutableStateOf(true) }   // the opening animation

    // The notification was tapped: go to the Radio tab (and skip the welcome if it's still playing).
    LaunchedEffect(openRadioSignal) {
        if (openRadioSignal > 0) {
            tab = Tab.RADIO
            showWelcome = false
        }
    }
    val controller by rememberController()

    // One WebView per web tab for the whole session, so each keeps its place
    // (and the chat stays signed in while the app is open).
    val siteView = remember { createWebView(context, Config.WEBSITE_URL) }
    // The schedule is built natively; the website page is only loaded if it's ever needed.
    val scheduleViewLazy = remember { lazy { createWebView(context, Config.SCHEDULE_URL) } }
    val chatView = remember { createWebView(context, Config.CHAT_URL) }
    DisposableEffect(Unit) {
        onDispose {
            WebAudio.forget(siteView)
            WebAudio.forget(chatView)
            if (scheduleViewLazy.isInitialized()) WebAudio.forget(scheduleViewLazy.value)
            siteView.destroy()
            if (scheduleViewLazy.isInitialized()) scheduleViewLazy.value.destroy()
            chatView.destroy()
        }
    }

    // Leaving a web tab silences its player; so does leaving the app.
    LaunchedEffect(tab) {
        if (tab != Tab.WEBSITE) WebAudio.pause(siteView)
        if (tab != Tab.CHAT) WebAudio.pause(chatView)
        if (tab != Tab.SCHEDULE && scheduleViewLazy.isInitialized()) WebAudio.pause(scheduleViewLazy.value)
    }
    DisposableEffect(context) {
        val owner = context as? LifecycleOwner
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) WebAudio.pauseAll()
        }
        owner?.lifecycle?.addObserver(observer)
        onDispose { owner?.lifecycle?.removeObserver(observer) }
    }

    val djState = remember { DjListState().also { it.useCache(context.cacheDir) } }
    val scheduleState = remember {
        ScheduleState().also {
            it.useCache(context.cacheDir)
            // Each time the schedule is read, the show reminders are worked out again from it.
            val app = context.applicationContext
            it.afterLoad = { list -> Reminders.rebuild(app, list) }
        }
    }

    // Opening a DJ's page from another tab (the Radio tab's name and "Next" line, a bell on the Schedule):
    // Back returns to the tab you came from.
    var returnTab by remember { mutableStateOf<Tab?>(null) }
    fun openDjPage(dj: Dj?) {
        if (dj != null) {
            if (tab != Tab.DJS) returnTab = tab
            djState.genre = null
            djState.openWeb = false
            djState.open = dj
        }
        tab = Tab.DJS
    }
    LaunchedEffect(djState.open) {
        if (djState.open == null) returnTab = null
    }

    // The next few live shows with a DJ named, for the "Next:" line on the Radio tab (checked every minute).
    var minuteTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(60_000)
            minuteTick++
        }
    }
    val upcoming = remember(scheduleState.shows, djState.djs, minuteTick) {
        UpNext.list(scheduleState.shows, djState.djs, java.time.Instant.now())
    }

    // Start getting the schedule as soon as the app opens (not when the tab is first tapped):
    // the saved copy appears instantly, and the fresh one replaces it a moment later.
    LaunchedEffect(Unit) {
        scheduleState.loadFromCache()
        if (!scheduleState.loading && scheduleState.needsRefresh()) scheduleState.load()
    }

    // Coming back to the app after a while away: read the schedule again if the copy is old
    // (nothing is read while the app is in the background).
    val appVisible by rememberAppVisible()
    var wasHidden by remember { mutableStateOf(false) }
    LaunchedEffect(appVisible) {
        if (!appVisible) {
            wasHidden = true
        } else if (wasHidden) {
            wasHidden = false
            if (!scheduleState.loading && scheduleState.needsRefresh()) scheduleState.load()
        }
    }

    // A little after start-up, once a week: read the DJ bios to learn which DJs go together (duos,
    // crews). Done quietly, a few pages at a time, and the pages are kept for the profile screen.
    LaunchedEffect(Unit) {
        val app = context.applicationContext
        DjGroups.ensureLoaded(app)
        withContext(Dispatchers.IO) { djState.loadFromCache() }
        if (DjGroups.shouldScan(app)) {
            kotlinx.coroutines.delay(8_000)
            if (djState.needsRefresh() && !djState.loading) djState.load()
            if (DjGroups.scan(app, djState)) {
                djState.groupsVersion++
                withContext(Dispatchers.Default) { Reminders.rebuild(app, scheduleState.shows) }
            }
        }
    }

    // Android 13+ needs permission to show the playback notification.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Back button: close a DJ page, or go back inside a web page, or return to Radio.
    val webForTab = when (tab) {
        Tab.SCHEDULE -> if (scheduleState.showWeb) scheduleViewLazy.value else null
        Tab.CHAT -> chatView
        Tab.WEBSITE -> siteView
        else -> null
    }
    BackHandler(enabled = tab != Tab.RADIO || scheduleState.showSetup) {
        if (scheduleState.showSetup) {
            scheduleState.showSetup = false
            scheduleState.setupSeen = true
        } else if (tab == Tab.DJS && djState.open != null) {
            if (djState.openWeb) {
                djState.openWeb = false
            } else {
                djState.open = null
                // Opened from the Radio or Schedule tab: go back there.
                returnTab?.let { tab = it }
                returnTab = null
            }
        } else if (tab == Tab.DJS && djState.genre != null) {
            djState.genre = null
        } else if (tab == Tab.SCHEDULE && scheduleState.showWeb && webForTab?.canGoBack() != true) {
            scheduleState.showWeb = false
        } else if (webForTab != null && webForTab.canGoBack()) {
            webForTab.goBack()
        } else {
            tab = Tab.RADIO
        }
    }

    // True while the on-screen keyboard is open (the chat), so the mini bar can step aside.
    val keyboardUp = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    Box(Modifier.fillMaxSize()) {
        // Very bottom layer: the wallpaper, filling the whole screen (behind the status bar too).
        Image(
            painter = painterResource(R.drawable.wallpaper),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            // Nudge the crop slightly right so the orange and pink swirls sit like the web player.
            alignment = BiasAlignment(0.2f, 0f),
            modifier = Modifier.fillMaxSize()
        )
        // Almost no tint at the top so the wallpaper stays vivid; darker at the bottom so the
        // text stays readable. The 0x14 / 0x26 / 0xB3 values are the darkness (00 = none, FF = black).
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colorStops = arrayOf(
                            0f to Color(0x14000000),
                            0.55f to Color(0x26000000),
                            1f to Color(0xB3000000)
                        )
                    )
                )
        )

        // An extra dark layer over the wallpaper on every tab, so titles and headings stand out
        // and all the pages match. Raise 0.5f for darker, lower for lighter.
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)))

        Scaffold(
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onBackground,
            bottomBar = {
                Column {
                // The small now-playing bar: on every tab except Radio, and not while the keyboard is up.
                if (tab != Tab.RADIO && !keyboardUp) {
                    MiniPlayerBar(controller) { tab = Tab.RADIO }
                }
                NavigationBar(containerColor = BarColor) {
                    for (t in Tab.values()) {
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { TabIconView(t.icon) },
                            label = {
                                Text(
                                    text = t.label,
                                    fontSize = 10.sp,
                                    letterSpacing = 0.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color(0xFFF8F8F8),
                                selectedTextColor = Color(0xFF050505),
                                indicatorColor = Color(0xFF1B1A22),
                                unselectedIconColor = BarDark,
                                unselectedTextColor = BarDark
                            )
                        )
                    }
                }
                }
            }
        ) { innerPadding ->
            Box(Modifier.padding(innerPadding).fillMaxSize()) {
                if (scheduleState.showSetup) {
                    // The one-time reminder setup, over whichever tab asked for it. Done goes back to it.
                    ReminderSetupScreen(onDone = {
                        scheduleState.showSetup = false
                        scheduleState.setupSeen = true
                    })
                } else when (tab) {
                    Tab.RADIO -> PlayerScreen(
                        controller,
                        upcoming = upcoming,
                        canOpenDj = { name -> UpNext.djFor(name, djState.djs) != null },
                        onOpenDj = { name -> openDjPage(UpNext.djFor(name, djState.djs)) },
                        onOpenNext = { next -> openDjPage(UpNext.djFor(next.dj, djState.djs)) }
                    )
                    Tab.SCHEDULE -> ScheduleScreen(
                        scheduleState,
                        djs = djState.djs,
                        // The bell on a card: go to that DJ's page, where the switches are.
                        onOpenDj = { show -> openDjPage(UpNext.djFor(show.dj, djState.djs)) }
                    ) { scheduleViewLazy.value }
                    Tab.CHAT -> WebTab(chatView)
                    Tab.DJS -> DjScreen(djState, scheduleState) {
                        // First reminder on a DJ's page: the one-time setup opens over that page.
                        scheduleState.showSetup = true
                    }
                    Tab.WEBSITE -> WebTab(siteView)
                }
            }
        }

        // The opening screen sits on top of everything until it has played.
        if (showWelcome) {
            WelcomeOverlay { showWelcome = false }
        }
    }
}

// ---------------------------------------------------------------------------
// Web tabs (Schedule, Chat, Website)
// ---------------------------------------------------------------------------

@Composable
fun WebTab(webView: WebView) {
    AndroidView(
        factory = {
            // The same WebView is reused when you come back to a tab, so detach it from
            // its old holder first (otherwise Android refuses to attach it twice).
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView
        },
        modifier = Modifier.fillMaxSize()
    )
}

/**
 * The website and chat pages have radio players of their own that the app can't see. This keeps
 * track of the pages and can tell them to stop making sound, so the app never ends up with audio
 * it can't switch off. (Must be called on the main thread, like anything that touches a WebView.)
 */
object WebAudio {
    private val views = java.util.Collections.newSetFromMap(java.util.WeakHashMap<WebView, Boolean>())

    private const val PAUSE_SCRIPT = """
        (function () {
          function stopIn(doc) {
            try {
              doc.querySelectorAll('audio,video').forEach(function (m) { try { m.pause(); } catch (e) {} });
              doc.querySelectorAll('iframe').forEach(function (f) { try { stopIn(f.contentDocument); } catch (e) {} });
            } catch (e) {}
          }
          stopIn(document);
        })();
    """

    fun register(view: WebView) {
        views.add(view)
    }

    /** Call just before a page is destroyed. */
    fun forget(view: WebView) {
        views.remove(view)
    }

    fun pause(view: WebView) {
        try {
            view.evaluateJavascript(PAUSE_SCRIPT, null)
        } catch (e: Exception) {
            // The page is already gone: nothing to stop.
        }
    }

    fun pauseAll() {
        for (view in views.toList()) pause(view)
    }
}

@SuppressLint("SetJavaScriptEnabled")
fun createWebView(context: Context, url: String): WebView =
    WebView(context).apply {
        WebAudio.register(this)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        // Cookies are what keep you signed in to the chat between visits.
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        webViewClient = object : WebViewClient() {
            // Keep all links inside the app.
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = false

            // A page that starts playing by itself while it is off screen gets stopped.
            override fun onPageFinished(view: WebView?, url: String?) {
                if (view != null && !view.isShown) WebAudio.pause(view)
            }
        }
        loadUrl(url)
    }

// ---------------------------------------------------------------------------
// Connecting to the background playback service
// ---------------------------------------------------------------------------

@Composable
fun rememberController(): State<MediaController?> {
    val context = LocalContext.current
    val controller = remember { mutableStateOf<MediaController?>(null) }

    DisposableEffect(context) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                try {
                    controller.value = future.get()
                } catch (e: Exception) {
                    controller.value = null
                }
            },
            ContextCompat.getMainExecutor(context)
        )
        onDispose {
            MediaController.releaseFuture(future)
            controller.value = null
        }
    }
    return controller
}

private fun streamItem(): MediaItem =
    MediaItem.Builder()
        .setUri(Config.STREAM_URL)
        .setMimeType(MimeTypes.AUDIO_MPEG)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(Config.STATION_NAME)
                .setArtist("Live on ${Config.STATION_NAME}")
                .setArtworkUri(Uri.parse(Config.LOGO_URL))
                .build()
        )
        .build()

fun togglePlayback(player: Player) {
    // Currently playing (or trying to): pause.
    if (player.playWhenReady && player.playbackState != Player.STATE_IDLE) {
        player.pause()
        return
    }
    // Otherwise load the station again so we always join the live stream, not stale buffered audio.
    // (Loading the item fresh also works when the radio is playing on a Chromecast.)
    // The website / chat players must not run at the same time as ours.
    WebAudio.pauseAll()
    player.setMediaItem(player.currentMediaItem ?: streamItem())
    player.prepare()
    player.play()
}
