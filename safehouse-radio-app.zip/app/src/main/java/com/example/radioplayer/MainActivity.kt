package com.example.radioplayer

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.net.HttpURLConnection
import java.net.URL
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import coil.imageLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

// FragmentActivity (a ComponentActivity with extras) is needed for the Chromecast device picker.
class MainActivity : FragmentActivity() {

    companion object {
        /** Sent by the notification: "open the app on the Radio tab". */
        const val EXTRA_OPEN_RADIO = "open_radio"
    }

    // Goes up by one each time the notification is tapped while the app is already open.
    private var radioSignal by mutableStateOf(0)

    // The phone's own file picker, used when the chat asks the person to choose a file (MP3s, profile pictures).
    // The app needs no storage permission for this: the person picks, and only the chosen file is handed over.
    private val filePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        ChatFiles.finish(result.resultCode, result.data)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        ChatFiles.launcher = { intent -> filePicker.launch(intent) }
        super.onCreate(savedInstanceState)
        Config.initUserAgent(applicationContext)
        ThemeState.load(applicationContext)
        // Wake Google Cast now, so it is already looking for speakers and TVs by the time the button is tapped.
        try {
            com.google.android.gms.cast.framework.CastContext.getSharedInstance(applicationContext)
        } catch (e: Exception) {
            // No Google Play services here: no casting.
        }
        onCreateBody()
    }

    override fun onDestroy() {
        ChatFiles.launcher = null
        ChatFiles.finish(RESULT_CANCELED, null)
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra(EXTRA_OPEN_RADIO, false)) radioSignal++
    }

    private fun onCreateBody() {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            RadioTheme {
                RadioApp(openRadioSignal = radioSignal)
            }
        }
    }

    override fun onStop() {
        // Save cookies to disk so the chat login survives the app being closed.
        CookieManager.getInstance().flush()
        super.onStop()
    }
}

// ---------------------------------------------------------------------------
// Theme
// ---------------------------------------------------------------------------

@Composable
fun RadioTheme(content: @Composable () -> Unit) {
    val p = ThemeState.current
    MaterialTheme(
        // The colours come from the chosen theme (see Theme.kt).
        colorScheme = darkColorScheme(
            primary = p.primary,
            onPrimary = p.onPrimary,
            secondaryContainer = p.card,
            onSecondaryContainer = p.text,
            background = p.background,
            surface = p.card,
            onBackground = p.text,
            onSurface = p.text,
            onSurfaceVariant = p.textDim
        ),
        typography = RadioTypography
    ) {
        // Plain Text(...) calls don't pick up the theme font on their own, so set it here.
        ProvideTextStyle(MaterialTheme.typography.bodyLarge) {
            content()
        }
    }
}

// ---------------------------------------------------------------------------
// App shell: bottom tabs
// ---------------------------------------------------------------------------

private enum class Tab(val label: String, val icon: TabIcon) {
    RADIO("Radio", TabIcon.RADIO),
    SCHEDULE("Schedule", TabIcon.SCHEDULE),
    CHAT("Chat", TabIcon.CHAT),
    DJS("DJs", TabIcon.DJS),
    MORE("More", TabIcon.MORE)
}

// The tab bar uses the lavender from the word "house" in the logo, with dark icons and text.

@Composable
fun RadioApp(openRadioSignal: Int = 0) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.RADIO) }
    // Where Back goes after the data card's Settings button took the listener to More.
    var backTo by remember { mutableStateOf<Tab?>(null) }
    LaunchedEffect(DataWarning.wantSetting) {
        if (DataWarning.wantSetting && tab != Tab.MORE) {
            backTo = tab
            tab = Tab.MORE
        }
    }
    LaunchedEffect(tab) { if (tab != Tab.MORE) backTo = null }
    var showWelcome by rememberSaveable { mutableStateOf(!AppSettings.skipWelcome(context)) }   // the opening animation
    DataWarning.appContext = context.applicationContext

    // The notification was tapped: go to the Radio tab (and skip the welcome if it's still playing).
    LaunchedEffect(openRadioSignal) {
        if (openRadioSignal > 0) {
            tab = Tab.RADIO
            showWelcome = false
        }
    }
    val controller by rememberController()

    // One WebView per web tab for the whole session, so each keeps its place
    // (and the chat stays signed in while the app is open).
    // The schedule is built natively; the website page is only loaded if it's ever needed.
    val scheduleViewLazy = remember { lazy { createWebView(context, Config.SCHEDULE_URL) } }
    val chatView = remember { createWebView(context, Config.CHAT_URL) }
    DisposableEffect(Unit) {
        onDispose {
            WebAudio.forget(chatView)
            if (scheduleViewLazy.isInitialized()) WebAudio.forget(scheduleViewLazy.value)
            if (scheduleViewLazy.isInitialized()) scheduleViewLazy.value.destroy()
            chatView.destroy()
        }
    }

    // Leaving a web tab silences its player; so does leaving the app.
    LaunchedEffect(tab) {
        if (tab != Tab.CHAT) {
            WebAudio.pause(chatView)
        } else {
            WebAudio.resumeSilent(chatView)
            // The chat page may have laid its messages out while the tab was hidden (no width); ask it to measure again.
            try { chatView.evaluateJavascript("window.dispatchEvent(new Event('resize'));", null) } catch (e: Exception) { }
        }
        if (tab != Tab.SCHEDULE && scheduleViewLazy.isInitialized()) WebAudio.pause(scheduleViewLazy.value)
    }
    DisposableEffect(context) {
        val owner = context as? LifecycleOwner
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) WebAudio.pauseAll()
        }
        owner?.lifecycle?.addObserver(observer)
        onDispose { owner?.lifecycle?.removeObserver(observer) }
    }

    val djState = remember { DjListState().also { it.useCache(context.cacheDir) } }
    // The DJ list is also what lets a calendar name that is one letter out ("Schultz") find its DJ.
    remember(djState.djs) { DjMatch.setKnown(djState.djs.map { it.name }) }
    val scheduleState = remember {
        ScheduleState().also {
            it.useCache(context.cacheDir)
            // Each time the schedule is read, the show reminders are worked out again from it.
            val app = context.applicationContext
            it.afterLoad = { list -> Reminders.rebuild(app, list) }
        }
    }

    // Opening a DJ's page from another tab (the Radio tab's name and "Next" line, a bell on the Schedule):
    // Back returns to the tab you came from.
    var returnTab by remember { mutableStateOf<Tab?>(null) }
    fun openDjPage(dj: Dj?) {
        if (dj != null) {
            if (tab != Tab.DJS) returnTab = tab
            djState.genre = null
            djState.openWeb = false
            djState.open = dj
        }
        tab = Tab.DJS
    }
    // Back from a DJ's page (the arrow and the phone's back button): to the tab it was opened from
    // (Radio or Schedule), or to the DJ list if it was opened inside the DJs tab.
    fun closeDjPage() {
        djState.open = null
        returnTab?.let { tab = it }
        returnTab = null
    }
    LaunchedEffect(djState.open) {
        if (djState.open == null) returnTab = null
    }

    // The next few live shows with a DJ named, for the "Next:" line on the Radio tab (checked every minute).
    var minuteTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(60_000)
            minuteTick++
        }
    }
    val upcoming = remember(scheduleState.shows, djState.djs, minuteTick) {
        UpNext.list(scheduleState.shows, djState.djs, java.time.Instant.now())
    }

    // Start getting the schedule as soon as the app opens (not when the tab is first tapped):
    // the saved copy appears instantly, and the fresh one replaces it a moment later.
    LaunchedEffect(Unit) {
        scheduleState.loadFromCache()
        if (!scheduleState.loading && scheduleState.needsRefresh()) scheduleState.load()
    }

    // Coming back to the app after a while away: read the schedule again if the copy is old
    // (nothing is read while the app is in the background).
    val appVisible by rememberAppVisible()
    var wasHidden by remember { mutableStateOf(false) }
    LaunchedEffect(appVisible) {
        if (!appVisible) {
            wasHidden = true
        } else if (wasHidden) {
            wasHidden = false
            if (!scheduleState.loading && scheduleState.needsRefresh()) scheduleState.load()
        }
    }

    // A little after start-up, once a week: read the DJ bios to learn which DJs go together (duos,
    // crews). Done quietly, a few pages at a time, and the pages are kept for the profile screen.
    LaunchedEffect(Unit) {
        val app = context.applicationContext
        DjGroups.ensureLoaded(app)
        withContext(Dispatchers.IO) { djState.loadFromCache() }
        if (DjGroups.shouldScan(app)) {
            kotlinx.coroutines.delay(8_000)
            if (djState.needsRefresh() && !djState.loading) djState.load()
            if (DjGroups.scan(app, djState)) {
                djState.groupsVersion++
                withContext(Dispatchers.Default) { Reminders.rebuild(app, scheduleState.shows) }
            }
        }
    }

    // Android 13+ needs permission to show the playback notification.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // "Clear saved pictures and schedule" on the More tab: deletes the saved copies and reads them again.
    val scope = rememberCoroutineScope()
    fun clearSaved() {
        val app = context.applicationContext
        scope.launch {
            withContext(Dispatchers.IO) {
                try {
                    java.io.File(app.cacheDir, "dj_cache.json").delete()
                    java.io.File(app.cacheDir, "schedule.json").delete()
                    app.imageLoader.diskCache?.clear()
                    app.imageLoader.memoryCache?.clear()
                } catch (e: Exception) {
                    // Nothing to clear, or it is in use: the copies are only a convenience.
                }
            }
            if (!scheduleState.loading) scheduleState.load()
            if (!djState.loading) djState.load()
        }
    }

    // Back button: close a DJ page, or go back inside a web page, or return to Radio.
    val webForTab = when (tab) {
        Tab.SCHEDULE -> if (scheduleState.showWeb) scheduleViewLazy.value else null
        Tab.CHAT -> chatView
        else -> null
    }
    BackHandler(enabled = tab != Tab.RADIO || scheduleState.showSetup) {
        if (scheduleState.showSetup) {
            scheduleState.showSetup = false
            scheduleState.setupSeen = true
        } else if (tab == Tab.DJS && djState.open != null) {
            if (djState.openWeb) {
                djState.openWeb = false
            } else {
                closeDjPage()
            }
        } else if (tab == Tab.DJS && djState.genre != null) {
            djState.genre = null
        } else if (tab == Tab.SCHEDULE && scheduleState.showWeb && webForTab?.canGoBack() != true) {
            scheduleState.showWeb = false
        } else if (webForTab != null && webForTab.canGoBack()) {
            webForTab.goBack()
        } else {
            tab = backTo ?: Tab.RADIO
            backTo = null
        }
    }

    // True while the on-screen keyboard is open (the chat), so the mini bar can step aside.
    val keyboardUp = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    Box(Modifier.fillMaxSize()) {
        // Very bottom layer: the wallpaper, filling the whole screen (behind the status bar too).
        Image(
            painter = painterResource(R.drawable.wallpaper),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            // Nudge the crop slightly right so the orange and pink swirls sit like the web player.
            alignment = BiasAlignment(0.2f, 0f),
            modifier = Modifier.fillMaxSize()
        )
        // Over the wallpaper: a light layer of the theme's black everywhere (so the middle stays about 85% clear),
        // and a stronger black fade from the top and from the bottom, thinning out towards the middle.
        val shade = ThemeState.current
        Box(Modifier.fillMaxSize().background(shade.background.copy(alpha = shade.wallpaperDim)))
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colorStops = arrayOf(
                            0f to shade.background.copy(alpha = 0.97f),
                            0.07f to shade.background.copy(alpha = 0.6f),
                            0.17f to shade.background.copy(alpha = 0.18f),
                            0.28f to shade.background.copy(alpha = 0f),
                            0.6f to shade.background.copy(alpha = 0f),
                            0.78f to shade.background.copy(alpha = 0.45f),
                            1f to shade.background.copy(alpha = 0.95f)
                        )
                    )
                )
        )

        Scaffold(
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onBackground,
            bottomBar = {
                Column {
                // The small now-playing bar: always there on Schedule, Chat and DJs (not Radio or More), and not while the keyboard is up.
                if (tab != Tab.RADIO && tab != Tab.MORE && !keyboardUp) {
                    MiniPlayerBar(controller, djState.djs, scheduleState.shows) { tab = Tab.RADIO }
                }
                // The bar's colour runs edge to edge; the five tabs are kept 12dp in from each side so the dark
                // pill of the selected tab lines up with the cards' margin instead of nearly touching the screen edge.
                Box(Modifier.fillMaxWidth().height(1.dp).background(ThemeState.current.primary))
                Box(Modifier.fillMaxWidth().background(ThemeState.current.background)) {
                NavigationBar(containerColor = Color.Transparent, modifier = Modifier.padding(horizontal = 12.dp)) {
                    for (t in Tab.values()) {
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = {
                                // A tab press always wins: it closes the reminder setup (as Back does) and goes there.
                                if (scheduleState.showSetup) {
                                    scheduleState.showSetup = false
                                    scheduleState.setupSeen = true
                                }
                                tab = t
                            },
                            icon = { TabIconView(t.icon) },
                            label = {
                                Text(
                                    text = t.label,
                                    fontSize = 10.sp,
                                    letterSpacing = 0.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ThemeState.current.onPrimary,
                                selectedTextColor = ThemeState.current.text,
                                indicatorColor = ThemeState.current.primary,
                                unselectedIconColor = ThemeState.current.textDim,
                                unselectedTextColor = ThemeState.current.textDim
                            )
                        )
                    }
                }
                }
                }
            }
        ) { innerPadding ->
            Column(Modifier.padding(innerPadding).fillMaxSize()) {
            // The same header on every page but Chat: "Safehouse Radio" and the Chromecast button.
            if (tab != Tab.CHAT) AppHeader()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (scheduleState.showSetup) {
                    // The one-time reminder setup, over whichever tab asked for it. Done goes back to it.
                    ReminderSetupScreen(onDone = {
                        scheduleState.showSetup = false
                        scheduleState.setupSeen = true
                    })
                } else when (tab) {
                    Tab.RADIO -> PlayerScreen(
                        controller,
                        upcoming = upcoming,
                        djs = djState.djs,
                        shows = scheduleState.shows,
                        onOpenDj = { dj -> openDjPage(dj) },
                        onOpenNext = { next -> openDjPage(UpNext.djFor(next.dj, djState.djs)) }
                    )
                    Tab.SCHEDULE -> ScheduleScreen(
                        scheduleState,
                        djs = djState.djs,
                        // The bell on a card: go to that DJ's page, where the switches are.
                        onOpenDj = { show -> openDjPage(UpNext.djForShow(show, djState.djs)) },
                        // The On Air card: that DJ's page. Back (arrow or button) returns here.
                        onOpenDjPage = { dj -> openDjPage(dj) },
                        // A slot with no description of its own borrows the opening of the DJ's bio (if their page has been read).
                        bioFor = { dj -> djState.profiles[dj.link]?.paragraphs?.firstOrNull() }
                    ) { scheduleViewLazy.value }
                    Tab.CHAT -> WebTab(chatView)
                    Tab.DJS -> DjScreen(
                        djState, scheduleState,
                        // The arrow in a DJ page's header: the same as the phone's back button.
                        onBack = { closeDjPage() },
                        onOpenReminderSetup = {
                            // First reminder on a DJ's page: the one-time setup opens over that page.
                            scheduleState.showSetup = true
                        }
                    )
                    Tab.MORE -> MoreScreen(
                        // The same one-time setup page as the Schedule's (i); Back returns to More.
                        onOpenReminderSetup = { scheduleState.showSetup = true },
                        onRemindersChanged = {
                            // On or off: the planned reminders are worked out again (or cleared).
                            val app = context.applicationContext
                            scope.launch(Dispatchers.Default) { Reminders.rebuild(app, scheduleState.shows) }
                        },
                        onClearSaved = { clearSaved() },
                        onClearChat = { clearChat(chatView) }
                    )
                }
            }
            }
        }

        // The opening screen sits on top of everything until it has played.
        if (showWelcome) {
            WelcomeOverlay { showWelcome = false }
        }

        // "Warn before using mobile data": asked once, never blocks the radio.
        DataWarningDialog()
        TipDialog()
    }
}

// ---------------------------------------------------------------------------
// Web tabs (Schedule, Chat, Website)
// ---------------------------------------------------------------------------

@Composable
fun WebTab(webView: WebView) {
    AndroidView(
        factory = {
            // The same WebView is reused when you come back to a tab, so detach it from
            // its old holder first (otherwise Android refuses to attach it twice).
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView
        },
        modifier = Modifier.fillMaxSize()
    )
}

/**
 * The website and chat pages have radio players of their own that the app can't see. This keeps
 * track of the pages and can tell them to stop making sound, so the app never ends up with audio
 * it can't switch off. (Must be called on the main thread, like anything that touches a WebView.)
 */
/**
 * In the app the chat gives each pasted GIF link's frame a height of about one pixel, so the GIF is there but cannot be seen.
 * This keeps any such frame at a sensible height (about the same as its width), and checks again whenever the chat adds messages.
 */
private const val GIF_FRAME_SCRIPT = """
    (function () {
      if (window.__shGifFix) return;
      window.__shGifFix = true;
      function fix() {
        try {
          document.querySelectorAll('iframe.chat-gif-embed').forEach(function (f) {
            var r = f.getBoundingClientRect();
            if (r.width > 40 && r.height < 60) {
              f.style.height = Math.round(r.width * 0.9) + 'px';
              f.style.minHeight = f.style.height;
            }
          });
        } catch (e) { }
      }
      fix();
      new MutationObserver(fix).observe(document.documentElement, { childList: true, subtree: true });
      setInterval(fix, 1500);
    })();
"""

object WebAudio {
    private val views = java.util.Collections.newSetFromMap(java.util.WeakHashMap<WebView, Boolean>())

    private const val PAUSE_SCRIPT = """
        (function () {
          function stopIn(doc) {
            try {
              doc.querySelectorAll('audio,video').forEach(function (m) { try { m.pause(); } catch (e) {} });
              doc.querySelectorAll('iframe').forEach(function (f) { try { stopIn(f.contentDocument); } catch (e) {} });
            } catch (e) {}
          }
          stopIn(document);
        })();
    """

    fun register(view: WebView) {
        views.add(view)
    }

    // Silent looping videos (GIFs) are paused with everything else when the tab is left; this starts them again.
    private const val RESUME_SCRIPT = """
        (function () {
          document.querySelectorAll('video').forEach(function (v) {
            try { if (v.muted && v.paused) { var p = v.play(); if (p && p.catch) p.catch(function () {}); } } catch (e) {}
          });
        })();
    """

    /** Starts the silent videos (GIFs) on a page again, without touching anything that makes sound. */
    fun resumeSilent(view: WebView) {
        try {
            view.evaluateJavascript(RESUME_SCRIPT, null)
        } catch (e: Exception) {
            // The page is already gone: nothing to start.
        }
    }

    /** Call just before a page is destroyed. */
    fun forget(view: WebView) {
        views.remove(view)
    }

    fun pause(view: WebView) {
        try {
            view.evaluateJavascript(PAUSE_SCRIPT, null)
        } catch (e: Exception) {
            // The page is already gone: nothing to stop.
        }
    }

    fun pauseAll() {
        for (view in views.toList()) pause(view)
    }
}

@SuppressLint("SetJavaScriptEnabled")
fun createWebView(context: Context, url: String): WebView =
    WebView(context).apply {
        WebAudio.register(this)
        if (url == Config.CHAT_URL) ChatDiag.view = java.lang.ref.WeakReference(this)
        settings.javaScriptEnabled = true
        // The page's own label gets the app's added to the end, so the website can tell app visits from browser visits.
        settings.userAgentString = settings.userAgentString + " " + Config.userAgent
        settings.domStorageEnabled = true
        // Like a normal browser, let a secure page show pictures (not scripts) that were linked with an old http://
        // address. Together with shouldInterceptRequest below, which fetches them over https, this lets GIFs
        // pasted into the chat show up.
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        // A GIF pasted into the chat is often a short silent looping video. Android's web view will not start a
        // video by itself unless told it may (Chrome does), which left a blank space where the GIF should be.
        // Leaving a web tab still stops anything playing (see WebAudio), so this cannot talk over the radio.
        settings.mediaPlaybackRequiresUserGesture = false
        // Cookies are what keep you signed in to the chat between visits.
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        webViewClient = object : WebViewClient() {
            // The station's own pages stay inside the app. A link the person taps that leads anywhere else (for
            // example one posted in the chat) opens in their normal browser instead, where the real address is
            // visible, so a look-alike page can never appear to be part of the app. Pages that move on by
            // themselves (sign-in redirects and the like) are left alone, so the chat keeps working.
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                // Only a whole-page navigation that the person tapped. Things the chat page loads inside itself
                // (a GIF from Giphy, an embedded player) are not touched, so they keep working.
                if (!request.isForMainFrame || !request.hasGesture()) return false
                val target = request.url
                val host = target.host.orEmpty().lowercase()
                val own = host == "safehouseradio.co.uk" || host.endsWith(".safehouseradio.co.uk")
                if (own) return false
                val scheme = target.scheme.orEmpty().lowercase()
                if (scheme == "http" || scheme == "https" || scheme == "mailto") {
                    // The matching app if the person has it (a YouTube or SoundCloud link, say), otherwise the browser.
                    Links.open(view.context, target.toString())
                }
                return true
            }

            // A picture linked with an old http:// address (a GIF pasted into the chat, say) is fetched over https
            // instead, as a normal browser does. Android blocks plain http by itself, so without this it never shows.
            // Only pictures are fetched this way, only over https, and nothing is sent that the browser would not send.
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                if (url.host.orEmpty().contains("giphy")) ChatDiag.add("asked for ${url.host}${url.path}")
                if (!url.scheme.equals("http", ignoreCase = true) || !request.method.equals("GET", ignoreCase = true)) return null
                val accept = request.requestHeaders["Accept"].orEmpty()
                val path = url.path.orEmpty().lowercase()
                val isPicture = accept.startsWith("image/") ||
                    path.endsWith(".gif") || path.endsWith(".png") || path.endsWith(".jpg") ||
                    path.endsWith(".jpeg") || path.endsWith(".webp")
                if (!isPicture) return null
                return try {
                    val secure = url.buildUpon().scheme("https").build().toString()
                    val conn = URL(secure).openConnection() as HttpURLConnection
                    conn.connectTimeout = 10_000
                    conn.readTimeout = 15_000
                    conn.setRequestProperty("User-Agent", request.requestHeaders["User-Agent"] ?: Config.userAgent)
                    val mime = conn.contentType?.substringBefore(';')?.trim().orEmpty()
                    if (conn.responseCode in 200..299 && mime.startsWith("image/")) {
                        WebResourceResponse(mime, null, conn.inputStream)
                    } else {
                        conn.disconnect()
                        null
                    }
                } catch (e: Exception) {
                    null
                }
            }

            // Notes for ChatDiag: pictures and files that failed to load.
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                ChatDiag.add("load error ${error.errorCode} ${error.description}: ${request.url}")
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                ChatDiag.add("http ${errorResponse.statusCode}: ${request.url}")
            }

            // A page that starts playing by itself while it is off screen gets stopped.
            override fun onPageFinished(view: WebView?, url: String?) {
                if (view != null && !view.isShown) WebAudio.pause(view)
                // Our own pages only: give GIF frames a proper height (see GIF_FRAME_SCRIPT).
                val host = try { Uri.parse(url).host.orEmpty() } catch (e: Exception) { "" }
                if (view != null && (host == "safehouseradio.co.uk" || host.endsWith(".safehouseradio.co.uk"))) {
                    view.evaluateJavascript(GIF_FRAME_SCRIPT, null)
                }
            }
        }
        // The pop-up questions a page asks ("Remove this message from the chat?"), shown as ordinary Android dialogs.
        // Without this the web view answers "no" to every one of them, so the chat's delete and edit buttons did nothing.
        webChromeClient = object : WebChromeClient() {
            private fun title(url: String?): String {
                val host = try { Uri.parse(url).host.orEmpty() } catch (e: Exception) { "" }
                return if (host.isEmpty()) "This page says" else "$host says"
            }

            override fun onJsAlert(view: WebView, url: String?, message: String?, result: JsResult): Boolean =
                try {
                    android.app.AlertDialog.Builder(view.context)
                        .setTitle(title(url))
                        .setMessage(message.orEmpty())
                        .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                        .setOnCancelListener { result.cancel() }
                        .show()
                    true
                } catch (e: Exception) {
                    result.cancel()
                    true
                }

            override fun onJsConfirm(view: WebView, url: String?, message: String?, result: JsResult): Boolean =
                try {
                    android.app.AlertDialog.Builder(view.context)
                        .setTitle(title(url))
                        .setMessage(message.orEmpty())
                        .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                        .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                        .setOnCancelListener { result.cancel() }
                        .show()
                    true
                } catch (e: Exception) {
                    result.cancel()
                    true
                }

            override fun onJsPrompt(
                view: WebView,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult
            ): Boolean =
                try {
                    val input = android.widget.EditText(view.context)
                    input.setText(defaultValue.orEmpty())
                    android.app.AlertDialog.Builder(view.context)
                        .setTitle(title(url))
                        .setMessage(message.orEmpty())
                        .setView(input)
                        .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm(input.text.toString()) }
                        .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                        .setOnCancelListener { result.cancel() }
                        .show()
                    true
                } catch (e: Exception) {
                    result.cancel()
                    true
                }

            override fun onShowFileChooser(
                view: WebView,
                callback: android.webkit.ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                // Only our own website may ask for a file.
                val host = Uri.parse(view.url.orEmpty()).host.orEmpty()
                val own = host == "safehouseradio.co.uk" || host.endsWith(".safehouseradio.co.uk")
                if (!own) {
                    callback.onReceiveValue(null)
                    return true
                }
                return ChatFiles.start(callback, params)
            }

            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                ChatDiag.add("console ${consoleMessage.messageLevel()}: ${consoleMessage.message()} (${consoleMessage.sourceId()}:${consoleMessage.lineNumber()})")
                return false
            }
        }
        loadUrl(url)
    }

// ---------------------------------------------------------------------------
// Connecting to the background playback service
// ---------------------------------------------------------------------------

@Composable
fun rememberController(): State<MediaController?> {
    val context = LocalContext.current
    val controller = remember { mutableStateOf<MediaController?>(null) }

    DisposableEffect(context) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                try {
                    controller.value = future.get()
                } catch (e: Exception) {
                    controller.value = null
                }
            },
            ContextCompat.getMainExecutor(context)
        )
        onDispose {
            MediaController.releaseFuture(future)
            controller.value = null
        }
    }
    return controller
}

private fun streamItem(): MediaItem =
    MediaItem.Builder()
        .setUri(Config.STREAM_URL)
        .setMimeType(MimeTypes.AUDIO_MPEG)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(Config.STATION_NAME)
                .setArtist("Live on ${Config.STATION_NAME}")
                .setArtworkUri(Uri.parse(Config.LOGO_URL))
                .build()
        )
        .build()

fun togglePlayback(player: Player) {
    // Currently playing (or trying to): pause.
    if (player.playWhenReady && player.playbackState != Player.STATE_IDLE) {
        player.pause()
        return
    }
    // On mobile data with the warning switched on, ask first (once); Play carries on as normal.
    DataWarning.guard {
        // The radio is what they came for: the welcome jingle gives way to it.
        WelcomeSound.stop()
        startPlayback(player)
    }
}

private fun startPlayback(player: Player) {
    // Load the station again so we always join the live stream, not stale buffered audio.
    // (Loading the item fresh also works when the radio is playing on a Chromecast.)
    // The website / chat players must not run at the same time as ours.
    WebAudio.pauseAll()
    player.setMediaItem(player.currentMediaItem ?: streamItem())
    player.prepare()
    player.play()
}

/**
 * "Sign out and clear chat data" (More tab): removes the saved sign-in, cookies and stored data that the
 * app's built-in web pages keep on the phone, then opens the chat's first page again. Nothing is deleted
 * from the chat's own servers: that is "Delete my chat account".
 */
private fun clearChat(chatView: WebView) {
    try {
        val cookies = android.webkit.CookieManager.getInstance()
        cookies.removeAllCookies(null)
        cookies.flush()
        android.webkit.WebStorage.getInstance().deleteAllData()
        chatView.clearCache(true)
        chatView.clearFormData()
        chatView.clearHistory()
        chatView.loadUrl(Config.CHAT_URL)
    } catch (e: Exception) {
        // Nothing to clear, or the web view is busy: the sign-in simply stays.
    }
}
