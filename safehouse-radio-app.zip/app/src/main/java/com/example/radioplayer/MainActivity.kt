package com.example.radioplayer

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            RadioTheme {
                RadioApp()
            }
        }
    }

    override fun onStop() {
        // Save cookies to disk so the chat login survives the app being closed.
        CookieManager.getInstance().flush()
        super.onStop()
    }
}

// ---------------------------------------------------------------------------
// Theme
// ---------------------------------------------------------------------------

@Composable
fun RadioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        // Colours sampled from the Safehouse Radio logo:
        // lavender #9994AC, white #F8F8F8, silver ring #C8C8C8, black.
        colorScheme = darkColorScheme(
            primary = Color(0xFF9994AC),
            onPrimary = Color(0xFF050505),
            secondaryContainer = Color(0xFF2B2935),
            onSecondaryContainer = Color(0xFFF8F8F8),
            background = Color(0xFF050505),
            surface = Color(0xFF111113),
            onBackground = Color(0xFFF8F8F8),
            onSurface = Color(0xFFF8F8F8),
            onSurfaceVariant = Color(0xFFC8C8C8)
        ),
        typography = RadioTypography
    ) {
        // Plain Text(...) calls don't pick up the theme font on their own, so set it here.
        ProvideTextStyle(MaterialTheme.typography.bodyLarge) {
            content()
        }
    }
}

// ---------------------------------------------------------------------------
// App shell: bottom tabs
// ---------------------------------------------------------------------------

private enum class Tab(val label: String, val icon: TabIcon) {
    RADIO("Radio", TabIcon.RADIO),
    SCHEDULE("Schedule", TabIcon.SCHEDULE),
    CHAT("Chat", TabIcon.CHAT),
    DJS("DJs", TabIcon.DJS),
    WEBSITE("Website", TabIcon.WEBSITE)
}

// The tab bar uses the lavender from the word "house" in the logo, with dark icons and text.
private val BarColor = Color(0xFF9994AC)
private val BarDark = Color(0xFF2B2935)

@Composable
fun RadioApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.RADIO) }
    val controller by rememberController()

    // One WebView per web tab for the whole session, so each keeps its place
    // (and the chat stays signed in while the app is open).
    val siteView = remember { createWebView(context, Config.WEBSITE_URL) }
    // The schedule is built natively; the website page is only loaded if it's ever needed.
    val scheduleViewLazy = remember { lazy { createWebView(context, Config.SCHEDULE_URL) } }
    val chatView = remember { createWebView(context, Config.CHAT_URL) }
    DisposableEffect(Unit) {
        onDispose {
            siteView.destroy()
            if (scheduleViewLazy.isInitialized()) scheduleViewLazy.value.destroy()
            chatView.destroy()
        }
    }

    val djState = remember { DjListState() }
    val scheduleState = remember { ScheduleState() }

    // Android 13+ needs permission to show the playback notification.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // Back button: close a DJ page, or go back inside a web page, or return to Radio.
    val webForTab = when (tab) {
        Tab.SCHEDULE -> if (scheduleState.showWeb) scheduleViewLazy.value else null
        Tab.CHAT -> chatView
        Tab.WEBSITE -> siteView
        else -> null
    }
    BackHandler(enabled = tab != Tab.RADIO) {
        if (tab == Tab.DJS && djState.openUrl != null) {
            djState.openUrl = null
        } else if (tab == Tab.SCHEDULE && scheduleState.showWeb && webForTab?.canGoBack() != true) {
            scheduleState.showWeb = false
        } else if (webForTab != null && webForTab.canGoBack()) {
            webForTab.goBack()
        } else {
            tab = Tab.RADIO
        }
    }

    Box(Modifier.fillMaxSize()) {
        // Very bottom layer: the wallpaper, filling the whole screen (behind the status bar too).
        Image(
            painter = painterResource(R.drawable.wallpaper),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            // Nudge the crop slightly right so the orange and pink swirls sit like the web player.
            alignment = BiasAlignment(0.2f, 0f),
            modifier = Modifier.fillMaxSize()
        )
        // Almost no tint at the top so the wallpaper stays vivid; darker at the bottom so the
        // text stays readable. The 0x14 / 0x26 / 0xB3 values are the darkness (00 = none, FF = black).
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colorStops = arrayOf(
                            0f to Color(0x14000000),
                            0.55f to Color(0x26000000),
                            1f to Color(0xB3000000)
                        )
                    )
                )
        )

        // An extra dark layer over the wallpaper on every tab, so titles and headings stand out
        // and all the pages match. Raise 0.5f for darker, lower for lighter.
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.5f)))

        Scaffold(
            containerColor = Color.Transparent,
            contentColor = MaterialTheme.colorScheme.onBackground,
            bottomBar = {
                NavigationBar(containerColor = BarColor) {
                    for (t in Tab.values()) {
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { TabIconView(t.icon) },
                            label = {
                                Text(
                                    text = t.label,
                                    fontSize = 10.sp,
                                    letterSpacing = 0.sp,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color(0xFFF8F8F8),
                                selectedTextColor = Color(0xFF050505),
                                indicatorColor = Color(0xFF1B1A22),
                                unselectedIconColor = BarDark,
                                unselectedTextColor = BarDark
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(Modifier.padding(innerPadding).fillMaxSize()) {
                when (tab) {
                    Tab.RADIO -> PlayerScreen(controller)
                    Tab.SCHEDULE -> ScheduleScreen(scheduleState) { scheduleViewLazy.value }
                    Tab.CHAT -> WebTab(chatView)
                    Tab.DJS -> DjScreen(djState)
                    Tab.WEBSITE -> WebTab(siteView)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Web tabs (Schedule, Chat, Website)
// ---------------------------------------------------------------------------

@Composable
fun WebTab(webView: WebView) {
    AndroidView(
        factory = {
            // The same WebView is reused when you come back to a tab, so detach it from
            // its old holder first (otherwise Android refuses to attach it twice).
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView
        },
        modifier = Modifier.fillMaxSize()
    )
}

@SuppressLint("SetJavaScriptEnabled")
fun createWebView(context: Context, url: String): WebView =
    WebView(context).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        // Cookies are what keep you signed in to the chat between visits.
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        webViewClient = object : WebViewClient() {
            // Keep all links inside the app.
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = false
        }
        loadUrl(url)
    }

// ---------------------------------------------------------------------------
// Connecting to the background playback service
// ---------------------------------------------------------------------------

@Composable
fun rememberController(): State<MediaController?> {
    val context = LocalContext.current
    val controller = remember { mutableStateOf<MediaController?>(null) }

    DisposableEffect(context) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                try {
                    controller.value = future.get()
                } catch (e: Exception) {
                    controller.value = null
                }
            },
            ContextCompat.getMainExecutor(context)
        )
        onDispose {
            MediaController.releaseFuture(future)
            controller.value = null
        }
    }
    return controller
}

private fun streamItem(): MediaItem =
    MediaItem.Builder()
        .setUri(Config.STREAM_URL)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(Config.STATION_NAME)
                .setArtist("Live")
                .build()
        )
        .build()

fun togglePlayback(player: Player) {
    // Currently playing (or trying to): pause.
    if (player.playWhenReady && player.playbackState != Player.STATE_IDLE) {
        player.pause()
        return
    }
    // Otherwise start fresh so we always join the live stream, not stale buffered audio.
    if (player.mediaItemCount == 0) {
        player.setMediaItem(streamItem())
    }
    player.stop()
    player.prepare()
    player.play()
}
