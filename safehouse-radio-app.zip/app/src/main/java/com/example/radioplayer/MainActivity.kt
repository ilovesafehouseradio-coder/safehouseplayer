package com.example.radioplayer

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            RadioTheme {
                RadioApp()
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Theme
// ---------------------------------------------------------------------------

@Composable
fun RadioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        // Colours sampled from the Safehouse Radio logo:
        // lavender #9994AC, white #F8F8F8, silver ring #C8C8C8, black.
        colorScheme = darkColorScheme(
            primary = Color(0xFF9994AC),
            onPrimary = Color(0xFF050505),
            secondaryContainer = Color(0xFF2B2935),
            onSecondaryContainer = Color(0xFFF8F8F8),
            background = Color(0xFF050505),
            surface = Color(0xFF111113),
            onBackground = Color(0xFFF8F8F8),
            onSurface = Color(0xFFF8F8F8),
            onSurfaceVariant = Color(0xFFC8C8C8)
        ),
        content = content
    )
}

// ---------------------------------------------------------------------------
// App shell: two tabs, Listen and Website
// ---------------------------------------------------------------------------

@Composable
fun RadioApp() {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val controller by rememberController()

    // One WebView for the whole session so the site keeps its place when you switch tabs.
    val webView = remember { createWebView(context) }
    DisposableEffect(Unit) {
        onDispose { webView.destroy() }
    }

    // Android 13+ needs permission to show the playback notification.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    BackHandler(enabled = tab == 1) {
        if (webView.canGoBack()) webView.goBack() else tab = 0
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("♪", fontSize = 20.sp) },
                    label = { Text("Listen") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("🌐", fontSize = 18.sp) },
                    label = { Text("Website") }
                )
            }
        }
    ) { innerPadding ->
        Box(Modifier.padding(innerPadding).fillMaxSize()) {
            if (tab == 0) {
                PlayerScreen(controller)
            } else {
                AndroidView(
                    factory = { webView },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Website tab
// ---------------------------------------------------------------------------

@SuppressLint("SetJavaScriptEnabled")
private fun createWebView(context: Context): WebView =
    WebView(context).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        webViewClient = object : WebViewClient() {
            // Keep all links inside the app.
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = false
        }
        loadUrl(Config.WEBSITE_URL)
    }

// ---------------------------------------------------------------------------
// Connecting to the background playback service
// ---------------------------------------------------------------------------

@Composable
fun rememberController(): State<MediaController?> {
    val context = LocalContext.current
    val controller = remember { mutableStateOf<MediaController?>(null) }

    DisposableEffect(context) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                try {
                    controller.value = future.get()
                } catch (e: Exception) {
                    controller.value = null
                }
            },
            ContextCompat.getMainExecutor(context)
        )
        onDispose {
            MediaController.releaseFuture(future)
            controller.value = null
        }
    }
    return controller
}

private fun streamItem(): MediaItem =
    MediaItem.Builder()
        .setUri(Config.STREAM_URL)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(Config.STATION_NAME)
                .setArtist("Live")
                .build()
        )
        .build()

private fun togglePlayback(player: Player) {
    // Currently playing (or trying to): pause.
    if (player.playWhenReady && player.playbackState != Player.STATE_IDLE) {
        player.pause()
        return
    }
    // Otherwise start fresh so we always join the live stream, not stale buffered audio.
    if (player.mediaItemCount == 0) {
        player.setMediaItem(streamItem())
    }
    player.stop()
    player.prepare()
    player.play()
}

// ---------------------------------------------------------------------------
// Listen tab
// ---------------------------------------------------------------------------

@Composable
fun PlayerScreen(controller: MediaController?) {
    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(false) }
    var hasError by remember { mutableStateOf(false) }
    var nowPlaying by remember { mutableStateOf<String?>(null) }

    DisposableEffect(controller) {
        val player = controller
        if (player == null) {
            onDispose { }
        } else {
            isPlaying = player.isPlaying
            isBuffering = player.playbackState == Player.STATE_BUFFERING
            nowPlaying = player.mediaMetadata.title?.toString()
                ?.takeIf { it != Config.STATION_NAME }

            val listener = object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying_: Boolean) {
                    isPlaying = isPlaying_
                    if (isPlaying_) hasError = false
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    isBuffering = playbackState == Player.STATE_BUFFERING
                }

                override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                    // Live streams usually send the current song as the title.
                    nowPlaying = mediaMetadata.title?.toString()
                        ?.takeIf { it != Config.STATION_NAME }
                }

                override fun onPlayerError(error: PlaybackException) {
                    hasError = true
                }
            }
            player.addListener(listener)
            onDispose { player.removeListener(listener) }
        }
    }

    val status = when {
        hasError -> "Can't reach the stream. Tap play to retry."
        isBuffering && !isPlaying -> "Connecting…"
        isPlaying -> nowPlaying ?: "Live now"
        else -> "Tap play to listen"
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(R.drawable.station_logo),
            contentDescription = Config.STATION_NAME,
            modifier = Modifier.size(240.dp)
        )

        Text(
            text = Config.SLOGAN,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            modifier = Modifier.padding(top = 20.dp)
        )

        Text(
            text = status,
            fontSize = 16.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
            modifier = Modifier.padding(top = 24.dp, bottom = 40.dp)
        )

        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .clickable(enabled = controller != null) {
                    controller?.let { togglePlayback(it) }
                },
            contentAlignment = Alignment.Center
        ) {
            if (isBuffering && !isPlaying) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(40.dp)
                )
            } else {
                PlayPauseIcon(isPlaying, MaterialTheme.colorScheme.onPrimary)
            }
        }
    }
}

@Composable
fun PlayPauseIcon(playing: Boolean, color: Color) {
    Canvas(Modifier.size(40.dp)) {
        if (playing) {
            val barWidth = size.width * 0.28f
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.12f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(6f, 6f)
            )
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.60f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(6f, 6f)
            )
        } else {
            val triangle = Path().apply {
                moveTo(size.width * 0.20f, size.height * 0.05f)
                lineTo(size.width * 0.95f, size.height * 0.50f)
                lineTo(size.width * 0.20f, size.height * 0.95f)
                close()
            }
            drawPath(triangle, color)
        }
    }
}
