package com.example.radioplayer

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.BiasAlignment
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            RadioTheme {
                RadioApp()
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Theme
// ---------------------------------------------------------------------------

@Composable
fun RadioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        // Colours sampled from the Safehouse Radio logo:
        // lavender #9994AC, white #F8F8F8, silver ring #C8C8C8, black.
        colorScheme = darkColorScheme(
            primary = Color(0xFF9994AC),
            onPrimary = Color(0xFF050505),
            secondaryContainer = Color(0xFF2B2935),
            onSecondaryContainer = Color(0xFFF8F8F8),
            background = Color(0xFF050505),
            surface = Color(0xFF111113),
            onBackground = Color(0xFFF8F8F8),
            onSurface = Color(0xFFF8F8F8),
            onSurfaceVariant = Color(0xFFC8C8C8)
        ),
        content = content
    )
}

// ---------------------------------------------------------------------------
// App shell: two tabs, Listen and Website
// ---------------------------------------------------------------------------

@Composable
fun RadioApp() {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val controller by rememberController()

    // One WebView for the whole session so the site keeps its place when you switch tabs.
    val webView = remember { createWebView(context) }
    DisposableEffect(Unit) {
        onDispose { webView.destroy() }
    }

    // Android 13+ needs permission to show the playback notification.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    BackHandler(enabled = tab == 1) {
        if (webView.canGoBack()) webView.goBack() else tab = 0
    }

    Box(Modifier.fillMaxSize()) {
        // Very bottom layer: the wallpaper, filling the whole screen (behind the status bar too).
        Image(
            painter = painterResource(R.drawable.wallpaper),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            // Nudge the crop slightly right so the orange and pink swirls sit like the web player.
            alignment = BiasAlignment(0.2f, 0f),
            modifier = Modifier.fillMaxSize()
        )
        // Almost no tint at the top so the wallpaper stays vivid; darker at the bottom so the
        // text stays readable. The 0x14 / 0x26 / 0xB3 values are the darkness (00 = none, FF = black).
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colorStops = arrayOf(
                            0f to Color(0x14000000),
                            0.55f to Color(0x26000000),
                            1f to Color(0xB3000000)
                        )
                    )
                )
        )

        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = Color(0xCC050505)) {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Text("♪", fontSize = 20.sp) },
                        label = { Text("Listen") }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Text("🌐", fontSize = 18.sp) },
                        label = { Text("Website") }
                    )
                }
            }
        ) { innerPadding ->
            Box(Modifier.padding(innerPadding).fillMaxSize()) {
                if (tab == 0) {
                    PlayerScreen(controller)
                } else {
                    AndroidView(
                        factory = { webView },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Website tab
// ---------------------------------------------------------------------------

@SuppressLint("SetJavaScriptEnabled")
private fun createWebView(context: Context): WebView =
    WebView(context).apply {
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        webViewClient = object : WebViewClient() {
            // Keep all links inside the app.
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean = false
        }
        loadUrl(Config.WEBSITE_URL)
    }

// ---------------------------------------------------------------------------
// Connecting to the background playback service
// ---------------------------------------------------------------------------

@Composable
fun rememberController(): State<MediaController?> {
    val context = LocalContext.current
    val controller = remember { mutableStateOf<MediaController?>(null) }

    DisposableEffect(context) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                try {
                    controller.value = future.get()
                } catch (e: Exception) {
                    controller.value = null
                }
            },
            ContextCompat.getMainExecutor(context)
        )
        onDispose {
            MediaController.releaseFuture(future)
            controller.value = null
        }
    }
    return controller
}

private fun streamItem(): MediaItem =
    MediaItem.Builder()
        .setUri(Config.STREAM_URL)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(Config.STATION_NAME)
                .setArtist("Live")
                .build()
        )
        .build()

private fun togglePlayback(player: Player) {
    // Currently playing (or trying to): pause.
    if (player.playWhenReady && player.playbackState != Player.STATE_IDLE) {
        player.pause()
        return
    }
    // Otherwise start fresh so we always join the live stream, not stale buffered audio.
    if (player.mediaItemCount == 0) {
        player.setMediaItem(streamItem())
    }
    player.stop()
    player.prepare()
    player.play()
}

// ---------------------------------------------------------------------------
// Listen tab
// ---------------------------------------------------------------------------

@Composable
fun PlayerScreen(controller: MediaController?) {
    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(false) }
    var hasError by remember { mutableStateOf(false) }
    var nowPlaying by remember { mutableStateOf<String?>(null) }

    DisposableEffect(controller) {
        val player = controller
        if (player == null) {
            onDispose { }
        } else {
            isPlaying = player.isPlaying
            isBuffering = player.playbackState == Player.STATE_BUFFERING
            nowPlaying = player.mediaMetadata.title?.toString()
                ?.takeIf { it != Config.STATION_NAME }

            val listener = object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying_: Boolean) {
                    isPlaying = isPlaying_
                    if (isPlaying_) hasError = false
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    isBuffering = playbackState == Player.STATE_BUFFERING
                }

                override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                    // Live streams usually send the current song as the title.
                    nowPlaying = mediaMetadata.title?.toString()
                        ?.takeIf { it != Config.STATION_NAME }
                }

                override fun onPlayerError(error: PlaybackException) {
                    hasError = true
                }
            }
            player.addListener(listener)
            onDispose { player.removeListener(listener) }
        }
    }

    // Reload the artwork whenever the show changes (and each time this screen opens).
    val artUrl = remember(nowPlaying) { "${Config.ARTWORK_URL}?t=${System.currentTimeMillis()}" }

    // Live streams usually send "DJ name - Show name" as one title: split it into two lines.
    val parts = nowPlaying?.split(" - ", limit = 2)?.map { it.trim() }.orEmpty()
    val djName = parts.getOrNull(0)?.takeIf { it.isNotEmpty() }
    val showName = parts.getOrNull(1)?.takeIf { it.isNotEmpty() }

    // A status message replaces the "Now Playing" block when there's nothing to show yet.
    val status: String? = when {
        hasError -> "Can't reach the stream. Tap play to retry."
        isBuffering && !isPlaying -> "Connecting\u2026"
        isPlaying -> if (djName == null) "Live now" else null
        else -> "Tap play to listen"
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // The current DJ's artwork, same size as the logo. While it loads, or if there is none,
        // the station logo is shown instead. The "?t=" part makes sure we never get a stale picture.
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(artUrl)
                .crossfade(true)
                .diskCachePolicy(CachePolicy.DISABLED)
                .memoryCachePolicy(CachePolicy.DISABLED)
                .build(),
            contentDescription = Config.STATION_NAME,
            placeholder = painterResource(R.drawable.station_logo),
            error = painterResource(R.drawable.station_logo),
            fallback = painterResource(R.drawable.station_logo),
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(220.dp)
                .clip(RoundedCornerShape(28.dp))
        )

        Spacer(Modifier.height(40.dp))

        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .clickable(enabled = controller != null) {
                    controller?.let { togglePlayback(it) }
                },
            contentAlignment = Alignment.Center
        ) {
            if (isBuffering && !isPlaying) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(36.dp)
                )
            } else {
                PlayPauseIcon(isPlaying, MaterialTheme.colorScheme.onPrimary)
            }
        }

        Spacer(Modifier.height(36.dp))

        // Fixed minimum height so the play button doesn't jump when the text changes.
        Column(
            modifier = Modifier.heightIn(min = 130.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (status != null) {
                ShadowText(status, fontSize = 18, weight = FontWeight.Normal, alpha = 0.85f)
            } else {
                ShadowText("Now Playing:", fontSize = 18, weight = FontWeight.Light, alpha = 0.75f)
                if (djName != null) {
                    ShadowText(
                        djName, fontSize = 26, weight = FontWeight.SemiBold, alpha = 1f,
                        topPadding = 12
                    )
                }
                if (showName != null) {
                    ShadowText(
                        showName, fontSize = 21, weight = FontWeight.Normal, alpha = 1f,
                        topPadding = 4
                    )
                }
            }
        }
    }
}

/** White text with a soft shadow so it stays readable over the wallpaper. */
@Composable
fun ShadowText(
    text: String,
    fontSize: Int,
    weight: FontWeight,
    alpha: Float,
    topPadding: Int = 0
) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = alpha),
        fontSize = fontSize.sp,
        fontWeight = weight,
        textAlign = TextAlign.Center,
        style = TextStyle(
            shadow = Shadow(
                color = Color.Black.copy(alpha = 0.85f),
                offset = Offset(0f, 2f),
                blurRadius = 12f
            )
        ),
        modifier = Modifier.padding(top = topPadding.dp)
    )
}

@Composable
fun PlayPauseIcon(playing: Boolean, color: Color) {
    Canvas(Modifier.size(40.dp)) {
        if (playing) {
            val barWidth = size.width * 0.28f
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.12f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(6f, 6f)
            )
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.60f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(6f, 6f)
            )
        } else {
            val triangle = Path().apply {
                moveTo(size.width * 0.20f, size.height * 0.05f)
                lineTo(size.width * 0.95f, size.height * 0.50f)
                lineTo(size.width * 0.20f, size.height * 0.95f)
                close()
            }
            drawPath(triangle, color)
        }
    }
}
