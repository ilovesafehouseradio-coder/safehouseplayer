package com.example.radioplayer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** What the stream server says is on air: the title text, and whether a live DJ is connected. */
class LiveStatus(val title: String, val liveDj: Boolean)

/**
 * Reads what's on air from the stream server's own status page.
 *
 * Returns the title text, "" if nothing is playing, or null if the page couldn't be read
 * (in which case the caller keeps showing what it already had).
 * Call this off the main thread.
 */
fun fetchNowPlayingTitle(): String? = fetchLiveStatus()?.title

/** Same as [fetchNowPlayingTitle], but also says whether a live DJ is connected (not the auto-DJ). */
fun fetchLiveStatus(): LiveStatus? {
    val conn = URL(Config.STATUS_URL).openConnection() as HttpURLConnection
    return try {
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.setRequestProperty("User-Agent", "SafehouseRadioApp/1.0")
        if (conn.responseCode !in 200..299) {
            null
        } else {
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            liveStatusFromStatus(body)
        }
    } catch (e: Exception) {
        null
    } finally {
        conn.disconnect()
    }
}

/**
 * Picks the current title out of the server's status JSON.
 * A live DJ connected on /stream wins; otherwise the auto-DJ (/autodj) title is used.
 */
fun titleFromStatus(body: String): String? = liveStatusFromStatus(body)?.title

fun liveStatusFromStatus(body: String): LiveStatus? {
    val root = JSONObject(body).optJSONObject("icestats") ?: return null

    // "source" is a single object when there's one stream and a list when there are several.
    val sources = ArrayList<JSONObject>()
    when (val s = root.opt("source")) {
        is JSONObject -> sources.add(s)
        is JSONArray -> {
            for (i in 0 until s.length()) {
                val item = s.optJSONObject(i)
                if (item != null) sources.add(item)
            }
        }
    }

    fun titleOf(source: JSONObject): String? =
        source.optString("title").trim().takeIf { it.isNotEmpty() && it != "null" }

    val live = sources.firstOrNull { it.optString("listenurl").endsWith("/stream") }
    val auto = sources.firstOrNull { it.optString("listenurl").endsWith("/autodj") }

    val liveTitle = live?.let { titleOf(it) }
    if (liveTitle != null) return LiveStatus(liveTitle, true)

    val other = (auto?.let { titleOf(it) }) ?: sources.firstNotNullOfOrNull { titleOf(it) }
    return LiveStatus(other ?: "", false)
}

/**
 * Splits the title into (DJ name, show name).
 * The station's titles look like "Cherish, TikTok Live 22-10-2026, Zebra," so the first two
 * comma-separated parts are used. Titles written as "DJ - Show" are handled too.
 */
fun splitNowPlaying(title: String?): Pair<String?, String?> {
    if (title.isNullOrBlank()) return Pair(null, null)
    val parts = if (title.contains(" - ")) title.split(" - ", limit = 2) else title.split(",")
    val clean = parts.map { it.trim() }.filter { it.isNotEmpty() }
    return Pair(clean.getOrNull(0), clean.getOrNull(1))
}

/**
 * What to show (and send to car displays and Chromecasts) for a stream title. [dj] is the name to
 * show: the DJ, or, when the stream only names a placeholder like "Syndicast" and no DJ of ours
 * matches, the station's own name ([generic] is then true). [match] is our DJ page, if any.
 */
class NowShown(val dj: String?, val show: String?, val match: Dj?, val generic: Boolean)

/**
 * Decides if a stream title is too poor to show or send out (a DJ who sends nonsense). Only plain
 * junk is caught: an empty title is "nothing playing" and is handled elsewhere, and an unusual but
 * readable title ("DJ X b2b Y - Live from Ibiza!!!") is always left alone.
 */
object StreamQuality {
    private val AUDIO_FILE = Regex("(?i)\\.(mp3|wav|flac|m4a|aac|ogg|oga|opus|wma|aiff?|mp4)\\b")
    private val URL_LIKE = Regex("(?i)(https?://|www\\.|\\.(com|co\\.uk|net|org|fm|io)/)")
    private val JUNK_WORD = Regex("(?i)^(null|none|n/?a|nil|unknown|undefined|untitled|no title|no name|test|testing|title|artist|-+|\\.+)$")
    private val GENERIC_TRACK = Regex("(?i)^(track|audio|recording|record|file|stream)\\s*[-_#]?\\s*\\d+$")

    fun isBad(title: String?): Boolean {
        val t = title?.trim().orEmpty()
        if (t.isEmpty()) return false
        if (t.length > 160 || '\uFFFD' in t) return true
        if (AUDIO_FILE.containsMatchIn(t) || URL_LIKE.containsMatchIn(t)) return true
        val letters = t.count { it.isLetterOrDigit() }
        if (letters < 2 || letters * 100 < t.length * 40) return true             // mostly symbols
        if (!t.contains(' ') && t.count { it == '_' } >= 2) return true            // mix_final_v2
        val parts = (if (t.contains(" - ")) t.split(" - ", limit = 2) else t.split(","))
            .map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.all { JUNK_WORD.matches(it) || GENERIC_TRACK.matches(it) }) return true
        if (parts.size == 2 && parts[0].equals(parts[1], ignoreCase = true)) return true
        return false
    }
}

object StreamNames {
    private val lock = Any()
    private var saved: List<Dj> = emptyList()
    private var savedShows: List<Show> = emptyList()
    private var savedAt = 0L

    /** True if the title needs our DJ list / the calendar to be shown well (a placeholder name or a poor title). */
    fun needsLists(title: String?): Boolean =
        StreamQuality.isBad(title) || DjMatch.isPlaceholder(splitNowPlaying(title).first)

    /** The DJ list and schedule saved on the phone (for the playback service, which has no screen state). Call off the main thread. */
    fun savedLists(dir: java.io.File): Pair<List<Dj>, List<Show>> = synchronized(lock) {
        val now = System.currentTimeMillis()
        if (saved.isEmpty() || savedShows.isEmpty() || now - savedAt > 5 * 60_000L) {
            DjCache.load(dir)?.djs?.let { saved = it; DjMatch.setKnown(it.map { d -> d.name }) }
            ScheduleCache.read(java.io.File(dir, "schedule.json"))?.shows?.let { savedShows = it }
            savedAt = now
        }
        saved to savedShows
    }

    /**
     * A title too poor to use: the DJ and show the calendar says are on air now, or, if it says nothing,
     * the station's own name and "All Day Every Day".
     */
    private fun fallback(djs: List<Dj>, shows: List<Show>, now: Instant): NowShown {
        val on = shows.filter { !it.isFiller && !it.start.isAfter(now) && it.end.isAfter(now) }.maxByOrNull { it.start }
        if (on != null) {
            val page = UpNext.djForShow(on, djs)
            val name = on.dj ?: page?.name
            return if (name != null) NowShown(name, on.title, page, false)
            else NowShown(Config.STATION_NAME, on.title, null, true)
        }
        return NowShown(Config.STATION_NAME, Config.FALLBACK_SHOW, null, true)
    }

    fun resolve(title: String?, djs: List<Dj>, shows: List<Show> = emptyList(), now: Instant = Instant.now()): NowShown {
        if (StreamQuality.isBad(title)) return fallback(djs, shows, now)
        val (d, s) = splitNowPlaying(title)
        val show = if (s == null || DjMatch.isPlaceholder(s)) null else DjMatch.scrub(s)
        if (d == null) return NowShown(null, null, null, false)
        if (!DjMatch.isPlaceholder(d)) return NowShown(DjMatch.scrub(d), show, UpNext.djFor(d, djs), false)
        val match = djs.firstOrNull { DjMatch.streamMatches(title, DjMatch.key(it.name)) }
        return if (match != null) NowShown(match.name, show, match, false)
        else NowShown(Config.STATION_NAME, show, null, true)
    }
}

/** The outcome of fetching the station artwork. */
class ArtFetch(
    val bytes: ByteArray?,    // the picture, or null (nothing usable)
    val failed: Boolean       // true if it was a network / decode problem (worth trying again)
)

/**
 * Downloads the DJ picture and shrinks it (max 600 pixels) to a small JPEG.
 * Car and Bluetooth displays are handed this picture directly, which is much more reliable
 * than giving them a web address. The bytes are null if it couldn't be fetched, or if it is just
 * the station's default picture (then [ArtFetch.failed] is false: nothing to retry).
 * Call this off the main thread.
 */
fun fetchArtworkResult(): ArtFetch {
    val conn = URL("${Config.ARTWORK_URL}?t=${System.currentTimeMillis()}")
        .openConnection() as HttpURLConnection
    try {
        conn.connectTimeout = 10000
        conn.readTimeout = 15000
        conn.setRequestProperty("User-Agent", "SafehouseRadioApp/1.0")
        if (conn.responseCode !in 200..299) return ArtFetch(null, true)
        val raw = conn.inputStream.use { it.readBytes() }

        // Read the size first, then decode at a reduced size so big pictures don't use much memory.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 600 && bounds.outHeight / (sample * 2) >= 600) sample *= 2
        val decode = BitmapFactory.Options().apply { inSampleSize = sample }
        val bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size, decode) ?: return ArtFetch(null, true)

        val longest = maxOf(bitmap.width, bitmap.height)
        val scaled = if (longest > 600) {
            Bitmap.createScaledBitmap(
                bitmap,
                bitmap.width * 600 / longest,
                bitmap.height * 600 / longest,
                true
            )
        } else {
            bitmap
        }
        // The station's plain default picture (sent when a show has no artwork) is skipped:
        // callers then show the app's own logo instead.
        val pixels = IntArray(scaled.width * scaled.height)
        scaled.getPixels(pixels, 0, scaled.width, 0, 0, scaled.width, scaled.height)
        if (GenericArt.isGeneric(pixels, scaled.width, scaled.height)) return ArtFetch(null, false)

        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
        return ArtFetch(out.toByteArray(), false)
    } catch (e: Exception) {
        return ArtFetch(null, true)
    } finally {
        conn.disconnect()
    }
}

/** Same as [fetchArtworkResult], keeping just the picture. */
fun fetchArtworkBytes(): ByteArray? = fetchArtworkResult().bytes

/**
 * The current show's picture, fetched once and shared by every part of the app (the Radio tab,
 * the On Air card, the notification and car display), so it is only downloaded once per show.
 * A failed download is never remembered, so it is tried again next time.
 */
object LiveArt {
    private val lock = Mutex()
    private var key: String? = null
    private var bytes: ByteArray? = null
    private var haveResult = false
    private var fetchedAt = 0L

    /**
     * [title] is the stream title of the show. The same title reuses the saved picture.
     * With no title, a picture fetched in the last [maxAgeMs] milliseconds is reused.
     * Returns null when there is no usable picture (none, or the station's default one).
     */
    suspend fun get(title: String?, maxAgeMs: Long = 20_000): ByteArray? = lock.withLock {
        val now = System.currentTimeMillis()
        val fresh = haveResult && (
            (title != null && title == key) ||
                (title == null && now - fetchedAt < maxAgeMs)
            )
        if (fresh) return@withLock bytes
        val result = withContext(Dispatchers.IO) { fetchArtworkResult() }
        if (result.failed) {
            haveResult = false
        } else {
            key = title
            bytes = result.bytes
            haveResult = true
            fetchedAt = now
        }
        result.bytes
    }
}
