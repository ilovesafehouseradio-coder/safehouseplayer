package com.example.radioplayer

import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

/**
 * Reads what's on air from the stream server's own status page.
 *
 * Returns the title text, "" if nothing is playing, or null if the page couldn't be read
 * (in which case the caller keeps showing what it already had).
 * Call this off the main thread.
 */
fun fetchNowPlayingTitle(): String? {
    val conn = URL(Config.STATUS_URL).openConnection() as HttpURLConnection
    return try {
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        conn.setRequestProperty("User-Agent", "SafehouseRadioApp/1.0")
        if (conn.responseCode !in 200..299) {
            null
        } else {
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            titleFromStatus(body)
        }
    } catch (e: Exception) {
        null
    } finally {
        conn.disconnect()
    }
}

/**
 * Picks the current title out of the server's status JSON.
 * A live DJ connected on /stream wins; otherwise the auto-DJ (/autodj) title is used.
 */
fun titleFromStatus(body: String): String? {
    val root = JSONObject(body).optJSONObject("icestats") ?: return null

    // "source" is a single object when there's one stream and a list when there are several.
    val sources = ArrayList<JSONObject>()
    when (val s = root.opt("source")) {
        is JSONObject -> sources.add(s)
        is JSONArray -> {
            for (i in 0 until s.length()) {
                val item = s.optJSONObject(i)
                if (item != null) sources.add(item)
            }
        }
    }

    fun titleOf(source: JSONObject): String? =
        source.optString("title").trim().takeIf { it.isNotEmpty() && it != "null" }

    val live = sources.firstOrNull { it.optString("listenurl").endsWith("/stream") }
    val auto = sources.firstOrNull { it.optString("listenurl").endsWith("/autodj") }

    return (live?.let { titleOf(it) })
        ?: (auto?.let { titleOf(it) })
        ?: sources.firstNotNullOfOrNull { titleOf(it) }
        ?: ""
}

/**
 * Splits the title into (DJ name, show name).
 * The station's titles look like "Cherish, TikTok Live 22-10-2026, Zebra," so the first two
 * comma-separated parts are used. Titles written as "DJ - Show" are handled too.
 */
fun splitNowPlaying(title: String?): Pair<String?, String?> {
    if (title.isNullOrBlank()) return Pair(null, null)
    val parts = if (title.contains(" - ")) title.split(" - ", limit = 2) else title.split(",")
    val clean = parts.map { it.trim() }.filter { it.isNotEmpty() }
    return Pair(clean.getOrNull(0), clean.getOrNull(1))
}
