package com.example.radioplayer

/**
 * Turns the genre text a DJ typed on their page into tidy pills for the profile: short (two words at
 * most; "and", "&" and dashes don't count as words), one standard spelling, no repeats, and in the
 * order the DJ wrote them (what a DJ lists first is taken as their main style).
 *
 * "Hard Techno with soaring melodic vibe" becomes "Hard Techno" and "Melodic Techno";
 * "Electronica with feeling" becomes "Electronica"; "Deep-House" becomes "Deep House";
 * "Drum & Bass" stays as one pill.
 */
object GenrePills {

    private const val MAX_PILLS = 12   // the profile also shows at most three rows of them

    private val LIST_SPLIT = Regex("[,;/|\\n\\u2022\\u00B7]+|\\s\\+\\s")
    private val STOP = Regex("(?i)\\b(?:with|w/|for|featuring|feat|plus|from|vibes?|style|flavou?rs?|infused|inspired|influenced|touch|hint|bit)\\b")
    private val CONNECTORS = setOf("&", "and", "n", "'n'", "+")
    private val WORD_SPLIT = Regex("[\\s\\-\\u2013\\u2014]+")

    // Words that can sit in front of a main genre, and the main genres they can sit in front of.
    private val MODIFIERS = setOf(
        "melodic", "dark", "deep", "driving", "hypnotic", "uplifting", "progressive", "soulful", "funky",
        "groovy", "hard", "acid", "minimal", "tribal", "raw", "industrial", "atmospheric", "peak", "organic"
    )
    private val CORE = setOf(
        "techno", "house", "trance", "garage", "disco", "funk", "breaks", "electro", "dubstep", "jungle", "bass"
    )

    // Standard spellings, keyed by the letters only.
    private val KNOWN = mapOf(
        "drumandbass" to "Drum & Bass", "drumnbass" to "Drum & Bass", "drumbass" to "Drum & Bass",
        "dnb" to "Drum & Bass", "dandb" to "Drum & Bass",
        "rnb" to "R&B", "randb" to "R&B", "edm" to "EDM",
        "hiphop" to "Hip Hop", "deephouse" to "Deep House", "techhouse" to "Tech House",
        "progressivehouse" to "Progressive House", "afrohouse" to "Afro House", "electrohouse" to "Electro House",
        "hardtechno" to "Hard Techno", "hardtrance" to "Hard Trance", "harddance" to "Hard Dance",
        "ukgarage" to "UK Garage", "bigroom" to "Big Room",
        // "I play everything" is not a genre: it is the same as saying nothing in particular.
        "everything" to "Multi genre", "anything" to "Multi genre", "allgenres" to "Multi genre",
        "eclectic" to "Multi genre", "various" to "Multi genre", "varied" to "Multi genre",
        "mixed" to "Multi genre", "multigenre" to "Multi genre", "multigenres" to "Multi genre",
        "multi" to "Multi genre", "allsorts" to "Multi genre"
    )

    fun fromText(text: String): List<String> {
        val out = LinkedHashMap<String, String>()
        for (piece in text.split(LIST_SPLIT)) {
            for (pill in fromPiece(piece)) {
                val k = pill.lowercase().filter { it.isLetterOrDigit() }
                if (k.isNotEmpty() && k !in out) out[k] = pill
            }
        }
        return out.values.take(MAX_PILLS)
    }

    private fun fromPiece(raw: String): List<String> {
        val clean = raw.trim().trim('.', '!', '"', '\'', '*', '(', ')', ':').replace(Regex("\\s+"), " ")
        if (clean.isEmpty()) return emptyList()

        // "Hard Techno with soaring melodic vibe": the genre is the part before "with", the rest may add a style.
        val stop = STOP.find(clean)
        val base = (if (stop != null) clean.substring(0, stop.range.first) else clean).trim().trim('-', ' ')
        val tail = if (stop != null) clean.substring(stop.range.last + 1) else ""
        if (base.isEmpty()) return emptyList()

        val pills = ArrayList<String>()
        val words = base.split(WORD_SPLIT).filter { it.isNotEmpty() }
        val real = words.filter { it.lowercase() !in CONNECTORS }
        if (real.size <= 2) {
            pills.add(normalise(base))
        } else if (words.size != real.size) {
            // "House & Techno & Trance": separate pills, each kept short.
            for (part in splitOnConnectors(words)) pills.addAll(fromPiece(part))
        } else {
            pills.add(normalise(real.take(2).joinToString(" ")))   // too long and no joiners: the first two words
        }

        // The "feeling" after the genre, if it is a known style word: "melodic" + "Techno" = "Melodic Techno".
        val core = real.lastOrNull()?.lowercase()
        if (core != null && core in CORE) {
            val modifier = tail.lowercase().split(Regex("[^a-z]+")).firstOrNull { it in MODIFIERS }
            if (modifier != null && modifier != real.first().lowercase()) {
                pills.add(normalise("$modifier $core"))
            }
        }
        return pills
    }

    private fun splitOnConnectors(words: List<String>): List<String> {
        val parts = ArrayList<String>()
        var current = ArrayList<String>()
        for (w in words) {
            if (w.lowercase() in CONNECTORS) {
                if (current.isNotEmpty()) parts.add(current.joinToString(" "))
                current = ArrayList()
            } else {
                current.add(w)
            }
        }
        if (current.isNotEmpty()) parts.add(current.joinToString(" "))
        return parts
    }

    /** One standard spelling: known names as listed, otherwise neat capitals ("EDM" stays, "deep-house" -> "Deep House"). */
    private fun normalise(text: String): String {
        val letters = text.lowercase().filter { it.isLetterOrDigit() }
        KNOWN[letters]?.let { return it }
        return text.split(WORD_SPLIT).filter { it.isNotEmpty() }.joinToString(" ") { w ->
            when {
                w.lowercase() in CONNECTORS -> "&"
                w.any { it.isDigit() } -> w
                w.length <= 4 && w.all { !it.isLowerCase() } -> w
                else -> w.lowercase().replaceFirstChar { it.uppercase() }
            }
        }
    }
}
