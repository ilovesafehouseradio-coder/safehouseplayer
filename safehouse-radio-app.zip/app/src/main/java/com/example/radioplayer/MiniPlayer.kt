package com.example.radioplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import coil.compose.AsyncImage

/**
 * The small "now playing" bar that sits just above the tab bar on every tab except Radio
 * (which has the full player). It shows the DJ and show, and has a play / pause button.
 * It appears once the radio has been started, and disappears again after "Stop".
 * It controls the same player as the rest of the app, so nothing restarts when you change tab.
 */
@Composable
fun MiniPlayerBar(controller: MediaController?, onOpenRadio: () -> Unit) {
    var hasItem by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf(Config.STATION_NAME) }
    var detail by remember { mutableStateOf("") }
    var artwork by remember { mutableStateOf<String?>(null) }

    DisposableEffect(controller) {
        val player = controller
        if (player == null) {
            hasItem = false
            return@DisposableEffect onDispose { }
        }
        fun sync() {
            hasItem = player.mediaItemCount > 0
            isPlaying = player.isPlaying
            isBuffering = player.playWhenReady && player.playbackState == Player.STATE_BUFFERING
            val meta = player.mediaMetadata
            title = meta.title?.toString()?.takeIf { it.isNotBlank() } ?: Config.STATION_NAME
            // The service puts the show name here, or "Live on Safehouse Radio" before it knows.
            detail = meta.artist?.toString()?.takeIf { it.isNotBlank() && !it.startsWith("Live on ") }
                ?: Config.STATION_NAME
            artwork = meta.artworkUri?.toString()
        }
        sync()
        val listener = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                sync()
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    if (controller == null || !hasItem) return

    val lavender = MaterialTheme.colorScheme.primary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xE6100C12))
            .clickable(onClick = onOpenRadio)
            .padding(start = 8.dp, top = 8.dp, bottom = 8.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = artwork,
            contentDescription = null,
            placeholder = painterResource(R.drawable.station_logo),
            error = painterResource(R.drawable.station_logo),
            fallback = painterResource(R.drawable.station_logo),
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(46.dp).clip(RoundedCornerShape(8.dp))
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "LIVE · $detail",
                color = Color(0xFFD0CAD8),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        // 48dp touch area; the visible circle inside is a little smaller.
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .clickable { togglePlayback(controller) }
                .semantics { contentDescription = if (isPlaying || isBuffering) "Pause" else "Play" },
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(lavender),
                contentAlignment = Alignment.Center
            ) {
                if (isBuffering && !isPlaying) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                } else {
                    MiniPlayPauseIcon(isPlaying, MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
    }
}

/** A small play / pause symbol, drawn the same way as the big one on the Radio tab. */
@Composable
private fun MiniPlayPauseIcon(playing: Boolean, color: Color) {
    Canvas(Modifier.size(18.dp)) {
        if (playing) {
            val barWidth = size.width * 0.28f
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.12f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(3f, 3f)
            )
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.60f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(3f, 3f)
            )
        } else {
            val triangle = Path().apply {
                moveTo(size.width * 0.20f, size.height * 0.05f)
                lineTo(size.width * 0.95f, size.height * 0.50f)
                lineTo(size.width * 0.20f, size.height * 0.95f)
                close()
            }
            drawPath(triangle, color)
        }
    }
}
