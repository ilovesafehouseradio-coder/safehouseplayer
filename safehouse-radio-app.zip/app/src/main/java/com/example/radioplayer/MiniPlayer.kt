package com.example.radioplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import coil.compose.AsyncImage
import java.nio.ByteBuffer

/**
 * The small "now playing" bar that sits just above the tab bar on Schedule, Chat and DJs (Radio has the full
 * player; More is just settings). It is always there, so the radio is one tap away from any of those tabs, before
 * the first Play too. It shows the DJ and show, and has a play / pause button. While the radio is playing it
 * shows what the player service sends; otherwise it keeps itself up to date from the station's status page.
 * It controls the same player as the rest of the app, so nothing restarts when you change tab.
 */
@Composable
fun MiniPlayerBar(controller: MediaController?, djs: List<Dj>, shows: List<Show>, onOpenRadio: () -> Unit) {
    var hasItem by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(false) }
    var playTitle by remember { mutableStateOf(Config.STATION_NAME) }
    var playDetail by remember { mutableStateOf("") }
    var playArtwork by remember { mutableStateOf<ByteArray?>(null) }
    // What the station says is on air, read here while the radio is not playing (null = not known yet).
    var polled by remember { mutableStateOf<String?>(null) }
    var idleArt by remember { mutableStateOf<ByteArray?>(null) }
    val turns = rememberTurns(2)   // the two lines slide (when too long) one after the other

    DisposableEffect(controller) {
        val player = controller
        if (player == null) {
            hasItem = false
            return@DisposableEffect onDispose { }
        }
        fun sync() {
            hasItem = player.mediaItemCount > 0
            isPlaying = player.isPlaying
            isBuffering = player.playWhenReady && player.playbackState == Player.STATE_BUFFERING
            val meta = player.mediaMetadata
            playTitle = DjMatch.scrub(meta.title?.toString())?.takeIf { it.isNotBlank() } ?: Config.STATION_NAME
            // The service puts the show name here, or "Live on Safehouse Radio" before it knows.
            playDetail = DjMatch.scrub(meta.artist?.toString())?.takeIf { it.isNotBlank() && !it.startsWith("Live on ") }
                ?: Config.STATION_NAME
            // The picture comes from the service as real image data: the DJ's artwork, or the
            // app's own logo tile when the station only sent its plain default picture.
            val data = meta.artworkData
            if (data == null) {
                if (playArtwork != null) playArtwork = null
            } else if (playArtwork?.contentEquals(data) != true) {
                playArtwork = data
            }
        }
        sync()
        val listener = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                sync()
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    // Not playing: keep up with the station's own status page (only while the app is on screen), so the bar is
    // ready with the latest show before Play is pressed. While playing, the service keeps the details.
    val appVisible by rememberAppVisible()
    val playingNow = isPlaying || isBuffering
    LaunchedEffect(appVisible, playingNow) {
        while (appVisible && !playingNow) {
            val t = withContext(Dispatchers.IO) { fetchNowPlayingTitle() }
            if (t != null) polled = t
            delay(15_000)
        }
    }
    val idle = remember(polled, djs, shows) { StreamNames.resolve(polled, djs, shows) }
    val idleTitle = idle.dj ?: Config.STATION_NAME
    val idleDetail = idle.show ?: if (idle.generic) Config.FALLBACK_SHOW else Config.STATION_NAME
    val appCtx = LocalContext.current.applicationContext
    val liveArtOn = LiveArtSwitch.on
    LaunchedEffect(polled, playingNow, liveArtOn) {
        if (!liveArtOn) {
            idleArt = null
            return@LaunchedEffect
        }
        if (playingNow || polled == null) return@LaunchedEffect
        idleArt = LiveArt.get(polled) ?: withContext(Dispatchers.Default) { ShowArt.bytes(appCtx, polled) }
    }
    val title = if (playingNow) playTitle else idleTitle
    val detail = if (playingNow) playDetail else idleDetail
    val artwork = if (playingNow) playArtwork else idleArt

    val lavender = MaterialTheme.colorScheme.primary
    // 64dp tall (taller only if the phone's text size is very large). The artwork fills the left end at
    // full height, cropped by the bar's rounded corners.
    val fontScale = LocalDensity.current.fontScale
    val barHeight = if (fontScale <= 1.3f) 64.dp else (64f * fontScale / 1.3f).dp
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)   // the same side margin as the cards on every page
            .lift(RoundedCornerShape(16.dp), tappable = true)
            .clip(RoundedCornerShape(16.dp))
            .background(ThemeState.current.cardSurface)
            .clickable(onClick = onOpenRadio)
            .height(barHeight),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = remember(artwork) { artwork?.let { ByteBuffer.wrap(it) } },
            contentDescription = null,
            placeholder = rememberLogoTile(),
            error = rememberLogoTile(),
            fallback = rememberLogoTile(),
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(barHeight)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                text = title,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = tightStyle(18.sp),
                modifier = Modifier.turnScroll(turns, 0, title)
            )
            Text(
                text = androidx.compose.ui.text.buildAnnotatedString {
                    withStyle(androidx.compose.ui.text.SpanStyle(color = ThemeState.current.live, fontWeight = FontWeight.Bold)) {
                        append("LIVE")
                    }
                    append(" · $detail")
                },
                color = ThemeState.current.textDim,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = tightStyle(16.sp),
                modifier = Modifier.turnScroll(turns, 1, detail)
            )
        }
        Spacer(Modifier.width(4.dp))
        // 48dp touch area; the visible circle inside is a little smaller.
        Box(
            modifier = Modifier
                .padding(end = 8.dp)
                .size(48.dp)
                .clip(CircleShape)
                .clickable { controller?.let { togglePlayback(it) } }
                .semantics { contentDescription = if (isPlaying || isBuffering) "Pause" else "Play" },
            contentAlignment = Alignment.Center
        ) {
            // Waiting to be pressed: a lighter lilac with a soft glow, to draw the eye.
            // Playing: the standard lilac, no glow and no movement.
            val waiting = !isPlaying && !isBuffering
            Box(
                Modifier
                    .size(40.dp)
                    .drawBehind {
                        if (waiting) {
                            for (i in 0 until 3) {
                                drawCircle(
                                    color = ThemeState.current.edge.copy(alpha = 0.12f),
                                    radius = size.minDimension / 2f + (4 - i) * 1.dp.toPx()
                                )
                            }
                        }
                    }
                    .clip(CircleShape)
                    .background(if (waiting) ThemeState.current.edge else lavender),
                contentAlignment = Alignment.Center
            ) {
                if (isBuffering && !isPlaying) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                } else {
                    MiniPlayPauseIcon(isPlaying, MaterialTheme.colorScheme.onPrimary)
                }
            }
        }
    }
}

/** A small play / pause symbol, drawn the same way as the big one on the Radio tab. */
@Composable
private fun MiniPlayPauseIcon(playing: Boolean, color: Color) {
    Canvas(Modifier.size(18.dp)) {
        if (playing) {
            val barWidth = size.width * 0.28f
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.12f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(3f, 3f)
            )
            drawRoundRect(
                color = color,
                topLeft = Offset(size.width * 0.60f, size.height * 0.08f),
                size = Size(barWidth, size.height * 0.84f),
                cornerRadius = CornerRadius(3f, 3f)
            )
        } else {
            val triangle = Path().apply {
                moveTo(size.width * 0.20f, size.height * 0.05f)
                lineTo(size.width * 0.95f, size.height * 0.50f)
                lineTo(size.width * 0.20f, size.height * 0.95f)
                close()
            }
            drawPath(triangle, color)
        }
    }
}
