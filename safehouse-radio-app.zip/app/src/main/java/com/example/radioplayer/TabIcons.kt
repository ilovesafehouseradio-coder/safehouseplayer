package com.example.radioplayer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

enum class TabIcon { RADIO, SCHEDULE, CHAT, DJS, WEBSITE }

/**
 * Simple outline icons drawn in code (24 x 24 grid, rounded line ends),
 * coloured by whatever the tab bar says (selected / not selected).
 */
@Composable
fun TabIconView(icon: TabIcon) {
    val color = LocalContentColor.current
    Canvas(Modifier.size(24.dp)) {
        val u = size.width / 24f // one grid unit in pixels
        val stroke = Stroke(width = 1.8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (icon) {
            TabIcon.RADIO -> drawRadio(color, u, stroke)
            TabIcon.SCHEDULE -> drawCalendar(color, u, stroke)
            TabIcon.CHAT -> drawChat(color, u, stroke)
            TabIcon.DJS -> drawHeadphones(color, u, stroke)
            TabIcon.WEBSITE -> drawGlobe(color, u, stroke)
        }
    }
}

private fun DrawScope.line(color: Color, u: Float, stroke: Stroke, x1: Float, y1: Float, x2: Float, y2: Float) {
    drawLine(
        color = color,
        start = Offset(x1 * u, y1 * u),
        end = Offset(x2 * u, y2 * u),
        strokeWidth = stroke.width,
        cap = StrokeCap.Round
    )
}

private fun DrawScope.dot(color: Color, u: Float, x: Float, y: Float, r: Float) {
    drawCircle(color = color, radius = r * u, center = Offset(x * u, y * u))
}

private fun DrawScope.drawRadio(color: Color, u: Float, stroke: Stroke) {
    drawRoundRect(
        color = color,
        topLeft = Offset(3f * u, 8f * u),
        size = Size(18f * u, 12f * u),
        cornerRadius = CornerRadius(2.5f * u),
        style = stroke
    )
    line(color, u, stroke, 8f, 8f, 17f, 4f) // aerial
    drawCircle(color = color, radius = 2.8f * u, center = Offset(8.5f * u, 14f * u), style = stroke)
    line(color, u, stroke, 14f, 12.5f, 18f, 12.5f)
    line(color, u, stroke, 14f, 16f, 18f, 16f)
}

private fun DrawScope.drawCalendar(color: Color, u: Float, stroke: Stroke) {
    drawRoundRect(
        color = color,
        topLeft = Offset(3.5f * u, 5f * u),
        size = Size(17f * u, 15.5f * u),
        cornerRadius = CornerRadius(2.5f * u),
        style = stroke
    )
    line(color, u, stroke, 4.2f, 10f, 19.8f, 10f)
    line(color, u, stroke, 8f, 3f, 8f, 6.5f)
    line(color, u, stroke, 16f, 3f, 16f, 6.5f)
    for (x in listOf(8f, 12f, 16f)) dot(color, u, x, 14.2f, 1.1f)
    for (x in listOf(8f, 12f)) dot(color, u, x, 17.4f, 1.1f)
}

/** A curve from (x0,y0) to (x1,y1) bending towards (cx,cy), all in grid units. */
private fun Path.curve(u: Float, x0: Float, y0: Float, cx: Float, cy: Float, x1: Float, y1: Float) {
    val k = 2f / 3f
    cubicTo(
        (x0 + k * (cx - x0)) * u, (y0 + k * (cy - y0)) * u,
        (x1 + k * (cx - x1)) * u, (y1 + k * (cy - y1)) * u,
        x1 * u, y1 * u
    )
}

private fun DrawScope.drawChat(color: Color, u: Float, stroke: Stroke) {
    val bubble = Path().apply {
        moveTo(7f * u, 4f * u)
        lineTo(17f * u, 4f * u)
        curve(u, 17f, 4f, 21f, 4f, 21f, 8f)
        lineTo(21f * u, 13f * u)
        curve(u, 21f, 13f, 21f, 17f, 17f, 17f)
        lineTo(12.5f * u, 17f * u)
        lineTo(8f * u, 21f * u)
        lineTo(8f * u, 17f * u)
        lineTo(7f * u, 17f * u)
        curve(u, 7f, 17f, 3f, 17f, 3f, 13f)
        lineTo(3f * u, 8f * u)
        curve(u, 3f, 8f, 3f, 4f, 7f, 4f)
        close()
    }
    drawPath(path = bubble, color = color, style = stroke)
    for (x in listOf(8f, 12f, 16f)) dot(color, u, x, 10.5f, 1.05f)
}

private fun DrawScope.drawHeadphones(color: Color, u: Float, stroke: Stroke) {
    drawArc(
        color = color,
        startAngle = 180f,
        sweepAngle = 180f,
        useCenter = false,
        topLeft = Offset(4f * u, 5f * u),
        size = Size(16f * u, 16f * u),
        style = stroke
    )
    drawRoundRect(
        color = color,
        topLeft = Offset(3f * u, 13f * u),
        size = Size(4.5f * u, 7f * u),
        cornerRadius = CornerRadius(2f * u)
    )
    drawRoundRect(
        color = color,
        topLeft = Offset(16.5f * u, 13f * u),
        size = Size(4.5f * u, 7f * u),
        cornerRadius = CornerRadius(2f * u)
    )
}

private fun DrawScope.drawGlobe(color: Color, u: Float, stroke: Stroke) {
    drawCircle(color = color, radius = 9f * u, center = Offset(12f * u, 12f * u), style = stroke)
    drawOval(
        color = color,
        topLeft = Offset(7.5f * u, 3f * u),
        size = Size(9f * u, 18f * u),
        style = stroke
    )
    line(color, u, stroke, 3.8f, 12f, 20.2f, 12f)
    line(color, u, stroke, 5.6f, 7.5f, 18.4f, 7.5f)
    line(color, u, stroke, 5.6f, 16.5f, 18.4f, 16.5f)
}

// ---------------------------------------------------------------------------
// Small icons for the buttons beside the play button on the Radio tab
// ---------------------------------------------------------------------------

enum class ActionIcon { SLEEP, SHARE }

@Composable
fun ActionIconView(icon: ActionIcon, color: Color) {
    Canvas(Modifier.size(26.dp)) {
        val u = size.width / 24f
        val stroke = Stroke(width = 1.8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (icon) {
            ActionIcon.SLEEP -> drawMoon(color, u)
            ActionIcon.SHARE -> drawShare(color, u, stroke)
        }
    }
}

/** A crescent moon: a full circle with a smaller circle cut out of it. */
private fun DrawScope.drawMoon(color: Color, u: Float) {
    val full = Path().apply {
        addOval(Rect(Offset(4f * u, 4f * u), Size(16f * u, 16f * u)))
    }
    val cut = Path().apply {
        addOval(Rect(Offset(9.5f * u, 1.5f * u), Size(13f * u, 13f * u)))
    }
    val moon = Path.combine(PathOperation.Difference, full, cut)
    drawPath(path = moon, color = color)
}

private fun DrawScope.drawShare(color: Color, u: Float, stroke: Stroke) {
    line(color, u, stroke, 8.2f, 11f, 15.8f, 6.8f)
    line(color, u, stroke, 8.2f, 13f, 15.8f, 17.2f)
    drawCircle(color = color, radius = 2.6f * u, center = Offset(6f * u, 12f * u), style = stroke)
    drawCircle(color = color, radius = 2.6f * u, center = Offset(18f * u, 5.8f * u), style = stroke)
    drawCircle(color = color, radius = 2.6f * u, center = Offset(18f * u, 18.2f * u), style = stroke)
}
