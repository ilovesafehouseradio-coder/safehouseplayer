package com.example.radioplayer

import android.content.Intent
import android.net.Uri
import android.text.Html
import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------

data class Dj(val name: String, val link: String, val imageUrl: String?)

/** Holds the DJ list and search box so they survive switching tabs. */
class DjListState {
    var djs by mutableStateOf<List<Dj>>(emptyList())
    var loading by mutableStateOf(false)
    var failed by mutableStateOf(false)
    var query by mutableStateOf("")
    var open by mutableStateOf<Dj?>(null)      // the DJ whose page is open (null = the list)
    var openWeb by mutableStateOf(false)       // showing the website's own page for that DJ
    val profiles = java.util.concurrent.ConcurrentHashMap<String, DjProfile>() // pages already read, so reopening is instant
    var groupsVersion by mutableStateOf(0)     // goes up when the groups learned from the bios change
    val profileAt = java.util.concurrent.ConcurrentHashMap<String, Long>() // when each page was read
    private var lastLoaded = 0L
    private var cacheDir: java.io.File? = null

    /** Where the DJ list and pages are saved between runs. */
    fun useCache(dir: java.io.File) {
        cacheDir = dir
    }

    /** Fills in the saved list and pages (if any), so the tab is ready before the internet answers. */
    fun loadFromCache() {
        val dir = cacheDir ?: return
        if (djs.isNotEmpty()) return
        val saved = DjCache.load(dir) ?: return
        djs = saved.djs
        lastLoaded = saved.listAt
        profiles.putAll(saved.profiles)
        profileAt.putAll(saved.profileAt)
    }

    /** Saves the list and pages. Call off the main thread. */
    fun saveCache() {
        val dir = cacheDir ?: return
        DjCache.save(dir, lastLoaded, djs, HashMap(profiles), HashMap(profileAt))
    }

    /** Remembers a page just read. */
    fun rememberProfile(link: String, profile: DjProfile) {
        profiles[link] = profile
        profileAt[link] = System.currentTimeMillis()
    }

    /** True if the list has never loaded, or is more than 10 minutes old. */
    fun needsRefresh(): Boolean =
        djs.isEmpty() || System.currentTimeMillis() - lastLoaded > 10 * 60 * 1000

    suspend fun load() {
        loading = true
        failed = false
        try {
            // Only replace the list on success, so a failed refresh keeps what we had.
            val fresh = withContext(Dispatchers.IO) { fetchAllDjs() }
            djs = fresh
            lastLoaded = System.currentTimeMillis()
            withContext(Dispatchers.IO) { saveCache() }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e   // leaving the tab part-way is not a failure
        } catch (e: Exception) {
            failed = true
        } finally {
            loading = false
        }
    }
}

/** Reads the DJ list from the station website's own WordPress feed (all pages). */
private fun fetchAllDjs(): List<Dj> {
    val result = mutableListOf<Dj>()
    var page = 1
    var totalPages = 1
    while (page <= totalPages && page <= 10) {
        val conn = URL("${Config.DJS_API_URL}&page=$page").openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("User-Agent", "SafehouseRadioApp/1.0")
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
            totalPages = conn.getHeaderField("X-WP-TotalPages")?.toIntOrNull() ?: 1
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            result.addAll(parseDjs(body))
        } finally {
            conn.disconnect()
        }
        page++
    }
    // distinctBy: if the site changes mid-download, never show (or crash on) a duplicate DJ.
    return result.distinctBy { it.link }.sortedBy { it.name.lowercase() }
}

private fun parseDjs(body: String): List<Dj> {
    val arr = JSONArray(body)
    val out = ArrayList<Dj>(arr.length())
    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val rawTitle = o.optJSONObject("title")?.optString("rendered").orEmpty()
        // Titles come HTML-encoded, e.g. "Above &amp; Beyond".
        val name = Html.fromHtml(rawTitle, Html.FROM_HTML_MODE_LEGACY).toString().trim()
        val link = o.optString("link")
        if (name.isEmpty() || link.isEmpty()) continue

        val media = o.optJSONObject("_embedded")
            ?.optJSONArray("wp:featuredmedia")
            ?.optJSONObject(0)
        val medium = media?.optJSONObject("media_details")
            ?.optJSONObject("sizes")
            ?.optJSONObject("medium")
            ?.optString("source_url")
            ?.takeIf { it.isNotBlank() }
        val full = media?.optString("source_url")?.takeIf { it.isNotBlank() }

        out.add(Dj(name, link, medium ?: full))
    }
    return out
}

// ---------------------------------------------------------------------------
// DJs tab
// ---------------------------------------------------------------------------

@Composable
fun DjScreen(state: DjListState, schedule: ScheduleState, onOpenReminderSetup: () -> Unit) {
    // Runs each time you open the tab: picks up new or changed DJs from the website.
    LaunchedEffect(Unit) {
        if (!state.loading && state.needsRefresh()) state.load()
    }

    // Kept here (not inside the list) so the list is exactly where you left it after a DJ's page.
    val gridState = rememberLazyGridState()

    val open = state.open
    when {
        open != null && state.openWeb -> DjPage(url = open.link, onBack = { state.openWeb = false })
        open != null -> DjProfilePage(open, state, schedule, onOpenReminderSetup)
        else -> DjList(state, schedule, gridState)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DjList(state: DjListState, schedule: ScheduleState, gridState: LazyGridState) {
    val scope = rememberCoroutineScope()
    // The moment this page was opened. The order is worked out from it, so it moves along each time
    // you come back to the page (and when the schedule updates), but never shuffles while you look.
    val openedAt = remember { java.time.Instant.now() }
    val textColor = MaterialTheme.colorScheme.onBackground

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        PageHeader("Our DJs", horizontalPadding = 0.dp)

        SearchField(
            value = state.query,
            onValueChange = { state.query = it },
            placeholder = "Search DJs…",
            modifier = Modifier.padding(bottom = 12.dp)
        )

        val shown = remember(state.djs, state.query, schedule.shows, state.groupsVersion) {
            val q = state.query.trim()
            if (q.isEmpty()) {
                // Live now, then up next, then the next few days, then everyone else A to Z.
                DjOrder.order(state.djs, schedule.shows, openedAt)
            } else {
                // While searching, the order stays A to Z.
                DjOrder.order(state.djs, schedule.shows, openedAt)
                    .filter { it.first.name.contains(q, ignoreCase = true) }
                    .sortedBy { it.first.name.lowercase() }
            }
        }

        when {
            state.loading && state.djs.isEmpty() -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            }

            state.djs.isEmpty() -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (state.failed) "Couldn't load the DJ list." else "No DJs found.",
                        color = textColor
                    )
                    Button(
                        onClick = { scope.launch { state.load() } },
                        modifier = Modifier.padding(top = 12.dp)
                    ) {
                        Text("Try again")
                    }
                }
            }

            shown.isEmpty() -> {
                Text(
                    text = "No DJs match \"${state.query.trim()}\".",
                    color = textColor,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }

            else -> {
                // Pull down on the grid to reload the DJ list.
                PullToRefreshBox(
                    isRefreshing = state.loading,
                    onRefresh = { scope.launch { state.load() } },
                    modifier = Modifier.fillMaxSize()
                ) {
                LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(shown, key = { it.first.link }) { (dj, tier) ->
                        DjCard(dj, tier) {
                            state.openWeb = false
                            state.open = dj
                        }
                    }
                }
                }
            }
        }
    }
}

@Composable
private fun DjCard(dj: Dj, tier: DjTier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val featured = tier == DjTier.LIVE || tier == DjTier.UP_NEXT
    Column(
        Modifier
            .followedGlow(shape, featured)
            .lift(shape, tappable = true)
            .clip(shape)
            .background(CardSurface)
            .then(
                when {
                    featured -> Modifier.border(2.dp, FollowedEdge, shape)
                    tier == DjTier.SOON -> Modifier.border(1.dp, FollowedEdge.copy(alpha = 0.55f), shape)
                    else -> Modifier
                }
            )
            .clickable(onClick = onClick)
    ) {
        Box {
            AsyncImage(
                model = dj.imageUrl,
                contentDescription = dj.name,
                placeholder = painterResource(R.drawable.station_logo_tile),
                error = painterResource(R.drawable.station_logo_tile),
                fallback = painterResource(R.drawable.station_logo_tile),
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(1f)
            )
            if (featured) {
                Text(
                    text = if (tier == DjTier.LIVE) "LIVE" else "UP NEXT",
                    color = LavenderInk,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(FollowedEdge)
                        .padding(horizontal = 10.dp, vertical = 3.dp)
                )
            }
        }
        // The name sits in a lavender strip. The strip is always tall enough for exactly two lines
        // (set in "sp" so it grows with the phone's text size), so every card is the same height
        // whether the name is one line or two. Two-line names are packed a little closer together.
        val stripHeight = with(LocalDensity.current) { (NAME_LINE * 2).toDp() } + 20.dp
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(stripHeight)
                .background(MaterialTheme.colorScheme.primary)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = dj.name,
                color = LavenderInk,
                fontSize = 14.sp,
                lineHeight = NAME_LINE,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/** A DJ page read less than this long ago is not read again when the profile opens. */
private const val PROFILE_FRESH_MS = 24L * 60 * 60 * 1000

private val NAME_LINE = 18.sp   // the gap between the two lines of a DJ's name

// ---------------------------------------------------------------------------
// A DJ's page, in the app's own style
// ---------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DjProfilePage(dj: Dj, state: DjListState, schedule: ScheduleState, onOpenReminderSetup: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val zone = remember { ZoneId.systemDefault() }
    val is24 = DateFormat.is24HourFormat(ctx)
    val timeFmt = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a") }
    val dayFmt = remember { DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault()) }
    val now = remember { Instant.now() }

    // The page text, photo and links come from the website (kept for next time).
    var profile by remember(dj.link) { mutableStateOf(state.profiles[dj.link]) }
    var failed by remember(dj.link) { mutableStateOf(false) }
    LaunchedEffect(dj.link) {
        schedule.followed = Reminders.followedKeys(ctx)
        schedule.showsOn = Reminders.showsOn(ctx)
        schedule.showsOff = Reminders.showsOff(ctx)
        schedule.setupSeen = Reminders.setupSeen(ctx)
        // A page read in the last day is used as it is; an older one is shown at once and refreshed behind it.
        val age = System.currentTimeMillis() - (state.profileAt[dj.link] ?: 0L)
        if (profile == null || age > PROFILE_FRESH_MS) {
            val loaded = withContext(Dispatchers.IO) { fetchDjProfile(dj.link, dj.name) }
            if (loaded != null) {
                state.rememberProfile(dj.link, loaded)
                profile = loaded
                withContext(Dispatchers.IO) { state.saveCache() }
            } else if (profile == null) {
                failed = true
            }
        }
    }

    // This DJ's coming shows, from the schedule we already load. Back-to-back slots of one event are
    // joined first, so a DJ in an event sees the whole event.
    val grouped = remember(schedule.shows) { Events.group(schedule.shows) }
    val mine = remember(grouped, dj.name, state.groupsVersion) {
        val k = DjMatch.key(dj.name)
        // Live shows, events, and this DJ's own "repeat show" slots (but not the empty "Repeat shows" fillers).
        grouped
            .filter { !(it.isFiller && it.dj == null) && it.end.isAfter(now) && DjMatch.showMatches(it, k) }
            .sortedBy { it.start }
    }
    val followName = mine.firstOrNull { it.dj != null && DjMatch.key(it.dj) == DjMatch.key(dj.name) }?.dj ?: dj.name
    val following = schedule.followed.any { DjMatch.key(it) == DjMatch.key(followName) }

    // Does this show get a reminder? (The same rule the Schedule tab uses.)
    fun reminded(s: Show): Boolean =
        FollowRules.reminderKey(s, schedule.followed, schedule.showsOn, schedule.showsOff) != null
    fun tagFor(s: Show): String? = when {
        !reminded(s) -> null
        FollowRules.isFollowing(s, schedule.followed) -> "Following"
        else -> "Reminder on"
    }

    // The switch on one show: follows the rules in FollowRules (off = skip it, on = just that show).
    fun switchShow(s: Show, wantOn: Boolean) {
        val djFollowed = FollowRules.isFollowing(s, schedule.followed)
        val k = DjMatch.followedKey(s, schedule.followed)?.let { DjMatch.key(it) } ?: DjMatch.key(followName)
        Reminders.setShowReminder(ctx, k, followName, FollowRules.showKey(s.title), wantOn, djFollowed)
        schedule.showsOn = Reminders.showsOn(ctx)
        schedule.showsOff = Reminders.showsOff(ctx)
        val app = ctx.applicationContext
        scope.launch(Dispatchers.Default) { Reminders.rebuild(app, schedule.shows) }
        if (wantOn && !djFollowed && !schedule.setupSeen) onOpenReminderSetup()
    }

    fun whenText(s: Show): String {
        val d = s.start.atZone(zone).toLocalDate()
        val today = now.atZone(zone).toLocalDate()
        val day = when (d) {
            today -> "Today"
            today.plusDays(1) -> "Tomorrow"
            else -> dayFmt.format(d)
        }
        return "$day · ${timeFmt.format(s.start.atZone(zone))} – ${timeFmt.format(s.end.atZone(zone))}"
    }

    // "Today", "Tomorrow" or "Mon 2 Nov" (for the switch rows).
    fun whenShort(s: Show): String {
        val d = s.start.atZone(zone).toLocalDate()
        val today = now.atZone(zone).toLocalDate()
        return when {
            !s.start.isAfter(now) -> "On now"
            d == today -> "Today"
            d == today.plusDays(1) -> "Tomorrow"
            else -> dayFmt.format(d)
        }
    }

    fun openLink(url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            // No app can open it: nothing to do.
        }
    }

    Column(Modifier.fillMaxSize()) {
        PageHeader(
            title = dj.name,
            leading = {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(start = 4.dp)
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(onClickLabel = "Back to all DJs", role = Role.Button) {
                            state.open = null
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_arrow_back),
                        contentDescription = "Back to all DJs",
                        tint = LavenderInk,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        )

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, bottom = 24.dp)
        ) {
            // Photo: the small one from the list shows at once, the sharp one replaces it.
            val photo = profile?.photoUrl ?: dj.imageUrl
            AsyncImage(
                model = ImageRequest.Builder(ctx)
                    .data(photo)
                    .placeholderMemoryCacheKey(dj.imageUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = dj.name,
                placeholder = painterResource(R.drawable.station_logo_tile),
                error = painterResource(R.drawable.station_logo_tile),
                fallback = painterResource(R.drawable.station_logo_tile),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .lift(RoundedCornerShape(20.dp))
                    .clip(RoundedCornerShape(20.dp))
            )

            val p = profile
            if (p != null && p.genres.isNotEmpty()) {
                FlowRow(
                    modifier = Modifier.padding(top = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    maxLines = 3     // a DJ's main genres only: anything that would need a fourth row is left off
                ) {
                    for (g in p.genres) {
                        Text(
                            text = g,
                            color = LavenderInk,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .lift(RoundedCornerShape(50))
                                .clip(RoundedCornerShape(50))
                                .background(MaterialTheme.colorScheme.primary)
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Follow: one pill for the whole DJ, on its own (not inside any card).
            FollowPill(
                following = following,
                onToggle = {
                    if (toggleFollowDj(ctx, schedule, scope, followName) && !schedule.setupSeen) {
                        onOpenReminderSetup()
                    }
                },
                modifier = Modifier.padding(top = 14.dp)
            )
            Text(
                text = "Reminder ${Reminders.LEAD_MINUTES} minutes before live shows",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
            )

            // Reminders by show: up to five of this DJ's shows, each with its own switch.
            val showRows = mine.filter { !it.isFiller }.distinctBy { FollowRules.showKey(it.title) }.take(5)
            if (showRows.isNotEmpty()) {
                DjSectionLabel("Reminders by show")
                Column(
                    Modifier
                        .fillMaxWidth()
                        .lift(RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .background(CardSurface)
                        .padding(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 12.dp)
                ) {
                    showRows.forEachIndexed { i, s ->
                        if (i > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x1FFFFFFF)))
                        ShowSwitchRow(
                            title = s.title,
                            next = "Next: " + whenShort(s),
                            on = reminded(s),
                            onChange = { switchShow(s, it) }
                        )
                    }
                    Text(
                        text = if (following) {
                            "Following turns on every show. Switch one off to skip it."
                        } else {
                            "Switch a show on to get reminders for just that show."
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }

            // Next show (or "on now"), with the reminder button.
            // A live show comes first; a repeat is shown here only if there is nothing live coming up.
            val next = mine.firstOrNull { !it.isFiller } ?: mine.firstOrNull()
            DjSectionLabel(if (next != null && !next.start.isAfter(now)) "On now" else "Next show")
            val nextTag = if (next != null) tagFor(next) else null
            Column(
                Modifier
                    .fillMaxWidth()
                    .followedGlow(RoundedCornerShape(16.dp), nextTag != null)
                    .lift(RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (next != null) LilacSurface else CardSurface)
                    .then(
                        if (next != null) {
                            Modifier.drawBehind { drawRect(LilacEdge, size = Size(4.dp.toPx(), size.height)) }
                        } else {
                            Modifier
                        }
                    )
                    .then(if (nextTag != null) Modifier.border(2.dp, FollowedEdge, RoundedCornerShape(16.dp)) else Modifier)
                    .padding(start = if (next != null) 18.dp else 14.dp, top = 14.dp, end = 14.dp, bottom = 14.dp)
            ) {
                if (next != null) {
                    Text(
                        text = whenText(next),
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = showLabel(next),
                        color = Color(0xFFDDD8EC),
                        fontSize = 15.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                } else {
                    Text(
                        text = "Not on the schedule in the coming months.",
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 15.sp
                    )
                }
                if (nextTag != null) {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                        FollowTag(nextTag)
                    }
                }
            }

            val later = mine.filter { it !== next }
            if (later.isNotEmpty()) {
                DjSectionLabel("Later")
                for (s in later.take(4)) {
                    val laterTag = tagFor(s)
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                            .followedGlow(RoundedCornerShape(14.dp), laterTag != null)
                            .lift(RoundedCornerShape(14.dp))
                            .clip(RoundedCornerShape(14.dp))
                            .background(CardSurface)
                            .then(if (laterTag != null) Modifier.border(2.dp, FollowedEdge, RoundedCornerShape(14.dp)) else Modifier)
                            .padding(14.dp)
                    ) {
                        Text(
                            text = whenText(s),
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = showLabel(s),
                            color = MaterialTheme.colorScheme.onBackground,
                            fontSize = 15.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        if (laterTag != null) {
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                                FollowTag(laterTag)
                            }
                        }
                    }
                }
            }

            // The bio (only when the page really has one).
            if (p != null) {
                DjSectionLabel("About")
                if (p.paragraphs.isNotEmpty()) DjAbout(p.paragraphs) else DjNoBio()
            }

            if (p != null && p.links.isNotEmpty()) {
                DjSectionLabel("Links")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (link in p.links) {
                        Box(
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .lift(RoundedCornerShape(50), tappable = true)
                                .clip(RoundedCornerShape(50))
                                .background(CardSurface)
                                .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(50))
                                .clickable(onClickLabel = "Open ${link.label}", role = Role.Button) { openLink(link.url) }
                                .padding(horizontal = 18.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = link.label,
                                color = MaterialTheme.colorScheme.onBackground,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            if (p == null && !failed) {
                Row(
                    modifier = Modifier.padding(top = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "  Loading profile…",
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 14.sp
                    )
                }
            }
            if (failed) {
                Text(
                    text = "Couldn't load the full profile. You can still see it on the website below.",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 18.dp)
                )
            }

            Box(
                modifier = Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .clickable(onClickLabel = "Open the website page", role = Role.Button) { state.openWeb = true },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "View full page on the website",
                    color = Color(0xFFD0CAD8),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textDecoration = TextDecoration.Underline
                )
            }
        }
    }
}

@Composable
private fun DjSectionLabel(text: String) {
    Text(
        text = text,
        color = Color(0xFFC4BFDA),
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 18.dp, bottom = 8.dp)
    )
}

/** The line under the time: the show name, with "Event · " in front of a joined-up event or a long block. */
private fun showLabel(s: Show): String {
    val long = java.time.Duration.between(s.start, s.end).toMinutes() >= 240
    return if (s.isEvent || long) "Event · ${s.title}" else s.title
}

/** Shown when a DJ's page has no bio yet: same card as the bio. */
@Composable
private fun DjNoBio() {
    Box(
        Modifier
            .fillMaxWidth()
            .lift(RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .padding(14.dp)
    ) {
        Text(
            text = "Bio coming soon",
            color = Color(0xFFD0CAD8),
            fontSize = 15.sp,
            lineHeight = 23.sp
        )
    }
}

/** The bio: first lines, with "Read more" when it's long. */
@Composable
private fun DjAbout(paragraphs: List<String>) {
    var expanded by remember { mutableStateOf(false) }
    val text = remember(paragraphs) { paragraphs.joinToString("\n\n") }
    val long = text.length > 320
    Column(
        Modifier
            .fillMaxWidth()
            .lift(RoundedCornerShape(16.dp), tappable = long)
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            // A long bio opens and closes with a tap anywhere on the card (a drag still scrolls).
            .clickable(
                enabled = long,
                onClickLabel = if (expanded) "Show less" else "Read more",
                role = Role.Button
            ) { expanded = !expanded }
            .padding(14.dp)
    ) {
        Text(
            text = text,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 15.sp,
            lineHeight = 23.sp,
            maxLines = if (expanded || !long) Int.MAX_VALUE else 7,
            overflow = TextOverflow.Ellipsis
        )
        if (long) {
            // The words are just the label: the whole card above is the button.
            Box(
                modifier = Modifier.heightIn(min = 48.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = if (expanded) "Show less" else "Read more",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Follow / Following: one pill for the whole DJ, full width, on its own.
 * Off: dark fill, thin lilac outline, outline bell. On: filled lavender, dark text, solid bell.
 */
@Composable
private fun FollowPill(following: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val lavender = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(50)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .lift(shape, tappable = true)
            .clip(shape)
            .background(if (following) lavender else CardSurface)
            .then(if (following) Modifier else Modifier.border(1.dp, LilacEdge, shape))
            .toggleable(value = following, role = Role.Switch, onValueChange = { onToggle() })
            .padding(horizontal = 18.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(if (following) R.drawable.ic_bell_filled else R.drawable.ic_bell_outline),
            contentDescription = null,
            tint = if (following) LavenderInk else LilacEdge,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = if (following) "Following" else "Follow",
            color = if (following) LavenderInk else MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

/** One row of "Reminders by show": the show's name, its next date, and a switch (the whole row is the target). */
@Composable
private fun ShowSwitchRow(title: String, next: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val lavender = MaterialTheme.colorScheme.primary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .toggleable(value = on, role = Role.Switch, onValueChange = onChange)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = next,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 1.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = on,
            onCheckedChange = null,
            colors = SwitchDefaults.colors(
                checkedThumbColor = LavenderInk,
                checkedTrackColor = lavender,
                checkedBorderColor = lavender,
                uncheckedThumbColor = LilacEdge,
                uncheckedTrackColor = Color(0xFF26242E),
                uncheckedBorderColor = LilacEdge
            )
        )
    }
}

/** A DJ's page from the website, with a back bar on top. */
@Composable
private fun DjPage(url: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val webView = remember(url) { createWebView(context, url) }
    DisposableEffect(webView) {
        onDispose {
            WebAudio.forget(webView)
            webView.destroy()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Text(
            text = "‹  Back to profile",
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xCC050505))
                .clickable(onClick = onBack)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        )
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
    }
}
