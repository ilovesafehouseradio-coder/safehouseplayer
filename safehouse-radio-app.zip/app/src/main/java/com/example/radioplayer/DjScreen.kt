package com.example.radioplayer

import android.text.Html
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------

data class Dj(val name: String, val link: String, val imageUrl: String?)

/** Holds the DJ list and search box so they survive switching tabs. */
class DjListState {
    var djs by mutableStateOf<List<Dj>>(emptyList())
    var loading by mutableStateOf(false)
    var failed by mutableStateOf(false)
    var query by mutableStateOf("")
    var openUrl by mutableStateOf<String?>(null)
    private var lastLoaded = 0L

    /** True if the list has never loaded, or is more than 10 minutes old. */
    fun needsRefresh(): Boolean =
        djs.isEmpty() || System.currentTimeMillis() - lastLoaded > 10 * 60 * 1000

    suspend fun load() {
        loading = true
        failed = false
        try {
            // Only replace the list on success, so a failed refresh keeps what we had.
            djs = withContext(Dispatchers.IO) { fetchAllDjs() }
            lastLoaded = System.currentTimeMillis()
        } catch (e: Exception) {
            failed = true
        }
        loading = false
    }
}

/** Reads the DJ list from the station website's own WordPress feed (all pages). */
private fun fetchAllDjs(): List<Dj> {
    val result = mutableListOf<Dj>()
    var page = 1
    var totalPages = 1
    while (page <= totalPages && page <= 10) {
        val conn = URL("${Config.DJS_API_URL}&page=$page").openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("User-Agent", "SafehouseRadioApp/1.0")
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
            totalPages = conn.getHeaderField("X-WP-TotalPages")?.toIntOrNull() ?: 1
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            result.addAll(parseDjs(body))
        } finally {
            conn.disconnect()
        }
        page++
    }
    // distinctBy: if the site changes mid-download, never show (or crash on) a duplicate DJ.
    return result.distinctBy { it.link }.sortedBy { it.name.lowercase() }
}

private fun parseDjs(body: String): List<Dj> {
    val arr = JSONArray(body)
    val out = ArrayList<Dj>(arr.length())
    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val rawTitle = o.optJSONObject("title")?.optString("rendered").orEmpty()
        // Titles come HTML-encoded, e.g. "Above &amp; Beyond".
        val name = Html.fromHtml(rawTitle, Html.FROM_HTML_MODE_LEGACY).toString().trim()
        val link = o.optString("link")
        if (name.isEmpty() || link.isEmpty()) continue

        val media = o.optJSONObject("_embedded")
            ?.optJSONArray("wp:featuredmedia")
            ?.optJSONObject(0)
        val medium = media?.optJSONObject("media_details")
            ?.optJSONObject("sizes")
            ?.optJSONObject("medium")
            ?.optString("source_url")
            ?.takeIf { it.isNotBlank() }
        val full = media?.optString("source_url")?.takeIf { it.isNotBlank() }

        out.add(Dj(name, link, medium ?: full))
    }
    return out
}

// ---------------------------------------------------------------------------
// DJs tab
// ---------------------------------------------------------------------------

@Composable
fun DjScreen(state: DjListState) {
    // Runs each time you open the tab: picks up new or changed DJs from the website.
    LaunchedEffect(Unit) {
        if (!state.loading && state.needsRefresh()) state.load()
    }

    val openUrl = state.openUrl
    if (openUrl != null) {
        DjPage(url = openUrl, onBack = { state.openUrl = null })
    } else {
        DjList(state)
    }
}

@Composable
private fun DjList(state: DjListState) {
    val scope = rememberCoroutineScope()
    val textColor = MaterialTheme.colorScheme.onBackground

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text(
            text = "Our DJs",
            color = textColor,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp)
        )

        OutlinedTextField(
            value = state.query,
            onValueChange = { state.query = it },
            placeholder = { Text("Search DJs…") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = textColor,
                unfocusedTextColor = textColor,
                focusedContainerColor = Color(0x99000000),
                unfocusedContainerColor = Color(0x99000000),
                cursorColor = MaterialTheme.colorScheme.primary,
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = Color(0x66FFFFFF)
            ),
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
        )

        val shown = remember(state.djs, state.query) {
            val q = state.query.trim()
            state.djs.filter { it.name.contains(q, ignoreCase = true) }
        }

        when {
            state.loading && state.djs.isEmpty() -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            }

            state.djs.isEmpty() -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (state.failed) "Couldn't load the DJ list." else "No DJs found.",
                        color = textColor
                    )
                    Button(
                        onClick = { scope.launch { state.load() } },
                        modifier = Modifier.padding(top = 12.dp)
                    ) {
                        Text("Try again")
                    }
                }
            }

            shown.isEmpty() -> {
                Text(
                    text = "No DJs match \"${state.query.trim()}\".",
                    color = textColor,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }

            else -> {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 16.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(shown, key = { it.link }) { dj ->
                        DjCard(dj) { state.openUrl = dj.link }
                    }
                }
            }
        }
    }
}

@Composable
private fun DjCard(dj: Dj, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x99000000))
            .clickable(onClick = onClick)
    ) {
        AsyncImage(
            model = dj.imageUrl,
            contentDescription = dj.name,
            placeholder = painterResource(R.drawable.station_logo),
            error = painterResource(R.drawable.station_logo),
            fallback = painterResource(R.drawable.station_logo),
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().aspectRatio(1f)
        )
        Text(
            text = dj.name,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(10.dp)
        )
    }
}

/** A DJ's page from the website, with a back bar on top. */
@Composable
private fun DjPage(url: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val webView = remember(url) { createWebView(context, url) }
    DisposableEffect(webView) {
        onDispose { webView.destroy() }
    }

    Column(Modifier.fillMaxSize()) {
        Text(
            text = "‹  All DJs",
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xCC050505))
                .clickable(onClick = onBack)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        )
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
    }
}
