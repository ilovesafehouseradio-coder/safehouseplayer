package com.example.radioplayer

import android.content.Intent
import android.net.Uri
import android.text.Html
import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------

data class Dj(val name: String, val link: String, val imageUrl: String?)

/** Holds the DJ list and search box so they survive switching tabs. */
class DjListState {
    var djs by mutableStateOf<List<Dj>>(emptyList())
    var loading by mutableStateOf(false)
    var failed by mutableStateOf(false)
    var query by mutableStateOf("")
    var open by mutableStateOf<Dj?>(null)      // the DJ whose page is open (null = the list)
    var openWeb by mutableStateOf(false)       // showing the website's own page for that DJ
    var genre by mutableStateOf<String?>(null) // a genre tapped on a DJ's page: the list shows only that genre
    val profiles = java.util.concurrent.ConcurrentHashMap<String, DjProfile>() // pages already read, so reopening is instant
    var groupsVersion by mutableStateOf(0)     // goes up when the groups learned from the bios change
    val profileAt = java.util.concurrent.ConcurrentHashMap<String, Long>() // when each page was read
    private var lastLoaded = 0L
    private var cacheDir: java.io.File? = null

    /** Where the DJ list and pages are saved between runs. */
    fun useCache(dir: java.io.File) {
        cacheDir = dir
    }

    /** Fills in the saved list and pages (if any), so the tab is ready before the internet answers. */
    fun loadFromCache() {
        val dir = cacheDir ?: return
        if (djs.isNotEmpty()) return
        val saved = DjCache.load(dir) ?: return
        djs = saved.djs
        lastLoaded = saved.listAt
        profiles.putAll(saved.profiles)
        profileAt.putAll(saved.profileAt)
    }

    /** Saves the list and pages. Call off the main thread. */
    fun saveCache() {
        val dir = cacheDir ?: return
        DjCache.save(dir, lastLoaded, djs, HashMap(profiles), HashMap(profileAt))
    }

    /** Remembers a page just read. */
    fun rememberProfile(link: String, profile: DjProfile) {
        profiles[link] = profile
        profileAt[link] = System.currentTimeMillis()
    }

    /** True if the list has never loaded, or is more than 10 minutes old. */
    fun needsRefresh(): Boolean =
        djs.isEmpty() || System.currentTimeMillis() - lastLoaded > 10 * 60 * 1000

    suspend fun load() {
        loading = true
        failed = false
        try {
            // Only replace the list on success, so a failed refresh keeps what we had.
            val fresh = withContext(Dispatchers.IO) { fetchAllDjs() }
            djs = fresh
            lastLoaded = System.currentTimeMillis()
            withContext(Dispatchers.IO) { saveCache() }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e   // leaving the tab part-way is not a failure
        } catch (e: Exception) {
            failed = true
        } finally {
            loading = false
        }
    }
}

/** Reads the DJ list from the station website's own WordPress feed (all pages). */
private fun fetchAllDjs(): List<Dj> {
    val result = mutableListOf<Dj>()
    var page = 1
    var totalPages = 1
    while (page <= totalPages && page <= 10) {
        val conn = URL("${Config.DJS_API_URL}&page=$page").openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 20000
            conn.setRequestProperty("User-Agent", Config.userAgent)
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
            totalPages = conn.getHeaderField("X-WP-TotalPages")?.toIntOrNull() ?: 1
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            result.addAll(parseDjs(body))
        } finally {
            conn.disconnect()
        }
        page++
    }
    // distinctBy: if the site changes mid-download, never show (or crash on) a duplicate DJ.
    return result.distinctBy { it.link }.sortedBy { it.name.lowercase() }
}

private fun parseDjs(body: String): List<Dj> {
    val arr = JSONArray(body)
    val out = ArrayList<Dj>(arr.length())
    for (i in 0 until arr.length()) {
        val o = arr.optJSONObject(i) ?: continue
        val rawTitle = o.optJSONObject("title")?.optString("rendered").orEmpty()
        // Titles come HTML-encoded, e.g. "Above &amp; Beyond".
        val name = Html.fromHtml(rawTitle, Html.FROM_HTML_MODE_LEGACY).toString().trim()
        val link = o.optString("link")
        if (name.isEmpty() || link.isEmpty()) continue

        val media = o.optJSONObject("_embedded")
            ?.optJSONArray("wp:featuredmedia")
            ?.optJSONObject(0)
        val medium = media?.optJSONObject("media_details")
            ?.optJSONObject("sizes")
            ?.optJSONObject("medium")
            ?.optString("source_url")
            ?.takeIf { it.isNotBlank() }
        val full = media?.optString("source_url")?.takeIf { it.isNotBlank() }

        out.add(Dj(name, link, medium ?: full))
    }
    return out
}

// ---------------------------------------------------------------------------
// DJs tab
// ---------------------------------------------------------------------------

@Composable
fun DjScreen(state: DjListState, schedule: ScheduleState, onBack: () -> Unit, onOpenReminderSetup: () -> Unit) {
    // Runs each time you open the tab: picks up new or changed DJs from the website.
    LaunchedEffect(Unit) {
        if (!state.loading && state.needsRefresh()) state.load()
    }

    // Kept here (not inside the list) so the list is exactly where you left it after a DJ's page.
    val gridState = rememberLazyGridState()

    val open = state.open
    when {
        open != null && state.openWeb -> DjPage(url = open.link, onBack = { state.openWeb = false })
        open != null -> DjProfilePage(open, state, schedule, onBack, onOpenReminderSetup)
        else -> DjList(state, schedule, gridState)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DjList(state: DjListState, schedule: ScheduleState, gridState: LazyGridState) {
    val scope = rememberCoroutineScope()
    // The moment this page was opened. The order is worked out from it, so it moves along each time
    // you come back to the page (and when the schedule updates), but never shuffles while you look.
    val openedAt = remember { java.time.Instant.now() }

    // Who the stream says is on air right now (a live DJ or a recorded show: either counts). Read when
    // the page opens: from the Schedule tab's last answer if it is fresh, then once more from the server.
    var onAir by remember {
        val f = schedule.feed
        val fresh = f != null && System.currentTimeMillis() - schedule.feedAt < 120_000L
        mutableStateOf(if (fresh) f?.title else null)
    }
    // Then again each minute while the app is on screen, so the featured DJ follows the show changes.
    val appVisible by rememberAppVisible()
    LaunchedEffect(appVisible) {
        while (appVisible) {
            val latest = withContext(Dispatchers.IO) { fetchLiveStatus() }
            if (latest != null) {
                schedule.feed = latest
                schedule.feedAt = System.currentTimeMillis()
                if (latest.title != onAir) onAir = latest.title
            }
            delay(60_000L)
        }
    }
    val textColor = MaterialTheme.colorScheme.onBackground

    Column(Modifier.fillMaxSize().padding(horizontal = ScreenLayout.side())) {
        val genre = state.genre
        PageHeader(
            title = genre ?: "Our DJs",
            horizontalPadding = 0.dp,
            leading = {
                if (genre != null) DjBackButton("Back to all DJs") { state.genre = null }
            }
        )

        if (genre == null) {
            SearchField(
                value = state.query,
                onValueChange = { state.query = it },
                placeholder = "Search DJs…",
                modifier = Modifier.padding(bottom = ScreenLayout.gap())
            )
        }

        // DJs added to the website lately get a "NEW" pill (worked out on the phone, kept for two weeks).
        val ctx = LocalContext.current
        var fresh by remember { mutableStateOf<Set<String>>(emptySet()) }
        LaunchedEffect(state.djs) {
            if (state.djs.isNotEmpty()) {
                fresh = withContext(Dispatchers.IO) { DjSeen.newLinks(ctx, state.djs) }
            }
        }

        val shown = remember(state.djs, state.query, schedule.shows, state.groupsVersion, onAir, genre) {
            val q = state.query.trim()
            if (genre != null) {
                // Everyone listed under this genre (from the pages already read), in the usual order.
                DjOrder.order(state.djs, schedule.shows, openedAt, onAir)
                    .filter { (dj, _) -> state.profiles[dj.link]?.genres.orEmpty().any { it.equals(genre, ignoreCase = true) } }
            } else if (q.isEmpty()) {
                // Live now, then up next, then the next few days, then everyone else A to Z.
                DjOrder.order(state.djs, schedule.shows, openedAt, onAir)
            } else {
                // While searching, the order stays A to Z.
                DjOrder.order(state.djs, schedule.shows, openedAt, onAir)
                    .filter { it.first.name.contains(q, ignoreCase = true) }
                    .sortedBy { it.first.name.lowercase() }
            }
        }

        when {
            state.loading && state.djs.isEmpty() -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            }

            state.djs.isEmpty() -> {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (state.failed) "Couldn't load the DJ list." else "No DJs found.",
                        color = textColor
                    )
                    Button(
                        onClick = { scope.launch { state.load() } },
                        modifier = Modifier.padding(top = 12.dp)
                    ) {
                        Text("Try again")
                    }
                }
            }

            shown.isEmpty() -> {
                Text(
                    text = if (genre != null) "No DJs listed under $genre yet." else "No DJs match \"${state.query.trim()}\".",
                    color = textColor,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }

            else -> {
                if (genre != null) {
                    Text(
                        text = if (shown.size == 1) "1 DJ" else "${shown.size} DJs",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    )
                }
                // Pull down on the grid to reload the DJ list.
                PullToRefreshBox(
                    isRefreshing = state.loading,
                    onRefresh = { scope.launch { state.load() } },
                    modifier = Modifier.fillMaxSize()
                ) {
                LazyVerticalGrid(
                    state = gridState,
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(ScreenLayout.gap()),
                    verticalArrangement = Arrangement.spacedBy(ScreenLayout.gap()),
                    contentPadding = PaddingValues(bottom = ScreenLayout.gap()),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(shown, key = { it.first.link }) { (dj, tier) ->
                        DjCard(dj, tier, isNew = dj.link in fresh) {
                            state.openWeb = false
                            state.open = dj
                        }
                    }
                }
                }
            }
        }
    }
}

@Composable
private fun DjCard(dj: Dj, tier: DjTier, isNew: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val featured = tier == DjTier.LIVE || tier == DjTier.UP_NEXT
    // One shape that scales as a whole: on a narrower phone the photo, the name strip, the name and the pill all
    // shrink together (designed at 172.5 dp wide on a flagship), so the card never gets taller and thinner.
    BoxWithConstraints(Modifier.fillMaxWidth()) {
    val k = (maxWidth.value / 172.5f).coerceIn(0.7f, 1.3f)
    Column(
        Modifier
            .followedGlow(shape, featured)
            .lift(shape, tappable = true)
            .clip(shape)
            .background(CardSurface)
            // Every card: card colour, thin border in the theme's main colour (a little thicker when LIVE or UP NEXT).
            .then(if (featured) Modifier.border(2.dp, FollowedEdge, shape) else Modifier)
            .clickable(onClick = onClick)
    ) {
        Box {
            AsyncImage(
                model = dj.imageUrl,
                contentDescription = dj.name,
                placeholder = rememberLogoTile(),
                error = rememberLogoTile(),
                fallback = rememberLogoTile(),
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().aspectRatio(1f)
            )
            // LIVE and UP NEXT come first; otherwise a recently added DJ gets a NEW pill.
            val pillText = when {
                tier == DjTier.LIVE -> "LIVE"
                tier == DjTier.UP_NEXT -> "UP NEXT"
                isNew -> "NEW"
                else -> null
            }
            if (pillText != null) {
                Text(
                    text = pillText,
                    color = LavenderInk,
                    fontSize = (12f * k).sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (1f * k).sp,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding((8f * k).dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (tier == DjTier.LIVE) ThemeState.current.live else FollowedEdge)
                        .padding(horizontal = (10f * k).dp, vertical = (3f * k).dp)
                )
            }
        }
        // The name sits in a lavender strip. The strip is always tall enough for exactly two lines
        // (set in "sp" so it grows with the phone's text size), so every card is the same height
        // whether the name is one line or two. Two-line names are packed a little closer together.
        val stripHeight = (with(LocalDensity.current) { (NAME_LINE * 2).toDp() } + 20.dp) * k
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(stripHeight)
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            FitOrScrollText(
                text = dj.name,
                color = ThemeState.current.text,
                fontSize = (14f * k).sp,
                lineHeight = (NAME_LINE.value * k).sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
        }
    }
}
}

/** A DJ page read less than this long ago is not read again when the profile opens. */
private const val PROFILE_FRESH_MS = 24L * 60 * 60 * 1000

private val NAME_LINE = 18.sp   // the gap between the two lines of a DJ's name

// ---------------------------------------------------------------------------
// A DJ's page, in the app's own style
// ---------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DjProfilePage(dj: Dj, state: DjListState, schedule: ScheduleState, onBack: () -> Unit, onOpenReminderSetup: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val zone = remember { ZoneId.systemDefault() }
    val is24 = DateFormat.is24HourFormat(ctx)
    val timeFmt = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a") }
    val dayFmt = remember { DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault()) }
    val now = remember { Instant.now() }

    // The page text, photo and links come from the website (kept for next time).
    var profile by remember(dj.link) { mutableStateOf(state.profiles[dj.link]) }
    var failed by remember(dj.link) { mutableStateOf(false) }
    LaunchedEffect(dj.link) {
        schedule.followed = Reminders.followedKeys(ctx)
        schedule.showsOn = Reminders.showsOn(ctx)
        schedule.showsOff = Reminders.showsOff(ctx)
        schedule.setupSeen = Reminders.setupSeen(ctx)
        // A page read in the last day is used as it is; an older one is shown at once and refreshed behind it.
        val age = System.currentTimeMillis() - (state.profileAt[dj.link] ?: 0L)
        if (profile == null || age > PROFILE_FRESH_MS) {
            val loaded = withContext(Dispatchers.IO) { fetchDjProfile(dj.link, dj.name) }
            if (loaded != null) {
                state.rememberProfile(dj.link, loaded)
                profile = loaded
                withContext(Dispatchers.IO) { state.saveCache() }
            } else if (profile == null) {
                failed = true
            }
        }
    }

    // This DJ's coming shows, from the schedule we already load. Back-to-back slots of one event are
    // joined first, so a DJ in an event sees the whole event.
    val grouped = remember(schedule.shows) { Events.group(schedule.shows) }
    val mine = remember(grouped, dj.name, state.groupsVersion) {
        val k = DjMatch.key(dj.name)
        // Live shows, events, and this DJ's own "repeat show" slots (but not the empty "Repeat shows" fillers).
        grouped
            .filter { !(it.isFiller && it.dj == null) && it.end.isAfter(now) && DjMatch.showMatches(it, k) }
            .sortedBy { it.start }
    }
    val followName = mine.firstOrNull { it.dj != null && DjMatch.key(it.dj) == DjMatch.key(dj.name) }?.dj ?: dj.name
    val following = schedule.followed.any { DjMatch.key(it) == DjMatch.key(followName) }

    // Does this show get a reminder? (The same rule the Schedule tab uses.)
    fun reminded(s: Show): Boolean =
        FollowRules.reminderKey(s, schedule.followed, schedule.showsOn, schedule.showsOff) != null
    fun tagFor(s: Show): String? = when {
        !reminded(s) -> null
        FollowRules.isFollowing(s, schedule.followed) -> "Following"
        else -> "Reminder on"
    }

    // The switch on one show: follows the rules in FollowRules (off = skip it, on = just that show).
    fun switchShow(s: Show, wantOn: Boolean) {
        val djFollowed = FollowRules.isFollowing(s, schedule.followed)
        val k = DjMatch.followedKey(s, schedule.followed)?.let { DjMatch.key(it) } ?: DjMatch.key(followName)
        Reminders.setShowReminder(ctx, k, followName, FollowRules.showKey(s.title), wantOn, djFollowed)
        schedule.showsOn = Reminders.showsOn(ctx)
        schedule.showsOff = Reminders.showsOff(ctx)
        val app = ctx.applicationContext
        scope.launch(Dispatchers.Default) { Reminders.rebuild(app, schedule.shows) }
        if (wantOn && !djFollowed && !schedule.setupSeen) onOpenReminderSetup()
    }

    fun whenText(s: Show): String {
        val d = s.start.atZone(zone).toLocalDate()
        val today = now.atZone(zone).toLocalDate()
        val day = when (d) {
            today -> "Today"
            today.plusDays(1) -> "Tomorrow"
            else -> dayFmt.format(d)
        }
        return "$day · ${timeFmt.format(s.start.atZone(zone))} – ${timeFmt.format(s.end.atZone(zone))}"
    }

    // "Today", "Tomorrow" or "Mon 2 Nov" (for the switch rows).
    fun whenShort(s: Show): String {
        val d = s.start.atZone(zone).toLocalDate()
        val today = now.atZone(zone).toLocalDate()
        return when {
            !s.start.isAfter(now) -> "On now"
            d == today -> "Today"
            d == today.plusDays(1) -> "Tomorrow"
            else -> dayFmt.format(d)
        }
    }

    // Opens in the matching app (SoundCloud, YouTube, Bandcamp...) if the person has it, otherwise the browser.
    fun openLink(url: String) = Links.open(ctx, url)

    Column(Modifier.fillMaxSize()) {
        PageHeader(
            title = dj.name,
            leading = {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(start = 4.dp)
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable(onClickLabel = "Go back", role = Role.Button, onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_arrow_back),
                        contentDescription = "Go back",
                        tint = LavenderInk,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        )

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(start = ScreenLayout.side(), end = ScreenLayout.side(), bottom = ScreenLayout.gap() * 2)
        ) {
            // Photo: the small one from the list shows at once, the sharp one replaces it.
            val photo = profile?.photoUrl ?: dj.imageUrl
            AsyncImage(
                model = ImageRequest.Builder(ctx)
                    .data(photo)
                    .placeholderMemoryCacheKey(dj.imageUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = dj.name,
                placeholder = rememberLogoTile(),
                error = rememberLogoTile(),
                fallback = rememberLogoTile(),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .lift(RoundedCornerShape(20.dp))
                    .clip(RoundedCornerShape(20.dp))
            )

            val p = profile
            if (p != null && p.genres.isNotEmpty()) {
                FlowRow(
                    modifier = Modifier.padding(top = (ScreenLayout.gap() - 7.dp).coerceAtLeast(0.dp)),
                    horizontalArrangement = Arrangement.spacedBy(ScreenLayout.gap()),
                    verticalArrangement = Arrangement.spacedBy(0.dp),
                    maxLines = 3     // a DJ's main genres only: anything that would need a fourth row is left off
                ) {
                    for (g in p.genres) {
                        // Tapping a genre lists every DJ under it ("Multi genre" is not a genre to look up).
                        val lookUp = !g.equals("Multi genre", ignoreCase = true)
                        // The 7dp above and below the pill make the touch area a full 48dp tall.
                        Box(
                            Modifier
                                .then(
                                    if (lookUp) {
                                        Modifier.clickable(onClickLabel = "Show all $g DJs", role = Role.Button) {
                                            state.openWeb = false
                                            state.open = null
                                            state.query = ""
                                            state.genre = g
                                        }
                                    } else {
                                        Modifier
                                    }
                                )
                                .padding(vertical = 7.dp)
                        ) {
                            Text(
                                text = g,
                                color = LavenderInk,
                                fontSize = AppType.Pill,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .lift(RoundedCornerShape(50), tappable = lookUp, fill = MaterialTheme.colorScheme.primary)
                                    .clip(RoundedCornerShape(50))
                                    .background(MaterialTheme.colorScheme.primary)
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Follow: one pill for the whole DJ, on its own (not inside any card).
            FollowPill(
                following = following,
                onToggle = {
                    if (toggleFollowDj(ctx, schedule, scope, followName) && !schedule.setupSeen) {
                        onOpenReminderSetup()
                    }
                },
                modifier = Modifier.padding(top = (ScreenLayout.gap() - 7.dp).coerceAtLeast(0.dp))
            )
            Text(
                text = "Reminder ${Reminders.LEAD_MINUTES} minutes before live shows",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = ScreenLayout.gap() / 2)
            )

            // Reminders by show: up to five of this DJ's shows, each with its own switch.
            val showRows = mine.filter { !it.isFiller }.distinctBy { FollowRules.showKey(it.title) }.take(5)
            if (showRows.isNotEmpty()) {
                DjSectionLabel("Reminders by show")
                Column(
                    Modifier
                        .fillMaxWidth()
                        .lift(RoundedCornerShape(16.dp))
                        .clip(RoundedCornerShape(16.dp))
                        .background(CardSurface)
                        .padding(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 12.dp)
                ) {
                    showRows.forEachIndexed { i, s ->
                        if (i > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(ThemeState.current.divider))
                        ShowSwitchRow(
                            title = s.title,
                            next = "Next: " + whenShort(s),
                            on = reminded(s),
                            onChange = { switchShow(s, it) }
                        )
                    }
                    Text(
                        text = if (following) {
                            "Following turns on every show. Switch one off to skip it."
                        } else {
                            "Switch a show on to get reminders for just that show."
                        },
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }

            // Next show (or "on now"), with the reminder button.
            // A live show comes first; a repeat is shown here only if there is nothing live coming up.
            val next = mine.firstOrNull { !it.isFiller } ?: mine.firstOrNull()
            DjSectionLabel(if (next != null && !next.start.isAfter(now)) "On now" else "Next show")
            val nextTag = if (next != null) tagFor(next) else null
            Column(
                Modifier
                    .fillMaxWidth()
                    .followedGlow(RoundedCornerShape(16.dp), nextTag != null)
                    .lift(RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (next != null) LilacSurface else CardSurface)
                    .then(
                        if (next != null) {
                            Modifier.drawBehind { drawRect(LilacEdge, size = Size(4.dp.toPx(), size.height)) }
                        } else {
                            Modifier
                        }
                    )
                    .then(if (nextTag != null) Modifier.border(2.dp, FollowedEdge, RoundedCornerShape(16.dp)) else Modifier)
                    .padding(start = if (next != null) 18.dp else 14.dp, top = 14.dp, end = if (next != null) 8.dp else 14.dp, bottom = if (next != null) 8.dp else 14.dp)
            ) {
                if (next != null) {
                    Text(
                        text = whenText(next),
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        style = tightStyle(23.sp)
                    )
                    // The show's name, with the plain Add-to-calendar and Share icons beside it
                    // (a show on now can only be shared; a repeat has neither).
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = showLabel(next),
                            color = MaterialTheme.colorScheme.onBackground,
                            fontSize = AppType.ShowName,
                            style = tightStyle(20.sp),
                            modifier = Modifier.weight(1f).padding(top = 2.dp)
                        )
                        ShowActionRow(dj.name, next, now, zone, is24, dj.imageUrl)
                    }
                } else {
                    Text(
                        text = "Not on the schedule in the coming months.",
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 15.sp
                    )
                }
                if (nextTag != null) {
                    Row(Modifier.fillMaxWidth().padding(top = 0.dp, end = if (next != null) 6.dp else 0.dp, bottom = 6.dp), horizontalArrangement = Arrangement.End) {
                        FollowTag(nextTag)
                    }
                }
            }

            val later = mine.filter { it !== next }
            if (later.isNotEmpty()) {
                DjSectionLabel("Later")
                for (s in later.take(4)) {
                    val laterTag = tagFor(s)
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(bottom = ScreenLayout.gap())
                            .followedGlow(RoundedCornerShape(14.dp), laterTag != null)
                            .lift(RoundedCornerShape(14.dp))
                            .clip(RoundedCornerShape(14.dp))
                            .background(CardSurface)
                            .then(if (laterTag != null) Modifier.border(2.dp, FollowedEdge, RoundedCornerShape(14.dp)) else Modifier)
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    text = whenText(s),
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = AppType.CardTime,
                                    fontWeight = FontWeight.Medium,
                                    style = tightStyle(17.sp)
                                )
                                Text(
                                    text = showLabel(s),
                                    color = MaterialTheme.colorScheme.onBackground,
                                    fontSize = 15.sp,
                                    style = tightStyle(20.sp),
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                            // Small icon buttons (48dp to touch): add to calendar, share.
                            ShowActionRow(dj.name, s, now, zone, is24, dj.imageUrl)
                        }
                        if (laterTag != null) {
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                                FollowTag(laterTag)
                            }
                        }
                    }
                }
            }

            // The bio (only when the page really has one).
            if (p != null) {
                DjSectionLabel("About")
                if (p.paragraphs.isNotEmpty()) DjAbout(p.paragraphs) else DjNoBio()
            }

            if (p != null) {
                // The DJ's own links, then the station's MixCloud / SoundCloud for any of those two the DJ hasn't
                // got (many DJs upload their shows through the station). The station's buttons are lilac.
                val shown = remember(p) {
                    val own = p.links.map { it to false }
                    val station = ArrayList<Pair<DjLink, Boolean>>()
                    if (p.links.none { it.label == "Mixcloud" }) station.add(DjLink("Safehouse MixCloud", Config.MIXCLOUD_URL) to true)
                    if (p.links.none { it.label == "SoundCloud" }) station.add(DjLink("Safehouse SoundCloud", Config.SOUNDCLOUD_URL) to true)
                    own + station
                }
                DjSectionLabel("Links")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(ScreenLayout.gap()),
                    verticalArrangement = Arrangement.spacedBy(ScreenLayout.gap())
                ) {
                    for ((link, isStation) in shown) {
                        if (isStation) {
                            StationLinkPill(link.label) { openLink(link.url) }
                        } else {
                            Box(
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .lift(RoundedCornerShape(50), tappable = true)
                                    .clip(RoundedCornerShape(50))
                                    .background(CardSurface)
                                    .clickable(onClickLabel = "Open ${link.label}", role = Role.Button) { openLink(link.url) }
                                    .padding(horizontal = 18.dp, vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = link.label,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    fontSize = AppType.Pill,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // More like this: up to three other DJs who share a genre with this one.
            if (p != null) {
                val similar = remember(p, state.djs, dj.link) { similarDjs(state, dj, p) }
                if (similar.isNotEmpty()) {
                    DjSectionLabel("More like this")
                    Row(horizontalArrangement = Arrangement.spacedBy(ScreenLayout.gap())) {
                        for (o in similar) {
                            Box(Modifier.weight(1f)) {
                                SimilarDjCard(o) {
                                    state.openWeb = false
                                    state.open = o
                                }
                            }
                        }
                        // Keep every card the same width when fewer than three are found.
                        for (i in similar.size until 3) Spacer(Modifier.weight(1f))
                    }
                }
            }

            if (p == null && !failed) {
                Row(
                    modifier = Modifier.padding(top = ScreenLayout.gap() * 2),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "  Loading profile…",
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 14.sp
                    )
                }
            }
            if (failed) {
                Text(
                    text = "Couldn't load the full profile. You can still see it on the website below.",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = ScreenLayout.gap() * 2)
                )
            }

            Box(
                modifier = Modifier
                    .padding(top = ScreenLayout.gap())
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .clickable(onClickLabel = "Open the website page", role = Role.Button) { state.openWeb = true },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "View full page on the website",
                    color = ThemeState.current.textDim,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textDecoration = TextDecoration.Underline
                )
            }
        }
    }
}

@Composable
private fun DjSectionLabel(text: String) {
    Text(
        text = text,
        color = ThemeState.current.textDim,
        fontSize = AppType.Heading,
        fontWeight = FontWeight.Bold,
        style = androidx.compose.ui.text.TextStyle(
            shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.85f), androidx.compose.ui.geometry.Offset(0f, 3f), 14f)
        ),
        // Two gaps above a heading (it belongs to what is under it), one gap below.
        modifier = Modifier.padding(top = ScreenLayout.gap() * 2, bottom = ScreenLayout.gap())
    )
}

/** The back arrow at the left of a lavender page title (used on the genre list). */
@Composable
private fun BoxScope.DjBackButton(label: String, onBack: () -> Unit) {
    Box(
        modifier = Modifier
            .align(Alignment.CenterStart)
            .padding(start = 4.dp)
            .size(48.dp)
            .clip(CircleShape)
            .clickable(onClickLabel = label, role = Role.Button, onClick = onBack),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_arrow_back),
            contentDescription = label,
            tint = LavenderInk,
            modifier = Modifier.size(24.dp)
        )
    }
}

/**
 * Up to three other DJs who share a genre with [dj] (from the pages already read). The most shared
 * genres come first; among equals the order changes day by day, so every DJ gets seen over time.
 */
private fun similarDjs(state: DjListState, dj: Dj, p: DjProfile): List<Dj> {
    val mine = p.genres.filter { !it.equals("Multi genre", ignoreCase = true) }.map { it.lowercase() }.toSet()
    if (mine.isEmpty()) return emptyList()
    val day = java.time.LocalDate.now().toEpochDay()
    return state.djs
        .filter { it.link != dj.link }
        .mapNotNull { o ->
            val g = state.profiles[o.link]?.genres ?: return@mapNotNull null
            val shared = g.count { it.lowercase() in mine }
            if (shared == 0) null else Triple(o, shared, (o.link.hashCode().toLong() * 31L + day).hashCode())
        }
        .sortedWith(compareByDescending<Triple<Dj, Int, Int>> { it.second }.thenBy { it.third })
        .take(3)
        .map { it.first }
}

/** A small DJ card for "More like this": photo with the name underneath, same style as the DJs page. */
@Composable
private fun SimilarDjCard(dj: Dj, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .lift(shape, tappable = true)
            .clip(shape)
            .background(CardSurface)
            .clickable(onClickLabel = "Open ${dj.name}'s page", role = Role.Button, onClick = onClick)
    ) {
        AsyncImage(
            model = dj.imageUrl,
            contentDescription = null,
            placeholder = rememberLogoTile(),
            error = rememberLogoTile(),
            fallback = rememberLogoTile(),
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().aspectRatio(1f)
        )
        val stripHeight = with(LocalDensity.current) { 32.sp.toDp() } + 16.dp
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(stripHeight)
                .background(MaterialTheme.colorScheme.primary)
                .padding(horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            FitOrScrollText(
                text = dj.name,
                color = LavenderInk,
                fontSize = 13.sp,
                lineHeight = 16.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
        }
    }
}

/** The line under the time: the show name, with "Event · " in front of a joined-up event or a long block. */
private fun showLabel(s: Show): String {
    val long = java.time.Duration.between(s.start, s.end).toMinutes() >= 240
    return if (s.isEvent || long) "Event · ${s.title}" else s.title
}

/** Shown when a DJ's page has no bio yet: same card as the bio. */
@Composable
private fun DjNoBio() {
    Box(
        Modifier
            .fillMaxWidth()
            .lift(RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .padding(14.dp)
    ) {
        Text(
            text = "Bio coming soon",
            color = ThemeState.current.textDim,
            fontSize = 15.sp,
            lineHeight = 23.sp
        )
    }
}

/** The bio: first lines, with "Read more" when it's long. */
@Composable
private fun DjAbout(paragraphs: List<String>) {
    var expanded by remember { mutableStateOf(false) }
    val text = remember(paragraphs) { paragraphs.joinToString("\n\n") }
    val long = text.length > 320
    Column(
        Modifier
            .fillMaxWidth()
            .lift(RoundedCornerShape(16.dp), tappable = long)
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            // A long bio opens and closes with a tap anywhere on the card (a drag still scrolls).
            .clickable(
                enabled = long,
                onClickLabel = if (expanded) "Show less" else "Read more",
                role = Role.Button
            ) { expanded = !expanded }
            .padding(14.dp)
    ) {
        Text(
            text = text,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 15.sp,
            lineHeight = 23.sp,
            maxLines = if (expanded || !long) Int.MAX_VALUE else 7,
            overflow = TextOverflow.Ellipsis
        )
        if (long) {
            // The words are just the label: the whole card above is the button.
            Box(
                modifier = Modifier.heightIn(min = 48.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = if (expanded) "Show less" else "Read more",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Follow / Following: one pill for the whole DJ, full width, on its own.
 * Off: dark fill, thin lilac outline, outline bell. On: filled lavender, dark text, solid bell.
 */
@Composable
private fun FollowPill(following: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    val lavender = MaterialTheme.colorScheme.primary
    val shape = RoundedCornerShape(50)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .lift(shape, tappable = true, fill = if (following) lavender else Color.Unspecified)
            .clip(shape)
            .background(if (following) lavender else CardSurface)
            .toggleable(value = following, role = Role.Switch, onValueChange = { onToggle() })
            .padding(horizontal = 18.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(if (following) R.drawable.ic_bell_filled else R.drawable.ic_bell_outline),
            contentDescription = null,
            tint = if (following) LavenderInk else LilacEdge,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text = if (following) "Following" else "Follow",
            color = if (following) LavenderInk else MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

/** One row of "Reminders by show": the show's name, its next date, and a switch (the whole row is the target). */
@Composable
private fun ShowSwitchRow(title: String, next: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val lavender = MaterialTheme.colorScheme.primary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 56.dp)
            .toggleable(value = on, role = Role.Switch, onValueChange = onChange)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = AppType.RowLabel,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = next,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 1.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = on,
            onCheckedChange = null,
            colors = SwitchDefaults.colors(
                checkedThumbColor = LavenderInk,
                checkedTrackColor = lavender,
                checkedBorderColor = lavender,
                uncheckedThumbColor = LilacEdge,
                uncheckedTrackColor = ThemeState.current.background,
                uncheckedBorderColor = LilacEdge
            )
        )
    }
}

/** A DJ's page from the website, with a back bar on top. */
@Composable
private fun DjPage(url: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val webView = remember(url) { createWebView(context, url) }
    DisposableEffect(webView) {
        onDispose {
            WebAudio.forget(webView)
            webView.destroy()
        }
    }

    Column(Modifier.fillMaxSize()) {
        // The same back arrow as every other page, on the page's side border.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ThemeState.current.scrimStrong)
                .clickable(onClickLabel = "Back to profile", role = Role.Button, onClick = onBack)
                .padding(horizontal = ScreenLayout.side(), vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_arrow_back),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.size(24.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(text = "Back to profile", color = MaterialTheme.colorScheme.onBackground, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
    }
}
