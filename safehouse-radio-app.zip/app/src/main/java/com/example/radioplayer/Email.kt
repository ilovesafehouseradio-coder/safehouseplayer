package com.example.radioplayer

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Opens a ready-made email to the station. Every email app on the phone gets the address, subject and body the
 * reliable way (a "send" with an email-only selector, plus the same details in the mailto: address for the apps that
 * only read that), so the template always arrives filled in. Nothing is sent unless the person presses Send.
 * Returns false if the phone has no email app.
 */
object Email {
    fun compose(ctx: Context, subject: String, body: String): Boolean {
        val to = Config.CONTACT_EMAIL
        val mailto = Uri.parse("mailto:$to?subject=" + Uri.encode(subject) + "&body=" + Uri.encode(body))
        val send = Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            selector = Intent(Intent.ACTION_SENDTO, mailto)
        }
        return try {
            ctx.startActivity(send)
            true
        } catch (e: Exception) {
            try {
                ctx.startActivity(Intent(Intent.ACTION_SENDTO, mailto))
                true
            } catch (e2: Exception) {
                false
            }
        }
    }
}
