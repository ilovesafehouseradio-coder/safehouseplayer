package com.example.radioplayer

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner

/**
 * True while the app is on screen (not in the background and not with the screen off). Screens use
 * it to stop checking the internet for things nobody is looking at.
 */
@Composable
fun rememberAppVisible(): State<Boolean> {
    val context = LocalContext.current
    val visible = remember { mutableStateOf(true) }
    DisposableEffect(context) {
        val owner = context as? LifecycleOwner
        if (owner == null) {
            onDispose { }
        } else {
            visible.value = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_START) visible.value = true
                if (event == Lifecycle.Event.ON_STOP) visible.value = false
            }
            owner.lifecycle.addObserver(observer)
            onDispose { owner.lifecycle.removeObserver(observer) }
        }
    }
    return visible
}
