package com.example.radioplayer

/**
 * A show we know by the file name it arrives with. Some regular shows come from a download whose
 * title is only a code (the Above & Beyond show arrives as "ABGT697"), so the DJ and the show name
 * are filled in here. [art] names the picture the app carries for it (see ShowArt).
 */
class KnownShow(val dj: String, val show: String, val art: String)

object KnownShows {
    // "ABGT" + the episode number, however the file name was typed: ABGT697, abgt 697, ABGT-697, ABGT697.mp3.
    private val ABGT = Regex("(?i)^abgt[\\s._-]*(\\d{1,4})(\\.(mp3|m4a|wav|flac|aac))?$")
    // Invisible characters that sometimes ride along in titles, and the non-breaking space.
    private val INVISIBLE = Regex("[\\u200B-\\u200F\\u2060\\uFEFF\\u00AD]")

    private fun clean(part: String): String =
        part.replace(INVISIBLE, "").replace('\u00A0', ' ').trim().trim(',', '-', '|', ':', ';', '.', ' ')

    /**
     * The known show a stream title stands for, or null. The title may carry stray separators around the
     * code (" - ABGT697", "ABGT697,", the code sent twice), but anything else in it means the DJ sent real
     * words, and then nothing is touched.
     */
    fun match(title: String?): KnownShow? {
        val (d, s) = splitNowPlaying(title?.replace(INVISIBLE, "")?.replace('\u00A0', ' '))
        if (d == null) return null
        val first = clean(d)
        if (s != null && !clean(s).equals(first, ignoreCase = true)) return null
        val m = ABGT.find(first) ?: return null
        val episode = m.groupValues[1].toInt()
        return KnownShow("Above & Beyond", "Group Therapy Radio $episode", "abgt")
    }
}
