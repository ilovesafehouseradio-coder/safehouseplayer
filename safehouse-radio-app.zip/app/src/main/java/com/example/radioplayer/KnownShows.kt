package com.example.radioplayer

/**
 * A show we know by the file name it arrives with. Some regular shows come from a download whose
 * title is only a code (the Above & Beyond show arrives as "ABGT697"), so the DJ and the show name
 * are filled in here. [art] names the picture the app carries for it (see ShowArt).
 */
class KnownShow(val dj: String, val show: String, val art: String)

object KnownShows {
    // "ABGT" + the episode number, however the file name was typed: ABGT697, abgt 697, ABGT-697, ABGT697.mp3.
    private val ABGT = Regex("(?i)^abgt[\\s._-]*(\\d{1,4})(\\.(mp3|m4a|wav|flac|aac))?$")

    /** The known show a whole stream title stands for, or null. Titles with anything else in them are never touched. */
    fun match(title: String?): KnownShow? {
        val m = ABGT.find(title?.trim().orEmpty()) ?: return null
        val episode = m.groupValues[1].toInt()
        return KnownShow("Above & Beyond", "Group Therapy Radio $episode", "abgt")
    }
}
