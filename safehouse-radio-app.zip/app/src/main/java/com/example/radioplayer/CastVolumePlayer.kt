package com.example.radioplayer

import android.content.Context
import androidx.media3.common.DeviceInfo
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.Player
import com.google.android.gms.cast.framework.CastContext
import java.util.concurrent.CopyOnWriteArraySet
import kotlin.math.roundToInt

/**
 * The Chromecast player, dressed up so Android treats the TV as a "remote" speaker: the phone's volume
 * buttons, the lock screen and the notification then control the TV's volume (1% a press) instead of the
 * phone's, even when the app isn't on screen. Everything else is passed straight to the real player.
 */
class CastVolumePlayer(player: Player, context: Context) : ForwardingPlayer(player) {

    private val appContext = context.applicationContext
    private val listeners = CopyOnWriteArraySet<Player.Listener>()

    init {
        current = this
    }

    private fun session() =
        try {
            CastContext.getSharedInstance(appContext).sessionManager.currentCastSession
                ?.takeIf { it.isConnected }
        } catch (e: Exception) {
            null
        }

    private fun percent(): Int = ((session()?.volume ?: 0.0) * 100).roundToInt().coerceIn(0, 100)

    private fun setPercent(value: Int) {
        val s = session() ?: return
        try {
            s.setVolume(value.coerceIn(0, 100) / 100.0)
        } catch (e: Exception) {
            // The TV can't be reached right now: leave the volume as it was.
        }
        announce()
    }

    /** Tells Android the volume has changed, so the slider it shows is right. */
    fun announce() {
        val v = percent()
        for (l in listeners) l.onDeviceVolumeChanged(v, false)
    }

    override fun addListener(listener: Player.Listener) {
        super.addListener(listener)
        listeners.add(listener)
    }

    override fun removeListener(listener: Player.Listener) {
        super.removeListener(listener)
        listeners.remove(listener)
    }

    override fun getDeviceInfo(): DeviceInfo =
        DeviceInfo.Builder(DeviceInfo.PLAYBACK_TYPE_REMOTE).setMinVolume(0).setMaxVolume(100).build()

    override fun getAvailableCommands(): Player.Commands =
        Player.Commands.Builder()
            .addAll(super.getAvailableCommands())
            .addAll(
                Player.COMMAND_GET_DEVICE_VOLUME,
                Player.COMMAND_SET_DEVICE_VOLUME,
                Player.COMMAND_SET_DEVICE_VOLUME_WITH_FLAGS,
                Player.COMMAND_ADJUST_DEVICE_VOLUME,
                Player.COMMAND_ADJUST_DEVICE_VOLUME_WITH_FLAGS
            )
            .build()

    override fun isCommandAvailable(command: Int): Boolean = availableCommands.contains(command)

    override fun getDeviceVolume(): Int = percent()

    override fun isDeviceMuted(): Boolean = false

    override fun setDeviceVolume(volume: Int) = setPercent(volume)

    override fun setDeviceVolume(volume: Int, flags: Int) = setPercent(volume)

    override fun increaseDeviceVolume() = setPercent(percent() + 1)

    override fun increaseDeviceVolume(flags: Int) = setPercent(percent() + 1)

    override fun decreaseDeviceVolume() = setPercent(percent() - 1)

    override fun decreaseDeviceVolume(flags: Int) = setPercent(percent() - 1)

    override fun setDeviceMuted(muted: Boolean) {}

    override fun setDeviceMuted(muted: Boolean, flags: Int) {}

    companion object {
        @Volatile var current: CastVolumePlayer? = null

        /** Called after the app itself changes the TV volume, so Android's slider follows. */
        fun announceChange() {
            current?.announce()
        }
    }
}
