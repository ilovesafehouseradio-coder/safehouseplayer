package com.example.radioplayer

import android.text.Html
import android.text.format.DateFormat
import android.webkit.WebView
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------

/** Holds the schedule so it survives switching tabs. */
class ScheduleState {
    var shows by mutableStateOf<List<Show>>(emptyList())
    var loading by mutableStateOf(false)
    var failed by mutableStateOf(false)
    var loadedOnce by mutableStateOf(false)
    var showWeb by mutableStateOf(false)   // fall back to the website's own schedule page
    var selectedDay by mutableStateOf(0)
    private var lastLoaded = 0L
    private var cacheFile: java.io.File? = null

    // What the saved copy was made from, so an unchanged calendar needs no reprocessing.
    private var signature = 0L     // a fingerprint of the calendar text it was made from
    private var etag: String? = null
    private var parsedAt = 0L      // when the list was last worked out from the calendar

    /** Where the last result is kept, so the schedule can appear instantly next time. */
    fun useCache(dir: java.io.File) {
        cacheFile = java.io.File(dir, "schedule.json")
        try {
            java.io.File(dir, "schedule.ics").delete()   // the old kind of saved copy
        } catch (e: Exception) {
        }
    }

    fun needsRefresh(): Boolean =
        shows.isEmpty() || System.currentTimeMillis() - lastLoaded > 10 * 60_000L

    private suspend fun parseText(text: String): List<Show>? =
        withContext(Dispatchers.Default) {
            try {
                val now = Instant.now()
                ScheduleLogic.toShows(
                    IcsCalendar.parse(text, now.minus(Duration.ofDays(3)), now.plus(Duration.ofDays(15)))
                )
            } catch (e: Exception) {
                null
            }
        }

    /** Shows the copy saved last time straight away (no waiting for the network). */
    suspend fun loadFromCache() {
        if (shows.isNotEmpty()) return
        val file = cacheFile ?: return
        val saved = withContext(Dispatchers.IO) {
            try {
                if (!file.exists()) return@withContext null
                val root = JSONObject(file.readText(Charsets.UTF_8))
                if (root.optInt("v") != CACHE_VERSION) return@withContext null
                val arr = root.getJSONArray("shows")
                val list = ArrayList<Show>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        Show(
                            start = Instant.ofEpochMilli(o.getLong("s")),
                            end = Instant.ofEpochMilli(o.getLong("e")),
                            dj = if (o.isNull("dj")) null else o.getString("dj"),
                            title = o.getString("t"),
                            genres = if (o.isNull("g")) null else o.getString("g"),
                            description = o.getString("d"),
                            isFiller = o.getBoolean("f")
                        )
                    )
                }
                SavedSchedule(
                    list, root.optLong("sig"), root.optString("etag").ifEmpty { null }, root.optLong("at")
                )
            } catch (e: Exception) {
                null   // a damaged or old-style file is simply ignored
            }
        } ?: return
        // A download may have finished while this was reading: never replace newer data.
        if (shows.isEmpty() && saved.shows.isNotEmpty()) {
            shows = saved.shows
            signature = saved.signature
            etag = saved.etag
            parsedAt = saved.parsedAt
            loadedOnce = true
        }
    }

    suspend fun load() {
        loading = true
        try {
            // If the list was worked out recently, ask the server "has it changed?" first.
            val recent = shows.isNotEmpty() && System.currentTimeMillis() - parsedAt < REPARSE_AFTER_MS
            val fetched = withContext(Dispatchers.IO) { fetchCalendar(if (recent) etag else null) }

            if (fetched == null) {
                // Keep showing what we have; only complain when there is nothing to show.
                if (shows.isEmpty()) failed = true
                return
            }
            if (fetched.notModified) {
                failed = false
                lastLoaded = System.currentTimeMillis()
                return
            }

            val text = fetched.text ?: return
            val sig = text.length.toLong() * 31L + text.hashCode()
            if (recent && sig == signature) {
                // Exactly the same calendar as last time: nothing to work out again.
                etag = fetched.etag ?: etag
                failed = false
                lastLoaded = System.currentTimeMillis()
                return
            }

            val parsed = parseText(text)
            if (parsed == null) {
                if (shows.isEmpty()) failed = true
                return
            }
            shows = parsed
            failed = false
            loadedOnce = true
            lastLoaded = System.currentTimeMillis()
            parsedAt = lastLoaded
            signature = sig
            etag = fetched.etag
            save(parsed)
        } finally {
            // Always clear the flag, even if leaving the tab cancelled the download half way.
            loading = false
        }
    }

    /** Keeps the worked-out list on the phone, ready for next time. */
    private suspend fun save(list: List<Show>) {
        val file = cacheFile ?: return
        val sig = signature
        val tag = etag
        val at = parsedAt
        withContext(Dispatchers.IO) {
            try {
                val arr = JSONArray()
                for (s in list) {
                    arr.put(
                        JSONObject()
                            .put("s", s.start.toEpochMilli())
                            .put("e", s.end.toEpochMilli())
                            .put("dj", s.dj ?: JSONObject.NULL)
                            .put("t", s.title)
                            .put("g", s.genres ?: JSONObject.NULL)
                            .put("d", s.description)
                            .put("f", s.isFiller)
                    )
                }
                val root = JSONObject()
                    .put("v", CACHE_VERSION)
                    .put("sig", sig)
                    .put("etag", tag ?: "")
                    .put("at", at)
                    .put("shows", arr)
                // Write to a temporary file first, so a half-finished save can't damage the good copy.
                val temp = java.io.File(file.parentFile, file.name + ".tmp")
                temp.writeText(root.toString(), Charsets.UTF_8)
                if (!temp.renameTo(file)) {
                    file.writeText(root.toString(), Charsets.UTF_8)
                    temp.delete()
                }
            } catch (e: Exception) {
                // Not being able to save is fine: it just won't be instant next time.
            }
        }
    }

    private class SavedSchedule(
        val shows: List<Show>,
        val signature: Long,
        val etag: String?,
        val parsedAt: Long
    )

    private companion object {
        const val CACHE_VERSION = 1
        // The list covers about two weeks ahead, so it is worked out again at least this often.
        const val REPARSE_AFTER_MS = 6 * 60 * 60_000L
    }
}

private class Fetched(val text: String?, val etag: String?, val notModified: Boolean)

/**
 * Downloads the station's public Google Calendar. Sends the "tag" from last time, if given, so
 * the server can answer "unchanged" (a tiny reply). Returns null if anything goes wrong.
 */
private fun fetchCalendar(etag: String?): Fetched? =
    try {
        val conn = URL(Config.CALENDAR_ICS_URL).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("User-Agent", "SafehouseRadioApp")
            if (etag != null) conn.setRequestProperty("If-None-Match", etag)
            when (conn.responseCode) {
                304 -> Fetched(null, etag, true)
                200 -> {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    if (body.contains("BEGIN:VCALENDAR")) Fetched(body, conn.getHeaderField("ETag"), false) else null
                }
                else -> null
            }
        } finally {
            conn.disconnect()
        }
    } catch (e: Exception) {
        null
    }

// ---------------------------------------------------------------------------
// Schedule tab
// ---------------------------------------------------------------------------

@Composable
fun ScheduleScreen(state: ScheduleState, webView: () -> WebView) {
    if (state.showWeb) {
        ScheduleWeb(webView(), onBack = { state.showWeb = false })
    } else {
        ScheduleContent(state)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScheduleContent(state: ScheduleState) {
    val scope = rememberCoroutineScope()
    val textColor = MaterialTheme.colorScheme.onBackground
    val zone = remember { ZoneId.systemDefault() }
    val is24 = DateFormat.is24HourFormat(LocalContext.current)
    val timeFmt = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a") }
    val dayFmt = remember { DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault()) }
    val chipFmt = remember { DateTimeFormatter.ofPattern("EEE d", Locale.getDefault()) }

    var pulled by remember { mutableStateOf(false) }

    // The clock ticks so "On Air" moves on by itself while the tab is open.
    var now by remember { mutableStateOf(Instant.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = Instant.now()
        }
    }

    // What the stream server says is on air right now. This is the truth: the calendar is only
    // the plan (a DJ may go live over the top, or the calendar may be wrong).
    var feed by remember { mutableStateOf<LiveStatus?>(null) }
    LaunchedEffect(Unit) {
        var misses = 0
        while (true) {
            val latest = withContext(Dispatchers.IO) { fetchLiveStatus() }
            if (latest != null) {
                feed = latest
                misses = 0
            } else if (++misses >= 3) {
                feed = null   // can't reach it for a while: fall back to the calendar alone
            }
            delay(15_000)
        }
    }

    // Fetch when the tab opens (if the data is old), then every 10 minutes while it stays open.
    LaunchedEffect(Unit) {
        if (!state.loading && state.needsRefresh()) state.load()
        while (true) {
            delay(10 * 60_000L)
            if (!state.loading) state.load()
        }
    }

    Column(Modifier.fillMaxSize()) {
        PageHeader("Schedule")

        if (state.shows.isEmpty()) {
            if (state.loading || (!state.failed && !state.loadedOnce)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (state.failed) "Couldn't load the schedule." else "No shows listed yet.",
                        color = textColor
                    )
                    Button(
                        onClick = { scope.launch { state.load() } },
                        modifier = Modifier.padding(top = 12.dp)
                    ) { Text("Try again") }
                    Button(
                        onClick = { state.showWeb = true },
                        modifier = Modifier.padding(top = 8.dp)
                    ) { Text("Open website schedule") }
                }
            }
            return@Column
        }

        val snap = remember(state.shows, now) { ScheduleLogic.snapshot(state.shows, now) }
        val today = now.atZone(zone).toLocalDate()
        val days = remember(today) { (0 until 14).map { today.plusDays(it.toLong()) } }
        val selected = state.selectedDay.coerceIn(0, days.size - 1)
        val dayList = remember(state.shows, selected, today) {
            ScheduleLogic.forDay(state.shows, days[selected], zone)
        }

        fun rangeText(s: Show): String =
            "${timeFmt.format(s.start.atZone(zone))} – ${timeFmt.format(s.end.atZone(zone))}"

        fun whenText(s: Show): String {
            val d = s.start.atZone(zone).toLocalDate()
            return when (d) {
                today -> rangeText(s)
                today.plusDays(1) -> "Tomorrow · ${rangeText(s)}"
                today.minusDays(1) -> "Yesterday · ${rangeText(s)}"
                else -> "${dayFmt.format(d)} · ${rangeText(s)}"
            }
        }

        // Pull down on the list to reload the schedule.
        // (The little spinner only shows for a pull, not for the quiet refresh in the background.)
        PullToRefreshBox(
            isRefreshing = pulled && state.loading,
            onRefresh = {
                pulled = true
                scope.launch {
                    try {
                        state.load()
                    } finally {
                        pulled = false
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { SectionLabel("On Air") }
            item {
                val onAir = remember(snap.onAir, feed) { ScheduleLogic.onAirDisplay(snap.onAir, feed) }
                if (onAir != null) {
                    val range = if (onAir.start != null && onAir.end != null) {
                        "${timeFmt.format(onAir.start.atZone(zone))} – ${timeFmt.format(onAir.end.atZone(zone))}"
                    } else {
                        null
                    }
                    OnAirCard(onAir, range, now)
                } else {
                    Note("Nothing on air right now.")
                }
            }

            if (snap.upNext.isNotEmpty()) {
                item { SectionLabel("Up Next") }
                itemsIndexed(snap.upNext) { _, s -> ShowCard(s, whenText(s)) }
            }

            if (snap.recent.isNotEmpty()) {
                item { SectionLabel("Recently Aired") }
                itemsIndexed(snap.recent) { _, s -> ShowCard(s, whenText(s), faded = true) }
            }

            item { SectionLabel("Schedule") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(days) { i, d ->
                        DayChip(
                            label = when (i) {
                                0 -> "Today"
                                1 -> "Tomorrow"
                                else -> chipFmt.format(d)
                            },
                            selected = i == selected,
                            onClick = { state.selectedDay = i }
                        )
                    }
                }
            }
            if (dayList.isEmpty()) {
                item { Note("No shows listed for this day.") }
            } else {
                itemsIndexed(dayList) { _, s -> ShowCard(s, rangeText(s)) }
            }
        }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        color = Color(0xFFC4BFDA),
        fontSize = 18.sp,
        fontWeight = FontWeight.SemiBold,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.85f), Offset(0f, 3f), 14f)),
        modifier = Modifier.padding(top = 10.dp)
    )
}

@Composable
private fun Note(text: String) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f),
        fontSize = 14.sp,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.85f), Offset(0f, 2f), 10f))
    )
}

@Composable
private fun DayChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text = label,
        color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) MaterialTheme.colorScheme.primary else CardSurface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

/** One show. Tap a card to read the show's description (when the calendar has one). */
@Composable
private fun ShowCard(
    show: Show,
    whenLabel: String,
    faded: Boolean = false
) {
    val primary = MaterialTheme.colorScheme.primary
    val textColor = MaterialTheme.colorScheme.onBackground
    val description = remember(show) { cleanDescription(show.description) }
    var open by remember(show) { mutableStateOf(false) }
    val quiet = show.isFiller || faded
    val alpha = if (quiet) 0.75f else 1f

    Column(
        Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .clickable(enabled = description.isNotEmpty()) { open = !open }
            .padding(14.dp)
    ) {
        Text(
            text = whenLabel,
            color = primary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )

        val dj = show.dj
        // Main line: the DJ if there is one, otherwise the show name.
        Text(
            text = dj ?: show.title,
            color = textColor.copy(alpha = alpha),
            fontSize = 18.sp,
            fontWeight = if (show.isFiller && dj == null) FontWeight.Normal else FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp)
        )
        if (dj != null) {
            Text(
                text = show.title,
                color = textColor.copy(alpha = alpha),
                fontSize = 15.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
        val genres = show.genres
        if (genres != null) {
            Text(
                text = genres,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alpha),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (open && description.isNotEmpty()) {
            Text(
                text = description,
                color = textColor.copy(alpha = 0.9f),
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

private val OnAirInk = Color(0xFF14121A)

/**
 * The "On Air" card: solid lavender (the same colour as the tab bar and play button), so it is
 * the clearest thing on the page. It shows what the live feed says is playing, with the calendar's
 * times and details when they agree.
 */
@Composable
private fun OnAirCard(view: OnAirDisplay, range: String?, now: Instant) {
    val lavender = MaterialTheme.colorScheme.primary
    val description = remember(view) { cleanDescription(view.description) }
    var open by remember(view) { mutableStateOf(false) }
    val artUrl = remember(view.feedKey) { "${Config.ARTWORK_URL}?t=${System.currentTimeMillis()}" }

    // The little dot beside LIVE breathes in and out.
    val pulse = rememberInfiniteTransition(label = "liveDot")
    val dotAlpha by pulse.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
        label = "dot"
    )

    Column(
        Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clip(RoundedCornerShape(18.dp))
            .background(lavender)
            .clickable(enabled = description.isNotEmpty()) { open = !open }
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            AsyncImage(
                model = artUrl,
                contentDescription = null,
                placeholder = painterResource(R.drawable.station_logo),
                error = painterResource(R.drawable.station_logo),
                fallback = painterResource(R.drawable.station_logo),
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(72.dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(OnAirInk)
                            .padding(horizontal = 9.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(7.dp)
                                .alpha(if (view.tag == "LIVE") dotAlpha else 1f)
                                .clip(CircleShape)
                                .background(Color.White)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            text = view.tag,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (range != null) {
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = range,
                            color = OnAirInk,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
                Text(
                    text = view.dj ?: view.title.orEmpty(),
                    color = OnAirInk,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    modifier = Modifier.padding(top = 6.dp)
                )
                if (view.dj != null && !view.title.isNullOrBlank()) {
                    Text(
                        text = view.title,
                        color = OnAirInk,
                        fontSize = 16.sp,
                        maxLines = 2,
                        modifier = Modifier.padding(top = 1.dp)
                    )
                }
                if (!view.genres.isNullOrBlank()) {
                    Text(
                        text = view.genres,
                        color = OnAirInk.copy(alpha = 0.75f),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }
        }

        if (view.scheduledNote != null) {
            Text(
                text = view.scheduledNote,
                color = OnAirInk.copy(alpha = 0.8f),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }

        if (view.start != null && view.end != null) {
            val total = Duration.between(view.start, view.end).toMillis().coerceAtLeast(1L)
            val done = Duration.between(view.start, now).toMillis()
            val fraction = (done.toFloat() / total.toFloat()).coerceIn(0f, 1f)
            Box(
                Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(OnAirInk.copy(alpha = 0.25f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(fraction)
                        .fillMaxHeight()
                        .background(OnAirInk)
                )
            }
        }

        if (open && description.isNotEmpty()) {
            Text(
                text = description,
                color = OnAirInk,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

/** Show descriptions in the calendar are sometimes plain text and sometimes HTML. */
private fun cleanDescription(raw: String): String {
    if (raw.isBlank()) return ""
    val text = if (raw.contains('<')) {
        Html.fromHtml(raw, Html.FROM_HTML_MODE_COMPACT).toString()
    } else {
        raw
    }
    return text.replace("\uFFFC", "").replace(Regex("\n{3,}"), "\n\n").trim()
}

/** The website's own schedule page, used if the calendar can't be loaded. */
@Composable
private fun ScheduleWeb(webView: WebView, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text(
            text = "‹  Back to schedule",
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xCC050505))
                .clickable(onClick = onBack)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        )
        Box(Modifier.fillMaxWidth().weight(1f)) {
            WebTab(webView)
        }
    }
}
