package com.example.radioplayer

import android.content.Context
import android.text.Html
import android.text.format.DateFormat
import android.webkit.WebView
import java.nio.ByteBuffer
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------

/** Holds the schedule so it survives switching tabs. */
class ScheduleState {
    var shows by mutableStateOf<List<Show>>(emptyList())
    var loading by mutableStateOf(false)
    var failed by mutableStateOf(false)
    var loadedOnce by mutableStateOf(false)
    var showWeb by mutableStateOf(false)   // fall back to the website's own schedule page
    var innerTab by mutableStateOf(0)       // 0 = On Air, 1 = Schedule (the two tabs inside this page)
    var query by mutableStateOf("")          // the search box on the Schedule tab

    // Show reminders: the DJs being followed (by key), the Following filter, and the setup screen.
    var followed by mutableStateOf<Set<String>>(emptySet())
    var showsOn by mutableStateOf<Set<String>>(emptySet())    // single shows switched on (DJ not followed)
    var showsOff by mutableStateOf<Set<String>>(emptySet())   // shows skipped for a followed DJ
    var onlyFollowing by mutableStateOf(false)
    var showSetup by mutableStateOf(false)
    var setupSeen by mutableStateOf(false)

    /** Called with the new list each time the calendar has been read (used to refresh reminders). */
    var afterLoad: ((List<Show>) -> Unit)? = null

    // What the stream server last said was on air, kept here so the On Air card can show the right
    // thing the moment the tab opens (instead of showing the calendar first and then changing).
    var feed by mutableStateOf<LiveStatus?>(null)
    var feedAt by mutableStateOf(0L)         // when that was known (0 = not yet)
    private var lastLoaded = 0L
    private var cacheFile: java.io.File? = null

    // What the saved copy was made from, so an unchanged calendar needs no reprocessing.
    private var signature = 0L     // a fingerprint of the calendar text it was made from
    private var etag: String? = null
    private var parsedAt = 0L      // when the list was last worked out from the calendar

    /** Where the last result is kept, so the schedule can appear instantly next time. */
    fun useCache(dir: java.io.File) {
        cacheFile = java.io.File(dir, "schedule.json")
        try {
            java.io.File(dir, "schedule.ics").delete()   // the old kind of saved copy
        } catch (e: Exception) {
        }
    }

    fun needsRefresh(): Boolean =
        shows.isEmpty() || System.currentTimeMillis() - lastLoaded > 10 * 60_000L

    /** Works the shows out of the calendar for the 3 days gone by and [daysAhead] days to come. */
    private suspend fun parseText(text: String, daysAhead: Long): List<Show>? =
        withContext(Dispatchers.Default) {
            try {
                val now = Instant.now()
                ScheduleLogic.toShows(
                    IcsCalendar.parse(text, now.minus(Duration.ofDays(3)), now.plus(Duration.ofDays(daysAhead)))
                )
            } catch (e: Exception) {
                null
            }
        }

    /** Shows the copy saved last time straight away (no waiting for the network). */
    suspend fun loadFromCache() {
        if (shows.isNotEmpty()) return
        val file = cacheFile ?: return
        val saved = withContext(Dispatchers.IO) { ScheduleCache.read(file) } ?: return
        // A download may have finished while this was reading: never replace newer data.
        if (shows.isEmpty() && saved.shows.isNotEmpty()) {
            shows = saved.shows
            signature = saved.signature
            etag = saved.etag
            parsedAt = saved.parsedAt
            loadedOnce = true
        }
    }

    suspend fun load() {
        loading = true
        try {
            // If the list was worked out recently, ask the server "has it changed?" first.
            val recent = shows.isNotEmpty() && System.currentTimeMillis() - parsedAt < REPARSE_AFTER_MS
            val fetched = withContext(Dispatchers.IO) { fetchCalendar(if (recent) etag else null) }

            if (fetched == null) {
                // Keep showing what we have; only complain when there is nothing to show.
                if (shows.isEmpty()) failed = true
                return
            }
            if (fetched.notModified) {
                failed = false
                lastLoaded = System.currentTimeMillis()
                return
            }

            val text = fetched.text ?: return
            val sig = text.length.toLong() * 31L + text.hashCode()
            if (recent && sig == signature) {
                // Exactly the same calendar as last time: nothing to work out again.
                etag = fetched.etag ?: etag
                failed = false
                lastLoaded = System.currentTimeMillis()
                return
            }

            // Nothing on screen yet: show the next two weeks first (quick), then fill in the rest.
            if (shows.isEmpty()) {
                val firstLook = parseText(text, FIRST_LOOK_DAYS)
                if (firstLook != null && firstLook.isNotEmpty()) {
                    shows = firstLook
                    failed = false
                    loadedOnce = true
                }
            }
            val parsed = parseText(text, MONTH_DAYS)
            if (parsed == null) {
                if (shows.isEmpty()) failed = true
                return
            }
            shows = parsed
            failed = false
            loadedOnce = true
            lastLoaded = System.currentTimeMillis()
            parsedAt = lastLoaded
            signature = sig
            etag = fetched.etag
            save(parsed)
            afterLoad?.let { callback ->
                withContext(Dispatchers.Default) {
                    try {
                        callback(parsed)
                    } catch (e: Exception) {
                        // Reminders failing must never break the schedule.
                    }
                }
            }
        } finally {
            // Always clear the flag, even if leaving the tab cancelled the download half way.
            loading = false
        }
    }

    /** Keeps the worked-out list on the phone, ready for next time. */
    private suspend fun save(list: List<Show>) {
        val file = cacheFile ?: return
        val sig = signature
        val tag = etag
        val at = parsedAt
        withContext(Dispatchers.IO) {
            try {
                val arr = JSONArray()
                for (s in list) {
                    arr.put(
                        JSONObject()
                            .put("s", s.start.toEpochMilli())
                            .put("e", s.end.toEpochMilli())
                            .put("dj", s.dj ?: JSONObject.NULL)
                            .put("t", s.title)
                            .put("g", s.genres ?: JSONObject.NULL)
                            .put("d", s.description)
                            .put("f", s.isFiller)
                    )
                }
                val root = JSONObject()
                    .put("v", ScheduleCache.VERSION)
                    .put("sig", sig)
                    .put("etag", tag ?: "")
                    .put("at", at)
                    .put("shows", arr)
                // Write to a temporary file first, so a half-finished save can't damage the good copy.
                val temp = java.io.File(file.parentFile, file.name + ".tmp")
                temp.writeText(root.toString(), Charsets.UTF_8)
                if (!temp.renameTo(file)) {
                    file.writeText(root.toString(), Charsets.UTF_8)
                    temp.delete()
                }
            } catch (e: Exception) {
                // Not being able to save is fine: it just won't be instant next time.
            }
        }
    }

    private companion object {
        // The list covers a month ahead, so it is worked out again at least this often.
        const val REPARSE_AFTER_MS = 6 * 60 * 60_000L
        const val FIRST_LOOK_DAYS = 15L
        const val MONTH_DAYS = 123L   // the calendar is read 120 days ahead (for the DJ pages); the Schedule tab lists the first 31
    }
}

private class Fetched(val text: String?, val etag: String?, val notModified: Boolean)

/** A saved copy of the schedule, as read from the phone. */
class SavedSchedule(val shows: List<Show>, val signature: Long, val etag: String?, val parsedAt: Long)

/** Reads the schedule saved on the phone (used by the Schedule tab, and by the playback service). */
object ScheduleCache {
    // 5: the placeholder "Syndicast" is no longer kept as a DJ, so older saved lists are read afresh.
    // 2: the saved list now covers a month (version 1 only covered two weeks, so it is ignored).
    const val VERSION = 5

    fun read(file: java.io.File): SavedSchedule? =
        try {
            if (!file.exists()) null
            else {
                val root = JSONObject(file.readText(Charsets.UTF_8))
                if (root.optInt("v") != VERSION) null
                else {
                    val arr = root.getJSONArray("shows")
                    val list = ArrayList<Show>(arr.length())
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        list.add(
                            Show(
                                start = Instant.ofEpochMilli(o.getLong("s")),
                                end = Instant.ofEpochMilli(o.getLong("e")),
                                dj = if (o.isNull("dj")) null else o.getString("dj"),
                                title = o.getString("t"),
                                genres = if (o.isNull("g")) null else o.getString("g"),
                                description = o.getString("d"),
                                isFiller = o.getBoolean("f")
                            )
                        )
                    }
                    SavedSchedule(list, root.optLong("sig"), root.optString("etag").ifEmpty { null }, root.optLong("at"))
                }
            }
        } catch (e: Exception) {
            null   // a damaged or old-style file is simply ignored
        }
}

/**
 * Downloads the station's public Google Calendar. Sends the "tag" from last time, if given, so
 * the server can answer "unchanged" (a tiny reply). Returns null if anything goes wrong.
 */
private fun fetchCalendar(etag: String?): Fetched? =
    try {
        val conn = URL(Config.CALENDAR_ICS_URL).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("User-Agent", Config.userAgent)
            if (etag != null) conn.setRequestProperty("If-None-Match", etag)
            when (conn.responseCode) {
                304 -> Fetched(null, etag, true)
                200 -> {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    if (body.contains("BEGIN:VCALENDAR")) Fetched(body, conn.getHeaderField("ETag"), false) else null
                }
                else -> null
            }
        } finally {
            conn.disconnect()
        }
    } catch (e: Exception) {
        null
    }

// ---------------------------------------------------------------------------
// Schedule tab
// ---------------------------------------------------------------------------

@Composable
fun ScheduleScreen(state: ScheduleState, djs: List<Dj>, onOpenDj: (Show) -> Unit, onOpenDjPage: (Dj) -> Unit, bioFor: (Dj) -> String?, webView: () -> WebView) {
    // (The reminder setup screen is shown by RadioApp, over whichever tab asked for it.)
    if (state.showWeb) {
        ScheduleWeb(webView(), onBack = { state.showWeb = false })
    } else {
        // The (i) beside the filters opens a "Safehouse says…" bubble over this page.
        val bubble = remember { BubbleState() }
        BubbleHost(bubble) { ScheduleContent(state, djs, onOpenDj, onOpenDjPage, bioFor, bubble) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScheduleContent(state: ScheduleState, djs: List<Dj>, onOpenDj: (Show) -> Unit, onOpenDjPage: (Dj) -> Unit, bioFor: (Dj) -> String?, bubble: BubbleState) {
    val scope = rememberCoroutineScope()
    val textColor = MaterialTheme.colorScheme.onBackground
    val zone = remember { ZoneId.systemDefault() }
    val ctx = LocalContext.current
    val is24 = DateFormat.is24HourFormat(ctx)
    val timeFmt = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a") }
    val dayFmt = remember { DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault()) }

    var pulled by remember { mutableStateOf(false) }

    // Who is followed for show reminders (kept on the phone).
    LaunchedEffect(Unit) {
        state.followed = Reminders.followedKeys(ctx)
        state.showsOn = Reminders.showsOn(ctx)
        state.showsOff = Reminders.showsOff(ctx)
        state.setupSeen = Reminders.setupSeen(ctx)
    }

    // The clock ticks so "On Air" moves on by itself while the tab is open.
    var now by remember { mutableStateOf(Instant.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = Instant.now()
        }
    }

    // What the stream server says is on air right now. This is the truth: the calendar is only
    // the plan (a DJ may go live over the top, or the calendar may be wrong).
    val feed = state.feed
    val visible by rememberAppVisible()
    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect      // nothing is checked while the app is in the background
        // Start from whatever the Radio tab (or anything else) heard a moment ago, so the card needn't wait.
        val heard = LiveFeed.last
        if (heard != null && LiveFeed.at > state.feedAt && System.currentTimeMillis() - LiveFeed.at < 60_000L) {
            state.feed = heard
            state.feedAt = LiveFeed.at
        }
        var misses = 0
        // A very recent answer needs no new request straight away.
        val age = System.currentTimeMillis() - state.feedAt
        if (state.feedAt != 0L && age in 0..9_000L) delay(15_000L - age)
        while (true) {
            val latest = withContext(Dispatchers.IO) { fetchLiveStatus() }
            if (latest != null) {
                state.feed = latest
                state.feedAt = System.currentTimeMillis()
                misses = 0
            } else if (++misses >= 3) {
                state.feed = null   // can't reach it for a while: fall back to the calendar alone
                state.feedAt = System.currentTimeMillis()
            }
            delay(15_000)
        }
    }

    // The On Air card waits (briefly) for the first answer from the stream server, so it never shows
    // the calendar's version for a moment and then jumps to the real one.
    var waited by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(2_500)
        waited = true
    }
    val feedKnown = waited || (state.feedAt != 0L && System.currentTimeMillis() - state.feedAt < 90_000L)

    // Fetch when the tab opens (if the data is old), then every 10 minutes while it stays open.
    LaunchedEffect(visible) {
        if (!visible) return@LaunchedEffect
        if (!state.loading && state.needsRefresh()) state.load()
        while (true) {
            delay(10 * 60_000L)
            if (!state.loading) state.load()
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (state.shows.isEmpty()) {
            PageHeader("Schedule")
            if (state.loading || (!state.failed && !state.loadedOnce)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = ScreenLayout.side()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (state.failed) "Couldn't load the schedule." else "No shows listed yet.",
                        color = textColor
                    )
                    Button(
                        onClick = { scope.launch { state.load() } },
                        modifier = Modifier.padding(top = 12.dp)
                    ) { Text("Try again") }
                    Button(
                        onClick = { state.showWeb = true },
                        modifier = Modifier.padding(top = 8.dp)
                    ) { Text("Open website schedule") }
                }
            }
            return@Column
        }

        val snap = remember(state.shows, now) { ScheduleLogic.snapshot(state.shows, now) }
        val today = now.atZone(zone).toLocalDate()
        val days = remember(today) { (0 until SHOWN_DAYS).map { today.plusDays(it.toLong()) } }
        // Every day for the next month, worked out once (not on every redraw).
        val dayLists = remember(state.shows, today) {
            days.map { ScheduleLogic.forDay(state.shows, it, zone) }
        }

        fun rangeText(s: Show): String =
            "${timeFmt.format(s.start.atZone(zone))} – ${timeFmt.format(s.end.atZone(zone))}"

        fun whenText(s: Show): String {
            val d = s.start.atZone(zone).toLocalDate()
            return when (d) {
                today -> rangeText(s)
                today.plusDays(1) -> "Tomorrow · ${rangeText(s)}"
                today.minusDays(1) -> "Yesterday · ${rangeText(s)}"
                else -> "${dayFmt.format(d)} · ${rangeText(s)}"
            }
        }

        // The DJ's photo for the round picture on a card (null = the station logo is used).
        val photoCache = remember(djs) { HashMap<String, String?>() }
        fun photoFor(s: Show): String? {
            // A DJ named on the slot, else the DJ found from the show's title (e.g. WARM).
            val name = s.dj ?: s.title.takeUnless { s.isFiller } ?: return null
            return photoCache.getOrPut(name) { UpNext.djForShow(s, djs)?.imageUrl }
        }

        // null = no bell on this card (empty slots and shows that have finished).
        fun bellFor(s: Show): Boolean? {
            if (s.isFiller || !s.end.isAfter(now)) return null
            if (s.dj == null && UpNext.djForShow(s, djs) == null) return null
            return FollowRules.reminderKey(s, state.followed, state.showsOn, state.showsOff) != null
        }
        // The one rule: does this slot get a reminder?
        fun isFollowedShow(s: Show): Boolean =
            FollowRules.reminderKey(s, state.followed, state.showsOn, state.showsOff) != null
        // The tag on a card: "Following" when the DJ is followed, "Reminder on" for a single show.
        fun tagFor(s: Show): String? = when {
            !s.end.isAfter(now) || !isFollowedShow(s) -> null
            FollowRules.isFollowing(s, state.followed) -> "Following"
            else -> "Reminder on"
        }

        // Share button for a card: only on shows that have a bell (coming up or on now, with a DJ).
        fun shareFor(s: Show): (() -> Unit)? {
            if (bellFor(s) == null) return null
            val name = s.dj ?: UpNext.djForShow(s, djs)?.name ?: s.title
            val live = !s.start.isAfter(now)
            val photo = UpNext.djForShow(s, djs)?.imageUrl
            return { ShowActions.share(ctx, ShowActions.shareText(name, s, live, zone, is24), ShowActions.cardFor(name, s, live, zone, is24, photo)) }
        }

        // What a card shows when tapped if its slot has no description: the opening of the DJ's bio.
        fun bioOf(s: Show): String? = if (s.isFiller) null else UpNext.djForShow(s, djs)?.let { bioFor(it) }?.let { shortBio(it) }

        ScheduleTabs(selected = state.innerTab) { state.innerTab = it }

        if (state.innerTab == 1) {
            SearchField(
                value = state.query,
                onValueChange = { state.query = it },
                placeholder = "Search show or DJ…",
                modifier = Modifier.padding(start = ScreenLayout.side(), end = ScreenLayout.side(), bottom = ScreenLayout.gap())
            )

            // A warning only when reminders are on but the phone is blocking them.
            val needsAttention = remember(state.followed, state.showsOn, state.showSetup, state.innerTab) {
                AppSettings.remindersOn(ctx) &&
                    (state.followed.isNotEmpty() || state.showsOn.isNotEmpty()) &&
                    (!Reminders.notificationsOk(ctx) || (!Reminders.batteryOk(ctx) && !state.setupSeen))
            }
            if (needsAttention) ReminderBanner(onFix = { state.showSetup = true })

            Row(
                modifier = Modifier.fillMaxWidth().padding(start = ScreenLayout.side(), end = ScreenLayout.side(), bottom = ScreenLayout.gap()),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilterPill("All shows", selected = !state.onlyFollowing) { state.onlyFollowing = false }
                Spacer(Modifier.width(8.dp))
                FilterPill("Following", selected = state.onlyFollowing) { state.onlyFollowing = true }
                Spacer(Modifier.weight(1f))
                // 48dp touch box with a 40dp pill: pull it 4dp right so the pill sits on the page margin.
                Box(Modifier.offset(x = 4.dp)) { RemindersButton(bubble) { state.showSetup = true } }
            }
        }

        // Pull down on the list to reload the schedule.
        // (The little spinner only shows for a pull, not for the quiet refresh in the background.)
        PullToRefreshBox(
            isRefreshing = pulled && state.loading,
            onRefresh = {
                pulled = true
                scope.launch {
                    try {
                        state.load()
                    } finally {
                        pulled = false
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        ) {
            if (state.innerTab == 0) {
                // ---- On Air tab: what's on now, what's next, what just finished ----
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = ScreenLayout.side(), end = ScreenLayout.side(), top = 0.dp, bottom = ScreenLayout.gap()),
                    verticalArrangement = Arrangement.spacedBy(ScreenLayout.gap())
                ) {
                    item { SectionLabel("On Air", first = true) }
                    item {
                        val onAir = remember(snap.onAir, feed, djs) { ScheduleLogic.onAirDisplay(snap.onAir, feed, djs) }
                        if (!feedKnown) {
                            OnAirPlaceholder()
                        } else if (onAir != null) {
                            val range = if (onAir.start != null && onAir.end != null) {
                                "${timeFmt.format(onAir.start.atZone(zone))} – ${timeFmt.format(onAir.end.atZone(zone))}"
                            } else {
                                null
                            }
                            OnAirCard(onAir, range, now, onOpenDjPage)
                        } else {
                            Note("Nothing on air right now.")
                        }
                    }

                    if (snap.upNext.isNotEmpty()) {
                        item { SectionLabel("Up Next") }
                        itemsIndexed(snap.upNext) { _, s -> ShowCard(s, whenText(s), lilac = true, bell = bellFor(s), tag = tagFor(s), photoUrl = photoFor(s), onBell = { onOpenDj(s) }, onShare = shareFor(s), fallbackText = bioOf(s)) }
                    }

                    if (snap.recent.isNotEmpty()) {
                        item { SectionLabel("Recently Aired") }
                        itemsIndexed(snap.recent) { _, s -> ShowCard(s, whenText(s), faded = true, photoUrl = photoFor(s), fallbackText = bioOf(s)) }
                    }
                }
            } else {
                // ---- Schedule tab: the next month, day by day, with search ----
                val q = state.query.trim()
                val shown = remember(dayLists, q, state.onlyFollowing, state.followed, state.showsOn, state.showsOff) {
                    dayLists.map { list ->
                        list.filter {
                            (q.isEmpty() || ScheduleLogic.matchesQuery(it, q)) &&
                                (!state.onlyFollowing || isFollowedShow(it))
                        }
                    }
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = ScreenLayout.side(), end = ScreenLayout.side(), top = 0.dp, bottom = ScreenLayout.gap()),
                    verticalArrangement = Arrangement.spacedBy(ScreenLayout.gap())
                ) {
                    if (shown.none { it.isNotEmpty() }) {
                        item {
                            Note(
                                when {
                                    state.onlyFollowing && state.followed.isEmpty() && state.showsOn.isEmpty() ->
                                        "You're not following anyone yet. Open a DJ's page and tap Follow to get a reminder ${Reminders.LEAD_MINUTES} minutes before they go on."
                                    state.onlyFollowing -> "None of your followed DJs or shows are on in the next month."
                                    q.isEmpty() -> "No shows listed for the next month."
                                    else -> "No shows match \"$q\" in the next month."
                                }
                            )
                        }
                    } else {
                        for (i in days.indices) {
                            val list = shown[i]
                            if (list.isEmpty()) continue
                            item(key = "day-${days[i]}") {
                                SectionLabel(
                                    when (i) {
                                        0 -> "Today · ${dayFmt.format(days[i])}"
                                        1 -> "Tomorrow · ${dayFmt.format(days[i])}"
                                        else -> dayFmt.format(days[i])
                                    },
                                    first = i == shown.indexOfFirst { it.isNotEmpty() }
                                )
                            }
                            itemsIndexed(list) { _, s ->
                                ShowCard(
                                    show = s,
                                    whenLabel = rangeText(s),
                                    faded = !s.end.isAfter(now),
                                    highlight = s == snap.onAir,
                                    lilac = i == 0,
                                    bell = bellFor(s),
                                    tag = tagFor(s),
                                    photoUrl = photoFor(s),
                                    onBell = { onOpenDj(s) },
                                    onShare = shareFor(s),
                                    fallbackText = bioOf(s)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * The two tabs inside the Schedule page: "On Air" and "Schedule". This bar is exactly the same
 * size as the lavender title bar on the Radio and DJs pages (same height, width, corners and
 * text size), so the three pages line up.
 */
@Composable
private fun ScheduleTabs(selected: Int, onSelect: (Int) -> Unit) {
    val lavender = MaterialTheme.colorScheme.primary
    Row(
        Modifier
            .fillMaxWidth()
            // The page's side border, and the same gap above and below as the Radio tab's Next pill (see ScreenLayout).
            .padding(start = ScreenLayout.side(), end = ScreenLayout.side(), top = ScreenLayout.gap(), bottom = ScreenLayout.gap())
            .lift(RoundedCornerShape(50))
            .clip(RoundedCornerShape(50))
            .background(CardSurface)
            .padding(4.dp)
    ) {
        listOf("On Air", "Schedule").forEachIndexed { i, label ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = BarHeight - 8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (i == selected) lavender else Color.Transparent)
                    .then(if (i == selected) Modifier.border(EdgeWidth, edgeFor(lavender), RoundedCornerShape(50)) else Modifier)
                    // "selectable" tells screen readers which tab is chosen.
                    .selectable(selected = i == selected, role = Role.Tab, onClick = { onSelect(i) })
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    color = if (i == selected) LavenderInk else MaterialTheme.colorScheme.onBackground,
                    fontSize = BarTextSize,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String, first: Boolean = false) {
    Text(
        text = text,
        color = ThemeState.current.textDim,
        fontSize = AppType.Heading,
        fontWeight = FontWeight.Bold,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.85f), Offset(0f, 3f), 14f)),
        // A heading has one extra gap above it (it belongs to the cards under it); the first one on a page has none.
        modifier = Modifier.padding(top = if (first) 0.dp else ScreenLayout.gap())
    )
}

@Composable
private fun Note(text: String) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f),
        fontSize = 14.sp,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.85f), Offset(0f, 2f), 10f))
    )
}

/**
 * One show. Tap a card to read the show's description (when the calendar has one).
 * Cards that are "coming up" ([lilac]) are dark lilac with a lavender edge; finished or later ones are black.
 * Up Next is lilac, Recently Aired is black; in the month list today is lilac and later days are black.
 */
@Composable
private fun ShowCard(
    show: Show,
    whenLabel: String,
    faded: Boolean = false,
    highlight: Boolean = false,   // the show that is on air right now (in the month list)
    lilac: Boolean = false,
    bell: Boolean? = null,        // null = no bell; true = reminders on for this show; false = off (the bell only shows it: tapping opens the DJ's page)
    tag: String? = null,          // "Following" / "Reminder on": the card stands out when it has one
    photoUrl: String? = null,     // the DJ's photo (shown as a small circle; the station logo if none)
    onBell: () -> Unit = {},
    onShare: (() -> Unit)? = null, // null = no Share button (shows that are over, or have no DJ)
    fallbackText: String? = null   // shown when the slot has no description of its own (the opening of the DJ's bio)
) {
    val primary = MaterialTheme.colorScheme.primary
    val textColor = MaterialTheme.colorScheme.onBackground
    val description = remember(show, fallbackText) { cleanDescription(show.description).ifEmpty { fallbackText.orEmpty() } }
    var open by remember(show) { mutableStateOf(false) }
    val quiet = show.isFiller || faded
    val alpha = if (quiet) 0.75f else 1f
    // A card only opens when there is more to see: a description, or genres that don't fit on one line.
    var genresClipped by remember(show) { mutableStateOf(false) }
    val canOpen = description.isNotEmpty() || genresClipped || open
    val shape = RoundedCornerShape(16.dp)
    val surface = if (lilac) LilacSurface else CardSurface
    val whenColor = if (lilac) ThemeState.current.edge else primary
    val genreColor = if (lilac) ThemeState.current.textDim else MaterialTheme.colorScheme.onSurfaceVariant

    // Share (top) and the bell (bottom) are plain icons in a narrow strip down the right edge; the text stops short of it.
    val iconStrip = onShare != null || bell != null
    val iconTint = ThemeState.current.text
    Box(Modifier.fillMaxWidth()) {
    Column(
        Modifier
            .fillMaxWidth()
            .animateContentSize()
            .followedGlow(shape, tag != null)
            .lift(shape, tappable = canOpen)
            .clip(shape)
            .background(surface)
            .then(
                if (lilac) {
                    Modifier.drawBehind { drawRect(LilacEdge, size = Size(4.dp.toPx(), size.height)) }
                } else {
                    Modifier
                }
            )
            .then(if (highlight) Modifier.border(2.dp, primary, shape) else Modifier)
            .then(if (tag != null) Modifier.border(2.dp, FollowedEdge, shape) else Modifier)
            .clickable(enabled = canOpen) { open = !open }
            .then(if (onShare != null && bell != null) Modifier.heightIn(min = 100.dp) else Modifier)
            .padding(start = if (lilac) 18.dp else 14.dp, top = 14.dp, end = if (iconStrip) 52.dp else 14.dp, bottom = 14.dp)
    ) {
        // A small round picture on the left, the same size on every card so the text always lines up.
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = photoUrl,
                contentDescription = null,
                placeholder = rememberLogoTile(),
                error = rememberLogoTile(),
                fallback = rememberLogoTile(),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .border(EdgeWidth, pictureEdge(), CircleShape)
                    .alpha(alpha)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = if (highlight) "ON AIR · $whenLabel" else whenLabel,
                    color = whenColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    style = tightStyle(16.sp),
                    modifier = Modifier
                )

                val dj = show.dj
                // One line each: a name that doesn't fit scrolls past (DJ first, then the show), like the mini player.
                // An opened card shows them in full instead.
                val turns = rememberTurns(2)
                val lines = if (open) Int.MAX_VALUE else 1
                // Main line: the DJ if there is one, otherwise the show name.
                FitOrScrollText(
                    text = dj ?: show.title,
                    color = textColor.copy(alpha = alpha),
                    fontSize = 18.sp,
                    fontWeight = if (show.isFiller && dj == null) FontWeight.Normal else FontWeight.Bold,
                    style = tightStyle(23.sp),
                    maxLines = lines,
                    modifier = Modifier.padding(top = 6.dp),
                    turns = turns, turnIndex = 0
                )
                if (dj != null) {
                    FitOrScrollText(
                        text = show.title,
                        color = textColor.copy(alpha = alpha),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal,
                        style = tightStyle(20.sp),
                        maxLines = lines,
                        turns = turns, turnIndex = 1
                    )
                }
                val genres = show.genres
                if (genres != null) {
                    Text(
                        text = genres,
                        color = genreColor.copy(alpha = alpha),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Normal,
                        // One line, however many genres the DJ listed; tap the card to see them all.
                        maxLines = if (open) Int.MAX_VALUE else 1,
                        overflow = TextOverflow.Ellipsis,
                        onTextLayout = { if (!open) genresClipped = it.hasVisualOverflow },
                        style = tightStyle(16.sp),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

            }
        }

        if (open && description.isNotEmpty()) {
            Text(
                text = description,
                color = textColor.copy(alpha = 0.9f),
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
        if (tag != null) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                FollowTag(tag)
            }
        }
    }
    if (onShare != null) {
        CardShareButton("Share ${show.dj ?: show.title}", iconTint, Modifier.align(Alignment.TopEnd).padding(top = 2.dp, end = 4.dp), onShare)
    }
    if (bell != null) {
        BellButton(
            on = bell,
            dj = show.dj ?: show.title,
            showTitle = show.title,
            tint = iconTint,
            onClick = onBell,
            modifier = Modifier.align(Alignment.BottomEnd).padding(bottom = 2.dp, end = 4.dp)
        )
    }
    }
}

/**
 * Follows or unfollows a DJ for show reminders (used by the bells on the Schedule tab and on a DJ's
 * page). Returns true if the DJ is now followed.
 */
internal fun toggleFollowDj(
    ctx: Context,
    state: ScheduleState,
    scope: CoroutineScope,
    dj: String,
    alsoStop: Collection<String> = emptyList()
): Boolean {
    val k = Reminders.key(dj)
    val same = state.followed.filter { DjMatch.key(it) == DjMatch.key(dj) || it in alsoStop }
    val follow = same.isEmpty()
    if (follow) {
        state.followed = Reminders.setFollowed(ctx, k, dj, true)
    } else {
        for (old in same) state.followed = Reminders.setFollowed(ctx, old, dj, false)
    }
    state.showsOn = Reminders.showsOn(ctx)
    state.showsOff = Reminders.showsOff(ctx)
    val app = ctx.applicationContext
    scope.launch(Dispatchers.Default) { Reminders.rebuild(app, state.shows) }
    return follow
}

/**
 * The bell in the corner of a show card. It only SHOWS the state (filled = reminders on for this show,
 * outline = off) and never changes it: tapping it opens the DJ's page, where the switches are.
 */
@Composable
private fun BellButton(on: Boolean, dj: String, showTitle: String, tint: Color, onClick: () -> Unit, modifier: Modifier) {
    Box(
        modifier = modifier
            .size(48.dp)
            .clip(CircleShape)
            .clickable(onClickLabel = "Open $dj's page", role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painter = painterResource(if (on) R.drawable.ic_bell_filled else R.drawable.ic_bell_outline),
            contentDescription = if (on) {
                "Reminders on for $dj's $showTitle. Opens their page."
            } else {
                "Reminders off for $dj's $showTitle. Opens their page."
            },
            tint = tint,
            modifier = Modifier.size(26.dp)
        )
    }
}

/** "All shows" / "Following" switch under the search box. */
@Composable
private fun FilterPill(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .heightIn(min = 40.dp)
            .lift(RoundedCornerShape(50), tappable = true, fill = if (selected) MaterialTheme.colorScheme.primary else Color.Unspecified)
            .clip(RoundedCornerShape(50))
            .background(if (selected) MaterialTheme.colorScheme.primary else CardSurface)
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) LavenderInk else MaterialTheme.colorScheme.onBackground,
            fontSize = AppType.Pill,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

/**
 * A round "i" pill. It opens a short "Safehouse says…" bubble about reminders, and the bubble has a
 * button that goes on to the full reminder setup page ([onCheckSetup]).
 */
@Composable
private fun RemindersButton(bubble: BubbleState, onCheckSetup: () -> Unit) {
    val view = androidx.compose.ui.platform.LocalView.current
    var bounds by remember { mutableStateOf<androidx.compose.ui.geometry.Rect?>(null) }
    // The outer box gives a full 48dp touch target; the pill you see is 40dp.
    Box(
        modifier = Modifier
            .size(48.dp)
            .onGloballyPositioned { bounds = it.screenBounds(view) }
            .clickable(onClickLabel = "Open explanation", role = Role.Button) {
                bounds?.let { from ->
                    bubble.show(from) {
                        ReminderHelp(onCheckSetup = {
                            bubble.hide()
                            onCheckSetup()
                        })
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .lift(CircleShape, tappable = true)
                .clip(CircleShape)
                .background(CardSurface),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_info),
                contentDescription = "About reminders",
                tint = ThemeState.current.edge,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

/** What the reminders bubble says: how they work, whether the phone is letting them through, and a way to the full setup. */
@Composable
private fun ColumnScope.ReminderHelp(onCheckSetup: () -> Unit) {
    val ctx = LocalContext.current
    val remindersOn = AppSettings.remindersOn(ctx)
    val notificationsOk = Reminders.notificationsOk(ctx)
    val batteryOk = Reminders.batteryOk(ctx)
    BubbleText("Tap the bell on a live show to get a reminder ${Reminders.LEAD_MINUTES} minutes before it goes on air.")
    BubbleText("Follow a DJ from their page and you will be reminded for all their live shows.")
    Column(
        Modifier
            .padding(top = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ThemeState.current.scrim)
            .padding(12.dp)
    ) {
        StatusLine(remindersOn, if (remindersOn) "Reminders are on" else "Reminders are switched off in More")
        StatusLine(notificationsOk, if (notificationsOk) "Notifications are on" else "Notifications are blocked")
        StatusLine(batteryOk, if (batteryOk) "Allowed to run in the background" else "Your phone may delay reminders")
    }
    Box(Modifier.padding(top = 12.dp)) {
        SetupButton("Check my reminder setup", onClick = onCheckSetup)
    }
    BubbleText("Sound and on/off are in More, under Reminders.")
}

@Composable
private fun StatusLine(ok: Boolean, text: String) {
    Row(Modifier.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(if (ok) ThemeState.current.primary else ThemeState.current.live)
        )
        Spacer(Modifier.width(10.dp))
        Text(text, color = ThemeState.current.text, fontSize = 14.sp)
    }
}

/** Shown only when reminders are on but the phone is stopping them. */
@Composable
private fun ReminderBanner(onFix: () -> Unit) {
    val amber = ThemeState.current.live
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = ScreenLayout.side(), end = ScreenLayout.side(), bottom = ScreenLayout.gap())
            .clip(RoundedCornerShape(14.dp))
            .background(ThemeState.current.card.copy(alpha = 0.94f))
            .border(1.dp, amber, RoundedCornerShape(14.dp))
            .padding(start = 14.dp, top = 10.dp, end = 10.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = "Reminders need one more step",
                color = ThemeState.current.live,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Your phone may be stopping them from arriving on time.",
                color = ThemeState.current.text,
                fontSize = 12.sp
            )
        }
        Spacer(Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .heightIn(min = 44.dp)
                .clip(RoundedCornerShape(50))
                .background(amber)
                .clickable(role = Role.Button, onClick = onFix)
                .padding(horizontal = 16.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "Fix", color = LavenderInk, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// Today's cards: a dark, slightly purple surface with a light lavender stripe down the left edge.
internal val LilacSurface: Color get() = ThemeState.current.lilacSurface
internal val LilacEdge: Color get() = ThemeState.current.edge
private const val SHOWN_DAYS = 31   // the Schedule tab lists today and the next 30 days (DJ profiles look further ahead)

private val OnAirInk: Color get() = LavenderInk

// The On Air card never gets shorter than this, so it doesn't jump when its details change.
private val ON_AIR_MIN_HEIGHT = 100.dp

/** Shown for a moment while the first answer from the stream server arrives: same size as the real card. */
@Composable
private fun OnAirPlaceholder() {
    Box(
        Modifier
            .fillMaxWidth()
            .heightIn(min = ON_AIR_MIN_HEIGHT)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
    )
}

/**
 * The "On Air" card: solid lavender (the same colour as the tab bar and play button), so it is
 * the clearest thing on the page. It shows what the live feed says is playing, with the calendar's
 * times and details when they agree.
 */
@Composable
private fun OnAirCard(view: OnAirDisplay, range: String?, now: Instant, onOpenDjPage: (Dj) -> Unit) {
    val shareCtx = LocalContext.current
    val lavender = MaterialTheme.colorScheme.primary
    val description = remember(view) { cleanDescription(view.description) }
    var open by remember(view) { mutableStateOf(false) }
    // The picture is shared with the Radio tab (fetched once per show). It stays null, so the logo
    // tile shows, while loading, if it can't be fetched, or if the station sent its plain default.
    // If the Radio tab already has this show's picture it is used at once, with no download.
    var artBytes by remember { mutableStateOf(if (LiveArtSwitch.on) LiveArt.peek(view.feedKey) else null) }
    val artContext = LocalContext.current.applicationContext
    val liveArtOn = LiveArtSwitch.on
    LaunchedEffect(view.feedKey, liveArtOn) {
        // "Show artwork from the radio" off: the theme's logo, the same as the Radio tab.
        if (!liveArtOn) {
            artBytes = null
            return@LaunchedEffect
        }
        val fetched = if (LiveArt.has(view.feedKey)) LiveArt.peek(view.feedKey) else LiveArt.get(view.feedKey)
        // No picture from the station: a known show's own picture, else the DJ's card photo.
        artBytes = fetched ?: withContext(Dispatchers.IO) {
            ShowArt.bytes(artContext, view.feedKey) ?: ShowArt.djPhoto(view.page?.imageUrl)
        }
    }

    // Tapping the card opens the DJ's page (to follow them, see their next shows); the little › says so.
    // Without a page of ours for this DJ it opens and closes the show's details instead.
    val page = view.page
    val hasDetails = description.isNotEmpty() || !view.genres.isNullOrBlank()
    // Share only when there is a DJ to promote (not for the station's own default programming).
    val canShare = !view.dj.isNullOrBlank()
    Box(Modifier.fillMaxWidth()) {
    Column(
        Modifier
            .fillMaxWidth()
            .animateContentSize()
            .lift(RoundedCornerShape(18.dp), tappable = page != null || hasDetails, fill = lavender)
            .clip(RoundedCornerShape(18.dp))
            .background(lavender)
            .heightIn(min = ON_AIR_MIN_HEIGHT)
            .then(
                if (page != null) {
                    Modifier.clickable(onClickLabel = "Open ${page.name}'s page", role = Role.Button) { onOpenDjPage(page) }
                } else {
                    Modifier.clickable(enabled = hasDetails) { open = !open }
                }
            )
            .padding(14.dp)
    ) {
        // The picture is centred beside the text, like the round photos on the other cards. The little › (the card
        // opens the DJ's page) sits on the right edge, in the middle. There is no "ON AIR" label: the tab and the
        // heading above already say it.
        Row(verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = remember(artBytes) { artBytes?.let { ByteBuffer.wrap(it) } },
                contentDescription = null,
                placeholder = rememberLogoTile(),
                error = rememberLogoTile(),
                fallback = rememberLogoTile(),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(EdgeWidth, pictureEdge(onLight = true), RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width(12.dp))
            val turns = rememberTurns(2)   // the DJ and the show slide (when too long) one after the other
            Column(Modifier.weight(1f)) {
                // The first lines keep clear of the share button in the corner.
                val clearOfShare = if (canShare) Modifier.padding(end = 40.dp) else Modifier
                if (range != null) {
                    Text(
                        text = range,
                        color = OnAirInk,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        style = tightStyle(16.sp),
                        modifier = clearOfShare
                    )
                }
                FitOrScrollText(
                    text = view.dj ?: view.title.orEmpty(),
                    color = OnAirInk,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    style = tightStyle(28.sp),
                    modifier = clearOfShare,
                    turns = turns, turnIndex = 0
                )
                if (view.dj != null && !view.title.isNullOrBlank()) {
                    FitOrScrollText(
                        text = view.title,
                        color = OnAirInk,
                        fontSize = 16.sp,
                        maxLines = 2,
                        style = tightStyle(21.sp),
                        turns = turns, turnIndex = 1
                    )
                }
                // Genres on the left; how long the show has left on the right (when the schedule gives its end).
                val heard = Heard.at(now)
                val timeLeft = Heard.behindText() ?: TimeLeft.text(view.end, heard)
                if (!view.genres.isNullOrBlank() || timeLeft != null) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        if (!view.genres.isNullOrBlank()) {
                            Text(
                                text = view.genres,
                                color = OnAirInk.copy(alpha = 0.75f),
                                fontSize = 12.sp,
                                maxLines = if (open) Int.MAX_VALUE else 1,
                                overflow = TextOverflow.Ellipsis,
                                style = tightStyle(16.sp),
                                modifier = Modifier.weight(1f).padding(top = 2.dp)
                            )
                        } else {
                            Spacer(Modifier.weight(1f))
                        }
                        if (timeLeft != null) {
                            Text(
                                text = timeLeft,
                                color = OnAirInk,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                softWrap = false,
                                style = tightStyle(16.sp),
                                modifier = Modifier.padding(start = 8.dp, top = 2.dp)
                            )
                        }
                    }
                }
            }
            if (page != null) {
                Spacer(Modifier.width(6.dp))
                Text(text = "›", color = OnAirInk, fontSize = 24.sp, fontWeight = FontWeight.Bold, style = tightStyle(26.sp))
            }
        }

        if (view.scheduledNote != null) {
            Text(
                text = view.scheduledNote,
                color = OnAirInk.copy(alpha = 0.8f),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }

        if (view.start != null && view.end != null) {
            val total = Duration.between(view.start, view.end).toMillis().coerceAtLeast(1L)
            val done = Duration.between(view.start, Heard.at(now)).toMillis()
            val fraction = (done.toFloat() / total.toFloat()).coerceIn(0f, 1f)
            Box(
                Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(OnAirInk.copy(alpha = 0.25f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(fraction)
                        .fillMaxHeight()
                        .background(OnAirInk)
                )
            }
        }

        if (open && description.isNotEmpty()) {
            Text(
                text = description,
                color = OnAirInk,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
    if (canShare) {
        val who = view.dj.orEmpty()
        CardShareButton("Share $who", OnAirInk, Modifier.align(Alignment.TopEnd).padding(top = 2.dp, end = 4.dp)) {
            val showLine = DjMatch.scrub(view.title).orEmpty().trim()
            ShowActions.share(
                shareCtx, ShowActions.liveText(who, showLine),
                ShareCard.Spec(who, showLine.ifEmpty { "On air now" }, "ON AIR NOW", photoUrl = view.page?.imageUrl)
            )
        }
    }
    }
}

/** The opening of a bio for a card: the first paragraph, cut at a sentence end (or a word) if it runs long. */
private fun shortBio(paragraph: String): String {
    val t = paragraph.trim()
    if (t.length <= 320) return t
    val cut = t.substring(0, 320)
    val end = maxOf(cut.lastIndexOf(". "), cut.lastIndexOf("! "), cut.lastIndexOf("? "))
    return if (end >= 120) cut.substring(0, end + 1) else cut.substring(0, cut.lastIndexOf(' ').coerceAtLeast(120)).trimEnd() + "…"
}

/** Show descriptions in the calendar are sometimes plain text and sometimes HTML. */
private fun cleanDescription(raw: String): String {
    if (raw.isBlank()) return ""
    val text = if (raw.contains('<')) {
        Html.fromHtml(raw, Html.FROM_HTML_MODE_COMPACT).toString()
    } else {
        raw
    }
    return text.replace("\uFFFC", "").replace(Regex("\n{3,}"), "\n\n").trim()
}

/** The website's own schedule page, used if the calendar can't be loaded. */
@Composable
private fun ScheduleWeb(webView: WebView, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        // The same back arrow as every other page, on the page's side border.
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ThemeState.current.scrimStrong)
                .clickable(onClickLabel = "Back to schedule", role = Role.Button, onClick = onBack)
                .padding(horizontal = ScreenLayout.side(), vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_arrow_back),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.size(24.dp)
            )
            Spacer(Modifier.width(10.dp))
            Text(text = "Back to schedule", color = MaterialTheme.colorScheme.onBackground, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        Box(Modifier.fillMaxWidth().weight(1f)) {
            WebTab(webView)
        }
    }
}
