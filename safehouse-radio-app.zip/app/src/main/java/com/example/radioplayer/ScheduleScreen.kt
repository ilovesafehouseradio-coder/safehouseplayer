package com.example.radioplayer

import android.text.Html
import android.text.format.DateFormat
import android.webkit.WebView
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------

/** Holds the schedule so it survives switching tabs. */
class ScheduleState {
    var shows by mutableStateOf<List<Show>>(emptyList())
    var loading by mutableStateOf(false)
    var failed by mutableStateOf(false)
    var loadedOnce by mutableStateOf(false)
    var showWeb by mutableStateOf(false)   // fall back to the website's own schedule page
    var innerTab by mutableStateOf(0)       // 0 = On Air, 1 = Schedule (the two tabs inside this page)
    var query by mutableStateOf("")          // the search box on the Schedule tab

    // What the stream server last said was on air, kept here so the On Air card can show the right
    // thing the moment the tab opens (instead of showing the calendar first and then changing).
    var feed by mutableStateOf<LiveStatus?>(null)
    var feedAt by mutableStateOf(0L)         // when that was known (0 = not yet)
    private var lastLoaded = 0L
    private var cacheFile: java.io.File? = null

    // What the saved copy was made from, so an unchanged calendar needs no reprocessing.
    private var signature = 0L     // a fingerprint of the calendar text it was made from
    private var etag: String? = null
    private var parsedAt = 0L      // when the list was last worked out from the calendar

    /** Where the last result is kept, so the schedule can appear instantly next time. */
    fun useCache(dir: java.io.File) {
        cacheFile = java.io.File(dir, "schedule.json")
        try {
            java.io.File(dir, "schedule.ics").delete()   // the old kind of saved copy
        } catch (e: Exception) {
        }
    }

    fun needsRefresh(): Boolean =
        shows.isEmpty() || System.currentTimeMillis() - lastLoaded > 10 * 60_000L

    /** Works the shows out of the calendar for the 3 days gone by and [daysAhead] days to come. */
    private suspend fun parseText(text: String, daysAhead: Long): List<Show>? =
        withContext(Dispatchers.Default) {
            try {
                val now = Instant.now()
                ScheduleLogic.toShows(
                    IcsCalendar.parse(text, now.minus(Duration.ofDays(3)), now.plus(Duration.ofDays(daysAhead)))
                )
            } catch (e: Exception) {
                null
            }
        }

    /** Shows the copy saved last time straight away (no waiting for the network). */
    suspend fun loadFromCache() {
        if (shows.isNotEmpty()) return
        val file = cacheFile ?: return
        val saved = withContext(Dispatchers.IO) {
            try {
                if (!file.exists()) return@withContext null
                val root = JSONObject(file.readText(Charsets.UTF_8))
                if (root.optInt("v") != CACHE_VERSION) return@withContext null
                val arr = root.getJSONArray("shows")
                val list = ArrayList<Show>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        Show(
                            start = Instant.ofEpochMilli(o.getLong("s")),
                            end = Instant.ofEpochMilli(o.getLong("e")),
                            dj = if (o.isNull("dj")) null else o.getString("dj"),
                            title = o.getString("t"),
                            genres = if (o.isNull("g")) null else o.getString("g"),
                            description = o.getString("d"),
                            isFiller = o.getBoolean("f")
                        )
                    )
                }
                SavedSchedule(
                    list, root.optLong("sig"), root.optString("etag").ifEmpty { null }, root.optLong("at")
                )
            } catch (e: Exception) {
                null   // a damaged or old-style file is simply ignored
            }
        } ?: return
        // A download may have finished while this was reading: never replace newer data.
        if (shows.isEmpty() && saved.shows.isNotEmpty()) {
            shows = saved.shows
            signature = saved.signature
            etag = saved.etag
            parsedAt = saved.parsedAt
            loadedOnce = true
        }
    }

    suspend fun load() {
        loading = true
        try {
            // If the list was worked out recently, ask the server "has it changed?" first.
            val recent = shows.isNotEmpty() && System.currentTimeMillis() - parsedAt < REPARSE_AFTER_MS
            val fetched = withContext(Dispatchers.IO) { fetchCalendar(if (recent) etag else null) }

            if (fetched == null) {
                // Keep showing what we have; only complain when there is nothing to show.
                if (shows.isEmpty()) failed = true
                return
            }
            if (fetched.notModified) {
                failed = false
                lastLoaded = System.currentTimeMillis()
                return
            }

            val text = fetched.text ?: return
            val sig = text.length.toLong() * 31L + text.hashCode()
            if (recent && sig == signature) {
                // Exactly the same calendar as last time: nothing to work out again.
                etag = fetched.etag ?: etag
                failed = false
                lastLoaded = System.currentTimeMillis()
                return
            }

            // Nothing on screen yet: show the next two weeks first (quick), then fill in the rest.
            if (shows.isEmpty()) {
                val firstLook = parseText(text, FIRST_LOOK_DAYS)
                if (firstLook != null && firstLook.isNotEmpty()) {
                    shows = firstLook
                    failed = false
                    loadedOnce = true
                }
            }
            val parsed = parseText(text, MONTH_DAYS)
            if (parsed == null) {
                if (shows.isEmpty()) failed = true
                return
            }
            shows = parsed
            failed = false
            loadedOnce = true
            lastLoaded = System.currentTimeMillis()
            parsedAt = lastLoaded
            signature = sig
            etag = fetched.etag
            save(parsed)
        } finally {
            // Always clear the flag, even if leaving the tab cancelled the download half way.
            loading = false
        }
    }

    /** Keeps the worked-out list on the phone, ready for next time. */
    private suspend fun save(list: List<Show>) {
        val file = cacheFile ?: return
        val sig = signature
        val tag = etag
        val at = parsedAt
        withContext(Dispatchers.IO) {
            try {
                val arr = JSONArray()
                for (s in list) {
                    arr.put(
                        JSONObject()
                            .put("s", s.start.toEpochMilli())
                            .put("e", s.end.toEpochMilli())
                            .put("dj", s.dj ?: JSONObject.NULL)
                            .put("t", s.title)
                            .put("g", s.genres ?: JSONObject.NULL)
                            .put("d", s.description)
                            .put("f", s.isFiller)
                    )
                }
                val root = JSONObject()
                    .put("v", CACHE_VERSION)
                    .put("sig", sig)
                    .put("etag", tag ?: "")
                    .put("at", at)
                    .put("shows", arr)
                // Write to a temporary file first, so a half-finished save can't damage the good copy.
                val temp = java.io.File(file.parentFile, file.name + ".tmp")
                temp.writeText(root.toString(), Charsets.UTF_8)
                if (!temp.renameTo(file)) {
                    file.writeText(root.toString(), Charsets.UTF_8)
                    temp.delete()
                }
            } catch (e: Exception) {
                // Not being able to save is fine: it just won't be instant next time.
            }
        }
    }

    private class SavedSchedule(
        val shows: List<Show>,
        val signature: Long,
        val etag: String?,
        val parsedAt: Long
    )

    private companion object {
        // 2: the saved list now covers a month (version 1 only covered two weeks, so it is ignored).
        const val CACHE_VERSION = 2
        // The list covers a month ahead, so it is worked out again at least this often.
        const val REPARSE_AFTER_MS = 6 * 60 * 60_000L
        const val FIRST_LOOK_DAYS = 15L
        const val MONTH_DAYS = 33L   // a little over the 31 days shown, so the last day is never cut short
    }
}

private class Fetched(val text: String?, val etag: String?, val notModified: Boolean)

/**
 * Downloads the station's public Google Calendar. Sends the "tag" from last time, if given, so
 * the server can answer "unchanged" (a tiny reply). Returns null if anything goes wrong.
 */
private fun fetchCalendar(etag: String?): Fetched? =
    try {
        val conn = URL(Config.CALENDAR_ICS_URL).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("User-Agent", "SafehouseRadioApp")
            if (etag != null) conn.setRequestProperty("If-None-Match", etag)
            when (conn.responseCode) {
                304 -> Fetched(null, etag, true)
                200 -> {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    if (body.contains("BEGIN:VCALENDAR")) Fetched(body, conn.getHeaderField("ETag"), false) else null
                }
                else -> null
            }
        } finally {
            conn.disconnect()
        }
    } catch (e: Exception) {
        null
    }

// ---------------------------------------------------------------------------
// Schedule tab
// ---------------------------------------------------------------------------

@Composable
fun ScheduleScreen(state: ScheduleState, webView: () -> WebView) {
    if (state.showWeb) {
        ScheduleWeb(webView(), onBack = { state.showWeb = false })
    } else {
        ScheduleContent(state)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScheduleContent(state: ScheduleState) {
    val scope = rememberCoroutineScope()
    val textColor = MaterialTheme.colorScheme.onBackground
    val zone = remember { ZoneId.systemDefault() }
    val is24 = DateFormat.is24HourFormat(LocalContext.current)
    val timeFmt = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a") }
    val dayFmt = remember { DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault()) }

    var pulled by remember { mutableStateOf(false) }

    // The clock ticks so "On Air" moves on by itself while the tab is open.
    var now by remember { mutableStateOf(Instant.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = Instant.now()
        }
    }

    // What the stream server says is on air right now. This is the truth: the calendar is only
    // the plan (a DJ may go live over the top, or the calendar may be wrong).
    val feed = state.feed
    LaunchedEffect(Unit) {
        var misses = 0
        while (true) {
            val latest = withContext(Dispatchers.IO) { fetchLiveStatus() }
            if (latest != null) {
                state.feed = latest
                state.feedAt = System.currentTimeMillis()
                misses = 0
            } else if (++misses >= 3) {
                state.feed = null   // can't reach it for a while: fall back to the calendar alone
                state.feedAt = System.currentTimeMillis()
            }
            delay(15_000)
        }
    }

    // The On Air card waits (briefly) for the first answer from the stream server, so it never shows
    // the calendar's version for a moment and then jumps to the real one.
    var waited by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(2_500)
        waited = true
    }
    val feedKnown = waited || (state.feedAt != 0L && System.currentTimeMillis() - state.feedAt < 90_000L)

    // Fetch when the tab opens (if the data is old), then every 10 minutes while it stays open.
    LaunchedEffect(Unit) {
        if (!state.loading && state.needsRefresh()) state.load()
        while (true) {
            delay(10 * 60_000L)
            if (!state.loading) state.load()
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (state.shows.isEmpty()) {
            PageHeader("Schedule")
            if (state.loading || (!state.failed && !state.loadedOnce)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (state.failed) "Couldn't load the schedule." else "No shows listed yet.",
                        color = textColor
                    )
                    Button(
                        onClick = { scope.launch { state.load() } },
                        modifier = Modifier.padding(top = 12.dp)
                    ) { Text("Try again") }
                    Button(
                        onClick = { state.showWeb = true },
                        modifier = Modifier.padding(top = 8.dp)
                    ) { Text("Open website schedule") }
                }
            }
            return@Column
        }

        val snap = remember(state.shows, now) { ScheduleLogic.snapshot(state.shows, now) }
        val today = now.atZone(zone).toLocalDate()
        val days = remember(today) { (0 until SHOWN_DAYS).map { today.plusDays(it.toLong()) } }
        // Every day for the next month, worked out once (not on every redraw).
        val dayLists = remember(state.shows, today) {
            days.map { ScheduleLogic.forDay(state.shows, it, zone) }
        }

        fun rangeText(s: Show): String =
            "${timeFmt.format(s.start.atZone(zone))} – ${timeFmt.format(s.end.atZone(zone))}"

        fun whenText(s: Show): String {
            val d = s.start.atZone(zone).toLocalDate()
            return when (d) {
                today -> rangeText(s)
                today.plusDays(1) -> "Tomorrow · ${rangeText(s)}"
                today.minusDays(1) -> "Yesterday · ${rangeText(s)}"
                else -> "${dayFmt.format(d)} · ${rangeText(s)}"
            }
        }

        ScheduleTabs(selected = state.innerTab) { state.innerTab = it }

        if (state.innerTab == 1) {
            OutlinedTextField(
                value = state.query,
                onValueChange = { state.query = it },
                placeholder = { Text("Search show or DJ…") },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = textColor,
                    unfocusedTextColor = textColor,
                    focusedContainerColor = CardSurface,
                    unfocusedContainerColor = CardSurface,
                    cursorColor = MaterialTheme.colorScheme.primary,
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = Color(0x66FFFFFF)
                ),
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 8.dp)
            )
        }

        // Pull down on the list to reload the schedule.
        // (The little spinner only shows for a pull, not for the quiet refresh in the background.)
        PullToRefreshBox(
            isRefreshing = pulled && state.loading,
            onRefresh = {
                pulled = true
                scope.launch {
                    try {
                        state.load()
                    } finally {
                        pulled = false
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        ) {
            if (state.innerTab == 0) {
                // ---- On Air tab: what's on now, what's next, what just finished ----
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item { SectionLabel("On Air") }
                    item {
                        val onAir = remember(snap.onAir, feed) { ScheduleLogic.onAirDisplay(snap.onAir, feed) }
                        if (!feedKnown) {
                            OnAirPlaceholder()
                        } else if (onAir != null) {
                            val range = if (onAir.start != null && onAir.end != null) {
                                "${timeFmt.format(onAir.start.atZone(zone))} – ${timeFmt.format(onAir.end.atZone(zone))}"
                            } else {
                                null
                            }
                            OnAirCard(onAir, range, now)
                        } else {
                            Note("Nothing on air right now.")
                        }
                    }

                    if (snap.upNext.isNotEmpty()) {
                        item { SectionLabel("Up Next") }
                        itemsIndexed(snap.upNext) { _, s -> ShowCard(s, whenText(s), lilac = true) }
                    }

                    if (snap.recent.isNotEmpty()) {
                        item { SectionLabel("Recently Aired") }
                        itemsIndexed(snap.recent) { _, s -> ShowCard(s, whenText(s), faded = true) }
                    }
                }
            } else {
                // ---- Schedule tab: the next month, day by day, with search ----
                val q = state.query.trim()
                val shown = remember(dayLists, q) {
                    if (q.isEmpty()) dayLists else dayLists.map { list -> list.filter { ScheduleLogic.matchesQuery(it, q) } }
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (shown.none { it.isNotEmpty() }) {
                        item {
                            Note(if (q.isEmpty()) "No shows listed for the next month." else "No shows match \"$q\" in the next month.")
                        }
                    } else {
                        for (i in days.indices) {
                            val list = shown[i]
                            if (list.isEmpty()) continue
                            item(key = "day-${days[i]}") {
                                SectionLabel(
                                    when (i) {
                                        0 -> "Today · ${dayFmt.format(days[i])}"
                                        1 -> "Tomorrow · ${dayFmt.format(days[i])}"
                                        else -> dayFmt.format(days[i])
                                    }
                                )
                            }
                            itemsIndexed(list) { _, s ->
                                ShowCard(
                                    show = s,
                                    whenLabel = rangeText(s),
                                    faded = !s.end.isAfter(now),
                                    highlight = s == snap.onAir,
                                    lilac = i == 0
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * The two tabs inside the Schedule page: "On Air" and "Schedule". This bar is exactly the same
 * size as the lavender title bar on the Radio and DJs pages (same height, width, corners and
 * text size), so the three pages line up.
 */
@Composable
private fun ScheduleTabs(selected: Int, onSelect: (Int) -> Unit) {
    val lavender = MaterialTheme.colorScheme.primary
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 10.dp)
            .clip(RoundedCornerShape(50))
            .background(CardSurface)
            .padding(4.dp)
    ) {
        listOf("On Air", "Schedule").forEachIndexed { i, label ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = BarHeight - 8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (i == selected) lavender else Color.Transparent)
                    // "selectable" tells screen readers which tab is chosen.
                    .selectable(selected = i == selected, role = Role.Tab, onClick = { onSelect(i) })
                    .padding(vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    color = if (i == selected) LavenderInk else MaterialTheme.colorScheme.onBackground,
                    fontSize = BarTextSize,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        color = Color(0xFFC4BFDA),
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.85f), Offset(0f, 3f), 14f)),
        modifier = Modifier.padding(top = 10.dp)
    )
}

@Composable
private fun Note(text: String) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f),
        fontSize = 14.sp,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.85f), Offset(0f, 2f), 10f))
    )
}

/**
 * One show. Tap a card to read the show's description (when the calendar has one).
 * Cards that are "coming up" ([lilac]) are dark lilac with a lavender edge; finished or later ones are black.
 * Up Next is lilac, Recently Aired is black; in the month list today is lilac and later days are black.
 */
@Composable
private fun ShowCard(
    show: Show,
    whenLabel: String,
    faded: Boolean = false,
    highlight: Boolean = false,   // the show that is on air right now (in the month list)
    lilac: Boolean = false
) {
    val primary = MaterialTheme.colorScheme.primary
    val textColor = MaterialTheme.colorScheme.onBackground
    val description = remember(show) { cleanDescription(show.description) }
    var open by remember(show) { mutableStateOf(false) }
    val quiet = show.isFiller || faded
    val alpha = if (quiet) 0.75f else 1f
    val canOpen = description.isNotEmpty() || !show.genres.isNullOrBlank()
    val shape = RoundedCornerShape(16.dp)
    val surface = if (lilac) LilacSurface else CardSurface
    val whenColor = if (lilac) Color(0xFFC9C4DA) else primary
    val genreColor = if (lilac) Color(0xFFDDD8EC) else MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clip(shape)
            .background(surface)
            .then(
                if (lilac) {
                    Modifier.drawBehind { drawRect(LilacEdge, size = Size(4.dp.toPx(), size.height)) }
                } else {
                    Modifier
                }
            )
            .then(if (highlight) Modifier.border(2.dp, primary, shape) else Modifier)
            .clickable(enabled = canOpen) { open = !open }
            .padding(start = if (lilac) 18.dp else 14.dp, top = 14.dp, end = 14.dp, bottom = 14.dp)
    ) {
        Text(
            text = if (highlight) "ON AIR · $whenLabel" else whenLabel,
            color = whenColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )

        val dj = show.dj
        // Main line: the DJ if there is one, otherwise the show name.
        Text(
            text = dj ?: show.title,
            color = textColor.copy(alpha = alpha),
            fontSize = 18.sp,
            fontWeight = if (show.isFiller && dj == null) FontWeight.Normal else FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp)
        )
        if (dj != null) {
            Text(
                text = show.title,
                color = textColor.copy(alpha = alpha),
                fontSize = 15.sp,
                fontWeight = FontWeight.Normal,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
        val genres = show.genres
        if (genres != null) {
            Text(
                text = genres,
                color = genreColor.copy(alpha = alpha),
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                // One line, however many genres the DJ listed; tap the card to see them all.
                maxLines = if (open) Int.MAX_VALUE else 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (open && description.isNotEmpty()) {
            Text(
                text = description,
                color = textColor.copy(alpha = 0.9f),
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

// Today's cards: a dark, slightly purple surface with a light lavender stripe down the left edge.
private val LilacSurface = Color(0xEB3F3A58)
private val LilacEdge = Color(0xFFC9C4DA)
private const val SHOWN_DAYS = 31   // the Schedule tab lists today and the next 30 days

private val OnAirInk = LavenderInk

// The On Air card never gets shorter than this, so it doesn't jump when its details change.
private val ON_AIR_MIN_HEIGHT = 136.dp

/** Shown for a moment while the first answer from the stream server arrives: same size as the real card. */
@Composable
private fun OnAirPlaceholder() {
    Box(
        Modifier
            .fillMaxWidth()
            .heightIn(min = ON_AIR_MIN_HEIGHT)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
    )
}

/**
 * The "On Air" card: solid lavender (the same colour as the tab bar and play button), so it is
 * the clearest thing on the page. It shows what the live feed says is playing, with the calendar's
 * times and details when they agree.
 */
@Composable
private fun OnAirCard(view: OnAirDisplay, range: String?, now: Instant) {
    val lavender = MaterialTheme.colorScheme.primary
    val description = remember(view) { cleanDescription(view.description) }
    var open by remember(view) { mutableStateOf(false) }
    val artUrl = remember(view.feedKey) { "${Config.ARTWORK_URL}?t=${System.currentTimeMillis()}" }

    // The little dot beside LIVE breathes in and out.
    val pulse = rememberInfiniteTransition(label = "liveDot")
    val dotAlpha by pulse.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
        label = "dot"
    )

    Column(
        Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clip(RoundedCornerShape(18.dp))
            .background(lavender)
            .heightIn(min = ON_AIR_MIN_HEIGHT)
            .clickable(enabled = description.isNotEmpty() || !view.genres.isNullOrBlank()) { open = !open }
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            AsyncImage(
                model = artUrl,
                contentDescription = null,
                placeholder = painterResource(R.drawable.station_logo),
                error = painterResource(R.drawable.station_logo),
                fallback = painterResource(R.drawable.station_logo),
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(72.dp).clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(OnAirInk)
                            .padding(horizontal = 9.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier
                                .size(7.dp)
                                .alpha(if (view.tag == "LIVE") dotAlpha else 1f)
                                .clip(CircleShape)
                                .background(Color.White)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            text = view.tag,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (range != null) {
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = range,
                            color = OnAirInk,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                Text(
                    text = view.dj ?: view.title.orEmpty(),
                    color = OnAirInk,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    modifier = Modifier.padding(top = 6.dp)
                )
                if (view.dj != null && !view.title.isNullOrBlank()) {
                    Text(
                        text = view.title,
                        color = OnAirInk,
                        fontSize = 16.sp,
                        maxLines = 2,
                        modifier = Modifier.padding(top = 1.dp)
                    )
                }
                if (!view.genres.isNullOrBlank()) {
                    Text(
                        text = view.genres,
                        color = OnAirInk.copy(alpha = 0.75f),
                        fontSize = 12.sp,
                        maxLines = if (open) Int.MAX_VALUE else 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }
        }

        if (view.scheduledNote != null) {
            Text(
                text = view.scheduledNote,
                color = OnAirInk.copy(alpha = 0.8f),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }

        if (view.start != null && view.end != null) {
            val total = Duration.between(view.start, view.end).toMillis().coerceAtLeast(1L)
            val done = Duration.between(view.start, now).toMillis()
            val fraction = (done.toFloat() / total.toFloat()).coerceIn(0f, 1f)
            Box(
                Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(OnAirInk.copy(alpha = 0.25f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(fraction)
                        .fillMaxHeight()
                        .background(OnAirInk)
                )
            }
        }

        if (open && description.isNotEmpty()) {
            Text(
                text = description,
                color = OnAirInk,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

/** Show descriptions in the calendar are sometimes plain text and sometimes HTML. */
private fun cleanDescription(raw: String): String {
    if (raw.isBlank()) return ""
    val text = if (raw.contains('<')) {
        Html.fromHtml(raw, Html.FROM_HTML_MODE_COMPACT).toString()
    } else {
        raw
    }
    return text.replace("\uFFFC", "").replace(Regex("\n{3,}"), "\n\n").trim()
}

/** The website's own schedule page, used if the calendar can't be loaded. */
@Composable
private fun ScheduleWeb(webView: WebView, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text(
            text = "‹  Back to schedule",
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xCC050505))
                .clickable(onClick = onBack)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        )
        Box(Modifier.fillMaxWidth().weight(1f)) {
            WebTab(webView)
        }
    }
}
