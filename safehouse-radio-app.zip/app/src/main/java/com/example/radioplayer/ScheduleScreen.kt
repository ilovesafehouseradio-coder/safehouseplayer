package com.example.radioplayer

import android.text.Html
import android.text.format.DateFormat
import android.webkit.WebView
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.HttpURLConnection
import java.net.URL
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------

/** Holds the schedule so it survives switching tabs. */
class ScheduleState {
    var shows by mutableStateOf<List<Show>>(emptyList())
    var loading by mutableStateOf(false)
    var failed by mutableStateOf(false)
    var loadedOnce by mutableStateOf(false)
    var showWeb by mutableStateOf(false)   // fall back to the website's own schedule page
    var selectedDay by mutableStateOf(0)
    private var lastLoaded = 0L
    private var cacheFile: java.io.File? = null

    /** Where the last download is kept, so the schedule can appear instantly next time. */
    fun useCache(dir: java.io.File) {
        cacheFile = java.io.File(dir, "schedule.ics")
    }

    fun needsRefresh(): Boolean =
        shows.isEmpty() || System.currentTimeMillis() - lastLoaded > 10 * 60_000L

    private suspend fun parseText(text: String): List<Show>? =
        withContext(Dispatchers.Default) {
            try {
                val now = Instant.now()
                ScheduleLogic.toShows(
                    IcsCalendar.parse(text, now.minus(Duration.ofDays(3)), now.plus(Duration.ofDays(15)))
                )
            } catch (e: Exception) {
                null
            }
        }

    /** Shows the copy saved last time straight away (no waiting for the network). */
    suspend fun loadFromCache() {
        if (shows.isNotEmpty()) return
        val file = cacheFile ?: return
        val text = withContext(Dispatchers.IO) {
            try {
                if (file.exists()) file.readText(Charsets.UTF_8) else null
            } catch (e: Exception) {
                null
            }
        } ?: return
        val parsed = parseText(text) ?: return
        // A download may have finished while this was reading: never replace newer data.
        if (shows.isEmpty() && parsed.isNotEmpty()) {
            shows = parsed
            loadedOnce = true
        }
    }

    suspend fun load() {
        loading = true
        try {
            val text = withContext(Dispatchers.IO) { fetchCalendarText() }
            val parsed = if (text == null) null else parseText(text)
            if (parsed == null) {
                // Keep showing the saved copy if we have one; only complain when there is nothing.
                if (shows.isEmpty()) failed = true
            } else {
                shows = parsed
                failed = false
                loadedOnce = true
                lastLoaded = System.currentTimeMillis()
                val file = cacheFile
                if (file != null && text != null) {
                    withContext(Dispatchers.IO) {
                        try {
                            file.writeText(text, Charsets.UTF_8)
                        } catch (e: Exception) {
                            // Not being able to save is fine: it just won't be instant next time.
                        }
                    }
                }
            }
        } finally {
            // Always clear the flag, even if leaving the tab cancelled the download half way.
            loading = false
        }
    }
}

/** Downloads the station's public Google Calendar. Returns null if anything goes wrong. */
private fun fetchCalendarText(): String? =
    try {
        val conn = URL(Config.CALENDAR_ICS_URL).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            conn.setRequestProperty("User-Agent", "SafehouseRadioApp")
            if (conn.responseCode != 200) {
                null
            } else {
                val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (body.contains("BEGIN:VCALENDAR")) body else null
            }
        } finally {
            conn.disconnect()
        }
    } catch (e: Exception) {
        null
    }

// ---------------------------------------------------------------------------
// Schedule tab
// ---------------------------------------------------------------------------

@Composable
fun ScheduleScreen(state: ScheduleState, webView: () -> WebView) {
    if (state.showWeb) {
        ScheduleWeb(webView(), onBack = { state.showWeb = false })
    } else {
        ScheduleContent(state)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScheduleContent(state: ScheduleState) {
    val scope = rememberCoroutineScope()
    val textColor = MaterialTheme.colorScheme.onBackground
    val zone = remember { ZoneId.systemDefault() }
    val is24 = DateFormat.is24HourFormat(LocalContext.current)
    val timeFmt = remember(is24) { DateTimeFormatter.ofPattern(if (is24) "HH:mm" else "h:mm a") }
    val dayFmt = remember { DateTimeFormatter.ofPattern("EEE d MMM", Locale.getDefault()) }
    val chipFmt = remember { DateTimeFormatter.ofPattern("EEE d", Locale.getDefault()) }

    var pulled by remember { mutableStateOf(false) }

    // The clock ticks so "On Air" moves on by itself while the tab is open.
    var now by remember { mutableStateOf(Instant.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000)
            now = Instant.now()
        }
    }

    // Fetch when the tab opens (if the data is old), then every 10 minutes while it stays open.
    LaunchedEffect(Unit) {
        if (!state.loading && state.needsRefresh()) state.load()
        while (true) {
            delay(10 * 60_000L)
            if (!state.loading) state.load()
        }
    }

    Column(Modifier.fillMaxSize()) {
        PageHeader("Schedule")

        if (state.shows.isEmpty()) {
            if (state.loading || (!state.failed && !state.loadedOnce)) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            } else {
                Column(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (state.failed) "Couldn't load the schedule." else "No shows listed yet.",
                        color = textColor
                    )
                    Button(
                        onClick = { scope.launch { state.load() } },
                        modifier = Modifier.padding(top = 12.dp)
                    ) { Text("Try again") }
                    Button(
                        onClick = { state.showWeb = true },
                        modifier = Modifier.padding(top = 8.dp)
                    ) { Text("Open website schedule") }
                }
            }
            return@Column
        }

        val snap = remember(state.shows, now) { ScheduleLogic.snapshot(state.shows, now) }
        val today = now.atZone(zone).toLocalDate()
        val days = remember(today) { (0 until 14).map { today.plusDays(it.toLong()) } }
        val selected = state.selectedDay.coerceIn(0, days.size - 1)
        val dayList = remember(state.shows, selected, today) {
            ScheduleLogic.forDay(state.shows, days[selected], zone)
        }

        fun rangeText(s: Show): String =
            "${timeFmt.format(s.start.atZone(zone))} – ${timeFmt.format(s.end.atZone(zone))}"

        fun whenText(s: Show): String {
            val d = s.start.atZone(zone).toLocalDate()
            return when (d) {
                today -> rangeText(s)
                today.plusDays(1) -> "Tomorrow · ${rangeText(s)}"
                today.minusDays(1) -> "Yesterday · ${rangeText(s)}"
                else -> "${dayFmt.format(d)} · ${rangeText(s)}"
            }
        }

        // Pull down on the list to reload the schedule.
        // (The little spinner only shows for a pull, not for the quiet refresh in the background.)
        PullToRefreshBox(
            isRefreshing = pulled && state.loading,
            onRefresh = {
                pulled = true
                scope.launch {
                    try {
                        state.load()
                    } finally {
                        pulled = false
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { SectionLabel("On Air") }
            item {
                val onAir = snap.onAir
                if (onAir != null) {
                    ShowCard(onAir, rangeText(onAir), onAirNow = now)
                } else {
                    Note("Nothing scheduled right now.")
                }
            }

            if (snap.upNext.isNotEmpty()) {
                item { SectionLabel("Up Next") }
                itemsIndexed(snap.upNext) { _, s -> ShowCard(s, whenText(s)) }
            }

            if (snap.recent.isNotEmpty()) {
                item { SectionLabel("Recently Aired") }
                itemsIndexed(snap.recent) { _, s -> ShowCard(s, whenText(s), faded = true) }
            }

            item { SectionLabel("Schedule") }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    itemsIndexed(days) { i, d ->
                        DayChip(
                            label = when (i) {
                                0 -> "Today"
                                1 -> "Tomorrow"
                                else -> chipFmt.format(d)
                            },
                            selected = i == selected,
                            onClick = { state.selectedDay = i }
                        )
                    }
                }
            }
            if (dayList.isEmpty()) {
                item { Note("No shows listed for this day.") }
            } else {
                itemsIndexed(dayList) { _, s -> ShowCard(s, rangeText(s)) }
            }
        }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        color = Color(0xFFC4BFDA),
        fontSize = 18.sp,
        fontWeight = FontWeight.SemiBold,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.85f), Offset(0f, 3f), 14f)),
        modifier = Modifier.padding(top = 10.dp)
    )
}

@Composable
private fun Note(text: String) {
    Text(
        text = text,
        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f),
        fontSize = 14.sp,
        style = TextStyle(shadow = Shadow(Color.Black.copy(alpha = 0.85f), Offset(0f, 2f), 10f))
    )
}

@Composable
private fun DayChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text = label,
        color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) MaterialTheme.colorScheme.primary else Color(0x99000000))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

/**
 * One show. Tap a card to read the show's description (when the calendar has one).
 * [onAirNow] set means this is the "On Air" card: it gets a badge and a progress bar.
 */
@Composable
private fun ShowCard(
    show: Show,
    whenLabel: String,
    faded: Boolean = false,
    onAirNow: Instant? = null
) {
    val primary = MaterialTheme.colorScheme.primary
    val textColor = MaterialTheme.colorScheme.onBackground
    val description = remember(show) { cleanDescription(show.description) }
    var open by remember(show) { mutableStateOf(false) }
    val quiet = show.isFiller || faded
    val alpha = if (quiet) 0.75f else 1f

    Column(
        Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clip(RoundedCornerShape(16.dp))
            .background(if (onAirNow != null) Color(0xCC000000) else Color(0x99000000))
            .clickable(enabled = description.isNotEmpty()) { open = !open }
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onAirNow != null) {
                Text(
                    text = "ON AIR",
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(primary)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                )
                Spacer(Modifier.padding(start = 8.dp))
            }
            Text(
                text = whenLabel,
                color = primary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        val dj = show.dj
        // Main line: the DJ if there is one, otherwise the show name.
        Text(
            text = dj ?: show.title,
            color = textColor.copy(alpha = alpha),
            fontSize = if (onAirNow != null) 22.sp else 18.sp,
            fontWeight = if (show.isFiller && dj == null) FontWeight.Normal else FontWeight.Bold,
            modifier = Modifier.padding(top = 8.dp)
        )
        if (dj != null) {
            Text(
                text = show.title,
                color = textColor.copy(alpha = alpha),
                fontSize = if (onAirNow != null) 17.sp else 15.sp,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
        val genres = show.genres
        if (genres != null) {
            Text(
                text = genres,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = alpha),
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (onAirNow != null) {
            val total = Duration.between(show.start, show.end).toMillis().coerceAtLeast(1L)
            val done = Duration.between(show.start, onAirNow).toMillis()
            val fraction = (done.toFloat() / total.toFloat()).coerceIn(0f, 1f)
            Box(
                Modifier
                    .padding(top = 12.dp)
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0x33FFFFFF))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(fraction)
                        .fillMaxHeight()
                        .background(primary)
                )
            }
        }

        if (open && description.isNotEmpty()) {
            Text(
                text = description,
                color = textColor.copy(alpha = 0.9f),
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

/** Show descriptions in the calendar are sometimes plain text and sometimes HTML. */
private fun cleanDescription(raw: String): String {
    if (raw.isBlank()) return ""
    val text = if (raw.contains('<')) {
        Html.fromHtml(raw, Html.FROM_HTML_MODE_COMPACT).toString()
    } else {
        raw
    }
    return text.replace("\uFFFC", "").replace(Regex("\n{3,}"), "\n\n").trim()
}

/** The website's own schedule page, used if the calendar can't be loaded. */
@Composable
private fun ScheduleWeb(webView: WebView, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text(
            text = "‹  Back to schedule",
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xCC050505))
                .clickable(onClick = onBack)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        )
        Box(Modifier.fillMaxWidth().weight(1f)) {
            WebTab(webView)
        }
    }
}
