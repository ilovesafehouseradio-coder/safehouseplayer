package com.example.radioplayer

import java.net.HttpURLConnection
import java.net.URL

// ---------------------------------------------------------------------------
// A DJ's profile, read from the DJ's page on the station website so it can be shown in the app's
// own style (instead of loading the website page itself).
// ---------------------------------------------------------------------------

data class DjLink(val label: String, val url: String)

class DjProfile(
    val genres: List<String>,        // from the "Music Style:" line
    val regular: String?,            // from the "Listen:" line, e.g. "Every 3rd Friday of the month, 7pm to 9pm"
    val paragraphs: List<String>,    // the bio (empty if the page has no real bio)
    val links: List<DjLink>,         // the "Social Links" list
    val photoUrl: String?            // the big picture (the page's "og:image")
)

/** Downloads a DJ's page and reads it. Returns null if the page can't be reached. */
fun fetchDjProfile(pageUrl: String, djName: String): DjProfile? =
    try {
        val conn = URL(pageUrl).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("User-Agent", "SafehouseRadioApp/1.0")
            if (conn.responseCode in 200..299) {
                val html = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                DjProfileParser.parse(html, djName)
            } else {
                null
            }
        } finally {
            conn.disconnect()
        }
    } catch (e: Exception) {
        null
    }

/**
 * Reads the website's DJ page. It is written to cope with the page looking a little different from
 * DJ to DJ: whatever can't be found is simply left out, and the app page still works without it.
 *
 * What it keeps: the genres, the regular slot, the bio, and a short list of the DJ's own links.
 * What it throws away: the website's breadcrumb and "By ... Comments are closed" line, ticket and
 * event links, PayPal, and the footer (including the website designer's credit and links).
 */
object DjProfileParser {

    private val SCRIPTS = Regex("(?is)<(script|style|noscript|svg|head)\\b.*?</\\1>")
    private val COMMENTS = Regex("(?s)<!--.*?-->")
    private val TAGS = Regex("<[^>]+>")
    private val BREAKS = Regex("(?i)<br\\s*/?>|</(p|div|li|ul|ol|h[1-6]|tr|section|article|blockquote)>")
    private val ANCHOR = Regex("(?is)<a\\s[^>]*?href\\s*=\\s*[\"']([^\"']+)[\"'][^>]*>(.*?)</a>")
    private val SOCIAL_MARKER = Regex("(?i)social\\s*links")
    private val STYLE_LINE = Regex("(?i)^music\\s*styles?\\s*[:\\-]?\\s*(.*)$")
    private val LISTEN_LINE = Regex("(?i)^listen\\s*[:\\-]?\\s*(.*)$")
    private val NUMERIC_ENTITY = Regex("&#(\\d+);")
    private val HEX_ENTITY = Regex("&#[xX]([0-9a-fA-F]+);")

    // Where the real page content ends: the footer and the "thank you to our artists" block
    // (which is where the website designer's credit and links live).
    private val END_OF_CONTENT = Regex(
        "(?i)<footer\\b|would\\s+like\\s+to\\s+thank|following\\s+artists\\s+for|animated\\s+visuals|" +
            "nex+us\\s*604|604\\s*nex+us|copyright\\s*(?:&copy;|&#169;|\\u00A9|\\d{4})"
    )

    // The only sites that get a button, in the order the buttons appear.
    private val ORDER = listOf(
        "Facebook", "Twitter", "SoundCloud", "Mixcloud", "Instagram", "TikTok", "YouTube",
        "Beatport", "Spotify", "Bandcamp", "Linktree", "Website"
    )
    private val SITES = listOf(
        "facebook." to "Facebook", "fb.com" to "Facebook", "fb.me" to "Facebook",
        "twitter." to "Twitter", "x.com" to "Twitter",
        "soundcloud." to "SoundCloud", "mixcloud." to "Mixcloud",
        "instagram." to "Instagram", "tiktok." to "TikTok",
        "youtube." to "YouTube", "youtu.be" to "YouTube",
        "beatport." to "Beatport", "spotify." to "Spotify", "bandcamp." to "Bandcamp",
        "linktr.ee" to "Linktree", "linktree." to "Linktree"
    )

    // Links that are never wanted: donations, the website designer, tickets and events.
    private val BLOCKED_HOSTS = listOf(
        "paypal.", "eventbrite.", "ticketmaster.", "skiddle.", "fatsoma.", "dice.fm", "seetickets.",
        "ticketsource.", "wegottickets.", "ents24.", "xceed.", "ticketweb.", "billetto.", "universe.com",
        "ra.co", "residentadvisor.", "ticketco.", "tixr.", "festicket."
    )
    private val BLOCKED_TEXT = Regex(
        "(?i)nex+us|604\\s*nex|ticket|\\bevents?\\b|eventbrite|paypal|donat"
    )

    private const val LABELS =
        "website|web|site|official\\s+site|official\\s+website|link\\s?tree|instagram|facebook|twitter|x|" +
            "soundcloud|mixcloud|youtube|tiktok|spotify|beatport|bandcamp|tickets?|events?|links?|socials?|" +
            "social\\s+links|find\\s+me\\s+on|follow\\s+me\\s+on|follow\\s+us\\s+on|follow"
    private val LABEL_ONLY = Regex("(?i)^(?:(?:$LABELS)\\s*[:\\-\\u2013|,&]?\\s*)+$")
    private val URL_WITH_LABEL = Regex(
        "(?i)((?:$LABELS)\\s*[:\\-\\u2013|]?\\s*)?((?:https?://|www\\.)[^\\s<>\"']+)"
    )

    private const val MONTH = "(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\\.?"
    private val DATE = Regex(
        "(?i)\\b\\d{1,2}(?:st|nd|rd|th)?\\s+$MONTH,?\\s+\\d{4}|\\b$MONTH\\s+\\d{1,2}(?:st|nd|rd|th)?,?\\s+\\d{4}|" +
            "\\b\\d{1,2}/\\d{1,2}/\\d{2,4}"
    )
    private val COMMENT_LINE = Regex("(?i)^(?:no\\s+comments?|leave\\s+a\\s+(?:comment|reply)|\\d+\\s+comments?|comments?\\s+(?:are\\s+)?(?:closed|off))\\.?$")
    private val PLACEHOLDER = Regex("(?i)^(?:more\\s+info(?:rmation)?\\s+(?:to\\s+follow|coming(?:\\s+soon)?)|coming\\s+soon|tbc|tba|to\\s+follow)\\W*$")

    fun parse(html: String, djName: String): DjProfile {
        val photo = ogImage(html)

        val clean = html.replace(COMMENTS, " ").replace(SCRIPTS, " ")
        var region = afterHeading(clean, djName)
        val end = END_OF_CONTENT.find(region)
        if (end != null) region = region.substring(0, end.range.first)

        // Everything before "Social Links" is the profile text; the links come after it.
        val markerAt = SOCIAL_MARKER.find(region)
        val textPart = if (markerAt != null) region.substring(0, markerAt.range.first) else region
        val linkPart = if (markerAt != null) region.substring(markerAt.range.last + 1) else ""

        val found = ArrayList<DjLink>()
        // The DJ's own "Social Links" list.
        for (m in ANCHOR.findAll(linkPart)) {
            classify(decode(m.groupValues[1]).trim(), textOf(m.groupValues[2]), "")?.let { found.add(it) }
        }

        // Links written inside the bio: collect them as buttons and take them (and their labels) out of the text.
        val bioHtml = ANCHOR.replace(textPart) { m ->
            val url = decode(m.groupValues[1]).trim()
            val text = textOf(m.groupValues[2])
            val link = classify(url, text, "")
            when {
                link != null -> {
                    found.add(link)
                    ""
                }
                isBlockedLink(url, text) -> ""
                // A plain address (the label before it, e.g. "Website", decides what it is).
                text.startsWith("http", true) || text.startsWith("www.", true) || text.contains("://") -> " $url "
                else -> m.groupValues[2]          // an ordinary word-link in a sentence: keep the words
            }
        }

        var genres: List<String> = emptyList()
        var regular: String? = null
        val paragraphs = ArrayList<String>()
        val lines = linesOf(bioHtml)
        var i = 0
        while (i < lines.size) {
            var line = lines[i]
            // Web addresses typed into the text: collect them, and remove them with their label.
            line = URL_WITH_LABEL.replace(line) { m ->
                val label = m.groupValues[1].lowercase().replace(Regex("[^a-z]"), "")
                val url = m.groupValues[2].trimEnd('.', ',', ';', ')', ']')
                classify(if (url.startsWith("http", true)) url else "https://$url", "", label)?.let { found.add(it) }
                ""
            }.trim()
            if (line.isEmpty() || LABEL_ONLY.matches(line)) {
                i++
                continue
            }
            val style = STYLE_LINE.find(line)
            val listen = LISTEN_LINE.find(line)
            when {
                isJunk(line, paragraphs.size + (if (genres.isNotEmpty()) 1 else 0), djName) -> {}
                style != null -> {
                    var value = style.groupValues[1].trim()
                    if (value.isEmpty() && i + 1 < lines.size) value = lines[++i]
                    genres = value.split(',', '/', '&').map { it.trim() }.filter { it.isNotEmpty() }
                }
                listen != null && listen.groupValues[1].isNotBlank() -> regular = listen.groupValues[1].trim()
                PLACEHOLDER.matches(line) -> {}
                else -> paragraphs.add(line)
            }
            i++
        }
        // Only a real bio counts.
        val bio = if (paragraphs.sumOf { it.length } >= 40) paragraphs else emptyList()

        return DjProfile(genres, regular, bio, tidy(found), photo)
    }

    /**
     * Decides whether a link becomes a button. [label] is the word written just before it (if any).
     * Returns null for anything that shouldn't be shown.
     */
    private fun classify(url: String, text: String, label: String): DjLink? {
        if (!url.startsWith("http", ignoreCase = true)) return null
        val host = hostOf(url)
        if (host.isEmpty() || host.endsWith("safehouseradio.co.uk")) return null
        if (isBlocked(url, host, text, label)) return null
        val site = SITES.firstOrNull { host.contains(it.first) }?.second
        if (site != null) return DjLink(site, url)
        // Any other address only counts if it is called "website"; the rest is ignored.
        val t = (text + " " + label).lowercase()
        if (Regex("\\b(web|website|site|homepage)\\b").containsMatchIn(t) || label.contains("web") || label.contains("site")) {
            return DjLink("Website", url)
        }
        return null
    }

    private fun isBlocked(url: String, host: String, text: String, label: String): Boolean =
        BLOCKED_HOSTS.any { host.contains(it) } ||
            BLOCKED_TEXT.containsMatchIn(text) || BLOCKED_TEXT.containsMatchIn(label) ||
            BLOCKED_TEXT.containsMatchIn(url.substringAfter("://").replace("-", "").replace("_", ""))

    /** A link in the bio that should disappear completely (tickets, events, PayPal, the designer). */
    private fun isBlockedLink(url: String, text: String): Boolean = isBlocked(url, hostOf(url), text, "")

    private fun tidy(found: List<DjLink>): List<DjLink> {
        val byLabel = LinkedHashMap<String, DjLink>()
        for (l in found) if (l.label !in byLabel) byLabel[l.label] = l
        return byLabel.values.sortedBy { ORDER.indexOf(it.label) }.take(ORDER.size)
    }

    /** The website's own page furniture that leaks in at the top: breadcrumb, name, byline, comment count. */
    private fun isJunk(line: String, keptSoFar: Int, djName: String): Boolean {
        val norm = line.lowercase().filter { it.isLetterOrDigit() }
        if (norm.isEmpty()) return true
        if (norm == djName.lowercase().filter { it.isLetterOrDigit() }) return true
        if (COMMENT_LINE.matches(line)) return true
        if (Regex("(?i)^(?:by|posted)\\b").containsMatchIn(line) &&
            (line.contains("comment", true) || DATE.containsMatchIn(line))
        ) return true
        // A date on its own, perhaps followed by a comment count ("7 June 2024 - 0").
        val noDate = DATE.replace(line, "")
        if (noDate != line && noDate.none { it.isLetter() }) return true
        // "Home » Our DJs » Name" and its pieces, only near the top of the text.
        if (keptSoFar < 4) {
            if (norm.startsWith("home") && (norm.contains("ourdj") || norm.length <= 5)) return true
            if (norm == "ourdjs" || norm == "ourdj" || norm == "home") return true
        }
        return false
    }

    /** The part of the page after the heading that holds the DJ's name. */
    private fun afterHeading(html: String, djName: String): String {
        if (djName.isNotBlank()) {
            val byName = Regex(
                "(?is)<h[1-4]\\b[^>]*>\\s*(?:<[^>]+>\\s*)*" + Regex.escape(djName.trim()).replace("\\ ", "\\s+") +
                    "\\s*(?:<[^>]+>\\s*)*</h[1-4]>"
            ).find(html)
            if (byName != null) return html.substring(byName.range.last + 1)
        }
        val h1 = Regex("(?is)<h1\\b.*?</h1>").find(html)
        if (h1 != null) return html.substring(h1.range.last + 1)
        val body = Regex("(?i)<body\\b[^>]*>").find(html)
        return if (body != null) html.substring(body.range.last + 1) else html
    }

    private fun ogImage(html: String): String? {
        val a = Regex("(?is)<meta[^>]+property\\s*=\\s*[\"']og:image[\"'][^>]*content\\s*=\\s*[\"']([^\"']+)[\"']").find(html)
        val b = Regex("(?is)<meta[^>]+content\\s*=\\s*[\"']([^\"']+)[\"'][^>]*property\\s*=\\s*[\"']og:image[\"']").find(html)
        val url = (a ?: b)?.groupValues?.get(1)?.let { decode(it).trim() }
        return url?.takeIf { it.startsWith("http") }
    }

    private fun hostOf(url: String): String =
        url.substringAfter("://").substringBefore('/').substringBefore('?').lowercase()

    private fun textOf(fragment: String): String = linesOf(fragment).joinToString(" ")

    /** HTML to plain lines of text: paragraph and line breaks become line breaks, tags are dropped. */
    fun linesOf(fragment: String): List<String> =
        decode(fragment.replace(BREAKS, "\n").replace(TAGS, ""))
            .replace('\u00A0', ' ')
            .replace("\uFFFC", "")
            .split('\n')
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotEmpty() }

    private val NAMED = mapOf(
        "nbsp" to " ", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "hellip" to "\u2026",
        "rsquo" to "\u2019", "lsquo" to "\u2018", "rdquo" to "\u201D", "ldquo" to "\u201C",
        "ndash" to "\u2013", "mdash" to "\u2014", "copy" to "\u00A9", "eacute" to "\u00E9", "raquo" to "\u00BB",
        "laquo" to "\u00AB"
    )

    private fun codePointText(code: Int?): String =
        if (code != null && Character.isValidCodePoint(code)) String(Character.toChars(code)) else ""

    private fun decode(s: String): String {
        var r = NUMERIC_ENTITY.replace(s) { codePointText(it.groupValues[1].toIntOrNull()) }
        r = HEX_ENTITY.replace(r) { codePointText(it.groupValues[1].toIntOrNull(16)) }
        for ((name, value) in NAMED) r = r.replace("&$name;", value)
        return r.replace("&amp;", "&")
    }
}
