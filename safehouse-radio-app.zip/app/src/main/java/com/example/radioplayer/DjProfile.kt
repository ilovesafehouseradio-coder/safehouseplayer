package com.example.radioplayer

import java.net.HttpURLConnection
import java.net.URL

// ---------------------------------------------------------------------------
// A DJ's profile, read from the DJ's page on the station website so it can be shown in the app's
// own style (instead of loading the website page itself).
// ---------------------------------------------------------------------------

data class DjLink(val label: String, val url: String)

class DjProfile(
    val genres: List<String>,        // from the "Music Style:" line
    val regular: String?,            // from the "Listen:" line, e.g. "Every 3rd Friday of the month, 7pm to 9pm"
    val paragraphs: List<String>,    // the bio (empty if the page has no real bio)
    val links: List<DjLink>,         // the "Social Links" list
    val photoUrl: String?            // the big picture (the page's "og:image")
)

/** Downloads a DJ's page and reads it. Returns null if the page can't be reached. */
fun fetchDjProfile(pageUrl: String, djName: String): DjProfile? =
    try {
        val conn = URL(pageUrl).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            conn.setRequestProperty("User-Agent", "SafehouseRadioApp/1.0")
            if (conn.responseCode in 200..299) {
                val html = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                DjProfileParser.parse(html, djName)
            } else {
                null
            }
        } finally {
            conn.disconnect()
        }
    } catch (e: Exception) {
        null
    }

/**
 * Reads the website's DJ page. It is written to cope with the page looking a little different from
 * DJ to DJ: whatever can't be found is simply left out, and the app page still works without it.
 */
object DjProfileParser {

    private val SCRIPTS = Regex("(?is)<(script|style|noscript|svg|head)\\b.*?</\\1>")
    private val COMMENTS = Regex("(?s)<!--.*?-->")
    private val TAGS = Regex("<[^>]+>")
    private val BREAKS = Regex("(?i)<br\\s*/?>|</(p|div|li|ul|ol|h[1-6]|tr|section|article|blockquote)>")
    private val ANCHOR = Regex("(?is)<a\\s[^>]*?href\\s*=\\s*[\"']([^\"']+)[\"'][^>]*>(.*?)</a>")
    private val SOCIAL_MARKER = Regex("(?i)social\\s*links")
    private val STYLE_LINE = Regex("(?i)^music\\s*styles?\\s*[:\\-]?\\s*(.*)$")
    private val LISTEN_LINE = Regex("(?i)^listen\\s*[:\\-]?\\s*(.*)$")
    private val NUMERIC_ENTITY = Regex("&#(\\d+);")
    private val HEX_ENTITY = Regex("&#[xX]([0-9a-fA-F]+);")

    // Known sites: shown with a tidy name whatever the link text says.
    private val SITES = listOf(
        "facebook." to "Facebook", "fb.com" to "Facebook", "instagram." to "Instagram",
        "soundcloud." to "SoundCloud", "youtube." to "YouTube", "youtu.be" to "YouTube",
        "beatport." to "Beatport", "mixcloud." to "Mixcloud", "twitter." to "Twitter",
        "x.com" to "X", "tiktok." to "TikTok", "spotify." to "Spotify", "bandcamp." to "Bandcamp",
        "linktr.ee" to "Linktree", "twitch." to "Twitch", "ra.co" to "Resident Advisor",
        "residentadvisor." to "Resident Advisor", "music.apple." to "Apple Music",
        "traxsource." to "Traxsource", "discogs." to "Discogs"
    )

    fun parse(html: String, djName: String): DjProfile {
        val photo = ogImage(html)

        val clean = html.replace(COMMENTS, " ").replace(SCRIPTS, " ")
        var region = afterHeading(clean, djName)
        val footer = Regex("(?i)<footer\\b").find(region)
        if (footer != null) region = region.substring(0, footer.range.first)

        // Everything before "Social Links" is the profile text; the links come after it.
        val markerAt = SOCIAL_MARKER.find(region)
        val textPart = if (markerAt != null) region.substring(0, markerAt.range.first) else region
        val linkPart = if (markerAt != null) region.substring(markerAt.range.last + 1) else region
        val hasMarker = markerAt != null

        var genres: List<String> = emptyList()
        var regular: String? = null
        val paragraphs = ArrayList<String>()
        val lines = linesOf(textPart)
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val style = STYLE_LINE.find(line)
            val listen = LISTEN_LINE.find(line)
            when {
                line.equals(djName, ignoreCase = true) -> {}
                style != null -> {
                    var value = style.groupValues[1].trim()
                    if (value.isEmpty() && i + 1 < lines.size) value = lines[++i]
                    genres = value.split(',', '/', '&').map { it.trim() }.filter { it.isNotEmpty() }
                }
                listen != null && listen.groupValues[1].isNotBlank() -> regular = listen.groupValues[1].trim()
                else -> paragraphs.add(line)
            }
            i++
        }
        // Only a real bio counts: "More info to follow…" on its own is not worth a card.
        val bio = if (paragraphs.sumOf { it.length } >= 80) paragraphs else emptyList()

        return DjProfile(genres, regular, bio, linksOf(linkPart, onlyKnown = !hasMarker), photo)
    }

    /** The part of the page after the heading that holds the DJ's name. */
    private fun afterHeading(html: String, djName: String): String {
        if (djName.isNotBlank()) {
            val byName = Regex(
                "(?is)<h[1-4]\\b[^>]*>\\s*(?:<[^>]+>\\s*)*" + Regex.escape(djName.trim()).replace("\\ ", "\\s+") +
                    "\\s*(?:<[^>]+>\\s*)*</h[1-4]>"
            ).find(html)
            if (byName != null) return html.substring(byName.range.last + 1)
        }
        val h1 = Regex("(?is)<h1\\b.*?</h1>").find(html)
        if (h1 != null) return html.substring(h1.range.last + 1)
        val body = Regex("(?i)<body\\b[^>]*>").find(html)
        return if (body != null) html.substring(body.range.last + 1) else html
    }

    private fun ogImage(html: String): String? {
        val a = Regex("(?is)<meta[^>]+property\\s*=\\s*[\"']og:image[\"'][^>]*content\\s*=\\s*[\"']([^\"']+)[\"']").find(html)
        val b = Regex("(?is)<meta[^>]+content\\s*=\\s*[\"']([^\"']+)[\"'][^>]*property\\s*=\\s*[\"']og:image[\"']").find(html)
        val url = (a ?: b)?.groupValues?.get(1)?.let { decode(it).trim() }
        return url?.takeIf { it.startsWith("http") }
    }

    private fun linksOf(fragment: String, onlyKnown: Boolean): List<DjLink> {
        val out = ArrayList<DjLink>()
        for (m in ANCHOR.findAll(fragment)) {
            val url = decode(m.groupValues[1]).trim()
            if (!url.startsWith("http", ignoreCase = true)) continue
            val host = hostOf(url)
            if (host.isEmpty() || host.endsWith("safehouseradio.co.uk")) continue
            val site = SITES.firstOrNull { host.contains(it.first) }?.second
            if (onlyKnown && site == null) continue
            val text = textOf(m.groupValues[2]).trim()
            val label = site ?: text.ifEmpty { host.removePrefix("www.") }
            if (out.none { it.url == url }) out.add(DjLink(label, url))
            if (out.size >= 8) break
        }
        return out
    }

    private fun hostOf(url: String): String =
        url.substringAfter("://").substringBefore('/').substringBefore('?').lowercase()

    private fun textOf(fragment: String): String = linesOf(fragment).joinToString(" ")

    /** HTML to plain lines of text: paragraph and line breaks become line breaks, tags are dropped. */
    fun linesOf(fragment: String): List<String> =
        decode(fragment.replace(BREAKS, "\n").replace(TAGS, ""))
            .replace('\u00A0', ' ')
            .replace("\uFFFC", "")
            .split('\n')
            .map { it.replace(Regex("\\s+"), " ").trim() }
            .filter { it.isNotEmpty() }

    private val NAMED = mapOf(
        "nbsp" to " ", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "hellip" to "\u2026",
        "rsquo" to "\u2019", "lsquo" to "\u2018", "rdquo" to "\u201D", "ldquo" to "\u201C",
        "ndash" to "\u2013", "mdash" to "\u2014", "copy" to "\u00A9", "eacute" to "\u00E9"
    )

    private fun codePointText(code: Int?): String =
        if (code != null && Character.isValidCodePoint(code)) String(Character.toChars(code)) else ""

    private fun decode(s: String): String {
        var r = NUMERIC_ENTITY.replace(s) { codePointText(it.groupValues[1].toIntOrNull()) }
        r = HEX_ENTITY.replace(r) { codePointText(it.groupValues[1].toIntOrNull(16)) }
        for ((name, value) in NAMED) r = r.replace("&$name;", value)
        return r.replace("&amp;", "&")
    }
}
