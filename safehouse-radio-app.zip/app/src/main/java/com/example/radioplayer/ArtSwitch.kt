package com.example.radioplayer

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * "Show artwork from the radio" (More tab). On (the normal way): the picture the radio server is showing for the
 * DJ or show appears on the Radio tab, the mini player and the lock screen. Off: always the Safehouse logo in the
 * current theme. DJ photos on the DJ page and schedule are never affected.
 */
object LiveArtSwitch {
    const val KEY = "show_live_art"

    var on by mutableStateOf(true)
        private set

    fun load(ctx: Context) {
        on = isOn(ctx)
    }

    /** The saved choice, for parts of the app that run without a screen (the notification). */
    fun isOn(ctx: Context): Boolean = AppSettings.prefs(ctx).getBoolean(KEY, true)

    fun choose(ctx: Context, value: Boolean) {
        on = value
        AppSettings.prefs(ctx).edit().putBoolean(KEY, value).apply()
    }
}
