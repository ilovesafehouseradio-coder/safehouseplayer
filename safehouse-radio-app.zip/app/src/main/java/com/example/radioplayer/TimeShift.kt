package com.example.radioplayer

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.TransferListener
import androidx.media3.exoplayer.ExoPlayer
import java.io.IOException
import java.io.InterruptedIOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Rewind and fast-forward for the live radio.
 *
 * A live stream has no past to jump back into, so the app keeps a rolling copy of the last couple of minutes of
 * the stream in the phone's memory (about 2 MB; it is the same audio the phone is already downloading, so it uses
 * no extra data). The player listens through that copy. Rewind starts the player again a little further back in
 * the copy; fast-forward moves it forward again, never closer to live than the buffer chosen in More.
 *
 * If this ever fails to connect, the app falls back to playing the stream directly, exactly as before (see
 * [disabled]); the rewind buttons then simply stay greyed out.
 */
object TimeShift {
    /** The player's address for the recording: "shift://live" (join live) or "shift://at?p=N" (a place in the copy). */
    const val SCHEME = "shift"

    /** How much of the stream is kept, and how long a pause is kept before the copy is dropped (seconds). */
    const val KEEP_SECONDS = 150

    /** How far one tap of rewind or fast-forward goes (seconds). */
    const val STEP_SECONDS = 10

    /** Always keep this much of the copy in hand ahead of the oldest audio when rewinding (seconds). */
    private const val EDGE_SECONDS = 8

    private const val MAX_CONNECT_TRIES = 10

    // ---------------------------------------------------------------- state the screen shows

    /** How far behind the live moment the listener is, in seconds. */
    var behindSeconds by mutableIntStateOf(0)
        private set

    /** True when the listener has deliberately gone back (more than the normal buffer behind). */
    var rewound by mutableStateOf(false)
        private set
    var canRewind by mutableStateOf(false)
        private set
    var canForward by mutableStateOf(false)
        private set

    // ---------------------------------------------------------------- wiring from the service

    /** The phone's player (set by the playback service). */
    @Volatile
    var player: ExoPlayer? = null

    /** True while the radio is playing on a Chromecast, when there is nothing to rewind here. */
    @Volatile
    var castActive: Boolean = false

    @Volatile
    var appContext: Context? = null

    /** Set when the recorder could not read the stream at all: the app plays the stream directly instead. */
    @Volatile
    var disabled: Boolean = false

    /** Times in a row the recorder failed before it had ever received a single byte. */
    @Volatile
    var failuresWithoutData: Int = 0

    /** True once any audio has ever been received by the recorder. */
    @Volatile
    var everReceived: Boolean = false

    /** True when the copy was dropped because the radio was paused for a long time (playing again joins live). */
    @Volatile
    var idleStopped: Boolean = false

    fun liveUri(): Uri = Uri.parse("$SCHEME://live")

    /** When the recorder last received any audio (SystemClock.elapsedRealtime). */
    @Volatile
    private var lastDataAt = 0L

    /**
     * Where to start listening when playing starts again (after a pause, a buffer change, or a reconnect). If the
     * recording is running and has fresh audio, that is the place your buffer choice (plus a 2 second margin) behind
     * the newest audio: the cushion is taken from what is already stored, so playing starts at once with the full
     * cushion instead of waiting for it to fill. If the copy holds less than that, it starts from the oldest audio
     * kept and only waits for the difference. With no recording, it simply joins live as before.
     */
    fun joinUri(): Uri {
        val rate = bytesPerSecond()
        val now = SystemClock.elapsedRealtime()
        val (h, t, fresh) = lock.withLock { Triple(head, tail, running && now - lastDataAt < 3_000L) }
        if (!fresh || h <= t) return liveUri()
        val want = h - (startBufferSeconds() + 2).toLong() * rate
        // Only one second from the oldest audio: while the copy is still filling nothing is being dropped (once it is
        // full, "want" is far from the oldest, so this never matters then).
        val place = maxOf(want, t + rate.toLong()).coerceAtMost(h)
        note("start: ${(h - place) / rate} s behind newest, copy ${(h - t) / rate} s, buffer ${startBufferSeconds()} s")
        return placeUri(place)
    }

    private fun placeUri(position: Long): Uri = Uri.parse("$SCHEME://at?p=$position")

    // ---------------------------------------------------------------- the rolling copy

    private class Chunk(val start: Long, val data: ByteArray, val atMs: Long) {
        val end: Long get() = start + data.size
    }

    private val lock = ReentrantLock()
    private val changed = lock.newCondition()
    private val chunks = ArrayDeque<Chunk>()
    private var head = 0L     // position after the newest byte
    private var tail = 0L     // position of the oldest byte kept

    @Volatile
    private var running = false
    private var generation = 0     // each start of the recorder gets its own number, so an old one can never write into a new copy
    private var thread: Thread? = null

    // The stream's own bit rate (bytes per second) if the server says it, else measured, else a guess.
    @Volatile
    private var headerRate = 0
    @Volatile
    private var measuredRate = 0
    private var connectedAt = 0L
    private var sampleAt = 0L
    private var samplePos = 0L

    /** Position of the last byte handed to the player (updated as it reads). */
    @Volatile
    private var readPos = 0L

    /** The bit rate the audio decoder reports for the stream (bytes per second); the most trustworthy figure. */
    @Volatile
    private var formatRate = 0

    /** Where in the copy the current play started (the live moment, or the place a tap sent it to). */
    @Volatile
    private var itemStart = 0L

    fun bytesPerSecond(): Int =
        when {
            formatRate in 2_000..80_000 -> formatRate
            measuredRate in 2_000..80_000 -> measuredRate
            headerRate in 2_000..80_000 -> headerRate
            else -> 16_000
        }

    /** Reads the stream's bit rate from the decoder. Main thread only (the player must be used from there). */
    private fun learnRate(p: ExoPlayer) {
        val bits = p.audioFormat?.let { if (it.averageBitrate > 0) it.averageBitrate else it.bitrate } ?: return
        if (bits in 16_000..640_000) formatRate = bits / 8
    }

    private fun recording(): Boolean = running

    /** Starts the recorder if it isn't running (safe to call again and again). */
    fun ensureRecording() {
        val mine = lock.withLock {
            if (running) return
            running = true
            idleStopped = false
            generation++
            generation
        }
        val t = Thread({ recordLoop(mine) }, "safehouse-recorder")
        t.isDaemon = true
        thread = t
        t.start()
    }

    /** Stops the recorder and throws the copy away. [idle] = it was a long pause (playing again joins live). */
    fun stop(idle: Boolean) {
        lock.withLock {
            running = false
            chunks.clear()
            tail = head
            idleStopped = idle
            changed.signalAll()
        }
        behindSeconds = 0
        rewound = false
        canRewind = false
        canForward = false
    }

    private fun current(mine: Int): Boolean = running && generation == mine

    private fun recordLoop(mine: Int) {
        var tries = 0
        val buffer = ByteArray(8192)
        val factory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(10_000)
            .setReadTimeoutMs(10_000)
        while (current(mine)) {
            val source = factory.createDataSource()
            var gotData = false
            try {
                source.open(DataSpec(Uri.parse(Config.STREAM_URL)))
                val rate = source.responseHeaders.entries
                    .firstOrNull { it.key.equals("icy-br", ignoreCase = true) }
                    ?.value?.firstOrNull()?.trim()?.toIntOrNull()
                if (rate != null && rate > 0) headerRate = rate * 1000 / 8
                connectedAt = SystemClock.elapsedRealtime()
                sampleAt = 0L
                while (current(mine)) {
                    val n = source.read(buffer, 0, buffer.size)
                    if (n == C.RESULT_END_OF_INPUT) break
                    if (n > 0) {
                        if (!gotData) {
                            gotData = true
                            tries = 0
                            everReceived = true
                            failuresWithoutData = 0
                        }
                        append(buffer, n, mine)
                    }
                }
            } catch (e: Exception) {
                // Dropped or refused: try again below.
            } finally {
                try {
                    source.close()
                } catch (e: Exception) {
                }
            }
            if (!current(mine)) break
            tries++
            if (tries > MAX_CONNECT_TRIES) break
            // Wait 2, 4, 8, 16 then 30 seconds between tries (in short slices, so stopping is quick).
            var waitMs = minOf(2_000L shl minOf(tries - 1, 4), 30_000L)
            while (current(mine) && waitMs > 0) {
                Thread.sleep(250)
                waitMs -= 250
            }
        }
        lock.withLock {
            if (generation == mine) running = false
            changed.signalAll()
        }
    }

    private fun append(buffer: ByteArray, n: Int, mine: Int) {
        val now = SystemClock.elapsedRealtime()
        lock.withLock {
            if (generation != mine || !running) return
            chunks.addLast(Chunk(head, buffer.copyOf(n), now))
            lastDataAt = now
            head += n
            // Measure the real bit rate (after the first 10 seconds, which include the server's start-up burst).
            if (sampleAt == 0L && now - connectedAt >= 10_000) {
                sampleAt = now
                samplePos = head
            } else if (sampleAt != 0L && now - sampleAt >= 15_000) {
                measuredRate = ((head - samplePos) * 1000L / (now - sampleAt)).toInt()
            }
            val maxBytes = KEEP_SECONDS.toLong() * bytesPerSecond()
            while (chunks.size > 1 && head - chunks.first().start > maxBytes) {
                chunks.removeFirst()
            }
            tail = chunks.first().start
            changed.signalAll()
        }
    }

    /** Copies up to [len] bytes from [pos] (which must be between tail and head). Call with the lock held. */
    private fun copy(pos: Long, out: ByteArray, off: Int, len: Int): Int {
        if (pos >= head || chunks.isEmpty()) return 0
        var lo = 0
        var hi = chunks.size - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (chunks[mid].start <= pos) lo = mid else hi = mid - 1
        }
        var copied = 0
        var p = pos
        var i = lo
        while (copied < len && i < chunks.size) {
            val c = chunks[i]
            val inChunk = (p - c.start).toInt()
            val n = minOf(c.data.size - inChunk, len - copied)
            System.arraycopy(c.data, inChunk, out, off + copied, n)
            copied += n
            p += n
            i++
        }
        return copied
    }

    // ---------------------------------------------------------------- the player's side

    /** What the player reads: the copy, from the live moment or from a place further back. */
    private class ShiftSource : BaseDataSource(/* isNetwork = */ false) {
        private var uri: Uri? = null
        private var pos = 0L
        private var opened = false

        override fun open(dataSpec: DataSpec): Long {
            uri = dataSpec.uri
            transferInitializing(dataSpec)
            ensureRecording()
            val wanted = dataSpec.uri.getQueryParameter("p")?.toLongOrNull()
            lock.withLock {
                pos = wanted ?: head
                itemStart = pos
            }
            opened = true
            transferStarted(dataSpec)
            return C.LENGTH_UNSET.toLong()
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            if (length == 0) return 0
            lock.lock()
            try {
                while (true) {
                    if (!opened) throw IOException("Closed")
                    if (pos < tail) pos = tail     // that part has been dropped: carry on from the oldest we have
                    if (pos > head) pos = head
                    val n = copy(pos, buffer, offset, length)
                    if (n > 0) {
                        pos += n
                        readPos = pos
                        bytesTransferred(n)
                        return n
                    }
                    if (!recording()) throw IOException("The live recording stopped")
                    try {
                        changed.await(500, TimeUnit.MILLISECONDS)
                    } catch (e: InterruptedException) {
                        Thread.currentThread().interrupt()
                        throw InterruptedIOException()
                    }
                }
            } finally {
                lock.unlock()
            }
        }

        override fun getUri(): Uri? = uri

        override fun close() {
            if (opened) {
                opened = false
                transferEnded()
            }
            uri = null
        }
    }

    /** Sends "shift://" addresses to the recording and everything else (the web address) to the normal downloader. */
    private class Router(private val web: DataSource) : DataSource {
        private val shift = ShiftSource()
        private var active: DataSource? = null

        override fun addTransferListener(transferListener: TransferListener) {
            web.addTransferListener(transferListener)
            shift.addTransferListener(transferListener)
        }

        override fun open(dataSpec: DataSpec): Long {
            val chosen = if (dataSpec.uri.scheme == SCHEME) shift else web
            active = chosen
            return chosen.open(dataSpec)
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int =
            (active ?: throw IOException("Not open")).read(buffer, offset, length)

        override fun getUri(): Uri? = active?.uri

        override fun getResponseHeaders(): Map<String, List<String>> = active?.responseHeaders ?: emptyMap()

        override fun close() {
            try {
                active?.close()
            } finally {
                active = null
            }
        }
    }

    /** The data source factory for the phone's player. */
    fun dataSourceFactory(context: Context): DataSource.Factory {
        val web = DataSource.Factory { Router(DefaultHttpDataSource.Factory().createDataSource()) }
        return DefaultDataSource.Factory(context, web)
    }

    // ---------------------------------------------------------------- rewind, fast-forward, and the numbers

    private fun isRecordingItem(p: Player): Boolean =
        p.currentMediaItem?.localConfiguration?.uri?.scheme == SCHEME

    private fun active(p: ExoPlayer): Boolean =
        !castActive && !disabled && isRecordingItem(p) && p.playbackState != Player.STATE_IDLE

    /**
     * Where in the copy the listener is hearing right now: the place this play started, plus how long it has
     * played (the player's own clock). This is right straight after a tap too, unlike "how much has been read".
     */
    private fun playPosition(p: ExoPlayer, rate: Int): Long {
        val (h, t) = lock.withLock { head to tail }
        val pos = itemStart + p.currentPosition.coerceAtLeast(0L) * rate / 1000L
        return pos.coerceIn(t - 60L * rate, h)
    }

    /** The older way of working it out (how much has been read, less what the player holds): only for the check log. */
    private fun readBasedPosition(p: ExoPlayer, rate: Int): Long =
        readPos - p.totalBufferedDuration * rate / 1000L

    private fun note(text: String) = ChatDiag.add("rewind: $text")

    /** After a tap: what we expect the "behind" figure to settle at, and when to check. */
    @Volatile private var expectBehind = -1
    @Volatile private var checkAt = 0L
    @Volatile private var lastTap = 0

    private fun startBufferSeconds(): Int {
        val ctx = appContext ?: return 8
        return AppSettings.bufferStartMs(ctx) / 1000
    }

    /** Brings the numbers the buttons need up to date. Call about once a second while the Radio tab is showing. */
    fun refresh() {
        val p = player
        if (p == null || !active(p)) {
            if (behindSeconds != 0) behindSeconds = 0
            rewound = false
            canRewind = false
            canForward = false
            return
        }
        learnRate(p)
        val rate = bytesPerSecond()
        val (h, t) = lock.withLock { head to tail }
        val playPos = playPosition(p, rate)
        val behind = ((h - playPos) / rate).toInt().coerceAtLeast(0)
        val normal = startBufferSeconds()
        if (checkAt != 0L && SystemClock.elapsedRealtime() >= checkAt) {
            checkAt = 0L
            note("after tap $lastTap: behind $behind s, expected about $expectBehind s " +
                "(player ${p.playbackState}, buffered ${p.totalBufferedDuration / 1000} s, " +
                "old method ${((h - readBasedPosition(p, rate)) / rate)} s)")
        }
        behindSeconds = behind
        rewound = behind >= normal + 6
        canRewind = playPos - STEP_SECONDS.toLong() * rate >= t + EDGE_SECONDS.toLong() * rate
        canForward = behind >= normal + 6
    }

    /** One tap: [seconds] negative goes back, positive goes forward. Call on the main thread. */
    fun skip(seconds: Int) {
        val p = player ?: return
        if (!active(p)) return
        learnRate(p)
        val rate = bytesPerSecond()
        val (h, t) = lock.withLock { head to tail }
        val playPos = playPosition(p, rate)
        var target = playPos + seconds.toLong() * rate
        val earliest = t + EDGE_SECONDS.toLong() * rate
        // Never nearer to live than the buffer chosen in More (plus a couple of seconds, so it never has to wait to
        // fill): closer than that would just be silence while it refills.
        val latest = h - (startBufferSeconds() + 2).toLong() * rate
        if (target > latest) target = latest
        if (target < earliest) target = earliest
        if (seconds < 0 && target >= playPos) return
        if (seconds > 0 && target <= playPos) return
        val item = p.currentMediaItem ?: return
        val before = ((h - playPos) / rate).toInt()
        expectBehind = ((h - target) / rate).toInt()
        lastTap = seconds
        checkAt = SystemClock.elapsedRealtime() + 2_500L
        note("tap $seconds s: behind $before s -> $expectBehind s, rate $rate B/s " +
            "(${if (formatRate > 0) "decoder" else if (measuredRate > 0) "measured" else if (headerRate > 0) "header" else "guess"}), " +
            "copy ${(h - t) / rate} s, old method ${((h - readBasedPosition(p, rate)) / rate)} s")
        itemStart = target     // so a second tap straight away starts from here, not from the old place
        p.setMediaItem(item.buildUpon().setUri(placeUri(target)).build())
        p.prepare()
        refresh()
    }
}
