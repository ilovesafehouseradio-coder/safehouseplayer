package com.example.radioplayer

/**
 * The three things you'll most likely want to change.
 */
object Config {
    const val STATION_NAME = "Safehouse Radio"
    const val SLOGAN = "The internet radio home of multi genre dance music..."
    const val STREAM_URL = "https://c4.radioboss.fm:8231/stream"
    const val WEBSITE_URL = "https://www.safehouseradio.co.uk"

    // Pages shown in the Schedule and Chat tabs.
    const val SCHEDULE_URL = "https://safehouseradio.co.uk/schedule/"
    const val CHAT_URL = "https://safehouseradio.co.uk/chat/intro.php"

    // The station's public Google Calendar (the same one the website schedule shows).
    const val CALENDAR_ICS_URL =
        "https://calendar.google.com/calendar/ical/ilovesafehouseradio%40gmail.com/public/basic.ics"

    // The website's own list of DJs (used for the searchable DJs tab).
    const val DJS_API_URL =
        "https://safehouseradio.co.uk/wp-json/wp/v2/our_djs?per_page=100&_embed=wp:featuredmedia&_fields=title,link,_links,_embedded"

    // The stream server's status page: it lists the title of whatever is playing.
    const val STATUS_URL = "https://c4.radioboss.fm:8231/status-json.xsl"

    // Picture of whichever DJ is on air (the same one the website player uses).
    const val ARTWORK_URL = "https://c4.radioboss.fm/w/artwork/231.jpg"

    // The web address of the picture used before the first lookup / when a show has none.
    // A Chromecast only loads pictures from servers that allow it. This one does (DJ pictures
    // show on the TV), the website's own logo address did not.
    const val LOGO_URL = ARTWORK_URL
}
