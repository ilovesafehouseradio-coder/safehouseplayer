package com.example.radioplayer

/**
 * The three things you'll most likely want to change.
 */
object Config {
    /**
     * What the app calls itself whenever it asks the stream server or the website for something, e.g.
     * "SafehouseRadioAndroidApp/2.0". The stream server's listener statistics (and the website's logs) can then tell
     * the app's listeners from everyone else's, and which app version they use. It carries nothing about the
     * person or the phone. The version is read from the app itself, so it needs no updating by hand.
     */
    @Volatile
    var userAgent: String = "SafehouseRadioAndroidApp"
        private set

    fun initUserAgent(context: android.content.Context) {
        try {
            val v = context.packageManager.getPackageInfo(context.packageName, 0).versionName
            if (!v.isNullOrBlank()) userAgent = "SafehouseRadioAndroidApp/$v"
        } catch (e: Exception) {
            // keep the plain name
        }
    }

    const val STATION_NAME = "Safehouse Radio"
    const val SLOGAN = "The internet radio home of multi genre dance music..."
    // Shown as the show name when the stream's title is unusable and the calendar has nothing on.
    const val FALLBACK_SHOW = "All Day Every Day"
    const val STREAM_URL = "https://c4.radioboss.fm:8231/stream"
    const val WEBSITE_URL = "https://www.safehouseradio.co.uk"
    // The link every share message carries. The website for now; the Play Store link once the app is published (change it here only).
    // The links out to the website carry a short tag (the same for everyone, nothing personal) so the website's own
    // statistics can tell visits that came from the app from other visits.
    const val WEBSITE_LINK = "$WEBSITE_URL/?utm_source=android_app&utm_medium=more"
    // False until the app is on Google Play. Then the share card says "Get the app" and the link is the Play Store address.
    const val PLAY_LIVE = false
    const val SHARE_URL = "$WEBSITE_URL/?utm_source=android_app&utm_medium=share"
    // The station's own MixCloud and SoundCloud pages. A DJ's page shows these as "Safehouse MixCloud" / "Safehouse
    // SoundCloud" buttons when the DJ has no MixCloud / SoundCloud link of their own (many DJs upload through the station).
    const val MIXCLOUD_URL = "https://www.mixcloud.com/Safehouse_Radio"
    const val SOUNDCLOUD_URL = "https://on.soundcloud.com/ChOLsB4eaV8XRvkkD8"
    // The station's other social pages, shown as buttons under More > About Safehouse Radio, after Website, MixCloud and
    // SoundCloud. Put the address after the name; anything left empty ("") is simply not shown.
    val SOCIALS: List<Pair<String, String>> = listOf(
        "Instagram" to "https://www.instagram.com/safehouse_radio",
        "Facebook" to "https://www.facebook.com/share/g/1DdMQm4NW4/",
        "YouTube" to "",
        "TikTok" to "https://www.tiktok.com/@safehouse.radio"
    ).filter { it.second.isNotBlank() }

    // Pages shown in the Schedule and Chat tabs.
    const val SCHEDULE_URL = "https://safehouseradio.co.uk/schedule/"
    const val CHAT_URL = "https://safehouseradio.co.uk/chat/intro.php"

    // The station's public Google Calendar (the same one the website schedule shows).
    const val CALENDAR_ICS_URL =
        "https://calendar.google.com/calendar/ical/ilovesafehouseradio%40gmail.com/public/basic.ics"

    // The website's own list of DJs (used for the searchable DJs tab).
    const val DJS_API_URL =
        "https://safehouseradio.co.uk/wp-json/wp/v2/our_djs?per_page=100&_embed=wp:featuredmedia&_fields=title,link,_links,_embedded"

    // The stream server's status page: it lists the title of whatever is playing.
    const val STATUS_URL = "https://c4.radioboss.fm:8231/status-json.xsl"

    // Picture of whichever DJ is on air (the same one the website player uses).
    const val ARTWORK_URL = "https://c4.radioboss.fm/w/artwork/231.jpg"

    // The About section of the More tab. Until the station's own pages are ready these open the
    // website's home page: change the three addresses (and add the contact email) here.
    // The public web copy of the privacy policy (privacy.html on GitHub Pages): the address Google Play is given too.
    const val PRIVACY_URL = "https://ilovesafehouseradio-coder.github.io/safehouseplayer/privacy.html"
    const val CONTACT_URL = WEBSITE_LINK
    const val CONTACT_EMAIL = "ilove@safehouseradio.co.uk"     // "Contact and help" and the chat-account deletion request open an email to this

    // The station's own high-resolution logo (1600 x 1600), kept on our GitHub Pages next to privacy.html.
    // This is the only picture a Chromecast (or any other player that fetches a picture by web address) is given.
    // To change it, upload a new station-logo-cast.png to the root of the GitHub repo.
    const val CAST_LOGO_URL = "https://ilovesafehouseradio-coder.github.io/safehouseplayer/station-logo-cast.png"

    // The web address of the picture used before the first lookup / when a show has none.
    const val LOGO_URL = CAST_LOGO_URL

}
