package com.example.radioplayer

/**
 * The three things you'll most likely want to change.
 */
object Config {
    const val STATION_NAME = "Safehouse Radio"
    const val SLOGAN = "The internet radio home of multi genre dance music..."
    const val STREAM_URL = "https://c4.radioboss.fm:8231/stream"
    const val WEBSITE_URL = "https://www.safehouseradio.co.uk"
}
