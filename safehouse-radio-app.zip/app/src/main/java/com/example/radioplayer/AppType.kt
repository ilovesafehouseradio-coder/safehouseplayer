package com.example.radioplayer

import androidx.compose.ui.unit.sp

/**
 * The app's text rules (part of the theme kit, with ScreenLayout for borders and gaps). Every screen uses these
 * sizes for the same job, so the same kind of thing always looks the same. Change them only when asked.
 *  - Heading: a section heading on a page ("On Air", "Up Next", "About", day headings): bold, dimmed main colour, shadow.
 *  - CardTime: the time / date line on a show card: medium.
 *  - CardName: the DJ (or show) name on a card: bold.
 *  - ShowName: a show's name under the DJ: regular, white (never dimmed).
 *  - RowLabel: the name of a setting or a switch row: medium.
 *  - Sub: the explanation under a row: regular, dimmed.
 *  - Pill: the words on any small pill or chip (choices, filters, genres, links, Try): bold.
 *  - Button: the words on a full-width button (Follow, Stop casting, Done): bold.
 *  - Small: the tiny labels (Sleep / Share, progress times).
 */
object AppType {
    val Heading = 18.sp
    val CardTime = 12.sp
    val CardName = 18.sp
    val ShowName = 15.sp
    val RowLabel = 16.sp
    val Sub = 13.sp
    val Pill = 14.sp
    val Button = 16.sp
    val Small = 11.sp
}
