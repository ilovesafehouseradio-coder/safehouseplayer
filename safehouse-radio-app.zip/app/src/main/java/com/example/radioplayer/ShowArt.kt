package com.example.radioplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * The picture the app carries for a known show (see KnownShows), used only when the station sends no
 * picture of its own. Returned as JPEG data, like the live picture, so every screen, the notification
 * and car displays use it the same way. Call off the main thread.
 */
object ShowArt {
    private val saved = HashMap<String, ByteArray>()

    fun bytes(ctx: Context, title: String?): ByteArray? {
        val known = KnownShows.match(title) ?: return null
        synchronized(saved) { saved[known.art]?.let { return it } }
        val res = when (known.art) {
            "abgt" -> R.drawable.show_abgt
            else -> return null
        }
        return try {
            val bitmap = BitmapFactory.decodeResource(ctx.applicationContext.resources, res) ?: return null
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            val data = out.toByteArray()
            synchronized(saved) { saved[known.art] = data }
            data
        } catch (e: Exception) {
            null
        }
    }

    private val photos = LinkedHashMap<String, ByteArray>()

    /**
     * The picture to use when the station sends none of its own: the one we carry for a known show (ABGT697),
     * else the photo on the card of the DJ who is on (Hardwell's card photo for "hardwell, on-air-536").
     * Null when neither exists: the theme's logo shows then. Call off the main thread.
     */
    fun fallback(ctx: Context, title: String?, djs: List<Dj>, shows: List<Show>): ByteArray? {
        bytes(ctx, title)?.let { return it }
        val shown = StreamNames.resolve(title, djs, shows)
        if (shown.generic) return null
        return djPhoto(shown.match?.imageUrl)
    }

    /** A DJ card's photo as small JPEG data (600 px at most), the same as the station's own picture. */
    fun djPhoto(url: String?): ByteArray? {
        if (url.isNullOrBlank()) return null
        val address = if (url.startsWith("http://")) "https://" + url.removePrefix("http://") else url
        synchronized(photos) { photos[address]?.let { return it } }
        val conn = try { URL(address).openConnection() as HttpURLConnection } catch (e: Exception) { return null }
        return try {
            conn.connectTimeout = 10000
            conn.readTimeout = 15000
            conn.setRequestProperty("User-Agent", Config.userAgent)
            if (conn.responseCode !in 200..299) return null
            val raw = conn.inputStream.use { it.readBytes() }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(raw, 0, raw.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 600 && bounds.outHeight / (sample * 2) >= 600) sample *= 2
            val bitmap = BitmapFactory.decodeByteArray(raw, 0, raw.size, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return null
            val longest = maxOf(bitmap.width, bitmap.height)
            val scaled = if (longest > 600) {
                Bitmap.createScaledBitmap(bitmap, bitmap.width * 600 / longest, bitmap.height * 600 / longest, true)
            } else {
                bitmap
            }
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 88, out)
            val data = out.toByteArray()
            synchronized(photos) {
                photos[address] = data
                if (photos.size > 8) photos.remove(photos.keys.first())
            }
            data
        } catch (e: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }
}
