package com.example.radioplayer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream

/**
 * The picture the app carries for a known show (see KnownShows), used only when the station sends no
 * picture of its own. Returned as JPEG data, like the live picture, so every screen, the notification
 * and car displays use it the same way. Call off the main thread.
 */
object ShowArt {
    private val saved = HashMap<String, ByteArray>()

    fun bytes(ctx: Context, title: String?): ByteArray? {
        val known = KnownShows.match(title) ?: return null
        synchronized(saved) { saved[known.art]?.let { return it } }
        val res = when (known.art) {
            "abgt" -> R.drawable.show_abgt
            else -> return null
        }
        return try {
            val bitmap = BitmapFactory.decodeResource(ctx.applicationContext.resources, res) ?: return null
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            val data = out.toByteArray()
            synchronized(saved) { saved[known.art] = data }
            data
        } catch (e: Exception) {
            null
        }
    }
}
