package com.example.radioplayer

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Finds out which DJs belong together (a duo, a crew, a brand) by reading the DJ bios on the
 * website: a bio that says "duo" / "crew" / "collective"... close to the name of another DJ on
 * the station links the two. The result is saved for a week and used by [DjMatch], so a show listed
 * under the brand also turns up on each member's profile, and the other way round.
 *
 * It is careful on purpose: only DJs from the station's own list can be linked, the name must be
 * close to a "team" word, and a mention of someone (a guest, a famous DJ) is not enough.
 */
object DjGroups {

    private const val PREFS = "dj_groups"
    private const val K_JSON = "groups"
    private const val K_TIME = "at"
    private const val WEEK_MS = 7L * 24 * 3600 * 1000
    private const val MIN_NAME_KEY = 5      // shorter names are too easy to find by accident
    private const val MAX_MEMBERS = 6
    private const val REUSE_MS = 14L * 24 * 3600 * 1000
    private const val PARALLEL = 3          // pages read at the same time

    // Only neutral words for a group of performers; nothing about anyone's private life is looked for or kept.
    private val TEAM_WORDS = Regex(
        "(?i)\\b(?:duo|trio|quartet|crew|collective|made\\s+up\\s+of|consists\\s+of|comprises|" +
            "resident\\s+djs?|team\\s+of)\\b"
    )

    @Volatile private var loaded = false

    /** Loads the saved groups once per run of the app (also used by the reminder worker). */
    fun ensureLoaded(ctx: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            try {
                val json = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_JSON, null)
                if (json != null) DjMatch.setLearned(parse(json))
            } catch (e: Exception) {
                // A damaged copy is ignored; it is learned again.
            }
            loaded = true
        }
    }

    /**
     * True when it is time to read the bios again: weekly on Wi-Fi (or any connection without a data
     * limit), and only every three weeks on a metered mobile connection.
     */
    fun shouldScan(ctx: Context): Boolean {
        val age = System.currentTimeMillis() - prefs(ctx).getLong(K_TIME, 0L)
        if (age <= WEEK_MS) return false
        val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
        val metered = try { cm?.isActiveNetworkMetered ?: true } catch (e: Exception) { true }
        return !metered || age > 3 * WEEK_MS
    }

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /**
     * Reads every DJ's page (a few at a time, keeping the pages for the profile screen too), works out
     * the groups and saves them. Returns true if the groups changed.
     */
    suspend fun scan(ctx: Context, state: DjListState): Boolean {
        val djs = state.djs
        if (djs.isEmpty()) return false
        val gate = Semaphore(PARALLEL)
        val ok = withContext(Dispatchers.IO) {
            coroutineScope {
                djs.map { dj ->
                    async {
                        gate.withPermit {
                            // A page kept in the last two weeks is good enough for this; only older or missing ones are read.
                            val age = System.currentTimeMillis() - (state.profileAt[dj.link] ?: 0L)
                            if (state.profiles[dj.link] != null && age < REUSE_MS) true
                            else {
                                val p = fetchDjProfile(dj.link, dj.name)
                                if (p != null) state.rememberProfile(dj.link, p)
                                p != null || state.profiles[dj.link] != null
                            }
                        }
                    }
                }.awaitAll()
            }
        }
        // Too many pages missing (no signal?): try again next time instead of trusting half a picture.
        if (ok.count { it } < djs.size * 0.8) return false

        withContext(Dispatchers.IO) { state.saveCache() }
        val found = HashMap<String, Set<String>>()
        val finder = NameFinder(djs.map { it.name })
        for (dj in djs) {
            val p = state.profiles[dj.link] ?: continue
            val members = membersIn(p.paragraphs.joinToString("\n"), DjMatch.key(dj.name), finder)
            if (members.isNotEmpty()) found[DjMatch.key(dj.name)] = members
        }
        val changed = found != DjMatch.learnedGroups()
        DjMatch.setLearned(found)
        prefs(ctx).edit().putString(K_JSON, toJson(found)).putLong(K_TIME, System.currentTimeMillis()).apply()
        loaded = true
        return changed
    }

    /** Finds the station DJs named in a piece of text. */
    class NameFinder(names: List<String>) {
        private class Entry(val key: String, val regex: Regex)
        private val entries: List<Entry> = names.mapNotNull { n ->
            val k = DjMatch.key(n)
            if (k.length < MIN_NAME_KEY) null
            else {
                val words = n.trim().replace(Regex("(?i)^dj\\s+"), "").split(Regex("[\\s\\-]+")).filter { it.isNotEmpty() }
                if (words.isEmpty()) null
                else Entry(
                    k,
                    Regex("(?i)(?<![\\p{L}\\p{N}])" + words.joinToString("[\\s\\-]*") { Regex.escape(it) } + "(?![\\p{L}\\p{N}])")
                )
            }
        }.distinctBy { it.key }

        fun inText(text: String): Set<String> = entries.filter { it.regex.containsMatchIn(text) }.map { it.key }.toSet()
    }

    private val SENTENCE_END = Regex("(?<=[.!?\\n])\\s+")

    /**
     * The DJs named in the same sentence as a "team" word in this bio (never the DJ's own name).
     * If that sentence names nobody, the sentence after it counts too ("... are a duo. Catch 22 and
     * Miss Behaviour ..."). A passing mention of someone else further on is ignored.
     */
    fun membersIn(bio: String, ownerKey: String, finder: NameFinder): Set<String> {
        val sentences = bio.split(SENTENCE_END)
        val out = LinkedHashSet<String>()
        for ((i, sentence) in sentences.withIndex()) {
            if (!TEAM_WORDS.containsMatchIn(sentence)) continue
            val here = finder.inText(sentence).filter { it != ownerKey }
            val named = if (here.isNotEmpty() || i + 1 >= sentences.size) here
            else finder.inText(sentences[i + 1]).filter { it != ownerKey }
            out.addAll(named)
        }
        return if (out.size > MAX_MEMBERS) emptySet() else out
    }

    private fun toJson(m: Map<String, Set<String>>): String {
        val o = JSONObject()
        for ((g, members) in m) o.put(g, JSONArray(members.toList()))
        return o.toString()
    }

    private fun parse(json: String): Map<String, Set<String>> {
        val o = JSONObject(json)
        val out = HashMap<String, Set<String>>()
        for (g in o.keys()) {
            val a = o.getJSONArray(g)
            out[g] = (0 until a.length()).map { a.getString(it) }.toSet()
        }
        return out
    }
}
