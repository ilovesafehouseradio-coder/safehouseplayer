package com.example.radioplayer

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build

/**
 * Opens a web address the way a person would want: in the matching app if it is installed (Instagram, Facebook,
 * TikTok, YouTube, SoundCloud, Mixcloud, Bandcamp, Spotify and so on), otherwise in the browser.
 *
 * Only ordinary web addresses (and mailto: for email) are opened; anything else is ignored. The app asks for no
 * permission and reads nothing from the other app: it just hands the address over.
 */
object Links {
    /** Web address (and any sub-address of it) -> the Android apps that open it. */
    private val APPS: List<Pair<List<String>, List<String>>> = listOf(
        listOf("instagram.com") to listOf("com.instagram.android"),
        listOf("facebook.com", "fb.com", "fb.me", "fb.watch") to listOf("com.facebook.katana"),
        listOf("tiktok.com") to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        listOf("youtube.com", "youtu.be") to listOf("com.google.android.youtube"),
        listOf("soundcloud.com", "snd.sc") to listOf("com.soundcloud.android"),
        listOf("mixcloud.com") to listOf("com.mixcloud.player"),
        listOf("bandcamp.com") to listOf("com.bandcamp.android"),
        listOf("spotify.com", "spotify.link") to listOf("com.spotify.music"),
        listOf("twitter.com", "x.com") to listOf("com.twitter.android"),
        listOf("twitch.tv") to listOf("tv.twitch.android.app"),
        listOf("linkedin.com") to listOf("com.linkedin.android")
    )

    fun open(ctx: Context, url: String) {
        val uri = try { Uri.parse(url.trim()) } catch (e: Exception) { return }
        val scheme = uri.scheme.orEmpty().lowercase()
        if (scheme == "mailto") {
            start(ctx, Intent(Intent.ACTION_VIEW, uri))
            return
        }
        if (scheme != "http" && scheme != "https") return
        val host = uri.host.orEmpty().lowercase()

        // 1. The matching app, if the person has it.
        val packages = APPS.firstOrNull { (hosts, _) -> hosts.any { host == it || host.endsWith(".$it") } }?.second.orEmpty()
        for (pkg in packages) {
            if (start(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))) return
        }
        // 2. Any other app that has been set up to open this address (never a browser).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (start(ctx, Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_REQUIRE_NON_BROWSER))) return
        }
        // 3. The browser.
        start(ctx, Intent(Intent.ACTION_VIEW, uri))
    }

    private fun start(ctx: Context, intent: Intent): Boolean =
        try {
            ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: Exception) {
            false
        }
}
