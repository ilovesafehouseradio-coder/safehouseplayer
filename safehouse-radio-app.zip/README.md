# Radio Player (Android)

A simple live radio player: native play/pause with background playback and lock screen
controls, plus a Website tab.

## 1. Change your details

Open `app/src/main/java/com/example/radioplayer/Config.kt`:

- `STATION_NAME`: shown in the notification
- `SLOGAN`: shown under the logo on the player
- `STREAM_URL`: your live stream address
- `WEBSITE_URL`: your station website

The name under the app icon is in `app/src/main/res/values/strings.xml`.

## 2. Get the installable APK (no Android Studio needed)

1. Create a new repository on GitHub and upload everything in this folder,
   including the hidden `.github` folder.
2. Open the repository's **Actions** tab. The "Build APK" workflow runs on every upload
   (or press **Run workflow**).
3. When it finishes (a few minutes), open the run and download the
   **radio-player-apk** file from the Artifacts section at the bottom.
4. Unzip it, copy `app-debug.apk` to your phone and install it
   (you'll need to allow installs from your browser or file manager).

If the build fails, open the failed run, copy the red error text, and paste it back to Claude.

## 3. Logo and colours

- The player logo is `app/src/main/res/drawable-nodpi/station_logo.png`. Replace the file
  (same name) to change it.
- The app icon is built from the same logo (`ic_launcher_foreground.png` and
  `mipmap-nodpi/ic_launcher.png`).
- Colours are in `RadioTheme` at the top of `MainActivity.kt`, sampled from the logo.

## Notes

- This builds a **debug** APK, which is fine for installing on your own devices.
  Publishing to the Play Store needs a signed release build, which can be added later.
