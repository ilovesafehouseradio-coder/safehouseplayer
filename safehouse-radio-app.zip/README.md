# Radio Player (Android)

A simple live radio player: native play/pause with background playback and lock screen
controls, plus a Website tab.

## 1. Change your details

Open `app/src/main/java/com/example/radioplayer/Config.kt`:

- `STATION_NAME`: shown in the notification
- `SLOGAN`: shown under the logo on the player
- `STREAM_URL`: your live stream address
- `WEBSITE_URL`: your station website
- `CALENDAR_ICS_URL`: the public Google Calendar the Schedule tab is built from (On Air, Up Next, Recently Aired and the day-by-day list)
- `SCHEDULE_URL`, `CHAT_URL`: website pages (schedule is the fallback if the calendar can't load; chat is the Chat tab)
- `DJS_API_URL`: the website feed the DJs tab reads (names, photos, links)
- `ARTWORK_URL`: the picture of the DJ on air

## Tabs

Radio, Schedule, Chat, DJs and Website. The Chat tab keeps you signed in by saving the
website's login cookie on the phone (the app never sees or stores your password).

The name under the app icon is in `app/src/main/res/values/strings.xml`.

## 2. Get the installable APK (no Android Studio needed)

1. Create a new repository on GitHub and upload everything in this folder,
   including the hidden `.github` folder.
2. Open the repository's **Actions** tab. The "Build APK" workflow runs on every upload
   (or press **Run workflow**).
3. When it finishes (a few minutes), open the run and download the
   **radio-player-apk** file from the Artifacts section at the bottom.
4. Unzip it, copy `app-debug.apk` to your phone and install it
   (you'll need to allow installs from your browser or file manager).

If the build fails, open the failed run, copy the red error text, and paste it back to Claude.

## 3. Logo and colours

- The player logo is `app/src/main/res/drawable-nodpi/station_logo.png`. Replace the file
  (same name) to change it.
- The app icon is built from the same logo (`ic_launcher_foreground.png` and
  `mipmap-nodpi/ic_launcher.png`).
- Colours are in `RadioTheme` at the top of `MainActivity.kt`, sampled from the logo.

## Notes

- This builds a **debug** APK, which is fine for installing on your own devices.
  Publishing to the Play Store needs a signed release build, which can be added later.

## Signing

The project contains `safehouse-debug.keystore`, a fixed key used to sign every build. Because every
build is signed the same way, a new APK installs over the old one without uninstalling.
(The first install after this key was added needs the old version uninstalled once.)
If you ever publish on Google Play, make a separate private key for that and keep it out of this folder.

## Extras

- Sleep timer and Share button beside the play button on the Radio tab
- Android Auto / car and Bluetooth screens can browse and play the station
- Swipe left and right between tabs; pull down to refresh Schedule and DJs
- Themed (monochrome) app icon for Android 13+
- Chromecast button (top right of the Radio tab, appears when a Cast device is nearby)
- Car / Bluetooth displays are given the DJ, show and picture directly
