package com.example.radioplayer

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.roundToInt
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

private val Edge: Color get() = ThemeState.current.edge
private val Muted: Color get() = ThemeState.current.textDim

/**
 * The More tab: the app's own settings and the About section. Nothing here is a web page. Every
 * switch is kept on the phone only.
 */
@Composable
fun MoreScreen(
    onOpenReminderSetup: () -> Unit,
    onRemindersChanged: () -> Unit,
    onClearSaved: () -> Unit,
    onClearChat: () -> Unit
) {
    // 0 = the settings, 1 = the Privacy page, 2 = the Terms page.
    var page by remember { mutableStateOf(0) }
    LaunchedEffect(DataWarning.wantSetting) { if (DataWarning.wantSetting) page = 0 }
    when (page) {
        1 -> PrivacyPage(onBack = { page = 0 })
        2 -> TermsPage(onBack = { page = 0 })
        else -> MoreMain(
            onOpenReminderSetup, onRemindersChanged, onClearSaved, onClearChat,
            onOpenPrivacy = { page = 1 }, onOpenTerms = { page = 2 }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MoreMain(
    onOpenReminderSetup: () -> Unit,
    onRemindersChanged: () -> Unit,
    onClearSaved: () -> Unit,
    onClearChat: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onOpenTerms: () -> Unit
) {
    val ctx = LocalContext.current
    val bubble = remember { BubbleState() }

    var remindersOn by remember { mutableStateOf(AppSettings.remindersOn(ctx)) }
    var sound by remember { mutableStateOf(AppSettings.reminderSound(ctx)) }
    var unplug by remember { mutableStateOf(AppSettings.pauseOnUnplug(ctx)) }
    var dataWarn by remember { mutableStateOf(AppSettings.warnMobileData(ctx)) }
    var buffer by remember { mutableStateOf(AppSettings.bufferChoice(ctx)) }
    var motion by remember { mutableStateOf(AppSettings.reduceMotionChoice(ctx)) }
    var skipWelcome by remember { mutableStateOf(AppSettings.skipWelcome(ctx)) }
    var welcomeSound by remember { mutableStateOf(AppSettings.welcomeSound(ctx)) }
    var castPics by remember { mutableStateOf(AppSettings.castDjPictures(ctx)) }
    var cleared by remember { mutableStateOf(false) }
    var chatCleared by remember { mutableStateOf(false) }
    var confirmChatClear by remember { mutableStateOf(false) }
    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName.orEmpty()
        } catch (e: Exception) {
            ""
        }
    }

    if (confirmChatClear) {
        ConfirmDialog(
            question = "Sign out of the chat?",
            detail = "This removes your saved chat sign-in and chat data from this phone. Your chat account is not deleted, and you can sign in again any time.",
            confirmLabel = "Sign out",
            onConfirm = {
                confirmChatClear = false
                onClearChat()
                chatCleared = true
            },
            onDismiss = { confirmChatClear = false }
        )
    }

    // The data card's Settings button lands here: scroll so the Listening card sits at the top, then clear the request.
    val scroll = rememberScrollState()
    var listeningTop by remember { mutableStateOf(0) }
    val density = LocalDensity.current
    LaunchedEffect(DataWarning.wantSetting, listeningTop) {
        if (DataWarning.wantSetting && listeningTop > 0) {
            scroll.animateScrollTo((listeningTop - with(density) { 8.dp.roundToPx() }).coerceAtLeast(0))
            DataWarning.wantSetting = false
        }
    }

    BubbleHost(bubble) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(scroll)
                .padding(bottom = 24.dp)
        ) {
            PageHeader("More")

            SettingsCard("Reminders") {
                ToggleRow(
                    label = "Show reminders",
                    sub = if (remindersOn) "Switch off to pause every reminder" else "Paused. The DJs you follow are kept.",
                    checked = remindersOn,
                    onChange = {
                        remindersOn = it
                        AppSettings.setRemindersOn(ctx, it)
                        onRemindersChanged()
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("Switches every show reminder on or off in one go.")
                        BubbleText("The DJs and shows you follow are kept, so switching back on brings all your reminders back.")
                    }
                )
                RowDivider()
                ChoiceRow(
                    label = "Reminder sound",
                    sub = "Plays when a reminder arrives",
                    options = ReminderSound.values().map { it.label },
                    selected = sound.ordinal,
                    onSelect = {
                        sound = ReminderSound.values()[it]
                        AppSettings.setReminderSound(ctx, sound)
                        Reminders.ensureChannel(ctx)
                    },
                    bubble = bubble,
                    trailing = { TryButton { Reminders.playPreview(ctx) } },
                    info = {
                        BubbleText("Safehouse plays a short, quiet Safehouse sound with each reminder. Phone uses your phone's own notification sound. Silent shows the reminder without any sound.")
                        BubbleText("You can also change it in your phone's notification settings for Safehouse Radio.")
                    }
                )
                RowDivider()
                NavRow(
                    label = "Reminder setup guide",
                    sub = "Battery tips, if reminders arrive late",
                    external = false,
                    onClick = onOpenReminderSetup
                )
            }

            SettingsCard("Listening", Modifier.onGloballyPositioned { listeningTop = it.positionInParent().y.roundToInt() }) {
                ToggleRow(
                    label = "Pause when headphones unplug",
                    sub = "Stops the radio if the cable or Bluetooth drops",
                    checked = unplug,
                    onChange = {
                        unplug = it
                        AppSettings.setPauseOnUnplug(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("Stops the radio when headphones or a Bluetooth speaker disconnect, so it never suddenly plays out loud.")
                        BubbleText("Switch this off if you would rather it carried on through the phone's speaker.")
                    }
                )
                RowDivider()
                ToggleRow(
                    label = "Warn before using mobile data",
                    sub = "Asks when you start listening on mobile data",
                    checked = dataWarn,
                    onChange = {
                        dataWarn = it
                        AppSettings.setWarnMobileData(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("Live radio uses about 140 MB of data an hour.")
                        BubbleText("When this is on and you press play on mobile data, the app asks before it starts, once for each listening session (again after a break of 10 minutes or more). You can always carry on: the radio is never blocked.")
                        BubbleText("It does not apply to the play buttons in notifications, cars or Bluetooth.")
                    }
                )
                RowDivider()
                ChoiceRow(
                    label = "Buffer",
                    sub = "Smoother in weak signal, a little behind live",
                    options = AppSettings.BUFFER_LABELS,
                    selected = buffer,
                    onSelect = {
                        buffer = it
                        AppSettings.setBufferChoice(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("The buffer is a cushion of audio the radio collects before it starts playing. A bigger cushion rides out short drops in signal (tunnels, Wi-Fi changes), but there is a pause before you hear anything and you hear the DJ that much later.")
                        BubbleText("Default is about 8 seconds and suits most phones. Try 30 s or 60 s if the radio keeps cutting out. It does not use extra data. A change starts the radio again if it is playing.")
                    }
                )
            }

            SettingsCard("Display") {
                ThemeRow(onChoose = { ThemeState.choose(ctx, it) })
                RowDivider()
                ToggleRow(
                    label = "Show artwork from the radio",
                    sub = "Off: always the Safehouse logo",
                    checked = LiveArtSwitch.on,
                    onChange = { LiveArtSwitch.choose(ctx, it) },
                    bubble = bubble,
                    info = {
                        BubbleText("Choose the picture shown on the Radio tab and on your lock screen while the radio plays.")
                        BubbleText("On: the picture the radio server is showing for the DJ or show, when there is one.")
                        BubbleText("Off: always the Safehouse Radio logo in your theme's colours. It also saves a little data.")
                    }
                )
                RowDivider()
                ToggleRow(
                    label = "DJ pictures on the TV",
                    sub = "Off: a Chromecast shows the Safehouse logo",
                    checked = castPics,
                    onChange = {
                        castPics = it
                        AppSettings.setCastDjPictures(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("Choose the picture a Chromecast or TV shows while you cast.")
                        BubbleText("Off (recommended): the Safehouse Radio logo, sharp and always right.")
                        BubbleText("On: the picture the radio server is broadcasting when you start casting. It may not change when the DJ changes while you are casting, and it can look softer.")
                        BubbleText("A change applies the next time you start casting.")
                    }
                )
                RowDivider()
                ToggleRow(
                    label = "Reduce animations",
                    sub = "Calmer play button and welcome screen",
                    checked = motion,
                    onChange = {
                        motion = it
                        AppSettings.setReduceMotion(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("Turns off the pulsing rings, the blinking LIVE dot and the bouncing logo on the welcome screen. Good if movement bothers you, and it saves a little battery.")
                        BubbleText("The app also does this by itself if your phone has animations turned off.")
                    }
                )
                RowDivider()
                ToggleRow(
                    label = "Skip the welcome screen",
                    sub = "Go straight to the radio",
                    checked = skipWelcome,
                    onChange = {
                        skipWelcome = it
                        AppSettings.setSkipWelcome(ctx, it)
                    },
                    bubble = bubble,
                    info = null
                )
                RowDivider()
                ToggleRow(
                    label = "Welcome sound",
                    sub = "A short Safehouse jingle when the app opens",
                    checked = welcomeSound,
                    onChange = {
                        welcomeSound = it
                        AppSettings.setWelcomeSound(ctx, it)
                    },
                    bubble = bubble,
                    info = {
                        BubbleText("A short Safehouse station ID that plays with the welcome screen, at your phone's media volume.")
                        BubbleText("It never plays if the radio or any other audio is already playing, or if your phone is on silent or vibrate.")
                    }
                )
                Text(
                    text = "Text size follows your phone's settings.",
                    color = Muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 8.dp)
                )
            }

            SettingsCard("Storage") {
                NavRow(
                    label = "Clear saved pictures and schedule",
                    sub = if (cleared) "Cleared. They download again when needed." else "Frees space; they download again when needed",
                    external = false,
                    showChevron = false,
                    onClick = {
                        onClearSaved()
                        cleared = true
                    }
                )
            }

            SettingsCard("Chat account") {
                NavRow(
                    label = "Sign out and clear chat data",
                    sub = if (chatCleared) "Done. You can sign in again from the Chat tab." else "Removes your saved chat sign-in from this phone",
                    external = false,
                    showChevron = false,
                    onClick = { confirmChatClear = true }
                )
                RowDivider()
                NavRow(
                    label = "Delete my chat account",
                    sub = "Opens an email asking Safehouse Radio to delete it",
                    external = true,
                    onClick = { requestChatDeletion(ctx) }
                )
            }

            SettingsCard("About Safehouse Radio") {
                // Safehouse's own pages, as lilac buttons (lilac is always "the station's own").
                FlowRow(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StationLinkPill("Website", "Open the Safehouse Radio website") { openUrl(ctx, Config.WEBSITE_LINK) }
                    StationLinkPill("MixCloud", "Open Safehouse MixCloud") { openUrl(ctx, Config.MIXCLOUD_URL) }
                    StationLinkPill("SoundCloud", "Open Safehouse SoundCloud") { openUrl(ctx, Config.SOUNDCLOUD_URL) }
                    for ((name, url) in Config.SOCIALS) {
                        StationLinkPill(name, "Open Safehouse $name") { openUrl(ctx, url) }
                    }
                }
                RowDivider()
                NavRow(
                    label = "Tell a friend about the app",
                    sub = "Share Safehouse Radio with a link",
                    external = false,
                    showChevron = false,
                    trailing = { ActionIconView(ActionIcon.SHARE, Edge) },
                    onClick = { ShowActions.share(ctx, ShowActions.appText(), ShareCard.Spec(Config.STATION_NAME, Config.FALLBACK_SHOW, null, station = true)) }
                )
                RowDivider()
                NavRow(
                    label = "Show the tips again",
                    sub = "The short hints for first-time listeners",
                    external = false,
                    showChevron = false
                ) {
                    Tips.reset(ctx)
                    android.widget.Toast.makeText(ctx, "The tips will show again as you listen", android.widget.Toast.LENGTH_SHORT).show()
                }
                RowDivider()
                NavRow("Privacy policy", "What the app does, and does not do, with data", external = false) { onOpenPrivacy() }
                RowDivider()
                NavRow("Terms of use", "The rules for using the app", external = false) { onOpenTerms() }
                RowDivider()
                NavRow("Contact and help", null, external = true) { contact(ctx) }
            }

            Column(
                Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "A non-profit internet radio station",
                    color = Edge,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
                Text(
                    Config.SLOGAN.trimEnd('.'),
                    color = Muted,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
                if (version.isNotEmpty()) {
                    // Tapped seven times: shares a short note of what went wrong in the chat window (for the developer).
                    var diagTaps by remember { mutableStateOf(0) }
                    Text(
                        "Version $version",
                        color = Muted,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .padding(top = 14.dp)
                            .clickable {
                                diagTaps++
                                if (diagTaps >= 7) {
                                    diagTaps = 0
                                    ChatDiag.snapshot { notes ->
                                        ShowActions.share(ctx, "Safehouse Radio $version chat notes\n" + notes.ifEmpty { "(nothing recorded)" })
                                    }
                                }
                            }
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Privacy and Terms pages (the words live in PolicyText, shared with privacy.html on the web)
// ---------------------------------------------------------------------------

@Composable
private fun PrivacyPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    PolicyPage("Privacy", PolicyText.privacyIntro, PolicyText.privacy, onBack) {
        SetupButton("Open the online version", onClick = { openUrl(ctx, Config.PRIVACY_URL) }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun TermsPage(onBack: () -> Unit) {
    PolicyPage("Terms of use", PolicyText.termsIntro, PolicyText.terms, onBack, null)
}

@Composable
private fun PolicyPage(
    title: String,
    intro: String,
    sections: List<Pair<String, String>>,
    onBack: () -> Unit,
    footer: (@Composable () -> Unit)?
) {
    BackHandler(onBack = onBack)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        PageHeader(title = title, leading = { BackArrowButton(onBack) })
        Text(
            intro,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 14.sp,
            modifier = Modifier.padding(start = IntroSideMargin, end = IntroSideMargin, bottom = 2.dp)
        )
        Text(
            "Last updated ${PolicyText.UPDATED}",
            color = Muted,
            fontSize = 12.sp,
            modifier = Modifier.padding(start = IntroSideMargin, end = IntroSideMargin, bottom = 12.dp)
        )
        for ((heading, text) in sections) PrivacyCard(heading, text)
        if (footer != null) Box(Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp)) { footer() }
    }
}

@Composable
private fun PrivacyCard(title: String, text: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
            .lift(RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .padding(14.dp)
    ) {
        Text(title, color = MaterialTheme.colorScheme.onBackground, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(text, color = ThemeState.current.textDim, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

/** The arrow at the left of a page title: the same as the phone's back button. */
@Composable
fun BoxScope.BackArrowButton(onBack: () -> Unit) {
    Box(
        modifier = Modifier
            .align(Alignment.CenterStart)
            .padding(start = 4.dp)
            .size(48.dp)
            .clip(CircleShape)
            .clickable(onClickLabel = "Go back", role = Role.Button, onClick = onBack),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_arrow_back),
            contentDescription = "Go back",
            tint = LavenderInk,
            modifier = Modifier.size(24.dp)
        )
    }
}

// ---------------------------------------------------------------------------
// The rows
// ---------------------------------------------------------------------------

@Composable
private fun SettingsCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
            .lift(RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(CardSurface)
            .padding(vertical = 6.dp)
    ) {
        Text(
            text = title,
            color = Edge,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp)
        )
        content()
    }
}

@Composable
private fun RowDivider() {
    Box(
        Modifier
            .padding(horizontal = 16.dp)
            .fillMaxWidth()
            .height(1.dp)
            .background(ThemeState.current.divider)
    )
}

/** The name of a setting, with its (i) beside it when there is something to explain. */
@Composable
private fun LabelWithInfo(
    label: String,
    bubble: BubbleState,
    info: (@Composable ColumnScope.() -> Unit)?,
    onClick: (() -> Unit)? = null
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .weight(1f, fill = false)
                .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        )
        if (info != null) InfoButton(label, bubble, info)
    }
}

@Composable
private fun ToggleRow(
    label: String,
    sub: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    bubble: BubbleState,
    info: (@Composable ColumnScope.() -> Unit)?
) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .padding(start = 16.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            LabelWithInfo(label, bubble, info, onClick = { onChange(!checked) })
            Text(
                text = sub,
                color = Muted,
                fontSize = 13.sp,
                modifier = Modifier.clickable { onChange(!checked) }
            )
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            modifier = Modifier.semantics { contentDescription = label },
            colors = SwitchDefaults.colors(
                checkedThumbColor = LavenderInk,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                checkedBorderColor = MaterialTheme.colorScheme.primary,
                uncheckedThumbColor = Edge,
                uncheckedTrackColor = ThemeState.current.scrim,
                uncheckedBorderColor = Edge
            )
        )
    }
}

@Composable
private fun ChoiceRow(
    label: String,
    sub: String,
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    bubble: BubbleState,
    info: (@Composable ColumnScope.() -> Unit)?,
    trailing: (@Composable () -> Unit)? = null
) {
    Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp, top = 4.dp, bottom = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                LabelWithInfo(label, bubble, info)
                Text(text = sub, color = Muted, fontSize = 13.sp)
            }
            if (trailing != null) {
                Spacer(Modifier.width(8.dp))
                trailing()
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for ((i, option) in options.withIndex()) {
                // Each pill is as wide as its words need (a little extra for longer ones), so nothing is ever cut off.
                Chip(option, selected = i == selected, modifier = Modifier.weight((option.length + 6).toFloat())) { onSelect(i) }
            }
        }
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .heightIn(min = 48.dp)
            .lift(RoundedCornerShape(50), tappable = true, fill = if (selected) MaterialTheme.colorScheme.primary else Color.Unspecified)
            .clip(RoundedCornerShape(50))
            .background(if (selected) MaterialTheme.colorScheme.primary else ThemeState.current.background.copy(alpha = 0.4f))
            .selectable(selected = selected, role = Role.RadioButton, onClick = onClick)
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) LavenderInk else MaterialTheme.colorScheme.onBackground,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

@Composable
private fun TryButton(onClick: () -> Unit) {
    Row(
        Modifier
            .heightIn(min = 48.dp)
            .lift(RoundedCornerShape(50), tappable = true, fill = ThemeState.current.lilacSurface)
            .clip(RoundedCornerShape(50))
            .background(ThemeState.current.lilacSurface)
            .clickable(onClickLabel = "Play the reminder sound", role = Role.Button, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Canvas(Modifier.size(14.dp)) {
            val p = Path().apply {
                moveTo(0f, 0f)
                lineTo(size.width, size.height / 2f)
                lineTo(0f, size.height)
                close()
            }
            drawPath(p, ThemeState.current.text)
        }
        Spacer(Modifier.width(8.dp))
        Text("Try", color = MaterialTheme.colorScheme.onBackground, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NavRow(
    label: String,
    sub: String?,
    external: Boolean,
    showChevron: Boolean = true,
    trailing: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = label,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
            if (sub != null) Text(text = sub, color = Muted, fontSize = 13.sp)
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        } else if (showChevron) {
            Spacer(Modifier.width(8.dp))
            Canvas(Modifier.size(20.dp)) {
                val w = 2.dp.toPx()
                if (external) {
                    // A small arrow leaving a box: "opens elsewhere".
                    drawLine(Edge, Offset(size.width * 0.3f, size.height * 0.7f), Offset(size.width * 0.8f, size.height * 0.2f), strokeWidth = w, cap = StrokeCap.Round)
                    drawLine(Edge, Offset(size.width * 0.4f, size.height * 0.2f), Offset(size.width * 0.8f, size.height * 0.2f), strokeWidth = w, cap = StrokeCap.Round)
                    drawLine(Edge, Offset(size.width * 0.8f, size.height * 0.2f), Offset(size.width * 0.8f, size.height * 0.6f), strokeWidth = w, cap = StrokeCap.Round)
                } else {
                    val p = Path().apply {
                        moveTo(size.width * 0.35f, size.height * 0.15f)
                        lineTo(size.width * 0.75f, size.height * 0.5f)
                        lineTo(size.width * 0.35f, size.height * 0.85f)
                    }
                    drawPath(p, Edge, style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
    }
}

private fun openUrl(ctx: Context, url: String) = Links.open(ctx, url)

/** "Contact and help": an email to the station if its address is set, otherwise the contact page. */
private fun contact(ctx: Context) {
    if (Config.CONTACT_EMAIL.isBlank()) {
        openUrl(ctx, Config.CONTACT_URL)
        return
    }
    // A ready-made draft, so we know the email came from the app and which version and phone it is. The person
    // can change or delete any of it before sending; nothing is sent by the app itself (see the Privacy page).
    val version = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName.orEmpty()
    } catch (e: Exception) {
        ""
    }
    val phone = listOf(android.os.Build.MANUFACTURER, android.os.Build.MODEL)
        .filter { it.isNotBlank() }.joinToString(" ").replaceFirstChar { it.uppercase() }
    val body = "Hello Safehouse Radio,\n\n(Tell us what is happening here.)\n\n\n" +
        "--- Please keep these lines, they help us find the problem ---\n" +
        "App: ${Config.STATION_NAME} ${version}\n" +
        "Phone: $phone, Android ${android.os.Build.VERSION.RELEASE}\n"
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                .putExtra(Intent.EXTRA_EMAIL, arrayOf(Config.CONTACT_EMAIL))
                .putExtra(Intent.EXTRA_SUBJECT, "${Config.STATION_NAME} app: help")
                .putExtra(Intent.EXTRA_TEXT, body)
        )
    } catch (e: Exception) {
        openUrl(ctx, Config.CONTACT_URL)
    }
}

/**
 * The question shown by "Warn before using mobile data". Play carries on as normal; Not now just does
 * nothing; Settings opens the setting. Shown once for each listening session on mobile data.
 */
@Composable
fun DataWarningDialog() {
    val start = DataWarning.pending
    if (start != null) {
        val shape = RoundedCornerShape(24.dp)
        Dialog(onDismissRequest = { DataWarning.pending = null }) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(shape)
                    .background(ThemeState.current.card)
                    .border(2.dp, ThemeState.current.primary, shape)
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = rememberLogoTile(),
                        contentDescription = null,
                        modifier = Modifier.size(30.dp).clip(CircleShape)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Safehouse says…", color = ThemeState.current.primary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
                Text(
                    "You are on mobile data.",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(top = 14.dp)
                )
                Text(
                    "Live radio uses about 140 MB of data an hour. Carry on?",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
                Text(
                    "To stop these reminders, tap Settings and switch off \"Warn before using mobile data\".",
                    color = ThemeState.current.textDim,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
                // Three equal choices in one row, none stressed above the others.
                Row(
                    Modifier.fillMaxWidth().padding(top = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CardChoice("Play", Modifier.weight(1f)) {
                        DataWarning.pending = null
                        start()
                    }
                    CardChoice("Not now", Modifier.weight(1f)) { DataWarning.pending = null }
                    CardChoice("Settings", Modifier.weight(1f), "Open the mobile data setting") {
                        DataWarning.pending = null
                        DataWarning.wantSetting = true
                    }
                }
            }
        }
    }
}

/**
 * A first-use tip, in the same "Safehouse says…" card as the mobile data question. "Got it" closes it for good;
 * "No more tips" closes it and switches the rest off.
 */
@Composable
fun TipDialog() {
    val tip = Tips.pending
    if (tip == 0) return
    val ctx = LocalContext.current
    val shape = RoundedCornerShape(24.dp)
    val title = when (tip) {
        1 -> "Go back, or catch up"
        2 -> "Sleep timer"
        else -> "Share what's playing"
    }
    val body = when (tip) {
        1 -> "The radio is live, so these buttons jump 10 seconds back or forward. You can go back as far as the app has kept."
        2 -> "Falling asleep to the radio? Set a timer and it stops by itself."
        else -> "Send the show to a friend, with the DJ and a link to listen live."
    }
    Dialog(onDismissRequest = { Tips.dismiss(ctx, false) }) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(ThemeState.current.card)
                .border(2.dp, ThemeState.current.primary, shape)
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = rememberLogoTile(),
                    contentDescription = null,
                    modifier = Modifier.size(30.dp).clip(CircleShape)
                )
                Spacer(Modifier.width(10.dp))
                Text("Safehouse says…", color = ThemeState.current.primary, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("Tip $tip of ${Tips.COUNT}", color = ThemeState.current.textDim, fontSize = 13.sp)
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (tip) {
                    1 -> {
                        TipSkipIcon("back")
                        Spacer(Modifier.width(32.dp))
                        TipSkipIcon("forward")
                    }
                    2 -> Box(Modifier.size(52.dp).graphicsLayer { scaleX = 1.9f; scaleY = 1.9f }, contentAlignment = Alignment.Center) {
                        ActionIconView(ActionIcon.SLEEP, ThemeState.current.text)
                    }
                    else -> Box(Modifier.size(52.dp).graphicsLayer { scaleX = 1.9f; scaleY = 1.9f }, contentAlignment = Alignment.Center) {
                        ActionIconView(ActionIcon.SHARE, ThemeState.current.text)
                    }
                }
            }
            Text(
                title,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 14.dp)
            )
            Text(
                body,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 15.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CardChoice("Got it", Modifier.weight(1f)) { Tips.dismiss(ctx, false) }
                CardChoice("No more tips", Modifier.weight(1f)) { Tips.dismiss(ctx, true) }
            }
        }
    }
}

/** One of the two "10" circles in the first tip, with its word under it. */
@Composable
private fun TipSkipIcon(word: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(48.dp).border(2.dp, ThemeState.current.text, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text("10", color = ThemeState.current.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Text(word, color = Edge, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

/** One of the equal choices on the data card: an outlined pill, 48 dp tall. */
@Composable
internal fun CardChoice(label: String, modifier: Modifier, clickLabel: String? = null, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .heightIn(min = 48.dp)
            .clip(shape)
            .border(2.dp, ThemeState.current.primary, shape)
            .clickable(onClickLabel = clickLabel, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = ThemeState.current.text, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

/** "Delete my chat account": an email to the station, already written out, for the listener to send. */
private fun requestChatDeletion(ctx: Context) {
    val body = "Hello Safehouse Radio,\n\nPlease delete my chat account and the details linked to it.\n\n" +
        "My display name: \nThe email address I used: \n\nThank you"
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                .putExtra(Intent.EXTRA_EMAIL, arrayOf(Config.CONTACT_EMAIL))
                .putExtra(Intent.EXTRA_SUBJECT, "Delete my chat account")
                .putExtra(Intent.EXTRA_TEXT, body)
        )
    } catch (e: Exception) {
        // No email app on this phone: nothing to open. The Privacy page gives the address.
    }
}

/** A question in the same "Safehouse says…" look as the other messages. */
@Composable
private fun ConfirmDialog(question: String, detail: String, confirmLabel: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(ThemeState.current.card)
                .border(2.dp, ThemeState.current.primary, shape)
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = rememberLogoTile(),
                    contentDescription = null,
                    modifier = Modifier.size(30.dp).clip(CircleShape)
                )
                Spacer(Modifier.width(10.dp))
                Text("Safehouse says…", color = ThemeState.current.primary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                question,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 14.dp)
            )
            Text(
                detail,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 15.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 18.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .heightIn(min = 48.dp)
                        .clip(RoundedCornerShape(50))
                        .clickable(role = Role.Button, onClick = onDismiss)
                        .padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Not now", color = ThemeState.current.primary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(8.dp))
                BubbleButton(confirmLabel, onClick = onConfirm)
            }
        }
    }
}

/**
 * The theme picker: one small preview for each theme (its background, card colour, main colour and gold),
 * with the one in use outlined. Tapping one changes the whole app at once.
 */
@Composable
private fun ThemeRow(onChoose: (Palette) -> Unit) {
    val current = ThemeState.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("Theme", color = MaterialTheme.colorScheme.onBackground, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Choose how the app looks", color = Muted, fontSize = 13.sp)
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            for (p in Themes.all) {
                val on = p.id == current.id
                val shape = RoundedCornerShape(16.dp)
                Column(
                    Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                        .clip(shape)
                        .background(p.background)
                        .border(if (on) 3.dp else 1.dp, if (on) p.primary else p.edge.copy(alpha = 0.45f), shape)
                        .selectable(selected = on, role = Role.RadioButton, onClick = { onChoose(p) })
                        .semantics { contentDescription = if (on) "${p.name} theme, selected" else "${p.name} theme" }
                        .padding(10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(5.dp)).background(p.card))
                    Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(20.dp).clip(RoundedCornerShape(50)).background(p.primary))
                    Box(Modifier.padding(top = 6.dp).width(14.dp).height(14.dp).clip(RoundedCornerShape(50)).background(p.live))
                    Text(
                        p.name, color = p.text, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
    }
}
