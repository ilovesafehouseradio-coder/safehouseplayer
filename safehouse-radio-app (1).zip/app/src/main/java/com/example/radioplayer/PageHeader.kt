package com.example.radioplayer

import androidx.compose.foundation.background
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The dark, see-through background of the cards on top of the wallpaper (shows, DJs, search box).
 * Raise the CC (80% black) towards FF for more solid cards, lower it to let more wallpaper through.
 */
val CardSurface: Color get() = ThemeState.current.cardSurface

/** Dark text used on top of lavender (the same near-black as the On Air card). */
val LavenderInk: Color get() = ThemeState.current.onPrimary

/**
 * Side margin of the plain white writing that sits between a bar and the cards (the lines that introduce a page).
 * The cards and bars have a 16dp margin; this text is pulled in a little further so that, next to their rounded
 * ends, it looks lined up with them instead of poking out past them.
 */
val IntroSideMargin = 24.dp

/** Height of the lavender bar at the top of the Radio, Schedule and DJs pages: the same on all three. */
val BarHeight = 52.dp

/** Size of the writing in that bar. Shared with the On Air / Schedule tabs so they always match. */
val BarTextSize = 18.sp

/**
 * The title at the top of the Radio and DJs pages: a lavender bar with dark bold text. The
 * Schedule page uses a bar with exactly the same height, width, corners and text size for its
 * On Air / Schedule tabs (see ScheduleTabs), so all three pages start the same way.
 * [leading] / [trailing] are for something that sits inside the bar at the left / right-hand end
 * (the back arrow, the cast button); they float over the bar and never change its size.
 */
@Composable
fun PageHeader(
    title: String,
    horizontalPadding: Dp = 16.dp,
    leading: @Composable BoxScope.() -> Unit = {},
    trailing: @Composable BoxScope.() -> Unit = {}
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = horizontalPadding, end = horizontalPadding, top = 8.dp, bottom = 10.dp)   // top matches the Radio tab's Next pill, so every page's first pill starts on the same line
            .lift(RoundedCornerShape(50))
            .clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.primary)
            .heightIn(min = BarHeight),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = LavenderInk,
            fontSize = BarTextSize,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            // Screen readers announce this as a page heading.
            modifier = Modifier
                .padding(horizontal = 56.dp, vertical = 8.dp)
                .semantics { heading() }
        )
        Box(Modifier.matchParentSize()) {
            leading()
            trailing()
        }
    }
}

/**
 * The search box on the Schedule and DJs pages: 48dp tall (the smallest comfortable size to tap),
 * 16sp text, dark see-through fill with a thin border that turns lavender while typing.
 * It grows taller only if the phone's text size is turned up.
 */
@Composable
fun SearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    val primary = MaterialTheme.colorScheme.primary
    val textColor = MaterialTheme.colorScheme.onBackground
    val shape = RoundedCornerShape(14.dp)
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        textStyle = TextStyle(color = textColor, fontSize = 16.sp),
        cursorBrush = SolidColor(primary),
        modifier = modifier
            .fillMaxWidth()
            .onFocusChanged { focused = it.isFocused },
        decorationBox = { inner ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .lift(shape)
                    .clip(shape)
                    .background(CardSurface)
                    .border(if (focused) 2.dp else 1.dp, if (focused) primary else ThemeState.current.edge.copy(alpha = 0.4f), shape)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                // Leave room on the right for the magnifying glass.
                Box(Modifier.fillMaxWidth().padding(end = 36.dp), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) {
                        Text(text = placeholder, color = textColor.copy(alpha = 0.65f), fontSize = 16.sp, maxLines = 1)
                    }
                    inner()
                }
                Canvas(Modifier.size(22.dp).align(Alignment.CenterEnd)) {
                    val line = 2.dp.toPx()
                    val ring = ThemeState.current.edge
                    drawCircle(
                        color = ring,
                        radius = size.width * 0.32f,
                        center = Offset(size.width * 0.42f, size.height * 0.42f),
                        style = Stroke(width = line)
                    )
                    drawLine(
                        color = ring,
                        start = Offset(size.width * 0.66f, size.height * 0.66f),
                        end = Offset(size.width * 0.92f, size.height * 0.92f),
                        strokeWidth = line,
                        cap = StrokeCap.Round
                    )
                }
            }
        }
    )
}

/**
 * The top of every page except Chat: "Safehouse Radio" at the left (the same Poppins bold size as a DJ's
 * name on the Radio page) and the Chromecast button at the right, always on show and ready to use.
 */
@Composable
fun AppHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 28.dp, end = 12.dp, top = 8.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .weight(1f)
                .semantics { heading() }
        ) {
            ShadowText(Config.STATION_NAME, fontSize = 28, weight = FontWeight.Bold, alpha = 1f, maxLines = 1)
        }
        CastButton()
    }
}

/** A small capital-letter label on a coloured pill ("NOW PLAYING", gold "LIVE"). */
@Composable
fun StatusPill(text: String, fill: Color, ink: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(fill)
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            color = ink,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            maxLines = 1
        )
    }
}
